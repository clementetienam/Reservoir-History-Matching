function [sgb,sgporob]=selectindex(nx,ny,nz,rossmary,rossmaryporo,signal,reali,N)
%signal=mean permeability ensemble
% reali=dictionary
%N= ensemble size=sparsity level
% rossmary/rossmaryporo=true permeability and porosity field
%nx,ny,nz=size of reservoir in x,y and z direction
%omega=indices
sgb2=reali;
rossmary=reshape(rossmary,nx,ny,nz);
disp('get the indices most correlated with the signal')
[x,omega] = omp(sgb2,signal,N);
omega=sort(omega);
unieperm=sgb2(:,omega);
disp(' get the equivalent porosity field')
[sgb,sgporob]=generateporosity(unieperm,nx,ny,nz,N,rossmary,rossmaryporo);
end