function [sgb,sgporob]=generateporosity(ydami,nx,ny,nz,bigsize,rossmary,rossmaryporo);

ydami=reshape(ydami,nx*ny*nz,bigsize);

a=log10(rossmary);
aa=rossmary;
b=rossmaryporo;

disp(' Find values greater than 100')
indices=find(a>=2);
indices2=find(a<2);
kk=aa(indices); % permeability greater than 100mD
kk2=aa(indices2); %permeability less than 100mD
disp(' Find porosity values greater than 0.1805')
kkporo=b(indices); % permeability greater than 100
kkporo2=b(indices2);
disp( 'get polyfit equation for high permeability-high porosity');
p = polyfit(log10(kk),kkporo,8);
disp(' get the polyfit for low permeability-low porosity');
p22 = polyfit(log10(kk2),kkporo2,8);

requiredK=abs(ydami);
sgg=reshape(requiredK,nx*ny*nz,bigsize);
%gggg=reshape(ggg2,72000,100);
for kv=1:bigsize
    sgc=log10(sgg(:,kv));
    %ggc=gggg(:,kv);
for j=1:nz
    sgsub=reshape(sgc,nx*ny,nz);
    %ggsub=reshape(ggc,7200,10);
   dsa=sgsub(:,j); 
    if sgsub>=2
     outside=polyval(p,dsa); 
    else
      outside=polyval(p22,dsa);   
    end
 
outsidee(:,j)=reshape(outside,nx*ny,1);
end
outsidew(:,kv)=reshape(outsidee,nx*ny*nz,1);

end

outsidew(outsidew>=0.5)=0.5;
outsidew=reshape(outsidew,nx*ny*nz*bigsize,1);
for i=1:nx*ny*nz*bigsize
if outsidew(i)>=0.28
    outsidew(i)=outsidew(i).*0.7;
end
end  

yapporo=abs(outsidew);
yapporo(yapporo<=0.05)=0.05;
yapporo=reshape(yapporo,nx*ny*nz,bigsize);
yapperm=requiredK;
sgb=yapperm;

for i=1:bigsize
sgsimporouse=reshape(yapporo(:,i),nx,ny,nz);
sgsporo=sgsimporouse(:,:,1:nz);
exporo=reshape(sgsporo,nx*ny*nz,1);
sgporob(:,i)=exporo;
end
end