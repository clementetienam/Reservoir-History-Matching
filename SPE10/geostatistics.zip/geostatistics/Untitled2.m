clc;
clear;
load rossmary.GRDECL;
% true=reshape(rossmary,120,60,10);
% trueuse=true(:,:,3:7);
% trueaverage=(trueuse(:,:,1)+trueuse(:,:,2)+trueuse(:,:,3)+trueuse(:,:,4)+trueuse(:,:,5))./5;
% [X,Y] = meshgrid(1:120,1:60);
% figure()
% surf(X',Y',log10(trueaverage))
% shading flat
% axis([1 120 1 60 ])
% grid off
% title('True average','FontName','Helvetica', 'Fontsize', 13);
% ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
% xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
% colormap('jet')
% caxis([1 5])
% h = colorbar;
% set(h, 'ylim', [1 5])
% set(gca, 'FontName','Helvetica', 'Fontsize', 13)
% set(gcf,'color','white')
% 
% file2 = fopen('TI.out','w+'); %output the dictionary
% for k=1:numel(trueaverage)                                                                       
% fprintf(file2,' %4.6f \n',trueaverage(k) );             
% end
load rossmaryporo.GRDECL;
nx=120;
ny=60;
nz=5;
bigsize=1500;
load reali.out;
[sgb,sgporob]=generateporosity(reali,nx,ny,nz,bigsize,rossmary,rossmaryporo);
rossmary=reshape(rossmary,nx,ny,10);
signal=rossmary(:,:,3:7);
signal=reshape(signal,nx*ny*nz,1);
[x,omega] = omp(sgb,signal,100);
omega=sort(omega);
% rossmaryporo=reshape(rossmaryporo,nx,ny,10);
% signalp=rossmaryporo(:,:,3:7);
% signalp=reshape(signalp,nx*ny*nz,1);
% [xp,omegap] = omp(sgporob,signalp,100);
% omegap=sort(omegap);
% %[y,ddc] = AOmp(100,sgb,signal);
% [yfit,r,coef,iopt,qual] = wmpalg('OMP',signal,sgb,'itermax',100);
% nelly=pinv(sgb)*yfit;
unieperm=sgb(:,omega);
%unieperm22=sgb(:,ddc);
% unieperm3=sgb(:,iopt);
% 
% unieperm2=sgb(:,ddc);
% unieperm2=sgb(:,kk);