function [mumyperm,mumyporo]=main_EnKF_Levelset(iyobo,nx,ny,nz,N,tol,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,SEn83,PEn83);
disp( 'History matching data assimilation technique using EnKF for SPE10 Reservoir'  ) 
disp( 'This code is longer and computationaly expensive')
disp( 'PhD Student: Clement Etienam' )
disp( 'Supervisor: Dr Rossmary Villegas' )
disp( 'Co-supervisor: Dr Masoud Babei' )


sgsim=reshape(perm,72000,N);
sgsimporo=reshape(poro,72000,N);
for i=1:N
sgsimuse=reshape(sgsim(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,36000,1);
sg(:,i)=ex;
end

for i=1:N
sgsimporouse=reshape(sgsimporo(:,i),120,60,10);
sgsporo=sgsimporouse(:,:,3:7);
exporo=reshape(sgsporo,36000,1);
sgporo(:,i)=ex;
end

Sim11=reshape(overallsim,17,history,N);

sgout=zeros(3600000,1);
sgoutporo=zeros(3600000,1);

 for ii=1:3600000
    if(sg(ii)>=100)
        sgout(ii)=1;
    end
end

 for ii=1:3600000
    if(sgporo(ii)>=0.1805)
        sgoutporo(ii)=1;
    end
end

disp (' get the signed distance of permeability and porosity fields')
clement=getsigned(sgout,nx,ny);
clementporo=getsigned(sgoutporo,nx,ny);

disp( 'get the narrowband function of permeability and porosity fields')
 nbandall=regionband(sgout,N,nx,ny,nz);
 nbandallporo=regionband(sgoutporo,N,nx,ny,nz);
%for i=1:131
disp(' assimilate sequentialy for EnKF')


 
 Sim1=Sim11(:,iyobo,:);
Sim1=reshape(Sim1,17,N);

f=observation(:,iyobo);
[sgsim2,DupdateK] = EnKF_Levelset (sg,sgporo, f, N, Sim1,scheme,tol,beta,clement,clementporo,nbandall,nbandallporo,SEn83,PEn83);

%condition the data
[output,outputporo] = honour2(rossmary, rossmaryporo, N,sgsim2,DupdateK);

sg=reshape(output,36000,N);
sgporo=reshape(outputporo,36000,N);

disp('  output to ASCII files  ');
sgassimi=sg; 
sgporoassimi=sgporo;

permanswers=reshape(sgassimi,36000,N);
poroanswers=reshape(sgporoassimi,36000,N);

for i=1:N
sgsim=zeros(120,60,10);
sgsimporo=zeros(120,60,10);
sgsim(:,:,3:7)=reshape(permanswers(:,i),120,60,5);
sgsimporo(:,:,3:7)=reshape(poroanswers(:,i),120,60,5);

sgsimmijana(:,i)=reshape(sgsim,72000,1);
sgsimporomijana(:,i)=reshape(sgsimporo,72000,1);
end
mumyperm=sgsimmijana;
mumyporo=sgsimporomijana;

 
%end
 %plot the mean and variance for each timestep
 %run('plot3D.m')
end
 