function [mumyperm,mumyporo]=main_EnKF(iyobo,N,tol,scheme,beta,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,SEn83,PEn83);
disp( 'History matching data assimilation technique using EnKF for SPE10 Reservoir'  ) 
disp( 'This code is longer and computationaly expensive')
disp( 'PhD Student: Clement Etienam' )
disp( 'Supervisor: Dr Rossmary Villegas' )
disp( 'Co-supervisor: Dr Masoud Babei' )


sgsim=reshape(perm,72000,N);
sgsimporo=reshape(poro,72000,N);
for i=1:N
sgsimuse=reshape(sgsim(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,36000,1);
sg(:,i)=ex;
end

for i=1:N
sgsimporouse=reshape(sgsimporo(:,i),120,60,10);
sgsporo=sgsimporouse(:,:,3:7);
exporo=reshape(sgsporo,36000,1);
sgporo(:,i)=exporo;
end

Sim11=reshape(overallsim,17,history,N);



%for i=1:131
disp(' assimilate sequentialy for EnKF')


 
 Sim1=Sim11(:,iyobo,:);
Sim1=reshape(Sim1,17,N);

f=observation(:,iyobo);
[sgsim2,DupdateK] = EnKF_Assimilate (sg,sgporo, f, N, Sim1,scheme,tol,beta,SEn83,PEn83);

%condition the data
[output,outputporo] = honour2(rossmary, rossmaryporo, N,sgsim2,DupdateK);

sg=reshape(output,36000,N);
sgporo=reshape(outputporo,36000,N);

disp('  output to ASCII files  ');
sgassimi=sg; 
sgporoassimi=sgporo;

permanswers=reshape(sgassimi,36000,N);
poroanswers=reshape(sgporoassimi,36000,N);

for i=1:N
sgsim=zeros(120,60,10);
sgsimporo=zeros(120,60,10);
sgsim(:,:,3:7)=reshape(permanswers(:,i),120,60,5);
sgsimporo(:,:,3:7)=reshape(poroanswers(:,i),120,60,5);

sgsimmijana(:,i)=reshape(sgsim,72000,1);
sgsimporomijana(:,i)=reshape(sgsimporo,72000,1);
end
mumyperm=sgsimmijana;
mumyporo=sgsimporomijana;

 
%end
 %plot the mean and variance for each timestep
 %run('plot3D.m')
end
 