function Ynew = anotherjoy (Y,Dj, N, Sim1,tol,Error1)
%standard EnKF



H=zeros(17,144017);
H(1:17,144001:144017)=eye(17);


M = mean(Sim1,2);
% Mean of the ensemble state
M2=mean(Y,2);
%M=M'
% Get the ensemble states pertubations
for j=1:N
    S(:,j)=Sim1(:,j)-M;
end
for j=1:N
    yprime(:,j)=Y(:,j)-M2;
end
unie=H*yprime;
Sim=H*Y;
unie2=unie+Error1;
[U0,Z0,V0] = svd(unie2,'econ');
joy2=Z0*Z0';

[Usig,Sig,Vsig] = svd(joy2);
xsmall = diag(Sig);
Bsig = cumsum(xsmall);
valuesig=Bsig(end);
valuesig=valuesig*0.9999;
indices = find(cumsum(xsmall) >= valuesig );
toluse=xsmall(indices,:);
tol=toluse(1,:);


X1=pinv(joy2)*U0';
% Residual vector
X2=X1*(Dj-Sim);

X3=U0*X2;

X4=unie'*X3;
%Update the ensemble state
disp('  update the new ensemble  ');
Ynew=Y+(yprime*X4);

 end