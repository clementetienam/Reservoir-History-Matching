function[output,outputporo] = honour2(rossmary, rossmaryporo, N,sgsim2,DupdateK);
disp('  Load the relevant files  ');
% honour the well permeability and porosity values

disp('  read true permeability field ');
% read true permeability well value
unie=reshape(rossmary,120,60,10);
unieporo=reshape(rossmaryporo,120,60,10);
% read true porosity well values

for j=3:7;
    aa(j)=unie(14,25,j);
    bb(j)=unie(38,39,j);
   cc(j)=unie(96,23,j);
    dd(j)=unie(67,41,j);
    ee(j)=unie(30,55,j);
    ff(j)=unie(58,18,j);
    gg(j)=unie(90,6,j);
    hh(j)=unie(101,39,j);
end

for j=3:7;
    aa1(j)=unieporo(14,25,j);
    bb1(j)=unieporo(38,39,j);
   cc1(j)=unieporo(96,23,j);
    dd1(j)=unieporo(67,41,j);
    ee1(j)=unieporo(30,55,j);
    ff1(j)=unieporo(58,18,j);
    gg1(j)=unieporo(90,6,j);
    hh1(j)=unieporo(101,39,j);
end


% read permeability ensemble after EnKF update
A=reshape(DupdateK,36000,N);
C=reshape(sgsim2,36000,N);
disp('  start the conditioning  ');

% start the conditioning for permeability
for i=1:N;
    %B=reshape(A(:,i),120,60,10);
    B = reshape(A(:,i),120,60,5); 
    %clement=B(i);
    for j=1:5;
    B(14,25,j)=aa(j);
    B(38,39,j)=bb(j);
   B(96,23,j)=cc(j);
    B(67,41,j)=dd(j);
    B(30,55,j)=ee(j);
    B(58,18,j)=ff(j);
    B(90,6,j)=gg(j);
    B(101,39,j)=hh(j);
    
    end
    output(:,i)=reshape(B,36000,1); 
	
    %Aa=reshape(B(i),72000,1);
end

for i=1:N;
    %B=reshape(A(:,i),120,60,10);
    D = reshape(C(:,i),120,60,5); 
    %clement=B(i);
    for j=1:5;
    D(14,25,j)=aa1(j);
    D(38,39,j)=bb1(j);
   D(96,23,j)=cc1(j);
    D(67,41,j)=dd1(j);
    D(30,55,j)=ee1(j);
    D(58,18,j)=ff1(j);
    D(90,6,j)=gg1(j);
    D(101,39,j)=hh1(j);
    
    end
    outputporo(:,i)=reshape(D,36000,1); 
    %Aa=reshape(B(i),72000,1);
end% 

output(output>=20000)=20000;
output(output<=50)=50;

outputporo(outputporo>=0.5)=0.5;
outputporo(outputporo<=0.15)=0.15;
end