function [mumyperm,mumyporo]=main_dynamicsparsity(nx,ny,nz,N,tol,observation,overallsim,rossmary,rossmaryporo,perm,history,alpha,reali)
disp( 'History matching data assimilation technique using ES-MDA/Dynamic sparsity for SPE10 Reservoir'  ) 
disp( 'PhD Student: Clement Etienam' )
disp( 'Supervisor: Dr Rossmary Villegas' )
disp( 'Co-supervisor: Dr Masoud Babei' )
disp( 'Co-supervisor: Dr Oliver Dorn' )
disp('  import the true data  ');
% N - size of ensemble

sgsim=reshape(perm,nx*ny*nz*2,N);

for i=1:N
sgsimuse=reshape(sgsim(:,i),nx,ny,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,nx*ny*nz,1);
sg(:,i)=ex;
end

Sim11=reshape(overallsim,17,history,N);

%History matching using ESMDA
for i=1:history
 fprintf('Now assimilating timestep %d .\n', i);
 
Sim1=Sim11(:,i,:);
Sim1=reshape(Sim1,17,N);

f=observation(:,i);
[DupdateK] = ESMDA_dynamic (sg, f, N, Sim1,alpha,tol);

sg=reshape(DupdateK,nx*ny*nz,N);

 fprintf('Finished assimilating timestep %d \n', i);
end
sgmean=mean(sg,2);
[sgb,sgporob]=selectindex(nx,ny,nz,rossmary,rossmaryporo,sgmean,reali,N);

[output,outputporo] = honour2(rossmary, rossmaryporo, N,sgporob,sgb);
sgassimi=output; 
sgporoassimi=outputporo;

permanswers=reshape(sgassimi,nx*ny*nz,N);
poroanswers=reshape(sgporoassimi,nx*ny*nz,N);

for i=1:N
sgsim=zeros(nx,ny,10);
sgsimporo=zeros(nx,ny,10);
sgsim(:,:,3:7)=reshape(permanswers(:,i),nx,ny,nz);
sgsimporo(:,:,3:7)=reshape(poroanswers(:,i),nx,ny,nz);

sgsimmijana(:,i)=reshape(sgsim,72000,1);
sgsimporomijana(:,i)=reshape(sgsimporo,72000,1);
end

mumyperm=sgsimmijana;
mumyporo=sgsimporomijana;

 disp('  program executed  ');
end
 