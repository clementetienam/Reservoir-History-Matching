clc;
clear;
close all;
Data=[5 6 9 1 5 2]
[sd,r]=sort(Data,'ascend')
sd % sorted data
r % the corresponding indices
%yap=zeros(1,6);
yap=Data(:,r(1:2));