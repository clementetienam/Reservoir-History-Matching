load conductivity.out

mat=reshape(conductivity,84,27,4);
% numDim=3;
% % new_size=[84,27,4];
% % mat_rs = resize(mat,new_size)
% 
% im=mat; %%% input image
% ny=60;nx=120;nz=10; %% desired output dimensions
% [x y z]=...
%    ndgrid(linspace(1,size(im,1),nx),...
%           linspace(1,size(im,2),ny),...
%           linspace(1,size(im,3),nz));
% imOut=interp3(im,x,y,z);
% imOut=reshape(imOut,120,60,10);
% file = fopen('Yes21.out','w+'); 
% for k=1:numel(imOut)                                                                       
% fprintf(file,' %4.4f \n',imOut(k) );             
%end
mat_rs = resize(mat,[28,9,42])
file = fopen('conductivity28942.out','w+'); 
for k=1:numel(mat_rs)                                                                       
fprintf(file,' %4.4f \n',mat_rs(k) );             
end