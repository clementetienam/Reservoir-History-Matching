clc;
clear all;
close all;
% if isdir('networks')==0
%     mkdir('networks');
% end
%load rossmary.GRDECL;
load sgsim.out;

sgsim=reshape(sgsim,72000,100);
load sgsimenkf.out;
% autoenc = trainAutoencoder(sgsim,'L2WeightRegularization',0.05,'MaxEpochs',1200);
% XReconstructed = predict(sgsim);
N=100;
sgout=zeros(7200000,1);


 for ii=1:7200000
    if(sgsim(ii)>=100)
        sgout(ii)=1;
    end
end
trainFcn = 'trainlm';  %use the Levenberg-Marquardt algorithm
targets=reshape(sgout,72000*N,1);

%Train the networks
clement=reshape(targets,72000,N);
for j=1:20
    hiddenLayerSize = 100; %number of hidden layer neurons
    net = fitnet(hiddenLayerSize,trainFcn); %create a fitting network
     net.divideParam.trainRatio = 70/100;  %use 70% of data for training 
    net.divideParam.valRatio = 15/100;  %15% for validation
    net.divideParam.testRatio = 15/100; %15% for testing
    [net,tr] = train(net,sgsim(:,j)',sgsim(:,j)'); % train the network
    outputs = net(sgsim(:,j)'); %simulate data
    %outputs=reshape(outputs,72000,N);
  
     outputall(:,j)=outputs;
    save(['net' num2str(j)],'net'); 
end
disp('get the weights of the neural netowork')
[iwall,bwall,Lwall]=getallweights(20);
 iwall=iwall+20.7;
% bwall=bwall.*0.6;
 %Lwall=Lwall.*0.53;
 disp('predict the new permeability with updated weights from ES-MDA')
pwall=putbackweights(iwall,bwall,Lwall,N,sgsim);
pwall(pwall<=5)=5;
pwall(pwall>20000)=20000;
pwall=abs(pwall);
% sgsim=reshape(rossmary,72000,1);
% sgsimenkf=reshape(sgsimenkf,72000,N);
% 
% %net = newrb(reshape(sgsim,72000,N),reshape(sgout,72000,N));
% Mdl = fitcensemble(reshape(sgsim,72000,1),reshape(sgout,72000,1),'CrossVal','on','LearningRate',0.05);
% 
% %disp('fit with SVM')
% % Mdl1 = fitrsvm(reshape(sgsim,7200000,1),reshape(sgout,7200000,1));
%  disp('fit with Bayes')
% Mdl2 = fitcnb(reshape(sgsim,72000,1),reshape(sgout,72000,1));
% disp(' fit with kmeans clustering')
% Mdl3 = fitcknn(reshape(sgsim,72000,1),reshape(sgout,72000,1),'NumNeighbors',3,...
%     'NSMethod','exhaustive','Distance','minkowski',...
%     'Standardize',1);
% Ypredicted = predict(Mdl3,reshape(sgsimenkf,7200000,1));
% Ypredicted =reshape(pwall,72000*20,1);
% sgsim11=reshape(sgsimenkf,7200000,1);
% Y = sim(net,sgsimenkf);
% Y(Y<=0)=0;
% Y(Y>0)=1;
% Y=reshape(Y,7200000,1);

updatedperm=zeros(72000*N,1);
for ii=1:72000*20
    if(sgsim11(ii)>=100)
        updatedperm(ii)=1;
    end
	
	
end


requiredK=zeros(72000*20,1);


for iii=1:72000*20

  if (updatedperm(iii)==Ypredicted(iii)) 
    requiredK(iii)=sgsim11(iii);
  end 
  
 
   
  if ((updatedperm(iii) ~= Ypredicted(iii)) && (Ypredicted(iii)==0)) 

        
        requiredK(iii)=95;
  end
   if ((updatedperm(iii)~= Ypredicted(iii)) && (Ypredicted(iii)==1)) 

      
         requiredK(iii)=105;
    end 
 
   
  
end
requiredK=abs(requiredK);

% for i=1:N
% sgsimuse=reshape(sgsim(:,i),120,60,10);
% sgs=sgsimuse(:,:,3:7);
% ex=reshape(sgs,36000,1);
% sg(:,i)=ex;
% end
% for j=1:5
% y(:,:,j) = datasample(sgsim,100,2,'Replace',false);
% end
% a=y(:,:,1);
% b=y(:,:,2);
% c=y(:,:,3);
% d=y(:,:,4);
% e=y(:,:,5);
%y2 = datasample(sgsim,100,2,'Replace',false);

% for i=1:N
%     I=mat2gray(reshape(sgsimenkf(:,i),120,60,10));
%     ref=mat2gray(reshape(sgsim(:,i),120,60,10));
%     for j=1:10
%     J = imhistmatch(I(:,:,j),ref(:,:,j));
%     jj(:,j)=reshape(J,7200,1);
%     end
%     allj(:,i)=reshape(jj,72000,1);
% end
% allj(allj>0)=1000;
% allj(allj==0)=50;
disp('1=yes')
disp('2=no' )
response=input('Do you want to plot the permeability map ');

disp( 'Well locaions consisting of injector and producer well')
iInj = [30, 58, 90, 101]; % 16 wells configuration, injection wells
jInj = [55, 18, 6, 39]; % 16 wells configuration, injection wells
iProd = [14, 38, 96, 67]; % 16 wells configuration, production wells
jProd = [25, 39, 23, 41]; % 16 wells configuration, production wells
CMRmap=[0 0 0;.3 .15 .75;.6 .2 .50;1 .25 .15;.9 .5 0;.9 .9 .5;1 1 1];

if response==1
    disp( 'Pixel map needed')
    [bestnorm3,PlogK]=clementPlot(requiredK,rossmary,20,2,CMRmap);
    xr=reshape(PlogK,120*60,5);
    
plottinglocations(xr, 120, 60,5, 'Layer', iInj, jInj, iProd, jProd, min(xr), max(xr),CMRmap);
disp(' green are injector wells and blue are producers')
     %run('clementPlot.m')
else
    disp (' pixel map not needed')
end
