clc;
clear;
load rossmaryporo.GRDECL;
true=reshape(rossmaryporo,120,60,10);
trueK=true(:,:,3:7);
a=trueK;
b=trueK;
a(a>=0.1805)=[]; %low perm
b(b<0.1805)=[]; %high perm
amean=mean(a);
bmean=mean(b);