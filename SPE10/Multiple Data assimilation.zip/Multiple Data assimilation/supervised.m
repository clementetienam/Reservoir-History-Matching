function [sgsim2,DupdateK]=supervised(Mdlperm,Mdlporo,DupdateK,sgsim2,nx,ny,nz,N);
% We predict the labels from our trained model
Ypredicted = predict(Mdlperm,reshape(DupdateK,nx*ny*nz*N,1));
Yporopredicted = predict(Mdlporo,reshape(sgsim2,nx*ny*nz*N,1));
sgsim11=reshape(DupdateK,nx*ny*nz*N,1);
sgporo=reshape(sgsim2,nx*ny*nz*N,1);
updatedperm=zeros(nx*ny*nz*N,1);
updatedporo=zeros(nx*ny*nz*N,1);
for ii=1:nx*ny*nz*N
    if(sgsim11(ii)>=100)
        updatedperm(ii)=1;
    end
	
    if(sgporo(ii)>=0.1805)
        updatedporo(ii)=1;
    end

	
end


requiredK=zeros(nx*ny*nz*N,1);
requiredporo=zeros(nx*ny*nz*N,1);

for iii=1:nx*ny*nz*N

  if (updatedperm(iii)==Ypredicted(iii)) 
    requiredK(iii)=sgsim11(iii);
  end 
  if (updatedporo(iii)==Yporopredicted(iii)) 
    requiredporo(iii)=sgsimporo(iii);
  end
 
   
  if ((updatedperm(iii) ~= Ypredicted(iii)) && (Ypredicted(iii)==0)) 

        
        requiredK(iii)=95;
  end
   if ((updatedperm(iii)~= Ypredicted(iii)) && (Ypredicted(iii)==1)) 

      
         requiredK(iii)=105;
   end 
 
    if ((updatedporo(iii) ~=Yporopredicted(iii)) && (Yporopredicted(iii)==0)) 

        
        requiredporo(iii)=0.1795 ;
  end
   if ((updatedporo(iii)~= Yporopredicted(iii)) && (Yporopredicted(iii)==1)) 

      
         requiredporo(iii)=0.1895;
    end 
    
  
end
DupdateK=abs(requiredK);
sgsim2=abs(requiredporo);

end