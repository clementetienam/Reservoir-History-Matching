% Neural Network Training Program 
% Developed by Daniel Okoh
% Space Environment Research Laboratory, CAR-NASRDA

%----------------------------------------------------
%The program trains several neural networks (that vary in their number of hidden layer neurons) and enables users to pick the best. 
%The program trains the networks using input and target data contained in files named
%Inputs1.txt and Targets1.txt respectively.

%The program randomly splits the supplied data into 3 portions: 
%70% for training, 15% for validation, and 15% for testing
%The user has the option to change this proportioning in lines 68 to 70
%The user also has the option to use his/her own test data:
%These should be saved in same format as Inputs2.txt and Targets2.txt

%When the program runs, it trains 100 different networks:
%The networks differ in their number of hidden layer neurons
%The networks generated are saved in in a folder named:
%networks, within the same folder where this program is run:
%The network saved as net1 has 1 hidden layer neuron,
%net2 has 2, net3 has 3, net4 has 4,....
%Users may change the values 1:100 in line 65 to their desired values

%Training is done using the Levenberg-Marquardt algorithm, trainlm 
%Users may change to their desired algorithm by changing line 62

%The program also computes and saves root-mean-squared-errors (RMSEs)
%in a file named rmse.txt
%Data in the file is in 3 columns: 
%column 1 for the number of hidden layer neurons, 
%column 2 for the RMSE computed on the random 15% test data, and
%column 3 for the RMSE computed on the user's own test data

%The data on this file guides the user to decide which of the 
%networks is best. Networks with smaller RMSEs are better, especially
%for the RMSEs computed on the user's own test data which is 
%outside the range of data used for the training. 
%More detailed guide on how to use the RMSEs to choose an optimal 
%network is contained in a book authored by the writter of this program
%and titled "Computer Neural Networks on MATLAB"
%-----------------------------------------------------



%Clear old stuff and create folder named networks if it doesn't 
%already  exist
clear all; fclose all; clc;
if isdir('networks')==0
    mkdir('networks');
end

%Import data
inputs=dlmread('Inputs1.txt', '\t', 1, 0);  %input data
targets=dlmread('Targets1.txt', '\t', 1, 0);  %target data
inputs2016=dlmread('Inputs2.txt', '\t', 1, 0);  %year 2016 inputs
targets2016=dlmread('Targets2.txt', '\t', 1, 0);  %year 2016 targets
inputs = inputs';   %transpose the data
targets = targets';
inputs2016 = inputs2016'; 
targets2016 = targets2016';

trainFcn = 'trainlm';  %use the Levenberg-Marquardt algorithm

%Train the networks
for i=1:100  %vary number of hidden layer neurons from 1 to 100
    hiddenLayerSize = i; %number of hidden layer neurons
    net = fitnet(hiddenLayerSize,trainFcn); %create a fitting network
    net.divideParam.trainRatio = 70/100;  %use 70% of data for training 
    net.divideParam.valRatio = 15/100;  %15% for validation
    net.divideParam.testRatio = 15/100; %15% for testing
    [net,tr] = train(net,inputs,targets); % train the network
    outputs = net(inputs(:,tr.testInd)); %simulate 15% test data
    outputs2016 = net(inputs2016); %simulate year 2016 data 
    rmse15(i)=sqrt(mean((outputs-targets(tr.testInd)).^2)); %RMSE for 15% random test data
    rmse2016(i) = sqrt(mean((outputs2016-targets2016).^2)); %RMSE for year 2016 test data
    r15(i)=regression(targets(tr.testInd), outputs);
    r2016(i)=regression(targets2016, outputs2016); 
    save(['networks\net' num2str(i)],'net');  %save the network in networks folder
end

%Plot the RMSEs
plot(1:100, rmse15, 'b*-'); hold on; plot(1:100, rmse2016, 'ro-');
legend('Random', 'Year 2016'); xlabel('Number of hidden layer neurons');
ylabel('RMSE (^oC)'); 

%Save the RMSEs
fid=fopen('rmse.txt', 'wt');
fprintf(fid, 'Nh\t RMSE15\t RMSE2016\n');
fprintf(fid, '%4.0f\t %f\t %f\n', [1:100; rmse15; rmse2016]);
fclose all;