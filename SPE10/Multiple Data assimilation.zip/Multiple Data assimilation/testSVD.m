clc;
clear all;
close all;
load sgsim.out;
A=reshape(sgsim,72000,100);
Anew=A(14401:50400,:);
[U,S,V] = svd(Anew,'econ');
UU=2.*U;

    % Construct an Image using the selected singular values
    D=U*S*V';
     D2=UU*S*V';

    DD=Anew-D;
    DD2=Anew-D2;
    
    value=DD-DD2;