%%This code is to obtain all the simulated data at once for each time step for the ensemble methods


clc;
clear;
clearvars;
close all;

disp( 'PhD student: Clement Oku Etienam' )

disp( 'Supervisor: Dr Rossmary Viellegas') 
disp( 'Co-supervisor: Dr Masoud Babei' )
disp('Advisor: Dr Oliver Dorn')
disp(   'This code is to obtain all the simulated data at once for each time step for the ensemble methods'   )

% N - size of ensemble

N=100;


oldfolder=cd;
cd(oldfolder) % setting original directory


cd(oldfolder) % setting original directory


overall=zeros(17,36,N);
    for ii=1:N %list of folders 
    
      f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',ii));
    cd(folder)   
    
  True= importdata('MASTER0.RSM',' ',7);
  A2 = importdata('MASTER0.RSM',' ',50);
  A3 = importdata('MASTER0.RSM',' ',93);
  A4 = importdata('MASTER0.RSM',' ',136);
 
 
 
 True=True.data;
 A2=A2.data;
 A3=A3.data;
 A4=A4.data;
 
 
 TO1=True(:,3);
 TO2=True(:,4);
 TO3=True(:,5);
 TO4=True(:,6);

     
     WWCT1=A2(:,2);
     WWCT2=A2(:,3);
     WWCT3=A2(:,4);
     WWCT4=A2(:,5);
     
     BHP1=A3(:,5);
     BHP2=A3(:,6);
     BHP3=A3(:,7);
     BHP4=A3(:,8);
	 
	 GORP1=A3(:,9);
     GORP2=A3(:,10);
     GORP3=A4(:,2);
     GORP4=A4(:,3);
	 
	 
	FOE=A4(:,8);

 for i=1:36
 obs=zeros(17,1);
 obs(1,:)=TO1(i,:);
 obs(2,:)=TO2(i,:);
 obs(3,:)=TO3(i,:);
 obs(4,:)=TO4(i,:);
 obs(5,:)=WWCT1(i,:);
 obs(6,:)=WWCT2(i,:);
 obs(7,:)=WWCT3(i,:);
 obs(8,:)=WWCT4(i,:);
 obs(9,:)=BHP1(i,:);
 obs(10,:)=BHP2(i,:);
 obs(11,:)=BHP3(i,:);
 obs(12,:)=BHP4(i,:);
 obs(13,:)=GORP1(i,:);
 obs(14,:)=GORP2(i,:);
 obs(15,:)=GORP3(i,:);
 obs(16,:)=GORP4(i,:);
 obs(17,:)=FOE(i,:);
 
 observation(:,i)=obs;
 end
        
   overall(:,:,ii)=observation; 
    cd(oldfolder) % returning to original directory

    end




cd(oldfolder) % returning to original directory

disp( 'store the simulated data')

file = fopen('Simulateddata.out','w+'); 
 for k=1:numel(overall)                                                                       
 fprintf(file,' %4.7f \n',overall(k) );             
 end


disp( 'programme executed')