function [mumyperm,mumyporo]=clean(nx,ny,nz,N,mumyperm,mumyporo,rossmary,rossmaryporo);
disp( 'smooth the permeability and porosity fields if required'  ) 
disp( 'PhD Student: Clement Etienam' )
disp( 'Supervisor: Dr Rossmary Villegas' )
disp( 'Co-supervisor: Dr Masoud Babei' )
disp( 'Co-supervisor: Dr Oliver Dorn' )

disp(' extract the active grid cells' )
sgsim=reshape(mumyperm,72000,N);
sgsimporo=reshape(mumyporo,72000,N);
for i=1:N
sgsimuse=reshape(sgsim(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,36000,1);
sg(:,i)=ex;
end

for i=1:N
sgsimporouse=reshape(sgsimporo(:,i),120,60,10);
sgsporo=sgsimporouse(:,:,3:7);
exporo=reshape(sgsporo,36000,1);
sgporo(:,i)=exporo;
end




sgout=zeros(3600000,1);
sgoutporo=zeros(3600000,1);

 for ii=1:3600000
    if(sg(ii)>=100)
        sgout(ii)=1;
    end
end

 for ii=1:3600000
    if(sgporo(ii)>=0.1805)
        sgoutporo(ii)=1;
    end
end

nfacies_en1=sgout;
sdf=zeros(120,60);
sgn(120,60)=1;
 sdf_dt=zeros(120,60,5);
LF=reshape(nfacies_en1,36000,N);
for ii=1:N;
    lf=reshape(LF(:,ii),120,60,5);
   for j=1:5;
     sdf=lf(:,:,j);
%      unie=lf(:,:,j);
%   unie(unie==1)=1;
%   unie(unie==0)=-1;
%   if  lf == 1;
%       sgn= 1;
%   end
 
  usdf = bwmorph(sdf,'clean',Inf);
  %usdf = bwmorph(usdf,'bridge',1);
  %usdf = bwmorph(usdf,'fill',Inf);
  usdf = bwmorph(usdf,'majority',1);
  %usdf = imclearborder(usdf);
  usdf=reshape(usdf,7200,1);
  young(:,j)=usdf;
   
   end
   sdfbig=reshape(young,36000,1);
  clementLL(:,ii)=sdfbig;
end

nfacies_en1=sgoutporo;
sdf=zeros(120,60);
sgn(120,60)=1;
 sdf_dt=zeros(120,60,5);
LF=reshape(nfacies_en1,36000,100);
for ii=1:N;
    lf=reshape(LF(:,ii),120,60,5);
   for j=1:5;
     sdf=lf(:,:,j);
%      unie=lf(:,:,j);
%   unie(unie==1)=1;
%   unie(unie==0)=-1;
%   if  lf == 1;
%       sgn= 1;
%   end
 
  usdf = bwmorph(sdf,'clean',Inf);
  %usdf = bwmorph(usdf,'bridge',1);
  %usdf = bwmorph(usdf,'fill',Inf);
  usdf = bwmorph(usdf,'majority',1);
  %usdf = imclearborder(usdf);
  usdf=reshape(usdf,7200,1);
  young(:,j)=usdf;
   
   end
   sdfbig=reshape(young,36000,1);
  clementporoLL(:,ii)=sdfbig;
end


requiredK=zeros(36000*N,1);
requiredporo=zeros(36000*N,1);

for iii=1:36000*N

  if (sgout(iii)==clementLL(iii)) 
    requiredK(iii)=sg(iii);
  end 
  
  if (sgoutporo(iii)==clementporoLL(iii)) 
    requiredporo(iii)=sgporo(iii);
  end 
  
  
  if ((sgout(iii) ~= clementLL(iii)) && (clementLL(iii)==0)) 

        
        requiredK(iii)=95;
  end
   if ((sgout(iii)~= clementLL(iii)) && (clementLL(iii)==1)) 

      
         requiredK(iii)=105;
    end 
 
  
  
  if ((sgoutporo(iii) ~= clementporoLL(iii)) && (clementporoLL(iii)==0)) 

        
        requiredporo(iii)=0.1795 ;
  end
   if ((sgoutporo(iii)~= clementporoLL(iii)) && (clementporoLL(iii)==1)) 

      
         requiredporo(iii)=0.1895;
    end 
  
  
end
requiredK=abs(requiredK);
requiredporo=abs(requiredporo);

disp( 'condition the field and honour')
[output,outputporo] = honour2(rossmary, rossmaryporo, N,requiredporo,requiredK);
permsteps=reshape(output,36000*N,1); 
porosteps=reshape(outputporo,36000*N,1);


sgassimi=permsteps; 
sgporoassimi=porosteps;

permanswers=reshape(sgassimi,36000,N);
poroanswers=reshape(sgporoassimi,36000,N);

for i=1:N
sgsim=zeros(120,60,10);
sgsimporo=zeros(120,60,10);
sgsim(:,:,3:7)=reshape(permanswers(:,i),120,60,5);
sgsimporo(:,:,3:7)=reshape(poroanswers(:,i),120,60,5);

sgsimmijana(:,i)=reshape(sgsim,72000,1);
sgsimporomijana(:,i)=reshape(sgsimporo,72000,1);
end

mumyperm=sgsimmijana;
mumyporo=sgsimporomijana;

end
 %plot the mean and variance for each timestep
 %run('plot3D.m')