function [sgsim2,DupdateK,updatedlevelset,updatedlevelsetporo,clement,clementporo] = supervised_Levelset_Cov(sg,sgporo,f, N,Sim1,clement,clementporo,nbandall,nbandallporo,alpha,c);

%
% PARAMETERS:
%   f           -   True data
%   sg           -  ensemble of permeability realizations
%   sgporo      -  ensemble of permeability realizations
%   N           -   ensemble size
%   Sim1        -   Simulated measurments
%   Clement     -  ensemble of permeability realizations signed distance
%   N           -  ensemble size
%   c           -  correlation length (scaled by a factor of 10)
%   nbandall,nbandporo          -  ensemble of narrow band matrix of permeability and porosity signed distance realizations
%   alpha           -  damping coefficient

%-----------------------------------------------------------------------------
A=zeros(120,60,5);
for j=1:5
    A(14,25,j)=1;
    A(38,39,j)=1;
    A(96,23,j)=1;
    A(67,41,j)=1;
    A(30,55,j)=1;
    A(58,18,j)=1;
    A(90,6,j)=1;
   
    A(101,39,j)=1;
    
    
    
end
disp( 'calculate the euclidean distance function to the 8 producer wells')
    lf=reshape(A,120,60,5);
   for j=1:5;
     sdf=lf(:,:,j);
  [usdf,IDX] = bwdist(sdf);
  usdf=reshape(usdf,7200,1);
  young(:,j)=usdf;
   
   end
   sdfbig=reshape(young,36000,1);
   sdfbig1=abs(sdfbig);
   z=sdfbig1;
   % the value of the range should be computed accurately.
   %c=range(z);
  
  
   c0OIL1=zeros(36000,1);
   disp( 'compute the gaspari-cohn coefficent')
  for i=1:36000;
 if (0<=z(i,:) || z(i,:)<=c)
  c0OIL1(i,:)=-0.25*(z(i,:)/c)^5+0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3-(5.0/3.0)*(z(i,:)/c)^2+1;
elseif z < 2*c
  c0OIL1(i,:)=(1.0/12.0)*(z(i,:)/c)^5-0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3+(5.0/3.0)*(z(i,:)/c)^2-5*(z(i,:)/c)+4-(2.0/3.0)*(c/z(i,:));
 elseif (c<=z(i,:) || z(i,:)<=2*c)
     c0OIL1(i,:)=-5*(z(i,:)/c)+4-0.667*(c/z(i,:));
 else
     c0OIL1(i,:)=0;
 end
  
  end
  
c0OIL1(c0OIL1<0)=0;
  

  
 disp(' get the gaspari cohn coefficient for the stochastic gradient') 
 
    schur=c0OIL1;
  Bsch = repmat(schur,1,N);
  
  yoboschur=ones(72000,N);
 
  yoboschur(1:36000,:)=Bsch;
  yoboschur(36001:72000,:)=Bsch;




sgsim1=log(sg);
% sgz1=log(sgz);
clement=reshape(clement,36000,N);
clementporo=reshape(clementporo,36000,N);
 sgsim11 = reshape(sgsim1,36000,N);
 sgsim11poro = reshape(sgporo,36000,N);

disp('  generate Gaussian noise for the observed measurments  ');


 stddWOPR1 = 0.15*f(1,:);
    stddWOPR2 = 0.15*f(2,:);
    stddWOPR3 = 0.15*f(3,:);
    stddWOPR4 = 0.15*f(4,:);

    stddWWCT1 = 0.2*f(5,:);
    stddWWCT2 = 0.2*f(6,:);
    stddWWCT3 =0.2*f(7,:);
    stddWWCT4 = 0.2*f(8,:);

    stddBHP1 = 0.2*f(9,:);
    stddBHP2 = 0.2*f(10,:);
    stddBHP3 = 0.2*f(11,:);
    stddBHP4 = 0.2*f(12,:);
     
    stddGORP1 = 0.2*f(13,:);
    stddGORP2 = 0.2*f(14,:);
    stddGORP3 = 0.2*f(15,:);
    stddGORP4 = 0.2*f(16,:);

    unierec=0.1*f(17,:);

Error1=ones(17,N);
Error1(1,:)=normrnd(0,stddWOPR1,1,N);
Error1(2,:)=normrnd(0,stddWOPR2,1,N);
Error1(3,:)=normrnd(0,stddWOPR3,1,N);
Error1(4,:)=normrnd(0,stddWOPR4,1,N);
Error1(5,:)=normrnd(0,stddWWCT1,1,N);
Error1(6,:)=normrnd(0,stddWWCT2,1,N);
Error1(7,:)=normrnd(0,stddWWCT3,1,N);
Error1(8,:)=normrnd(0,stddWWCT4,1,N);
Error1(9,:)= normrnd(0,stddBHP1,1,N);
Error1(10,:)= normrnd(0,stddBHP2,1,N);
Error1(11,:)= normrnd(0,stddBHP3,1,N);
Error1(12,:)= normrnd(0,stddBHP4,1,N);
Error1(13,:)= normrnd(0,stddGORP1,1,N);
Error1(14,:)= normrnd(0,stddGORP2,1,N);
Error1(15,:)= normrnd(0,stddGORP3,1,N);
Error1(16,:)= normrnd(0,stddGORP4,1,N);
Error1(17,:)= normrnd(0,unierec,1,N);


 Cd2 = (Error1*Error1')./(N-1);

for i=1:N
     Dj(:,i)=f+Error1(:,i);
	
 end
   
 %simulated measurements
%load Sim.uF; %simulated measurements


%Sim1=reshape(Sim,19,200);
disp('  generate the ensemble state matrix containing parameters and states  ');
overall=zeros(144017,N); %ensemble state for EnKF

overall(1:36000,1:N)=sgsim11;
overall(36001:72000,1:N)=sgsim11poro;
overall(72001:108000,1:N)=clement;
overall(108001:144000,1:N)=clementporo;
overall(144001:144017,1:N)=Sim1;


Y=overall; %State variable,it is important we include simulated measurements in the ensemble state variable


nbandall=reshape(nbandall,36000,N);
nbandallporo=reshape(nbandallporo,36000,N);

nbandI=ones(144017,N); %narrow band and covariance correlation matrix
nbandI(72001:108000,1:N)=nbandall;
nbandI(108001:144000,1:N)=nbandallporo;
nbandI(1:72000,1:N)=yoboschur;

M = mean(Sim1,2);
% Mean of the ensemble state
M2=mean(overall,2);
%M=M'
% Get the ensemble states pertubations
for j=1:N
    S(:,j)=Sim1(:,j)-M;
end
for j=1:N
    yprime(:,j)=overall(:,j)-M2;
end


disp('  update the stochastic gradient  ');
Cyd=(yprime*S')./((N-1));
Cdd=(S*S')./((N-1));

[Usig,Sig,Vsig] = svd(Cdd+(alpha.*Cd2));
xsmall = diag(Sig);
Bsig = cumsum(xsmall);
valuesig=Bsig(end);
valuesig=valuesig*0.9999;
indices = find(cumsum(xsmall) >= valuesig );
toluse=xsmall(indices,:);
tol=toluse(1,:);



disp('  update the new ensemble  ');
Ynew=Y+((Cyd*pinv((Cdd+(alpha.*Cd2))))*(Dj-Sim1)).*nbandI;
disp( 'extract the updated states ')
value1=Ynew(1:36000,1:N);


DupdateK=exp(value1);
sgsim2=Ynew(36001:72000,1:N);
%% Supervised learning
% nx=120;
% ny=60;
% nz=5;
% % load rossmary.GRDECL;
% % load rossmaryporo.GRDECL;
% 
% %if method==14
%     disp(' fit with k-nearest neighbor classification')
% Labelslearn=zeros(nx*ny*nz*2,1);
% Labelslearnp=zeros(nx*ny*nz*2,1);
% 
%  for ii=1:nx*ny*nz*2
%     if(rossmary(ii)>=100)
%         Labelslearn(ii)=1;
%     end
%     if(rossmaryporo(ii)>=0.1805)
%         Labelslearnp(ii)=1;
%     end
% end
% 
% datalearn=reshape(rossmary,72000,1); % The true permeability was used, in the future we can use
% % the intial realizations generated from multiple point statistics
% datalearnp=reshape(rossmaryporo,72000,1);
% %net = newrb(reshape(sgsim,72000,N),reshape(sgout,72000,N));
% % Mdl = fitcensemble(reshape(datalearn,72000,1),reshape(labellearn,72000,1),'CrossVal','on','LearningRate',0.05);
% % 
% % %disp('fit with SVM') % This is an equaly good method for supervised
% % learning
% % % Mdlperm = fitrsvm(reshape(datalearn,72000,1),reshape(Labelslearn,72000,1),'Standardize',true,'KernelFunction','RBF',...
%    % 'KernelScale','auto');
% % % Mdlporo = fitrsvm(reshape(datalearnp,72000,1),reshape(Labelslearnp,72000,1),'Standardize',true,'KernelFunction','RBF',...
%    % 'KernelScale','auto');
%    %  disp('fit with Bayes')
% % Mdl2 = fitcnb(reshape(sgsim,72000,1),reshape(sgout,72000,1));
% 
% Mdlperm = fitcknn(reshape(datalearn,72000,1),reshape(Labelslearn,72000,1),'NumNeighbors',3,...
%     'NSMethod','exhaustive','Distance','minkowski',...
%     'Standardize',1);
% Mdlporo = fitcknn(reshape(datalearnp,72000,1),reshape(Labelslearnp,72000,1),'NumNeighbors',3,...
%     'NSMethod','exhaustive','Distance','minkowski',...
%     'Standardize',1);
%end
% %% supervised learning prediction
% 
% % We predict the labels from our trained model
% Ypredicted = predict(Mdlperm,reshape(DupdateK,nx*ny*nz*N,1));
% Yporopredicted = predict(Mdlporo,reshape(sgsim2,nx*ny*nz*N,1));
% sgsim11=reshape(DupdateK,nx*ny*nz*N,1);
% sgporo=reshape(sgsim2,nx*ny*nz*N,1);
% updatedperm=zeros(nx*ny*nz*N,1);
% updatedporo=zeros(nx*ny*nz*N,1);
% for ii=1:nx*ny*nz*N
%     if(sgsim11(ii)>=100)
%         updatedperm(ii)=1;
%     end
% 	
%     if(sgporo(ii)>=0.1805)
%         updatedporo(ii)=1;
%     end
% 
% 	
% end
% 
% 
% requiredK=zeros(nx*ny*nz*N,1);
% requiredporo=zeros(nx*ny*nz*N,1);
% 
% for iii=1:nx*ny*nz*N
% 
%   if (updatedperm(iii)==Ypredicted(iii)) 
%     requiredK(iii)=sgsim11(iii);
%   end 
%   if (updatedporo(iii)==Yporopredicted(iii)) 
%     requiredporo(iii)=sgporo(iii);
%   end
%  
%    
%   if ((updatedperm(iii) ~= Ypredicted(iii)) && (Ypredicted(iii)==0)) 
% 
%         
%         requiredK(iii)=95;
%   end
%    if ((updatedperm(iii)~= Ypredicted(iii)) && (Ypredicted(iii)==1)) 
% 
%       
%          requiredK(iii)=105;
%    end 
%  
%     if ((updatedporo(iii) ~=Yporopredicted(iii)) && (Yporopredicted(iii)==0)) 
% 
%         
%         requiredporo(iii)=0.1795 ;
%   end
%    if ((updatedporo(iii)~= Yporopredicted(iii)) && (Yporopredicted(iii)==1)) 
% 
%       
%          requiredporo(iii)=0.1895;
%     end 
%     
%   
% end
% DupdateK=abs(requiredK);
% sgsim2=abs(requiredporo);
%%
%[sgsim2,DupdateK]=supervised(Mdlperm,Mdlporo,DupdateK,sgsim2,120,60,5,N);

updatedlevelset=Ynew(72001:108000,1:N);
clement=Ynew(72001:108000,1:N);
updatedlevelset(updatedlevelset>0)=1;
updatedlevelset(updatedlevelset<=0)=0;


updatedlevelsetporo=Ynew(108001:144000,1:N);
clementporo=Ynew(108001:144000,1:N);
updatedlevelsetporo(updatedlevelsetporo>0)=1;
updatedlevelsetporo(updatedlevelsetporo<=0)=0;
 
 
end