function [mumyperm,mumyporo]=main_Velocity_LS(nx,ny,nz,N,tol,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha);
disp( 'History matching data assimilation technique using ESMDA+Level set for SPE10 Reservoir'  ) 
disp( 'permeability,porosity and the velocity functions of the signed distance field are the petro-physical properies of interest'  ) 
disp( 'PhD Student: Clement Etienam' )
disp( 'Supervisor: Dr Rossmary Villegas' )
disp( 'Co-supervisor: Dr Masoud Babei' )
disp( 'Co-supervisor: Dr Oliver Dorn' )



disp(' extract the active grid cells' )
sgsim=reshape(perm,72000,N);
sgsimporo=reshape(poro,72000,N);
for i=1:N
sgsimuse=reshape(sgsim(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,36000,1);
sg(:,i)=ex;
end

for i=1:N
sgsimporouse=reshape(sgsimporo(:,i),120,60,10);
sgsporo=sgsimporouse(:,:,3:7);
exporo=reshape(sgsporo,36000,1);
sgporo(:,i)=exporo;
end

Sim11=reshape(overallsim,17,history,N);




disp(' extract the facies of pixel permeability and porosity fields' )
sgout=zeros(36000*N,1);
sgoutporo=zeros(36000*N,1);

 for ii=1:36000*N
    if(sg(ii)>=100)
        sgout(ii)=1;
    end
end

 for ii=1:36000*N
    if(sgporo(ii)>=0.1805)
        sgoutporo(ii)=1;
    end
end
sginitial=sgout;
sgporoinitial=sgoutporo;

disp (' get the signed distance of initial iteration permeability and porosity fields')
clement=getsigned(sgout,nx,ny);
clementporo=getsigned(sgoutporo,nx,ny);


disp( 'get the narrowband function of permeability and porosity fields')
 nbandall=regionband(sgout,N,nx,ny,nz);
 nbandallporo=regionband(sgoutporo,N,nx,ny,nz);

disp( 'extract the velocity function')
%% parameter setting
timestep=1;  % time step
mu=0.1/timestep;  % coefficient of the distance regularization term R(phi)
iter_inner=5;
iter_outer=20;
lambda=5; % coefficient of the weighted length term L(phi)
alfa=-3;  % coefficient of the weighted area term A(phi)
epsilon=1.5; % papramater that specifies the width of the DiracDelta function

sigma=.4;    % scale parameter in Gaussian kernel
G=fspecial('gaussian',15,sigma); % Gaussian kernel
sdf=zeros(nx,ny);
LF=reshape(sg,36000,N);
for ii=1:N
    lf=reshape(LF(:,ii),nx,ny,nz);
   for j=1:5
     Img_smooth=conv2(lf(:,:,j),G,'same'); 
    [Ix,Iy]=gradient(Img_smooth);
    f=Ix.^2+Iy.^2;
    g=1./(1+f);
  usdf=reshape(g,7200,1);
  young(:,j)=usdf;
   
   end
   sdfbig=reshape(young,36000,1);
  velocity(:,ii)=sdfbig;
end


LFporo=reshape(sgporo,36000,N);
for ii=1:N
    lfporo=reshape(LFporo(:,ii),nx,ny,nz);
   for j=1:5
     Img_smoothporo=conv2(lfporo(:,:,j),G,'same'); 
    [Ix,Iy]=gradient(Img_smoothporo);
    fporo=Ix.^2+Iy.^2;
    gporo=1./(1+fporo);
  usdfporo=reshape(gporo,7200,1);
  youngporo(:,j)=usdfporo;
   
   end
   sdfbigporo=reshape(youngporo,36000,1);
  velocityporo(:,ii)=sdfbigporo;
end

disp(' History matching using ESMDA and Level set velocity starts here ')
 for i=1:history
 fprintf('Now assimilating timestep %d .\n', i);
 

 f=observation(:,i); %true observation
 Sim1=Sim11(:,i,:);
Sim1=reshape(Sim1,17,N); %simulated data

disp('assimilate the historical production data')

[sg,sgporo,velocity,velocityporo,clement,clementporo] = ESMDA_Velocity(sg,sgporo,f, N,Sim1,velocity,velocityporo,tol,alpha,nbandall,nbandallporo,clement,clementporo,10);

potential=1;  
if potential ==1
    potentialFunction = 'single-well';  % use single well potential p1(s)=0.5*(s-1)^2, which is good for region-based model 
elseif potential == 2
    potentialFunction = 'double-well';  % use double-well potential in Eq. (16), which is good for both edge and region based models
else
    potentialFunction = 'double-well';  % default choice of potential function
end  


disp(' start level set evolution for permeability ')
for ii=1:N
    phi=reshape(clement(:,ii),nx,ny,nz);
    vel=reshape(velocity(:,ii),nx,ny,nz);
for j=1:5
    phiuse=phi(:,:,j);
     veluse=vel(:,:,j);
for n=1:iter_outer
    phiuse = drlse_edge(phiuse, veluse, lambda, mu, alfa, epsilon, timestep, iter_inner, potentialFunction); 
end
usdf=reshape(phiuse,7200,1);
 young(:,j)=usdf;
end
 sdfbig=reshape(young,36000,1);
  facies(:,ii)=sdfbig;
end



disp(' start level set evolution for porosity ')
for ii=1:N
    phiporo=reshape(clementporo(:,ii),nx,ny,nz);
    velporo=reshape(velocityporo(:,ii),nx,ny,nz);
for j=1:5
    phiuseporo=phiporo(:,:,j);
     veluseporo=velporo(:,:,j);
for n=1:iter_outer
    phiuseporo = drlse_edge(phiuseporo, veluseporo, lambda, mu, alfa, epsilon, timestep, iter_inner, potentialFunction); 
end
usdfporo=reshape(phiuseporo,7200,1);
 youngporo(:,j)=usdfporo;
end
 sdfbigporo=reshape(youngporo,36000,1);
  faciesporo(:,ii)=sdfbigporo;
end
clement=facies;
clementporo=faciesporo;

LSperm=facies;
LSporo=faciesporo;

disp(' convert the signed distance fields to facies indicator field ')
LSperm(LSperm>0)=1;
LSperm(LSperm<=0)=0;

LSporo(LSporo>0)=1;
LSporo(LSporo<=0)=0;

nbandall=regionband(LSperm,N,nx,ny,nz);
nbandallporo=regionband(LSporo,N,nx,ny,nz);

 fprintf('Finished assimilating timestep %d \n', i);
end

disp( 'rectify the conflict of permeabilit and porosity fields with updated Level set')
sgsim11=reshape((sg),36000*N,1);
sgsim2=reshape(sgporo,36000*N,1);
LSperm=reshape(LSperm,36000*N,1);
LSporo=reshape(LSporo,36000*N,1);
updatedperm=zeros(36000*N,1);
updatedporo=zeros(36000*N,1);

requiredK=zeros(36000*N,1);
requiredporo=zeros(36000*N,1);
for ii=1:36000*N
    if(sgsim11(ii)>=100)
        updatedperm(ii)=1;
    end
	if(sgsim2(ii)>=0.1805)
        updatedporo(ii)=1;
    end
	
end



for iii=1:36000*N

  if (updatedperm(iii)==LSperm(iii)) 
    requiredK(iii)=sgsim11(iii);
  end 
  
  if (updatedporo(iii)==LSporo(iii)) 
    requiredporo(iii)=sgsim2(iii);
  end 
  
  
  if ((updatedperm(iii) ~= LSperm(iii)) && (LSperm(iii)==0)) 

        
        requiredK(iii)=95;
  end
   if ((updatedperm(iii)~= LSperm(iii)) && (LSperm(iii)==1)) 

      
         requiredK(iii)=105;
    end 
 
  
  
  if ((updatedporo(iii) ~= LSporo(iii)) && (LSporo(iii)==0)) 

        
        requiredporo(iii)=0.1797 ;
  end
   if ((updatedporo(iii)~= LSporo(iii)) && (LSporo(iii)==1)) 

      
         requiredporo(iii)=0.1895;
    end 
  
  
end
requiredK=abs(requiredK);
%requiredporo=(0.00002.*requiredK)+0.1785;
requiredporo(requiredporo<=0.1)=0.1;
requiredporo=abs(requiredporo);


disp( 'condition the field and honour')
[output,outputporo] = honour2(rossmary, rossmaryporo, N,requiredporo,requiredK);
permsteps=reshape(output,36000*N,1); 
porosteps=reshape(outputporo,36000*N,1);

disp('  output to ASCII files the states at each time step  ');
sgassimi=permsteps; 
sgporoassimi=porosteps;


permanswers=reshape(sgassimi,36000,N);
poroanswers=reshape(sgporoassimi,36000,N);

for i=1:N
sgsim=zeros(120,60,10);
sgsimporo=zeros(120,60,10);
sgsim(:,:,3:7)=reshape(permanswers(:,i),120,60,5);
sgsimporo(:,:,3:7)=reshape(poroanswers(:,i),120,60,5);

sgsimmijana(:,i)=reshape(sgsim,72000,1);
sgsimporomijana(:,i)=reshape(sgsimporo,72000,1);
end
mumyperm=sgsimmijana;
mumyporo=sgsimporomijana;
 disp('  The program has been executed  ');
end














