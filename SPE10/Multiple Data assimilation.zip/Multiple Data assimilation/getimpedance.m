clc;
clear;
close all;

% N - size of ensemble

N=100;

for j=1:N
f = 'MASTER';
%folder = strcat(f, num2str('%.5d',j));
folder = strcat(f, sprintf('%.5d',j));
copyfile('field2Metric.m',folder)
copyfile('Eclipse2Matlab.m',folder)
copyfile('Gassmann.m',folder)
end

oldfolder=cd;
cd(oldfolder) % setting original directory

for m=1:2

    for i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',i));
     
    cd(folder);
     if m==1  % 1983
        
  
    
    SW1983 = importdata('MASTER0.F0001',' ',2938); %change here for 1st and 10th timestep
    SW1983=SW1983.data;
    SO1983=ones(2268,4)-SW1983;
    
     %Pressure data lines [670-2937]
    P1983 = importdata('MASTER0.F0001',' ',669);
    P1983=P1983.data;
    save('P1983.out','P1983','-ascii');
    save('SO1983.out','SW1983','-ascii');
     end
    if m==2  % 1989
    %Pressure data lines [670-2937]
    P1989 = importdata('MASTER0.F0016',' ',669);
    P1989=P1989.data;
    
    %Saturation data lines [2939-5206]
    SW1989 = importdata('MASTER0.F0016',' ',2938);
    SW1989=SW1989.data;
    SO1989=ones(2268,4)-SW1989;
    
    save('P1989.out','P1989','-ascii');
    save('SO1989.out','SO1989','-ascii');
    end
    %Saturation
   
    cd(oldfolder);
    end
 
end

cd(oldfolder) % returning to original directory


   
%% Get synthetic impedance


cd(oldfolder) % returning to original directory


for m=1:2
    for i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',i));
    cd(folder)
     if m==1
    %Loading values
    
    PORO = importdata('POROVANCOUVER.DAT',' ',1);
    PORO=PORO.data;
    Pr=load('P1983.out');
    SO=load('SO1983.out');
     end

    if m==2
    PORO = importdata('POROVANCOUVER.DAT',' ',1);
    PORO=PORO.data;
    Pr=load('P1989.out');
    SO=load('SO1989.out');
    end
     
    
        %Calc Impedance
    ImpP=Gassmann(PORO,Pr,SO);

    %Saving Results
 
    if m==1
        save('I1983.out','ImpP', '-ascii');
        IEn83(:,i)=reshape(ImpP,2268,1);
    end
    if m==2
        save('I1989.out','ImpP', '-ascii');
        IEn89(:,i)=reshape(ImpP,2268,1);
    end

 
   
    cd(oldfolder) % setting original directory
    
    end


end
if m==1
    IEn83=reshape(IEn83,2268*N,1);
end    

if m==2
    IEn89=reshape(IEn89,2268*N,1);
end

save('IEn83.out','IEn83','-ascii');
save('IEn89.out','IEn89','-ascii');