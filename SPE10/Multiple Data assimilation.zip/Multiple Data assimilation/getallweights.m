function [iwall,bwall,Lwall]=getallweights(N);

for j=1:20
    
     load(['net' num2str(j) '.mat']);
    wb=getwb(net);

[b,IW,LW]=separatewb(net,wb);

 weights=IW{1,1};
 biass=b{1,1};
 layweight=LW{2,1};
 
 iwall(:,j)=weights;
 bwall(:,j)=biass;
 Lwall(:,j)=layweight;
 end

end