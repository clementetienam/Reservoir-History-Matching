function [clement]=signedD(sgout,nx,ny)


nfacies_en1=sgout;
LF=reshape(nfacies_en1,36000,100);
for ii=1:100
    lf=reshape(LF(:,ii),nx,ny,5);
   for j=1:5
     sdf=lf(:,:,j);
   
  [usdf,IDX] = bwdist(sdf);
  usdf=reshape(usdf,7200,1);
  young(:,j)=usdf;
   
   end
   sdfbig=reshape(young,36000,1);
  clement(:,ii)=sdfbig;
end
disp('  output  signed distance  ');
end