%%This code is to obtain the states for the ensemble

%%PhD student: Clement Oku Etienam
%%Supervisor: Dr Rossmary Viellegas
%%Co-supervisor: Dr Masoud Babei
%%Advisor: Dr Oliver Dorn
clc;
clear;
close all;


disp( 'PhD student: Clement Oku Etienam' )

disp( 'Supervisor: Dr Rossmary Viellegas') 
disp( 'Co-supervisor: Dr Masoud Babei' )
disp('Advisor: Dr Oliver Dorn')
% N - size of ensemble

N=200;
disp('Copy necessary files into the 200 ensmble member folder')
for j=1:N
f = 'MASTER';
%folder = strcat(f, num2str('%.5d',j));
folder = strcat(f, sprintf('%.5d',j));
%copyfile('field2Metric.m',folder)
copyfile('Eclipse2Matlab.m',folder)
%copyfile('Gassmann.m',folder)
end

oldfolder=cd;
cd(oldfolder) % setting original directory

%% Saving Pressure & Saturation Ensemble 
% importing F000 files for 1,17,19,
cd(oldfolder) % setting original directory



    for i=1:N %list of folders 
    
      f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',i));
    cd(folder)   
    
    
        
    %Pressure data lines 
    P1 = importdata('MASTER0.F0001',' ',9752);
    P1=P1.data;
    
    % water Saturation data lines 
    SW = importdata('MASTER0.F0001',' ',10194);
    SW=SW.data;
    
    % Gas Saturation data lines 
    SG = importdata('MASTER0.F0001',' ',10636);
    SG=SG.data;
    
    % RS data lines 
    RS = importdata('MASTER0.F0001',' ',11078);
    RS=RS.data;
    %save('P1983.out','P1983','-ascii');
    %save('SO1983.out','SO1983','-ascii');
    
    %Reshape 
    %Pressure
    A1=P1;
    B1=Eclipse2Matlab(A1);
    PEn(:,i)=B1;
    %water Saturation
    A2=SW;
    B2=Eclipse2Matlab(A2);
    SEn(:,i)=B2;  
 
    %Gas Saturation
    A3=SG;
    B3=Eclipse2Matlab(A3);
    SGEn(:,i)=B3;
    
    %RS
    A4=RS;
    B4=Eclipse2Matlab(A4);
    RSEn(:,i)=B4;
    cd(oldfolder) % returning to original directory

    end


PEn=reshape(PEn,1764*N,1);
PEn(isnan(PEn))=0;
SEn=reshape(SEn,1764*N,1);
SEn(isnan(SEn))=0;
SGEn=reshape(SGEn,1764*N,1);
SGEn(isnan(SGEn))=0;
RSEn=reshape(RSEn,1764*N,1);
RSEn(isnan(RSEn))=0;


cd(oldfolder) % returning to original directory

disp( 'store the states')

save('pressureensemble.out','PEn','-ascii');
save('saturationensemble.out','SEn','-ascii');
save('SGensemble.out','SGEn','-ascii');
save('RSensemble.out','RSEn','-ascii');

disp( 'programme executed')