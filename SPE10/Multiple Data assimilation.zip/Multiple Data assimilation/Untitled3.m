clc;
clear all;
close all;

load rossmary.GRDECL;


sgout=zeros(72000,1);


 for ii=1:72000
    if(rossmary(ii)>=100)
        sgout(ii)=1;
    end
end
trainFcn = 'trainlm';  %use the Levenberg-Marquardt algorithm


%Train the networks


    hiddenLayerSize = 100; %number of hidden layer neurons
    net = fitnet(hiddenLayerSize,trainFcn); %create a fitting network
     net.divideParam.trainRatio = 70/100;  %use 70% of data for training 
    net.divideParam.valRatio = 15/100;  %15% for validation
    net.divideParam.testRatio = 15/100; %15% for testing
    [net,tr] = train(net,rossmary',rossmary'); % train the network
    outputs = net(rossmary'); %simulate data
    %outputs=reshape(outputs,72000,N);
    %net=load 'net1.mat'
   wb=getwb(net);
%separate weights and biases
[b,IW,LW]=separatewb(net,wb);
weights=IW{1,1};
