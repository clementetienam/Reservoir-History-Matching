function [mumyperm,mumyporo]=main_DCT_LS2(nx,ny,nz,N,tol,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha);
disp( 'History matching data assimilation technique using DCT + Level set,(second scheme) ESMDA for SPE10 Reservoir'  ) 
disp( 'The Level set alone is used as the variable for updating'  ) 
disp( 'PhD Student: Clement Etienam' )
disp( 'Supervisor: Dr Rossmary Villegas' )
disp( 'Co-supervisor: Dr Masoud Babei' )
disp('  import the true data  ');

sgsim=reshape(perm,72000,N);
sgsimporo=reshape(poro,72000,N);
for i=1:N
sgsimuse=reshape(sgsim(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,36000,1);
sg(:,i)=ex;
end

for i=1:N
sgsimporouse=reshape(sgsimporo(:,i),120,60,10);
sgsporo=sgsimporouse(:,:,3:7);
exporo=reshape(sgsporo,36000,1);
sgporo(:,i)=exporo;
end

Sim11=reshape(overallsim,17,history,N);

sgout=zeros(36000*N,1);
sgoutporo=zeros(36000*N,1);

 for ii=1:36000*N
    if(sg(ii)>=100)
        sgout(ii)=1;
    end
end

 for ii=1:36000*N
    if(sgporo(ii)>=0.1805)
        sgoutporo(ii)=1;
    end
end
disp( 'Convert the facies field to signed distance transform')
clement=getsigned(sgout,nx,ny);
clementporo=getsigned(sgoutporo,nx,ny);


disp( 'Get the DCT coefficients of the signed distance transform and permeability and porosity full field')
clementDCTsigned = DCTsigned(clement, N);
clementporoDCTsigned = DCTsigned(clementporo, N);
sgreduced = mainDCT(sg, N);
sgpororeduced = DCTsigned(sgporo, N);

for i=1:history
 fprintf('Now assimilating timestep %d .\n', i); 
 Sim1=Sim11(:,i,:);
Sim1=reshape(Sim1,17,N);
 

f=observation(:,i);
[clementDCTsigned2,clementporoDCTsigned2,sgreduced2,sgpororeduced2] = ESMDA_DCT_LS2 (clementDCTsigned,clementporoDCTsigned, f, N,Sim1,alpha,tol,sgreduced,sgpororeduced);
sgreduced=sgreduced2;
sgpororeduced=sgpororeduced2;
clementDCTsigned=clementDCTsigned2;
clementporoDCTsigned=clementporoDCTsigned2;
 fprintf('Finished assimilating timestep %d \n', i);
end

valuepermjoy=clementDCTsigned;
disp( 'extract the inverse DCT of the signed distance fields')
for ii=1:N
    lf=reshape(valuepermjoy(:,ii),100,50,5);
     for jj=1:5
         valueperm=lf(:,:,jj);
         big=zeros(120,60,5);

        big(1:100,1:50,jj)=valueperm;
        kkperm=big(:,:,jj);
        rec = mirt_idctn(kkperm);
        rec=(abs(rec));
         usdf=reshape(rec,7200,1);
         young(:,jj)=usdf;
     end
      sdfbig=reshape(young,36000,1);
  clementperm(:,ii)=sdfbig;
end
clementperm(clementperm<=0.54)=0;

valueporojoy=clementporoDCTsigned;
for ii=1:N
    lf=reshape(valueporojoy(:,ii),100,50,5);
     for jj=1:5
         valueporo=lf(:,:,jj);
         big=zeros(120,60,5);

        big(1:100,1:50,jj)=valueporo;
        kkporo=big(:,:,jj);
        rec = mirt_idctn(kkporo);
        rec=(abs(rec));
         usdf=reshape(rec,7200,1);
         youngporo(:,jj)=usdf;
     end
      sdfbigporo=reshape(youngporo,36000,1);
  clementporo(:,ii)=sdfbigporo;
end
clementporo(clementporo<=0.54)=0;

disp( 'extract the inverse DCT of the permeability and porosity fields')
for ii=1:N
    lf=reshape(sgreduced(:,ii),100,50,5);
     for jj=1:5
         valueperm=lf(:,:,jj);
         big=zeros(120,60,5);

        big(1:100,1:50,jj)=valueperm;
        kkperm=big(:,:,jj);
        rec = mirt_idctn(kkperm);
        rec=(abs(rec));
         usdf=reshape(rec,7200,1);
         young(:,jj)=usdf;
     end
      sdfbig=reshape(young,36000,1);
  yobo(:,ii)=sdfbig;
end

for ii=1:N
    lf=reshape(sgpororeduced(:,ii),100,50,5);
     for jj=1:5
         valueperm=lf(:,:,jj);
         big=zeros(120,60,5);

        big(1:100,1:50,jj)=valueperm;
        kkperm=big(:,:,jj);
        rec = mirt_idctn(kkperm);
        rec=(abs(rec));
         usdf=reshape(rec,7200,1);
         young(:,jj)=usdf;
     end
      sdfbig=reshape(young,36000,1);
  yoboporo(:,ii)=sdfbig;
end

disp( 'reclassify the signed distance field to facies indicator field')

clementperm(clementperm>0)=1;
clementperm(clementperm<=0)=0;

clementporo(clementporo>0)=1;
clementporo(clementporo<=0)=0;
% for ii=1:N
%     lf=reshape(clementperm(:,ii),120,60,5);
%      for jj=1:5
%          value=lf(:,:,jj);
% 		 usdf=value<=0;
% 		 usdf=double(usdf);
%          usdf=reshape(usdf,7200,1);
%          young(:,jj)=usdf;
%      end
%       sdfbig=reshape(young,36000,1);
%   clementpermL(:,ii)=sdfbig;
%   
% end
 clementpermL=reshape( clementperm,36000*N,1);

% for ii=1:N
%     lf=reshape(clementporo(:,ii),120,60,5);
%      for jj=1:5
%          value=lf(:,:,jj);
% 		 usdf=value<=0;
% 		 usdf=double(usdf);
%          usdf=reshape(usdf,7200,1);
%          young(:,jj)=usdf;
%      end
%       sdfbig=reshape(young,36000,1);
%   clementporoL(:,ii)=sdfbig;
% end
clementporoL=reshape(clementporo,36000*N,1);

disp( 'reclassify the permeability and porosity field to facies indicator field')

updatedperm=zeros(36000*N,1);
updatedporo=zeros(36000*N,1);

yobo=reshape(yobo,36000*N,1);
yoboporo=reshape(yoboporo,36000*N,1);
for ii=1:36000*N
    if(yobo(ii)>=100)
        updatedperm(ii)=1;
    end
	 if(yoboporo(ii)>=0.1805)
        updatedporo(ii)=1;
    end
	
end
%disp( 'Convert to continuous pixel values using the right mean and standard deviation')
zz=[2 -0.01];
zz2=[1 0.09];
requiredK=zeros(36000*N,1);
requiredporo=zeros(36000*N,1);

for iii=1:36000*N

  if (updatedperm(iii)== clementpermL(iii)) 
    requiredK(iii)=yobo(iii);
  end 
  
  if (updatedporo(iii)==clementporoL(iii)) 
    requiredporo(iii)=yoboporo(iii);
  end 
  
  
  if ((updatedperm(iii) ~= clementpermL(iii)) && (clementpermL(iii)==0)) 

        
        requiredK(iii)=95;
  end
   if ((updatedperm(iii)~= clementpermL(iii)) && (clementpermL(iii)==1)) 

      
         requiredK(iii)=105;
    end 
 
  
  
  if ((updatedporo(iii) ~= clementporoL(iii)) && (clementporoL(iii)==0)) 

        
        requiredporo(iii)=0.1795 ;
  end
   if ((updatedporo(iii)~= clementporoL(iii)) && (clementporoL(iii)==1)) 

      
         requiredporo(iii)=0.1895;
    end 
  
  
end

requiredK=abs(requiredK);
requiredporo=abs(requiredporo);
%requiredporo= filter(1,zz2,requiredporo);
requiredK(requiredK<=50)=50;
requiredK(requiredK>=20000)=20000;

requiredporo(requiredporo<=0.01)=0.01;
requiredporo(requiredporo>=0.5)=0.5;


disp( 'condition the field and honour')
[output,outputporo] = honour2(rossmary, rossmaryporo, N,requiredporo,requiredK);
permsteps=reshape(output,36000*N,1); 
porosteps=reshape(outputporo,36000*N,1);

disp('  output to ASCII files the states at each time step  ');
sgassimi=permsteps; 
sgporoassimi=porosteps;


permanswers=reshape(sgassimi,36000,N);
poroanswers=reshape(sgporoassimi,36000,N);

for i=1:N
sgsim=zeros(120,60,10);
sgsimporo=zeros(120,60,10);
sgsim(:,:,3:7)=reshape(permanswers(:,i),120,60,5);
sgsimporo(:,:,3:7)=reshape(poroanswers(:,i),120,60,5);

sgsimmijana(:,i)=reshape(sgsim,72000,1);
sgsimporomijana(:,i)=reshape(sgsimporo,72000,1);
end
mumyperm=sgsimmijana;
mumyporo=sgsimporomijana;
 disp('  The program has been executed  ');
end
%end
 %plot the mean and variance for each timestep
 %run('plot3D.m')
 
 