function [sgsim2,DupdateK] = anotherjoy (sg,sgporo,f, N, Sim1,alpha,tol,SWe,Pe)
%standard EnKF
sgsim1=log(sg);
% sgz1=log(sgz);

 sgsim11 = reshape(sgsim1,36000,N);
 sgsim11poro= reshape(sgporo,36000,N);
disp('  generate Gaussian noise  ');


Error1=ones(17,N);
Error1(1,:)=normrnd(0,481.15,1,N);
Error1(2,:)=normrnd(0,861.3795,1,N);
Error1(3,:)=normrnd(0,784.1,1,N);
Error1(4,:)=normrnd(0,1358.9735,1,N);
Error1(5,:)=normrnd(0,0.085,1,N);
Error1(6,:)=normrnd(0,0.186,1,N);
Error1(7,:)=normrnd(0,0.185,1,N);
Error1(8,:)=normrnd(0,0.164,1,N);
Error1(9,:)= normrnd(0,17.79,1,N);
Error1(10,:)= normrnd(0,16.3,1,N);
Error1(11,:)= normrnd(0,16.7,1,N);
Error1(12,:)= normrnd(0,17.4,1,N);
Error1(13,:)= normrnd(0,51.9,1,N);
Error1(14,:)= normrnd(0,36.9,1,N);
Error1(15,:)= normrnd(0,64.87,1,N);
Error1(16,:)= normrnd(0,76.43,1,N);
Error1(17,:)= normrnd(0,0.062265,1,N);

 for i=1:100;
     Dj(:,i)=f+Error1(:,i);
 end



H=zeros(17,144017);
H(1:17,144001:144017)=eye(17);
overall=zeros(144017,N); %ensemble state for EnKF

overall(1:36000,1:N)=SWe;
overall(36001:72000,1:N)=Pe;
overall(72001:108000,1:N)=sgsim11;
overall(108001:144000,1:N)=sgsim11poro;
overall(144001:144017,1:N)=Sim1;






Y=overall; %State variable,it is important we include simulated measurements in the ensemble state variable

M = mean(Sim1,2);
% Mean of the ensemble state
M2=mean(overall,2);
%M=M'
% Get the ensemble states pertubations
for j=1:100
    S(:,j)=Sim1(:,j)-M;
end
for j=1:100
    yprime(:,j)=overall(:,j)-M2;
end
unie=H*yprime;
Sim=H*Y;
unie2=unie+Error1;
[U0,Z0,V0] = svd(unie2,'econ');
joy2=Z0*Z0';

[Usig,Sig,Vsig] = svd(joy2);
xsmall = diag(Sig);
Bsig = cumsum(xsmall);
valuesig=Bsig(end);
valuesig=valuesig*0.9999;
indices = find(cumsum(xsmall) >= valuesig );
toluse=xsmall(indices,:);
tol=toluse(1,:);


X1=pinv(joy2,tol)*U0';
% Residual vector
X2=X1*(Dj-Sim);

X3=U0*X2;

X4=unie'*X3;
%Update the ensemble state
disp('  update the new ensemble  ');
Ynew=Y+(yprime*X4);
vdisp( 'extract the active permeability field ')
value1=Ynew(72001:108000,1:N);


DupdateK=exp(value1);

sgsim2=Ynew(108001:144000,1:N);
 end