%%This code is to plot all the ensemble permeability field data at once
clc;
clear;
close all;
disp('  Load the relevant files  ');
% N - size of ensemble

N=input( ' enter the number of realizations(ensemble size)  ');
load Permall.out;
load Poroall.out;
load rossmary.GRDECL;
load rossmaryporo.GRDECL;

%A=reshape(sgsim,2660,100);

permall=reshape(Permall,36000,N,36);
poroall=reshape(Poroall,36000,N,36);


for k=1:36
  fprintf('plot the mean and variance for assimilation %d .\n', k);   
perm=permall(:,:,k);
perm2=log10(permall(:,:,k));
permmean=mean((perm),2);
permmean2=mean(log10(perm),2);
for i=1:N
permvall(:,i)=(perm2(:,i)-permmean2).^2;
end
permv=(sum(permvall,2))./N-1;


poro=poroall(:,:,k);
poromean=mean(poro,2);

for i=1:N
porovall(:,i)=(poro(:,i)-poromean).^2;
end
porov=(sum(porovall,2))./N-1;
   
   
   disp(' get the dissimilarity for permeability reconstruction')
 
%load sgsim.out;



permv=reshape((permv),120,60,5);





porov=reshape(porov,120,60,5);


permmean=log10(permmean);


permmean=reshape(permmean,120,60,5);


poromean=reshape(poromean,120,60,5);


True=reshape(rossmary,120,60,10);

True=log10(True);



 [X,Y] = meshgrid(1:120,1:60);



Trueperm=True(:,:,3:7);


Trueporo2=reshape(rossmaryporo,120,60,10);


Trueporo=Trueporo2(:,:,3:7);




disp( 'plot the ensemble mean permeability and porosity')


h1=figure;
% pause(0.00001);
% frame_h = get(handle(gcf),'JavaFrame');
% set(frame_h,'Maximized',1); 
subplot(6,5,1);
surf(X',Y',Trueporo(:,:,1))

shading flat
axis([1 120 1 60 ])
grid off
title('True Layer 1','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([0.1 0.4])
h = colorbar;
ylabel(h, 'porosity','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [0.1 0.4])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])


subplot(6,5,2);
surf(X',Y',Trueporo(:,:,2))

shading flat
axis([1 120 1 60 ])
grid off
title('True Layer 2','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([0.1 0.4])
h = colorbar;
ylabel(h, 'porosity','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [0.1 0.4])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,3);
surf(X',Y',Trueporo(:,:,3))

shading flat
axis([1 120 1 60 ])
grid off
title('True Layer 3','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([0.1 0.4])
h = colorbar;
ylabel(h, 'porosity','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [0.1 0.4])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,4);
surf(X',Y',Trueporo(:,:,4))

shading flat
axis([1 120 1 60 ])
grid off
title('True Layer 4','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([0.1 0.4])
h = colorbar;
ylabel(h, 'porosity','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [0.1 0.4])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,5);

surf(X',Y',Trueporo(:,:,5))

shading flat
axis([1 120 1 60 ])
grid off
title('True Layer 5','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([0.1 0.4])
h = colorbar;
ylabel(h, 'porosity','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [0.1 0.4])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
	
	

subplot(6,5,6);
surf(X',Y',poromean(:,:,1))

shading flat
axis([1 120 1 60 ])
grid off
title('Layer 1 mean','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([0.1 0.4])
h = colorbar;
ylabel(h, 'porosity','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [0.1 0.4])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])	


subplot(6,5,7);
surf(X',Y',poromean(:,:,2))

shading flat
axis([1 120 1 60 ])
grid off
title('Layer 2','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([0.1 0.4])
h = colorbar;
ylabel(h, 'porosity','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [0.1 0.4])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])	


subplot(6,5,8);
surf(X',Y',poromean(:,:,3))

shading flat
axis([1 120 1 60 ])
grid off
title('Layer 3','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([0.1 0.4])
h = colorbar;
ylabel(h, 'porosity','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [0.1 0.4])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,9);
surf(X',Y',poromean(:,:,4))

shading flat
axis([1 120 1 60 ])
grid off
title('Layer 4 mean','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([0.1 0.4])
h = colorbar;
ylabel(h, 'porosity','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [0.1 0.4])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,10);
surf(X',Y',poromean(:,:,5))

shading flat
axis([1 120 1 60 ])
grid off
title('Layer 5','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([0.1 0.4])
h = colorbar;
ylabel(h, 'porosity','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [0.1 0.4])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,11);
surf(X',Y',porov(:,:,1))

shading flat
axis([1 120 1 60 ])
grid off
title('variance poro 1','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([-1 -0.995])
h = colorbar;
ylabel(h, 'porosity','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [-1 -0.995])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,12);
surf(X',Y',porov(:,:,2))

shading flat
axis([1 120 1 60 ])
grid off
title('variance poro 2','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([-1 -0.995])
h = colorbar;
ylabel(h, 'porosity','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [-1 -0.995])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])


subplot(6,5,13);
surf(X',Y',porov(:,:,3))

shading flat
axis([1 120 1 60 ])
grid off
title('variance poro 3','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([-1 -0.995])
h = colorbar;
ylabel(h, 'porosity','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [-1 -0.995])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])


subplot(6,5,14);
surf(X',Y',porov(:,:,4))

shading flat
axis([1 120 1 60 ])
grid off
title('variance poro 4','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([-1 -0.995])
h = colorbar;
ylabel(h, 'porosity','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [-1 -0.995])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])



subplot(6,5,15);
surf(X',Y',porov(:,:,5))

shading flat
axis([1 120 1 60 ])
grid off
title('variance poro 5','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([-1 -0.995])
h = colorbar;
ylabel(h, 'porosity','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [-1 -0.995])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,16);
surf(X',Y',Trueperm(:,:,1))

shading flat
axis([1 120 1 60 ])
grid off
title('True Layer 1','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,17);
surf(X',Y',Trueperm(:,:,2))

shading flat
axis([1 120 1 60 ])
grid off
title('True Layer 2','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,18);
surf(X',Y',Trueperm(:,:,3))

shading flat
axis([1 120 1 60 ])
grid off
title('True Layer 3','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,19);
surf(X',Y',Trueperm(:,:,4))

shading flat
axis([1 120 1 60 ])
grid off
title('True Layer 4','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,20);
surf(X',Y',Trueperm(:,:,5))

shading flat
axis([1 120 1 60 ])
grid off
title('True Layer 5','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])


subplot(6,5,21);
surf(X',Y',permv(:,:,1))

shading flat
axis([1 120 1 60 ])
grid off
title('variance perm 1','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([-1 -0.5])
h = colorbar;
ylabel(h, 'Log K(variance)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [-1 -0.5])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])


subplot(6,5,22);
surf(X',Y',permv(:,:,2))

shading flat
axis([1 120 1 60 ])
grid off
title('variance perm 2','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([-1 -0.5])
h = colorbar;
ylabel(h, 'Log K(variance)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [-1 -0.5])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])


subplot(6,5,23);
surf(X',Y',permv(:,:,3))

shading flat
axis([1 120 1 60 ])
grid off
title('variance perm 3','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([-1 -0.5])
h = colorbar;
ylabel(h, 'Log K(variance)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [-1 -0.5])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])


subplot(6,5,24);
surf(X',Y',permv(:,:,4))

shading flat
axis([1 120 1 60 ])
grid off
title('variance perm 4','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([-1 -0.5])
h = colorbar;
ylabel(h, 'Log K(variance)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [-1 -0.5])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])


subplot(6,5,25);
surf(X',Y',permv(:,:,5))

shading flat
axis([1 120 1 60 ])
grid off
title('variance perm 5','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([-1 -0.5])
h = colorbar;
ylabel(h, 'Log K(variance)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [-1 -0.5])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])




subplot(6,5,26);
surf(X',Y',permmean(:,:,1))

shading flat
axis([1 120 1 60 ])
grid off
title('mean Layer 1','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])



subplot(6,5,27);
surf(X',Y',permmean(:,:,2))

shading flat
axis([1 120 1 60 ])
grid off
title('mean Layer 2','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])


subplot(6,5,28);
surf(X',Y',permmean(:,:,3))

shading flat
axis([1 120 1 60 ])
grid off
title('mean Layer 3','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])


subplot(6,5,29);
surf(X',Y',permmean(:,:,4))

shading flat
axis([1 120 1 60 ])
grid off
title('mean Layer 4','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])


subplot(6,5,30);
surf(X',Y',permmean(:,:,5))

shading flat
axis([1 120 1 60 ])
grid off
title('mean Layer 5','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

saveas(h1,sprintf('Evariance%d.fig',k));
saveas(h1,sprintf('Evariance(b)%d.jpeg',k));
fprintf('Finished for timestep %d \n', k);

end
disp( 'save the ensemble mean to ASCII')

Nikeperm=permall(:,:,16);
meanK=mean(Nikeperm,2);
Nikeporo=poroall(:,:,16);
meanporo=mean(Nikeporo,2);


disp('  output to ASCII files the ensemble mean  ');
save('sgsimmean.out','meanK','-ascii');
save('sgporomean.out','meanporo','-ascii');
save('ensembleK.out','Nikeperm','-ascii');
save('ensembleporo.out','Nikeporo','-ascii');
disp(' programme completed')