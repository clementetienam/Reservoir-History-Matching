clc;
clear all;
close all;
% honour the well permeability and porosity values
load sgsimhonour.out;
load rossmary.GRDECL;


% read true permeability well value
unie=reshape(rossmary,120,60,10);
% read true porosity well values

for j=1:10;
    aa(j)=unie(14,25,j);
    bb(j)=unie(38,39,j);
   cc(j)=unie(96,23,j);
    dd(j)=unie(67,4,j);
    ee(j)=unie(30,55,j);
    ff(j)=unie(50,18,j);
    gg(j)=unie(90,6,j);
    hh(j)=unie(101,39,j);
end




% read permeability ensemble after EnKF update
A=reshape(sgsimhonour,72000,100);

N=100;
% start the conditioning for permeability
for i=1:N;
    %B=reshape(A(:,i),120,60,10);
    B = reshape(A(:,i),120,60,10); 
    %clement=B(i);
    for j=1:10;
    B(14,25,j)=aa(j);
    B(38,39,j)=bb(j);
   B(96,23,j)=cc(j);
    B(67,4,j)=dd(j);
    B(30,55,j)=ee(j);
    B(50,18,j)=ff(j);
    B(90,6,j)=gg(j);
    B(101,39,j)=hh(j);
    
    end
    output(:,i)=reshape(B,72000,1); 
    %Aa=reshape(B(i),72000,1);
end

% 

% output=reshape(B,120*60*10,100);
%output permeability conditioned ensemble
 file = fopen('sgsimtest.out','w+'); 
 for k=1:numel(output)                                                                       
 fprintf(file,' %4.4f \n',output(k) );             
 end
 
