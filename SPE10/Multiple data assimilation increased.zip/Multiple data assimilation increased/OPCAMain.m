%% O-PCA Code

%  Instructions
%  ------------
% 
%  This file contains code that helps you use O-PCA algorithm detailed in the paper "A new differentiable
%  parameterization based on Principal Component Analysis for the low-dimensional representation of complex
%  geological models" by H. X. Vo and L. J. Durlorfky. The examples are for binary and bimodal systems. 
%  
%  Authors: H. X. Vo and L. J. Durlorfky
%%=========================================================================
%% Load SGeMS realizations to train O-PCA
clc;
clear all;
close all;
tic
%addpath SGeMSSim/; % add a path where SGeMS realizations are
addpath(genpath('C:\Work\GSLIB\sgsim\PhD Petroleum Engineering\Dulorfsky'))
%  Load SGeMS realizations
load sgsim.out; %  realizations model:
N=100;
% nx=120;
% ny=60;
% nz=5;
sgsim=reshape(sgsim,72000,N);

for i=1:N
sgsimuse=reshape(sgsim(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,36000,1);
sg(:,i)=ex;
end
X=log(sg);
[Nc, Nr] = size(X);% Nc: number of cells; Nr: number of realizations
disp( 'Well locaions consisting of injector and producer well')
iInj = [30, 58, 90, 101]; % 16 wells configuration, injection wells
jInj = [55, 18, 6, 39]; % 16 wells configuration, injection wells
iProd = [14, 38, 96, 67]; % 16 wells configuration, production wells
jProd = [25, 39, 23, 41]; % 16 wells configuration, production wells
CMRmap=[0 0 0;.3 .15 .75;.6 .2 .50;1 .25 .15;.9 .5 0;.9 .9 .5;1 1 1];

nx = 120; % number of gridblocks in "x" direction
ny = 60; % number of gridblocks in "y" direction
nz=5;
%  Plot a random SGeMS realization
%r = randi(Nr, 1, 1); % a random SGeMS realization
PlogK = X(:, 87);
%plotting(xr, Nx, Ny, 'One SGeMS Realization', iInj, jInj, iProd, jProd, min(xr), max(xr));
   xr=reshape(PlogK,nx*ny,nz);
    
plottinglocations(xr, nx, ny,nz, 'Layer', iInj, jInj, iProd, jProd, min(xr), max(xr),CMRmap);
%%=========================================================================
%% Find eigenvectors and eigenvalues of the covariance matrix
%  Center the data matrix
xm = mean(X, 2);
Xc = (X - repmat(xm, 1, Nr));

%  Find eigenvector and eigenvalues using SVD of data matrix
Y = Xc/sqrt(Nr-1); % YY' = C
[U, Sig, V] = svd(Y); % SVD of Y
Sig = diag(Sig);% convert Sigma from an diagonal matrix to a vector for convinience

% %  Find eigenvector and eigenvalues of covariance matrix C using 1st-order polynomial kernel matrix K
% %  to reduce computational cost and memory requirement if Nc is large 
% [U, Sig] = firstOrderPolyKernelEigenDecomposition(Xc);

%  Compute, plot variances and energy
computePlotVariancesAndEnergy(Sig);
reducedDim = 100;
MU=zeros(reducedDim,100);
SIGMA=eye(100,100);
R = mvnrnd(MU,SIGMA);
%%=========================================================================
%% Draw a standard normal random vector xi to generate a random realization
 % dimension of the subspace
%xi = randn(reducedDim, 1);
xi=R(:,1);

%%=========================================================================
%% Direct method (PCA)
xPCA = U(:, 1:reducedDim) * diag(Sig(1:reducedDim)) * xi + xm;
xPCA=reshape(xPCA,nx*ny,nz);
plottinglocations(xPCA, nx, ny,nz, 'Layer', iInj, jInj, iProd, jProd, min(xr), max(xr),CMRmap);

% %%=========================================================================
% %% Optimization based method (O-PCA) for binary models (comment this part out if use bimodal model)
% %  Use "%{" and "%}" to comment out, use "%%{" and "%}" to uncomment
% %  everything in between them.
% %%{ 
% %  Truncated PCA realization
% % xPCA_thr = generateThresholdPCARealization(xPCA);
% % plotting(xPCA_thr, Nx, Ny,'', iInj, jInj, iProd, jProd, min(xPCA_thr), max(xPCA_thr)); 
% % 
% % %  Numerical solution
% % gamma = 1.8;
% % xGen = generateOPCARealization(U, Sig, reducedDim, xi, xm, gamma);%solution from optimizer
% % plotting(xGen, Nx, Ny, 'O-PCA Numerical Solution', iInj, jInj, iProd, jProd, min(xGen), max(xGen));
% % 
% % %  Analytical solution
% % [xGen2, S]= generateAnalyticalOPCARealization(U, Sig, reducedDim, xi, xm, gamma);%analytical solution with sensitivity matrix dx/dxi
% % plotting(xGen2, Nx, Ny, 'O-PCA Analytical Solution', iInj, jInj, iProd, jProd, min(xGen2), max(xGen2));
% % 
% % %  Comparing numerical solution and analytical solution
% % xError = norm(xGen2 - xGen, 2);%compare numerical solution with analytical solution
% % SNumTest = computeOPCANumSensMat(U, Sig, reducedDim, xi, xm, gamma);%compute numerical sensitivity matrix
% % SError = norm(S - SNumTest, 'fro');%compare numerical sensitivity with analytical sensitivity dx/dxi
% % 
% % %  Check facies data at well locations for SGeMS realizations (binary case)
% % IndI = [iInj, iProd];
% % IndJ = [jInj, jProd];
% % IndK = 1;
% % index = (IndK-1) * Nx * Ny + (IndJ-1) * Nx + IndI;
% % hardData = X(index,r);
% % 
% % % Check if the facies data is honored by PCA, O-PCA (binary case)
% % hardDataPCA = xPCA(index);
% % hardDataOPCA = xGen(index);
% % 
% % %  Compute average sand-fraction of SGEMS realizations for binary system
% % NFrac = 100;
% % XFrac_SGeMS = X(:,randi(Nr, NFrac, 1));
% % SGEMSSandFracAve = computeAveSandFractionOfSGeMSRealizations(XFrac_SGeMS);
% % 
% % %  Compute average sand-fraction of O-PCA realizations for binary system
% % [xiMat, XFrac_PCA] = generateSetOfPCARealizations(U, Sig, xm, reducedDim, NFrac);
% % XFrac_OPCA = generateSetOfOPCARealizations(U, Sig, xm, reducedDim, NFrac, gamma, xiMat);
% % [OPCASandFracAve, OPCAThresSandFracAve] = computeAveSandFractionOfOPCARealizations(XFrac_OPCA, Nc);
% % %}
% 
% %%=========================================================================
% %% Optimization based method (O-PCA) for bimodal models (comment this part out if use binary model)
% 
cle=mean(X,2);
%X=reshape(X,3600000,1);
logkMin  = min(cle); % min average of the training set
logkMax  =   max(cle); % max average of the training set

optGamma =  1; % weight of the regularization term
sg=reshape(log(sg),nx*ny*nz*N,1);
indices=find(sg>=4.61);
indices2=find(sg<4.61);
kk=sg(indices); % permeability greater than 100mD,sand
kk2=sg(indices2); %permeability less than 100mD,shale


optMu1   =   mean(kk2); % mean of Gaussian distribution within shale facies
optMu2   =    mean(kk); % mean of Gaussian distribution within sand facies
optV1    =  var(kk2); % variance of of Gaussian distribution within shale facies
optV2    =  var(kk); % variance of Gaussian distribution within sand facies

optParaVector = [optGamma, optV1, optV2, optMu1, optMu2];

xGen = generateOPCARealizationBimodal(U, Sig, reducedDim, xi, xm, optParaVector, logkMin, logkMax);
%plotting(xGen, Nx, Ny, 'O-PCA Numerical Solution', iInj, jInj, iProd, jProd, logkMin,logkMax);
xGen=reshape(xGen,nx*ny,nz);
plottinglocations(xGen, nx, ny,nz, 'Layer', iInj, jInj, iProd, jProd, 1.61,10,CMRmap);


%%=========================================================================
%% Compute, plot average semivariogram of SGeMS, O-PCA, PCA realizations (used for both models)
%  Use "%{" and "%}" to comment out, use "%%{" and "%}" to uncomment
%  everything in between them.

NVario = 1;
X=reshape(X,36000,100);
XVario_SGeMS = X(:,randi(Nr,NVario, 1));
%[h, angle_center, SGeMS_aveVario] = computeAnisotropicVariogramsAverage(XVario_SGeMS, Nx, Ny);

%  Compute average semivariogram of PCA realizations
[xiMat, XVario_PCA] = generateSetOfPCARealizations(U, Sig, xm, reducedDim, NVario);
%[~, ~, PCA_aveVario] = computeAnisotropicVariogramsAverage(XVario_PCA, Nx, Ny);

% Computing average semivariogram of corresponding O-PCA realizations
%XVario_OPCA = generateSetOfOPCARealizations(U, Sig, xm, reducedDim, NVario, gamma, xiMat); % for binary case
 XVario_OPCA = generateSetOfOPCARealizationsBimodal(U, Sig, xm, reducedDim, NVario, optParaVector, logkMin, logkMax, xiMat); % for bimodal
%[~, ~, OPCA_aveVario] = computeAnisotropicVariogramsAverage(XVario_OPCA, Nx, Ny);

% Plot average semivariogram of SGEMS, O-PCA, and PCA realizations
%plotAnisotropicVariogramsAverage(h, SGeMS_aveVario, OPCA_aveVario, PCA_aveVario);
toc

%%=========================================================================





