clc;
clear;
load sgsimfinal.out;
load sgsimporofinal.out;
load rossmary.GRDECL;
load rossmaryporo.GRDECL;
[mumyperm,mumyporo]=clean(120,60,5,100,sgsimfinal,sgsimporofinal,rossmary,rossmaryporo);
file = fopen('sgsimfinal.out','w+'); %output the dictionary
for k=1:numel(mumyperm)                                                                       
fprintf(file,' %4.6f \n',mumyperm(k) );             
end

file2 = fopen('sgsimporofinal.out','w+'); %output the dictionary
for k=1:numel(mumyporo)                                                                       
fprintf(file2,' %4.6f \n',mumyporo(k) );             
end
disp('1=yes')
disp('2=no' )
response=input('Do you want to plot the permeability map ');


if response==1
    disp( 'Pixel map needed')
     run('ClementPlot.m')
else
    disp (' pixel map not needed')
end