clc;
clear;
close all;

disp( ' This code is to get the pressure and saturation fields for all the states')
% N - size of ensemble

N=100;

for j=1:N
f = 'MASTER';
%folder = strcat(f, num2str('%.5d',j));
folder = strcat(f, sprintf('%.5d',j));
%sprintf('%.5d',23)
copyfile('Eclipse2Matlab.m',folder)
copyfile('resize.m',folder)

end

oldfolder=cd;
cd(oldfolder) % setting original directory

%for m=1:2

  
    for i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',i));
    %folder=oldfolder;
    %cd 'C:\Work\GSLIB\sgsim\EnKFMATLABRun'   
    cd(folder);
    %if m==1  % 1983
  
  
    for j=1:36 %desired time steps
	 ff = 'MASTER0.F';
   
    %Saturation data lines [2939-5206]
    SW1983 = importdata(strcat(ff, sprintf('%.4d',j)),' ',12020); %change here for 1st and 10th timestep
    SW1983=SW1983.data;
    %SO1983=ones(2268,4)-SW1983;
     A=SW1983;
    B2=Eclipse2Matlab(A);
	B(:,j)=B2;
    end
	%[Bpad, TF] = padcat(B(:,1:end));
	%Bpad(~TF) = 0.22;
	Bpad = resize(B,[36000,36]);
    
	  for jj=1:36 % desired time steps
	 fff = 'MASTER0.F';
    %save('P1983.out','P1983','-ascii');
    %save('SW1983.out','SW1983','-ascii');
    P1983 = importdata(strcat(fff, sprintf('%.4d',jj)),' ',3019);
    P1983=P1983.data;
     C=P1983;
	 D2=Eclipse2Matlab(C);
	 D(:,jj)=D2;
      end
   Dpad = resize(D,[36000,36]);
    %Saturation
   
    SEn83(:,:,i)=Bpad;
     
	
    PEn83(:,:,i)=Dpad;
	
    cd(oldfolder);
    end
   cd(oldfolder) % returning to original directory

 


 
SEn89=reshape(SEn83,36000*36*N,1);
PEn89=reshape(PEn83,36000*36*N,1);



cd(oldfolder) % returning to original directory


save('SEn89.out','SEn89','-ascii');
save('PEn83.out','PEn89','-ascii');
    %run Assimilate.m % data assimilation