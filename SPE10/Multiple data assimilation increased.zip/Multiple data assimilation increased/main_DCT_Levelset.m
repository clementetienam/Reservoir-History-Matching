function [mumyperm,mumyporo]=main_DCT_Levelset(nx,ny,nz,N,tol,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha);
disp( 'History matching data assimilation technique using DCT + Level set ESMDA for SPE10 Reservoir'  ) 
disp( 'PhD Student: Clement Etienam' )
disp( 'Supervisor: Dr Rossmary Villegas' )
disp( 'Co-supervisor: Dr Masoud Babei' )


sgsim=reshape(perm,72000,N);
sgsimporo=reshape(poro,72000,N);
for i=1:N
sgsimuse=reshape(sgsim(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,36000,1);
sg(:,i)=ex;
end

for i=1:N
sgsimporouse=reshape(sgsimporo(:,i),120,60,10);
sgsporo=sgsimporouse(:,:,3:7);
exporo=reshape(sgsporo,36000,1);
sgporo(:,i)=exporo;
end

Sim11=reshape(overallsim,17,history,N);

sgout=zeros(36000*N,1);
sgoutporo=zeros(36000*N,1);

 for ii=1:36000*N
    if(sg(ii)>=100)
        sgout(ii)=1;
    end
end

 for ii=1:36000*N
    if(sgporo(ii)>=0.1805)
        sgoutporo(ii)=1;
    end
end
disp( 'Convert the facies field to signed distance transform')
clement=getsigned(sgout,nx,ny,N);
clementporo=getsigned(sgoutporo,nx,ny,N);


disp( 'Get the DCT coefficients of the signed distance transform')
clementDCTsigned = DCTsigned(clement, N);
clementporoDCTsigned = DCTsigned(clementporo, N);
for i=1:history
 fprintf('Now assimilating timestep %d .\n', i);
 
 Sim1=Sim11(:,i,:);
Sim1=reshape(Sim1,17,N);
 
f=observation(:,i);
[porolevel,permlevel,sg2,sgporo2,clementDCTsigned2,clementporoDCTsigned2] = ESMDA_DCT_Levelset (sg,sgporo,clementDCTsigned,clementporoDCTsigned, f, N,Sim1,alpha,tol);

permsteps(:,i)=reshape(permlevel,36000*N,1); 
porosteps(:,i)=reshape(porolevel,36000*N,1);
sg=sg2;
sgporo=sgporo2;
clementDCTsigned=clementDCTsigned2;
clementporoDCTsigned=clementporoDCTsigned2;

 fprintf('Finished assimilating timestep %d \n', i);
end

permout=reshape((permsteps(:,36)),36000,N);
%permout=exp(permout);
poroout=reshape(porosteps(:,36),36000,N);


valuepermjoy=clementDCTsigned;
disp( 'extract the inverse DCT of the signed distance field')
for ii=1:N
    lf=reshape(valuepermjoy(:,ii),100,50,5);
     for jj=1:5
         valueperm=lf(:,:,jj);
         big=zeros(120,60,5);

        big(1:100,1:50,jj)=valueperm;
        kkperm=big(:,:,jj);
        rec = mirt_idctn(kkperm);
        rec=(abs(rec));
         usdf=reshape(rec,7200,1);
         young(:,jj)=usdf;
     end
      sdfbig=reshape(young,36000,1);
  clementperm(:,ii)=sdfbig;
end
clementperm(clementperm<=0.54)=0;

valueporojoy=clementporoDCTsigned;
for ii=1:N
    lf=reshape(valueporojoy(:,ii),100,50,5);
     for jj=1:5
         valueporo=lf(:,:,jj);
         big=zeros(120,60,5);

        big(1:100,1:50,jj)=valueporo;
        kkporo=big(:,:,jj);
        rec = mirt_idctn(kkporo);
        rec=(abs(rec));
         usdf=reshape(rec,7200,1);
         youngporo(:,jj)=usdf;
     end
      sdfbigporo=reshape(youngporo,36000,1);
  clementporo(:,ii)=sdfbigporo;
end
clementporo(clementporo<=0.54)=0;
disp( 'reclassify the signed distance field to facies indicator field')
clementperm(clementperm>0)=1;
clementperm(clementperm<=0)=0;

clementporo(clementporo>0)=1;
clementporo(clementporo<=0)=0;

clementpermL=clementperm;
clementporoL=clementporo;
% for ii=1:N
%     lf=reshape(clementperm(:,ii),120,60,5);
%      for jj=1:5
%          value=lf(:,:,jj);
% 		 usdf=value<=0;
% 		 usdf=double(usdf);
%          usdf=reshape(usdf,7200,1);
%          young(:,jj)=usdf;
%      end
%       sdfbig=reshape(young,36000,1);
%   clementpermL(:,ii)=sdfbig;
%   
% end

% for ii=1:N
%     lf=reshape(clementporo(:,ii),120,60,5);
%      for jj=1:5
%          value=lf(:,:,jj);
% 		 usdf=value<=0;
% 		 usdf=double(usdf);
%          usdf=reshape(usdf,7200,1);
%          young(:,jj)=usdf;
%      end
%       sdfbig=reshape(young,36000,1);
%   clementporoL(:,ii)=sdfbig;
% end



disp( 'rectify the conflict of permeability and porosity fields with updated Level set')
sgsim11=reshape((permout),36000*N,1);


sgsim2=reshape(poroout,36000*N,1);


updatedlevelset=reshape(clementpermL,36000*N,1);
updatedlevelsetporo=reshape(clementporoL,36000*N,1);
updatedperm=zeros(36000*N,1);
updatedporo=zeros(36000*N,1);

for ii=1:36000*N
    if(sgsim11(ii)>=100)
        updatedperm(ii)=1;
    end
	 if(sgsim2(ii)>=0.1805)
        updatedporo(ii)=1;
    end
	
end


requiredK=zeros(36000*N,1);
requiredporo=zeros(36000*N,1);

for iii=1:36000*N

  if (updatedperm(iii)==updatedlevelset(iii)) 
    requiredK(iii)=sgsim11(iii);
  end 
  
  if (updatedporo(iii)==updatedlevelsetporo(iii)) 
    requiredporo(iii)=sgsim2(iii);
  end 
  
  
  if ((updatedperm(iii) ~= updatedlevelset(iii)) && (updatedlevelset(iii)==0)) 

        
        requiredK(iii)=95;
  end
   if ((updatedperm(iii)~= updatedlevelset(iii)) && (updatedlevelset(iii)==1)) 

      
         requiredK(iii)=105;
    end 
 
  
  
  if ((updatedporo(iii) ~= updatedlevelsetporo(iii)) && (updatedlevelsetporo(iii)==0)) 

        
        requiredporo(iii)=0.1795 ;
  end
   if ((updatedporo(iii)~= updatedlevelsetporo(iii)) && (updatedlevelsetporo(iii)==1)) 

      
         requiredporo(iii)=0.1895;
    end 
  
  
end
requiredK=abs(requiredK);
requiredporo=abs(requiredporo);
disp( 'condition the field and honour')
[output,outputporo] = honour2(rossmary, rossmaryporo, N,requiredporo,requiredK);
permsteps=reshape(output,36000*N,1); 
porosteps=reshape(outputporo,36000*N,1);

disp('  output to ASCII files the states at each time step  ');
sgassimi=permsteps; 
sgporoassimi=porosteps;


permanswers=reshape(sgassimi,36000,N);
poroanswers=reshape(sgporoassimi,36000,N);

for i=1:N
sgsim=zeros(120,60,10);
sgsimporo=zeros(120,60,10);
sgsim(:,:,3:7)=reshape(permanswers(:,i),120,60,5);
sgsimporo(:,:,3:7)=reshape(poroanswers(:,i),120,60,5);

sgsimmijana(:,i)=reshape(sgsim,72000,1);
sgsimporomijana(:,i)=reshape(sgsimporo,72000,1);
end
mumyperm=sgsimmijana;
mumyporo=sgsimporomijana;

disp('  The program has been executed  ');
end
  %run('plot3D.m')
 
 