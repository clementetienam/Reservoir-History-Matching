function [PE,SW,SG,RS,sgz1,Sim1,sgsim2,DupdateK,c] = localization2(sgsim, f, N, PE,SW,SG,RS, Sim1,c);
%%History matching data assimilation technique 
%%PhD Student: Clement Etienam
%%Supervisor: Dr Rossmary Villegas
%%Co-supervisor: Dr Masoud Babei
%DESCRIPTION:
%   Various EnKF update schemes following Evensen (2009).
%
% PARAMETERS:
%   f           -   True data
%   sgsim           -  ensemble of simulate states
%   N           -   ensemble size
%   Sim      -   Simulated measurments
%
%
% We aim to get the analysed ensemble as U:
%   Updated ensemble of model states= U
%
%
%
%-----------------------------------------------------------------------------
disp( 'History matching data assimilation technique usingcovariance localization with EnKF for PUNQ Reservoir'  ) 
disp( 'PhD Student: Clement Etienam' )
disp( 'Supervisor: Dr Rossmary Villegas' )
disp( 'Co-supervisor: Dr Masoud Babei' )
disp( 'Advisor: Dr Oliver Dorn' )
disp('  load the files  ');

%Get the localization for oil recovery ratio
A=zeros(19,28,5);
for j=1:5
    A(10,22,j)=1;
    A(9,17,j)=1;
    A(17,11,j)=1;
    A(11,24,j)=1;
    A(15,12,j)=1;
    A(17,22,j)=1;
end

disp( 'calculate the euclidean distance function to the 6 producer wells')
    lf=reshape(A,19,28,5);
   for j=1:5;
     sdf=lf(:,:,j);
     unie=lf(:,:,j);
  unie(unie==1)=1;
  unie(unie==0)=-1;
%   if  lf == 1;
%       sgn= 1;
%   end
  usdf = ac_reinit(sdf,unie);
  usdf=reshape(usdf,532,1);
  young(:,j)=usdf;
   
   end
   sdfbig=reshape(young,2660,1);
   sdfbig1=abs(sdfbig);
   z=sdfbig1;
   % the value of the range should be computed accurately.
   %c=range(z);
  
  
   c0FOE=zeros(2660,1);
   disp( 'compute the gaspari-cohn coefficent')
  for i=1:2660;
 if (0<=z(i,:) || z(i,:)<=c)
  c0FOE(i,:)=-0.25*(z(i,:)/c)^5+0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3-(5.0/3.0)*(z(i,:)/c)^2+1;
elseif z < 2*c
  c0FOE(i,:)=(1.0/12.0)*(z(i,:)/c)^5-0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3+(5.0/3.0)*(z(i,:)/c)^2-5*(z(i,:)/c)+4-(2.0/3.0)*(c/z(i,:));
 elseif (c<=z(i,:) || z(i,:)<=2*c)
     c0FOE(i,:)=-5*(z(i,:)/c)+4-0.667*(c/z(i,:));
 else
     c0FOE(i,:)=0;
 end
  
  end
  

  
  
  
  
  
  %Get the oil recovery for PRO-1  pressure data
 
A=zeros(19,28,5);
for j=1:5
    A(10,22,j)=1;
   
end

disp( 'calculate the euclidean distance function to the  producer 1 well')
    lf=reshape(A,19,28,5);
   for j=1:5;
     sdf=lf(:,:,j);
     unie=lf(:,:,j);
  unie(unie==1)=1;
  unie(unie==0)=-1;
%   if  lf == 1;
%       sgn= 1;
%   end
  usdf = ac_reinit(sdf,unie);
  usdf=reshape(usdf,532,1);
  young(:,j)=usdf;
   
   end
   sdfbig=reshape(young,2660,1);
   sdfbig1=abs(sdfbig);
   z=sdfbig1;
   % the value of the range should be computed accurately.
   %c=range(z);
  
  
   c0P1=zeros(2660,1);
   disp( 'compute the gaspari-cohn coefficent')
  for i=1:2660;
 if (0<=z(i,:) || z(i,:)<=c)
  c0P1(i,:)=-0.25*(z(i,:)/c)^5+0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3-(5.0/3.0)*(z(i,:)/c)^2+1;
elseif z < 2*c
  c0P1(i,:)=(1.0/12.0)*(z(i,:)/c)^5-0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3+(5.0/3.0)*(z(i,:)/c)^2-5*(z(i,:)/c)+4-(2.0/3.0)*(c/z(i,:));
 elseif (c<=z(i,:) || z(i,:)<=2*c)
     c0P1(i,:)=-5*(z(i,:)/c)+4-0.667*(c/z(i,:));
 else
     c0P1(i,:)=0;
 end
  
  end
  
  
  
  
  %Get the localization for PRO-2 pressure data
A=zeros(19,28,5);
for j=1:5
   
    A(9,17,j)=1;
    
end

disp( 'calculate the euclidean distance function to the producer wells')
    lf=reshape(A,19,28,5);
   for j=1:5;
     sdf=lf(:,:,j);
     unie=lf(:,:,j);
  unie(unie==1)=1;
  unie(unie==0)=-1;
%   if  lf == 1;
%       sgn= 1;
%   end
  usdf = ac_reinit(sdf,unie);
  usdf=reshape(usdf,532,1);
  young(:,j)=usdf;
   
   end
   sdfbig=reshape(young,2660,1);
   sdfbig1=abs(sdfbig);
   z=sdfbig1;
   % the value of the range should be computed accurately.
   %c=range(z);
  
  
   c0P2=zeros(2660,1);
   disp( 'compute the gaspari-cohn coefficent')
  for i=1:2660;
 if (0<=z(i,:) || z(i,:)<=c)
  c0P2(i,:)=-0.25*(z(i,:)/c)^5+0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3-(5.0/3.0)*(z(i,:)/c)^2+1;
elseif z < 2*c
  c0P2(i,:)=(1.0/12.0)*(z(i,:)/c)^5-0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3+(5.0/3.0)*(z(i,:)/c)^2-5*(z(i,:)/c)+4-(2.0/3.0)*(c/z(i,:));
 elseif (c<=z(i,:) || z(i,:)<=2*c)
     c0P2(i,:)=-5*(z(i,:)/c)+4-0.667*(c/z(i,:));
 else
     c0P2(i,:)=0;
 end
  
  end
  
  
  %Get the localization for PRO-5 pressure data
A=zeros(19,28,5);
for j=1:5
   
    A(17,11,j)=1;
   
end

disp( 'calculate the euclidean distance function to the producer wells')
    lf=reshape(A,19,28,5);
   for j=1:5;
     sdf=lf(:,:,j);
     unie=lf(:,:,j);
  unie(unie==1)=1;
  unie(unie==0)=-1;
%   if  lf == 1;
%       sgn= 1;
%   end
  usdf = ac_reinit(sdf,unie);
  usdf=reshape(usdf,532,1);
  young(:,j)=usdf;
   
   end
   sdfbig=reshape(young,2660,1);
   sdfbig1=abs(sdfbig);
   z=sdfbig1;
   % the value of the range should be computed accurately.
   %c=range(z);
  
  
   c0P3=zeros(2660,1);
   disp( 'compute the gaspari-cohn coefficent')
  for i=1:2660;
 if (0<=z(i,:) || z(i,:)<=c)
  c0P3(i,:)=-0.25*(z(i,:)/c)^5+0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3-(5.0/3.0)*(z(i,:)/c)^2+1;
elseif z < 2*c
  c0P3(i,:)=(1.0/12.0)*(z(i,:)/c)^5-0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3+(5.0/3.0)*(z(i,:)/c)^2-5*(z(i,:)/c)+4-(2.0/3.0)*(c/z(i,:));
 elseif (c<=z(i,:) || z(i,:)<=2*c)
     c0P3(i,:)=-5*(z(i,:)/c)+4-0.667*(c/z(i,:));
 else
     c0P3(i,:)=0;
 end
  
  end
  
  
  %Get the localization for PRO-11 pressure data
A=zeros(19,28,5);
for j=1:5
   
    A(11,25,j)=1;
   
end

disp( 'calculate the euclidean distance function to the producer wells')
    lf=reshape(A,19,28,5);
   for j=1:5;
     sdf=lf(:,:,j);
     unie=lf(:,:,j);
  unie(unie==1)=1;
  unie(unie==0)=-1;
%   if  lf == 1;
%       sgn= 1;
%   end
  usdf = ac_reinit(sdf,unie);
  usdf=reshape(usdf,532,1);
  young(:,j)=usdf;
   
   end
   sdfbig=reshape(young,2660,1);
   sdfbig1=abs(sdfbig);
   z=sdfbig1;
   % the value of the range should be computed accurately.
   %c=range(z);
  
  
   c0P4=zeros(2660,1);
   disp( 'compute the gaspari-cohn coefficent')
  for i=1:2660;
 if (0<=z(i,:) || z(i,:)<=c)
  c0P4(i,:)=-0.25*(z(i,:)/c)^5+0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3-(5.0/3.0)*(z(i,:)/c)^2+1;
elseif z < 2*c
  c0P4(i,:)=(1.0/12.0)*(z(i,:)/c)^5-0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3+(5.0/3.0)*(z(i,:)/c)^2-5*(z(i,:)/c)+4-(2.0/3.0)*(c/z(i,:));
 elseif (c<=z(i,:) || z(i,:)<=2*c)
     c0P4(i,:)=-5*(z(i,:)/c)+4-0.667*(c/z(i,:));
 else
     c0P4(i,:)=0;
 end
  
  end
  
  
  
  %Get the localization for PRO-12 pressure data
A=zeros(19,28,5);
for j=1:5
   
    A(15,12,j)=1;
   
end

disp( 'calculate the euclidean distance function to the producer wells')
    lf=reshape(A,19,28,5);
   for j=1:5;
     sdf=lf(:,:,j);
     unie=lf(:,:,j);
  unie(unie==1)=1;
  unie(unie==0)=-1;
%   if  lf == 1;
%       sgn= 1;
%   end
  usdf = ac_reinit(sdf,unie);
  usdf=reshape(usdf,532,1);
  young(:,j)=usdf;
   
   end
   sdfbig=reshape(young,2660,1);
   sdfbig1=abs(sdfbig);
   z=sdfbig1;
   % the value of the range should be computed accurately.
   %c=range(z);
 
  
   c0P5=zeros(2660,1);
   disp( 'compute the gaspari-cohn coefficent')
  for i=1:2660;
 if (0<=z(i,:) || z(i,:)<=c)
  c0P5(i,:)=-0.25*(z(i,:)/c)^5+0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3-(5.0/3.0)*(z(i,:)/c)^2+1;
elseif z < 2*c
  c0P5(i,:)=(1.0/12.0)*(z(i,:)/c)^5-0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3+(5.0/3.0)*(z(i,:)/c)^2-5*(z(i,:)/c)+4-(2.0/3.0)*(c/z(i,:));
 elseif (c<=z(i,:) || z(i,:)<=2*c)
     c0P5(i,:)=-5*(z(i,:)/c)+4-0.667*(c/z(i,:));
 else
     c0P5(i,:)=0;
 end
  
  end
  
  %Get the localization for PRO-15 pressure data
A=zeros(19,28,5);
for j=1:5
   
    A(17,22,j)=1;
   
end

disp( 'calculate the euclidean distance function to the producer wells')
    lf=reshape(A,19,28,5);
   for j=1:5;
     sdf=lf(:,:,j);
     unie=lf(:,:,j);
  unie(unie==1)=1;
  unie(unie==0)=-1;
%   if  lf == 1;
%       sgn= 1;
%   end
  usdf = ac_reinit(sdf,unie);
  usdf=reshape(usdf,532,1);
  young(:,j)=usdf;
   
   end
   sdfbig=reshape(young,2660,1);
   sdfbig1=abs(sdfbig);
   z=sdfbig1;
   % the value of the range should be computed accurately.
   %c=range(z);
 
  
   c0P6=zeros(2660,1);
   disp( 'compute the gaspari-cohn coefficent')
  for i=1:2660;
 if (0<=z(i,:) || z(i,:)<=c)
  c0P6(i,:)=-0.25*(z(i,:)/c)^5+0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3-(5.0/3.0)*(z(i,:)/c)^2+1;
elseif z < 2*c
  c0P6(i,:)=(1.0/12.0)*(z(i,:)/c)^5-0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3+(5.0/3.0)*(z(i,:)/c)^2-5*(z(i,:)/c)+4-(2.0/3.0)*(c/z(i,:));
 elseif (c<=z(i,:) || z(i,:)<=2*c)
     c0P6(i,:)=-5*(z(i,:)/c)+4-0.667*(c/z(i,:));
 else
     c0P6(i,:)=0;
 end
  
  end
  
  
  
  
  
  
  
  
  
  
  

disp( 'Now do the History matching')

sgsim1=log(sgsim);
% sgz1=log(sgz);

 sgsim11 = reshape(sgsim1,2660,N);
N=200; %ensemble size

%load indexnow.out; % The non-active grid positions
disp('  generate Gaussian noise  ');

for i=1:N
    noisewater1(:,i)=normrnd(0,0.000051);
end
for i=1:N
    noisewater2(:,i)=normrnd(0,0.29);
end
for i=1:N
    noisewater3(:,i)=normrnd(0,0.039);
end
for i=1:N
    noisewater4(:,i)=normrnd(0,0.233);
end
for i=1:N
    noisewater5(:,i)=normrnd(0,0.19);
end
for i=1:N
    noisewater6(:,i)=normrnd(0,0.00013);
end


for i=1:N
    noisepressure1(:,i)=normrnd(0,25.09669);
end
for i=1:N
    noisepressure2(:,i)=normrnd(0,40.7447);
end
for i=1:N
    noisepressure3(:,i)=normrnd(0,18.44556);
end
for i=1:N
    noisepressure4(:,i)=normrnd(0,41.6449);
end
for i=1:N
    noisepressure5(:,i)=normrnd(0,35.2);
end
for i=1:N
    noisepressure6(:,i)=normrnd(0,37.8);
end

for i=1:N
    noisegor1(:,i)=normrnd(0,31.93052);

end

for i=1:N
    noisegor2(:,i)=normrnd(0,6.220671);
end
for i=1:N
    noisegor3(:,i)=normrnd(0,4.5735);
end
for i=1:N
    noisegor4(:,i)=normrnd(0,4.91044);
end
for i=1:N
    noisegor5(:,i)=normrnd(0,4.067739);
end
for i=1:N
    noisegor6(:,i)=normrnd(0,48.28586);
end

for i=1:N
    noiserecovery(:,i)=normrnd(0,0.079);
end
Error1=ones(19,N);
Error1(1,:)=noiserecovery;
Error1(2,:)=noisepressure1;
Error1(3,:)=noisepressure2;
Error1(4,:)=noisepressure3;
Error1(5,:)=noisepressure4;
Error1(6,:)=noisepressure5;
Error1(7,:)=noisepressure6;
Error1(8,:)= noisegor1;
Error1(9,:)= noisegor2;
Error1(10,:)= noisegor3;
Error1(11,:)= noisegor4;
Error1(12,:)= noisegor5;
Error1(13,:)= noisegor6;
Error1(14,:)=noisewater1;
Error1(15,:)=noisewater2;
Error1(16,:)=noisewater3;
Error1(17,:)=noisewater4;
Error1(18,:)=noisewater5;
Error1(19,:)=noisewater6;


for i=1:N;
     Dj(:,i)=f+Error1(:,i);
 end


 %simulated measurements
%load Sim.uF; %simulated measurements


%Sim1=reshape(Sim,19,200);
disp('  generate the ensemble state matrix containing parameters and states  ');
overall=zeros(9735,N); %ensemble state for EnKF




overall(1:2660,1:N)=sgsim11;
overall(2661:4424,1:N)=PE;
overall(4425:6188,1:N)=SW;
overall(6189:7952,1:N)=SG;
overall(7953:9716,1:N)=RS;
overall(9717:9735,1:N)=Sim1;




Y=overall; %State variable,it is important we include simulated measurements in the ensemble state variable

M = mean(Sim1,2);
% Mean of the ensemble state
M2=mean(overall,2);
%M=M'
% Get the ensemble states pertubations
for j=1:N
    S(:,j)=Sim1(:,j)-M;
end
for j=1:N
    yprime(:,j)=overall(:,j)-M2;
end

H=zeros(19,9735);
H(1:19,9717:9735)=eye(19);

disp(' get the gaspari cohn for Cyd')
coouse=zeros(2660,19);
coouse(:,1)=c0FOE;
coouse(:,2)=c0P1;
coouse(:,3)=c0P2;
coouse(:,4)=c0P3;
coouse(:,5)=c0P4;
coouse(:,6)=c0P5;
coouse(:,7)=c0P6;
coouse(:,8)=c0P1;
coouse(:,9)=c0P2;
coouse(:,10)=c0P3;
coouse(:,11)=c0P4;
coouse(:,12)=c0P5;
coouse(:,13)=c0P6;
coouse(:,14)=c0P1;
coouse(:,15)=c0P2;
coouse(:,16)=c0P3;
coouse(:,17)=c0P4;
coouse(:,18)=c0P5;
coouse(:,19)=c0P6;





ddd=resize(coouse,[1764,19]);
ddsmall=resize(coouse,[19,19]);
c001=zeros(9735,19);
c001(1:2660,1:19) = coouse;
c001(2661:4424,1:19) = ddd;
c001(4425:6188,1:19) = ddd;
c001(6189:7952,1:19) = ddd;
c001(7953:9716,1:19) = ddd;
c001(9717:9735,1:19) = ddsmall;



%c001(1:9735,1:19) = resize(coouse,[9735,19]);
%c001(9717:9735,1:19)=ones(19,19);
%c002 = resize(coouse,[19,19]);
Ce=(yprime*yprime')/N-1;
Cd=(Error1*Error1')/(N-1);

up=Ce*H';
down=(H*Ce*H')+Cd;
disp (' compute the kalman gain matrix ')
    
    K = up/down;
     D = Dj;
     Kcov_loc=K.*c001;
%     d = mean(D')';
%             D = sqrt(200 / (200 - 1)) * (D - repmat(d, 1, 200));
   disp( 'update the ensemble ')
            Ynew = Y + Kcov_loc * (D - H*Y);



disp( 'extract the active permeability field ')
value1=Ynew(1:2660,1:N);


sgsim11=value1;
% sgsim2=value2;
% sgz1=value3;

sgsim11=exp(sgsim11);
sgsim11(sgsim11<=0.4967)=0.4967;
sgsim11(sgsim11>=9500)=9500;

PE=Ynew(2661:4424,1:N);
SW=Ynew(4425:6188,1:N);
SG=Ynew(6189:7952,1:N);
RS=Ynew(7953:9716,1:N);
Sim1=Ynew(9717:9735,1:N);

SW(SW>=1)=1;

SG(SG>=1)=1;


 
DupdateK= sgsim11;
%DupdateK= sgsim1;

disp('  recover the porosity and permz field from Logs  ');
for ii=1:N;
    Knew=reshape(DupdateK(:,ii),19,28,5);
   for j=1:5;
 pore(:,:,1)=0.040228*log(Knew(:,:,1))-0.03101;
pore(:,:,2)=0.022608*log(Knew(:,:,2))+0.0066038;
pore(:,:,3)=0.046974*log(Knew(:,:,3))-0.072764;
pore(:,:,4)=0.025312*log(Knew(:,:,4))+0.01088;
pore(:,:,5)=0.039746*log(Knew(:,:,5))-0.038238;


permz(:,:,1)=0.88227*log(Knew(:,:,1))-0.29112;
permz(:,:,2)=0.89976*log(Knew(:,:,2))-1.1289;
permz(:,:,3)=0.69049*log(Knew(:,:,3))+1.0074;
permz(:,:,4)=0.82778*log(Knew(:,:,4))-0.56077;
permz(:,:,5)=0.97173*log(Knew(:,:,5))-0.74865;

   end
   bigporo=reshape(pore,2660,1);
   bigpermz=reshape(permz,2660,1);
  clementporo(:,ii)=bigporo;
   clementpermz(:,ii)=bigpermz;
end
disp('  exit the loop  ');
disp('  output porosity field  ');
sgsim2=clementporo;
sgsim2(sgsim2<0.01024)=0.01024;
sgsim2(sgsim2>=0.2992)=0.2992;

disp('  output the perm z field from Logs  ');
sgz1=clementpermz;
sgz1(sgz1<=0.1478)=0.1478;
sgz1(sgz1>=498.4011)=498.4011;


end