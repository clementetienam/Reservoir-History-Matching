%Clement etienam
% PhD supervisor: Dr Rossmary Villegas
%Co-supervisor: Dr Masoud Babei
%KSVDDEMO K-SVD dictionary learning.
clc;
clear all;
close all;
load sgsimenkf.out; %(nosiy permeability realizations)
nx=input('enter the value of x direction grid cells ');
ny=input(' enter the value of y direction grid cells ');
nz=input(' enter he value of z direction grid cells ');
N=input('enther the ensemble size ');
sgsim=reshape(sgsimenkf,nx*ny*10,N);

for i=1:N
sgsimuse=reshape(sgsim(:,i),nx,ny,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,36000,1);
sg(:,i)=ex;
end

for i=1:N
    x1=reshape(sg(:,i),nx,ny,nz);
    for j=1:nz
[thr,sorh,keepapp] = ddencmp('den','wv',x1(:,:,j));
xd = wdencmp('gbl',x1(:,:,j),'db3',2,thr,sorh,keepapp);
xdall(:,j)=reshape(xd,nx*ny,1);
    end
    xrequired(:,i)=reshape(xdall,nx*ny*nz,1);
end
xrequired(xrequired<50)=50;
for i=1:N
sgsim1=zeros(120,60,10);

sgsim1(:,:,3:7)=reshape(xrequired(:,i),120,60,5);


sgsimmijana(:,i)=reshape(sgsim1,72000,1);

end


disp( 'Well locaions consisting of injector and producer well')
iInj = [30, 58, 90, 101]; % 16 wells configuration, injection wells
jInj = [55, 18, 6, 39]; % 16 wells configuration, injection wells
iProd = [14, 38, 96, 67]; % 16 wells configuration, production wells
jProd = [25, 39, 23, 41]; % 16 wells configuration, production wells
CMRmap=[0 0 0;.3 .15 .75;.6 .2 .50;1 .25 .15;.9 .5 0;.9 .9 .5;1 1 1];

%if response==1
    disp( 'Pixel map needed')
    [bestnorm3,PlogK]=clementPlot(sgsimmijana,sgsim(:,2),N,4,CMRmap);
    xr=reshape(PlogK,nx*ny,nz);
    
plottinglocations(xr, nx, ny,nz, 'Layer', iInj, jInj, iProd, jProd, min(xr), max(xr),CMRmap);
disp(' green are injector wells and blue are producers')
     %run('clementPlot.m')
%else
    disp (' pixel map not needed')
%end