clc;
clear;
  ne=100; % number of ensemble members
   
clc;
clear all;
close all;
load sgsim1.out;
load Dj.uf;
load Sim.uF;

load Error1.uF;
Dj=reshape(Dj,12,100);
Sim1=reshape(Sim,12,100);
Error1=reshape(Error1,12,100);
H=zeros(12,36012);
H(1:12,36001:36012)=eye(12);
%H=reshape(H,12,72000);
overall=zeros(36012,100);
sgsim1=reshape(sgsim1,72000,100);
sgsimactual=sgsim1(14401:50400,1:100);
overall(1:36000,1:100)=sgsimactual;
overall(36001:36012,1:100)=Sim1;
A=overall;




Ymeasure=reshape(Dj,12,100);
Dmeasure=reshape(Sim1,12,100);

scheme=3;
tol=0.01;
beta=1;
R=reshape(Error1,12,100);
U = EnKF (Dmeasure, Ymeasure, A, scheme, R, tol, beta);
value=U(1:36000,1:100);
sgsim1(14401:50400,1:100)=value;
%Ynew(Ynew<50)=50;
%sgsim1=exp(sgsim1);
sgsim1=10.^(sgsim1);
file = fopen('sgsim1output.out','w+'); 
 for k=1:numel(sgsim1)                                                                       
 fprintf(file,' %4.4f \n',sgsim1(k) );             
 end
