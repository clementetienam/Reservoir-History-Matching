function [mumyperm,mumyporo]=main_EnKFyap(iyobo,N,tol,scheme,beta,observation,overallsim,rossmary,rossmaryporo,SEn89,PEn89,perm,poro,history);
disp( 'History matching data assimilation technique using EnKF for SPE10 Reservoir'  ) 
disp( 'This code is longer and computationaly expensive')
disp( 'PhD Student: Clement Etienam' )
disp( 'Supervisor: Dr Rossmary Villegas' )
disp( 'Co-supervisor: Dr Masoud Babei' )


sgsim=reshape(perm,72000,N);
sgsimporo=reshape(poro,72000,N);
for i=1:N
sgsimuse=reshape(sgsim(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,36000,1);
sg(:,i)=ex;
end

for i=1:N
sgsimporouse=reshape(sgsimporo(:,i),120,60,10);
sgsporo=sgsimporouse(:,:,3:7);
exporo=reshape(sgsporo,36000,1);
sgporo(:,i)=ex;
end

Sim11=reshape(overallsim,17,history,N);

SWe1=reshape(SEn89,36000,36,N);
Pe1=reshape(PEn89,36000,36,N);

%for i=1:131
disp(' assimilate sequentialy for EnKF')


 
 Sim1=Sim11(:,iyobo,:);
Sim1=reshape(Sim1,17,N);

f=observation(:,iyobo);
[sgsim2,DupdateK] = EnKF_MDA_Yap (sg,sgporo, f, N, Sim1,scheme,tol,beta);

%condition the data
[output,outputporo] = honour2(rossmary, rossmaryporo, N,sgsim2,DupdateK);

sg=reshape(output,36000,N);
sgporo=reshape(outputporo,36000,N);

disp('  output to ASCII files  ');
sgassimi=sg; 
sgporoassimi=sgporo;

permanswers=reshape(sgassimi,36000,N);
poroanswers=reshape(sgporoassimi,36000,N);

for i=1:N
sgsim=zeros(120,60,10);
sgsimporo=zeros(120,60,10);
sgsim(:,:,3:7)=reshape(permanswers(:,i),120,60,5);
sgsimporo(:,:,3:7)=reshape(poroanswers(:,i),120,60,5);

sgsimmijana(:,i)=reshape(sgsim,72000,1);
sgsimporomijana(:,i)=reshape(sgsimporo,72000,1);
end
mumyperm=sgsimmijana;
mumyporo=sgsimporomijana;
if iyobo==36
disp( 'output the permeability and porosity history matched model for the last timestep')
file = fopen('sgsimfinal.out','w+'); %output the dictionary
for k=1:numel(sgsimmijana)                                                                       
fprintf(file,' %4.4f \n',sgsimmijana(k) );             
end

file2 = fopen('sgsimporofinal.out','w+'); %output the dictionary
for k=1:numel(sgsimporomijana)                                                                       
fprintf(file2,' %4.4f \n',sgsimporomijana(k) );             
end
end
 
%end
 %plot the mean and variance for each timestep
 %run('plot3D.m')
end
 