%%This code is to plot all the ensemble permeability field data at once
clc;
clear;
close all;
disp('  Load the relevant files  ');
% N - size of ensemble

N=100;


load sgsimfinal.out; %permeability ensemble


disp(' extract the active grid cells' )
sgsim=reshape(sgsimfinal,72000,N);

for i=1:N
sgsimuse=reshape(sgsim(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,36000,1);
sg(:,i)=ex;
end

perm=sg;

CMRmap=[0 0 0;.3 .15 .75;.6 .2 .50;1 .25 .15;.9 .5 0;.9 .9 .5;1 1 1];


   disp(' get the dissimilarity for permeability reconstruction')
 
%load sgsim.out;
load rossmary.GRDECL;


%A=reshape(sgsim,2660,100);

Truen=reshape(rossmary,120,60,10);
True=Truen(:,:,3:7);
True=log10(True);
True=reshape(True,36000,1);



Ause=perm;
A1=log10(Ause);


for i=1:100
    J(:,i)=A1(:,i)-True;
end
for i=1:100
test(i,:)=sum(abs((J(:,i))));
end
reali=[1:100]';

jj3=min(test);
index3 = test; 
bestnorm3 = find(index3 == min(index3));
	%Pssim = Pnew(:,bestssim); %best due to ssim

fprintf('The best Norm Realization for Log(K) reconstruction  is number %i with value %4.4f \n',bestnorm3,jj3);




 PlogK = reshape(A1(:,bestnorm3),120,60,5);
 

  
 [X,Y] = meshgrid(1:120,1:60);



Trueperm=reshape(True,120,60,5);

figure()
subplot(3,5,1);
surf(X',Y',Trueperm(:,:,1))

shading flat
axis([1 120 1 60 ])
grid off
title('True Layer 1','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap(CMRmap)
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(3,5,2);
surf(X',Y',Trueperm(:,:,2))

shading flat
axis([1 120 1 60 ])
grid off
title('True Layer 2','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap(CMRmap)
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(3,5,3);
surf(X',Y',Trueperm(:,:,3))

shading flat
axis([1 120 1 60 ])
grid off
title('True Layer 3','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap(CMRmap)
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(3,5,4);
surf(X',Y',Trueperm(:,:,4))

shading flat
axis([1 120 1 60 ])
grid off
title('True Layer 4','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap(CMRmap)
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(3,5,5);

surf(X',Y',Trueperm(:,:,5))

shading flat
axis([1 120 1 60 ])
grid off
title('True Layer 5','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap(CMRmap)
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
	
	



subplot(3,5,6);
surf(X',Y',PlogK(:,:,1))

shading flat
axis([1 120 1 60 ])
grid off
title('Layer 1(best Log(K)-Match)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap(CMRmap)
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(3,5,7);
surf(X',Y',PlogK(:,:,2))

shading flat
axis([1 120 1 60 ])
grid off
title('Layer 2(best Log(K)-Match)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap(CMRmap)
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(3,5,8);
surf(X',Y',PlogK(:,:,3))

shading flat
axis([1 120 1 60 ])
grid off
title('Layer 3(best Log(K)-Match)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap(CMRmap)
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])


subplot(3,5,9);
surf(X',Y',PlogK(:,:,4))

shading flat
axis([1 120 1 60 ])
grid off
title('Layer 4(best Log(K)-Match)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap(CMRmap)
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(3,5,10);
surf(X',Y',PlogK(:,:,5))

shading flat
axis([1 120 1 60 ])
grid off
title('Layer 5(best Log(K)-Match)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap(CMRmap)
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])



disp(' plot the mean of the ensemble')
A1=reshape(A1,36000,N);
A1mean=mean(A1,2);
A1mean=reshape(A1mean,120,60,5);


subplot(3,5,11);
surf(X',Y',A1mean(:,:,1))

shading flat
axis([1 120 1 60 ])
grid off
title('Layer 1 mean','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap(CMRmap)
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(3,5,12);
surf(X',Y',A1mean(:,:,2))

shading flat
axis([1 120 1 60 ])
grid off
title('Layer 2 mean','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap(CMRmap)
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(3,5,13);
surf(X',Y',A1mean(:,:,3))

shading flat
axis([1 120 1 60 ])
grid off
title('Layer 3 mean','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap(CMRmap)
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])


subplot(3,5,14);
surf(X',Y',A1mean(:,:,4))

shading flat
axis([1 120 1 60 ])
grid off
title('Layer 4 mean','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap(CMRmap)
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(3,5,15);
surf(X',Y',A1mean(:,:,5))

shading flat
axis([1 120 1 60 ])
grid off
title('Layer 5 mean','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap(CMRmap)
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

saveas(gcf,'figurem','fig')
saveas(gcf,'figurem','jpg')



figure()
subplot(2,2,1);
redd=slice(Trueperm,[1 60],[1 120],[3 7]);
axis equal on
%axis([1 27 1 84 1 4 ])
% xlim([1 84])
% ylim([1 27])
% zlim([0 4])
shading flat
grid off
title('True','FontName','Helvetica', 'Fontsize', 16);
colormap(CMRmap)
caxis([1 5])
xlabel('X','FontName','Helvetica', 'Fontsize', 16)
ylabel('Y','FontName','Helvetica', 'Fontsize', 16)
zlabel('Z','FontName','Helvetica', 'Fontsize', 16)

set(gca, 'FontName','Helvetica', 'Fontsize', 16)
set(gcf,'color','white')
hold on
plot3([55 55],[30 30],[1 -50],'k','Linewidth',2);
text(55,30,-55,'I1','Fontsize', 11)
%title('I1','FontName','Helvetica', 'Fontsize', 18);
hold on
plot3([18 18],[58 58],[1 -50],'k','Linewidth',2);
text(18 ,58 ,-52,'I2','Fontsize', 11)
hold on
plot3([6 6],[90 90],[1 -50],'k','Linewidth',2);
text(6 ,90 , -51,'I3','Fontsize', 11)
hold on
plot3([39 39],[101 101],[1 -50],'k','Linewidth',2);
text(39 ,101 , -31,'I4','Fontsize', 11)
hold on
plot3([25 25],[14 14],[1 -50],'r','Linewidth',2);
% text(x1(i,1),y1(i,1),z1(i,1),['   ' ...
% num2str(time(i,1))],'HorizontalAlignment','left','FontSize',8);
text( 25, 14,-52,'P1','HorizontalAlignment','left','FontSize',11)
hold on
plot3([39 39],[38 38],[1 -50],'r','Linewidth',2);
text( 39, 38, -52,'P2','Fontsize', 11)
hold on
plot3([23 23],[96 96],[1 -30],'r','Linewidth',2);
text(23 ,96 , -35,'P3','Fontsize', 11)
hold on
plot3([41 41],[67 67],[1 -50],'r','Linewidth',2)
text( 41, 67, -45,'P4','Fontsize', 11)
direction = [0 1 0];
rotate(redd,direction,180)
set(gcf,'color','white')
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca,'zticklabel',[])


subplot(2,2,2);
redd=slice(A1mean,[1 60],[1 120],[1 5]);
axis equal on
%axis([1 27 1 84 1 4 ])
% xlim([1 84])
% ylim([1 27])
% zlim([0 4])
shading flat
grid off
title('Mean','FontName','Helvetica', 'Fontsize', 16);
colormap(CMRmap)
caxis([1 5])
xlabel('X','FontName','Helvetica', 'Fontsize', 16)
ylabel('Y','FontName','Helvetica', 'Fontsize', 16)
zlabel('Z','FontName','Helvetica', 'Fontsize', 16)

set(gca, 'FontName','Helvetica', 'Fontsize', 16)
set(gcf,'color','white')
hold on
plot3([55 55],[30 30],[1 -50],'k','Linewidth',2);
text(55,30,-55,'I1','Fontsize', 11)
%title('I1','FontName','Helvetica', 'Fontsize', 18);
hold on
plot3([18 18],[58 58],[1 -50],'k','Linewidth',2);
text(18 ,58 ,-52,'I2','Fontsize', 11)
hold on
plot3([6 6],[90 90],[1 -50],'k','Linewidth',2);
text(6 ,90 , -51,'I3','Fontsize', 11)
hold on
plot3([39 39],[101 101],[1 -50],'k','Linewidth',2);
text(39 ,101 , -31,'I4','Fontsize', 11)
hold on
plot3([25 25],[14 14],[1 -50],'r','Linewidth',2);
% text(x1(i,1),y1(i,1),z1(i,1),['   ' ...
% num2str(time(i,1))],'HorizontalAlignment','left','FontSize',8);
text( 25, 14,-52,'P1','HorizontalAlignment','left','FontSize',11)
hold on
plot3([39 39],[38 38],[1 -50],'r','Linewidth',2);
text( 39, 38, -52,'P2','Fontsize', 11)
hold on
plot3([23 23],[96 96],[1 -30],'r','Linewidth',2);
text(23 ,96 , -35,'P3','Fontsize', 11)
hold on
plot3([41 41],[67 67],[1 -50],'r','Linewidth',2)
text( 41, 67, -45,'P4','Fontsize', 11)
direction = [0 1 0];
rotate(redd,direction,180)
set(gcf,'color','white')
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca,'zticklabel',[])



subplot(2,2,3);
redd=slice(PlogK,[1 60],[1 120],[1 5]);
axis equal on
%axis([1 27 1 84 1 4 ])
% xlim([1 84])
% ylim([1 27])
% zlim([0 4])
shading flat
grid off
title('Best Log','FontName','Helvetica', 'Fontsize', 16);
colormap(CMRmap)
caxis([1 5])
xlabel('X','FontName','Helvetica', 'Fontsize', 16)
ylabel('Y','FontName','Helvetica', 'Fontsize', 16)
zlabel('Z','FontName','Helvetica', 'Fontsize', 16)

set(gca, 'FontName','Helvetica', 'Fontsize', 16)
set(gcf,'color','white')
hold on
plot3([55 55],[30 30],[1 -50],'k','Linewidth',2);
text(55,30,-55,'I1','Fontsize', 11)
%title('I1','FontName','Helvetica', 'Fontsize', 18);
hold on
plot3([18 18],[58 58],[1 -50],'k','Linewidth',2);
text(18 ,58 ,-52,'I2','Fontsize', 11)
hold on
plot3([6 6],[90 90],[1 -50],'k','Linewidth',2);
text(6 ,90 , -51,'I3','Fontsize', 11)
hold on
plot3([39 39],[101 101],[1 -50],'k','Linewidth',2);
text(39 ,101 , -31,'I4','Fontsize', 11)
hold on
plot3([25 25],[14 14],[1 -50],'r','Linewidth',2);
% text(x1(i,1),y1(i,1),z1(i,1),['   ' ...
% num2str(time(i,1))],'HorizontalAlignment','left','FontSize',8);
text( 25, 14,-52,'P1','HorizontalAlignment','left','FontSize',11)
hold on
plot3([39 39],[38 38],[1 -50],'r','Linewidth',2);
text( 39, 38, -52,'P2','Fontsize', 11)
hold on
plot3([23 23],[96 96],[1 -30],'r','Linewidth',2);
text(23 ,96 , -35,'P3','Fontsize', 11)
hold on
plot3([41 41],[67 67],[1 -50],'r','Linewidth',2)
text( 41, 67, -45,'P4','Fontsize', 11)
direction = [0 1 0];
rotate(redd,direction,180)
set(gcf,'color','white')
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca,'zticklabel',[])



saveas(gcf,'figure1d','eps')
saveas(gcf,'figure1d','jpg')
close(figure)

disp(' The Fortran and MATLAB programme has been completed')

file2 = fopen('bestlog.out','w+'); %output the dictionary
for k=1:numel(PlogK)                                                                       
fprintf(file2,' %4.6f \n',PlogK(k) );             
end

file = fopen('meanK.out','w+');
 for k=1:numel(A1mean)                                                                       
 fprintf(file,' %4.6f \n',A1mean(k) );             
 end
%run('testvar.m')