clc;
clear;
clearvars;
close all;
disp( 'History matching data assimilation technique using EnKF for SPE10 Reservoir'  ) 
disp( 'This code is longer and computationaly expensive')
disp( 'PhD Student: Clement Etienam' )
disp( 'Supervisor: Dr Rossmary Villegas' )
disp( 'Co-supervisor: Dr Masoud Babei' )
disp('  import the true data  ');
% N - size of ensemble

N=input( ' enter the number of realizations(ensemble size)  ');
tol=input( ' enter the tolerance for pseudo inversion  ');
scheme=input( ' enter the scheme for EnKF assimilation  ');
beta=1;

 disp('  import the true data  ');
 
 True= importdata('Real.RSM',' ',7);
 True2= importdata('Real.RSM',' ',50);
 True3= importdata('Real.RSM',' ',93);
 True4= importdata('Real.RSM',' ',136);
 
 
 True=True.data;
 True2=True2.data;
 True3=True3.data;
 True4=True4.data;
 
 
  TO1=True(:,3);
 TO2=True(:,4);
 TO3=True(:,5);
 TO4=True(:,6);
 
 
 
 TW1=True2(:,2);
 TW2=True2(:,3);
 TW3=True2(:,4);
 TW4=True2(:,5);
 
  TP1=True3(:,5);
 TP2=True3(:,6);
 TP3=True3(:,7);
 TP4=True3(:,8);
 
 TG1=True3(:,9);
 TG2=True3(:,10);
 TG3=True4(:,2);
 TG4=True4(:,3);
 
 TFOE=True4(:,8);
 
 
 disp(' make the true observation')
 for i=1:131
 obs=zeros(17,1);
 obs(1,:)=TO1(i,:);
 obs(2,:)=TO2(i,:);
 obs(3,:)=TO3(i,:);
 obs(4,:)=TO4(i,:);
 obs(5,:)=TW1(i,:);
 obs(6,:)=TW2(i,:);
 obs(7,:)=TW3(i,:);
 obs(8,:)=TW4(i,:);
 obs(9,:)=TP1(i,:);
 obs(10,:)=TP2(i,:);
 obs(11,:)=TP3(i,:);
 obs(12,:)=TP4(i,:);
 obs(13,:)=TG1(i,:);
 obs(14,:)=TG2(i,:);
 obs(15,:)=TG3(i,:);
 obs(16,:)=TG4(i,:);
 obs(17,:)=TFOE(i,:);
 observation(:,i)=obs;
 end
 disp(' for initial ensemble states load the files')
load sgsim.out; %permeability ensemble
load sgsimporo.out; %porosity ensemble



sgsim=reshape(sgsim,72000,N);
sgsimporo=reshape(sgsimporo,72000,N);
for i=1:N
sgsimuse=reshape(sgsim(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,36000,1);
sg(:,i)=ex;
end

for i=1:N
sgsimporouse=reshape(sgsimporo(:,i),120,60,10);
sgsporo=sgsimporouse(:,:,3:7);
exporo=reshape(sgsporo,36000,1);
sgporo(:,i)=ex;
end
load Simulateddata.out;
Sim11=reshape(Simulateddata,17,131,N);


load rossmary.GRDECL;
load rossmaryporo.GRDECL;

load SEn89.out;
load PEn83.out;

SWe1=reshape(SEn89,36000,36,N);
Pe1=reshape(PEn83,36000,36,N);

%for i=1:131
disp(' assimilate sequentialy for EnKF')
i=1; % change here from 1 to 36
 %fprintf('Now assimilating timestep %d .\n', i);

SWe= SWe1(:,i,:);
SWe=reshape(SWe,36000,N);
Pe=Pe1(:,i,:);
Pe=reshape(Pe,36000,N);
 
 Sim1=Sim11(:,i,:);
Sim1=reshape(Sim1,17,N);

f=observation(:,i);
[sgsim2,DupdateK] = EnKF_MDA (sg,sgporo, f, N, Sim1,scheme,tol,beta,SWe,Pe);

%condition the data
[output,outputporo] = honour2(rossmary, rossmaryporo, N,sgsim2,DupdateK);
permsteps(:,i)=reshape(output,36000*N,1); 
porosteps(:,i)=reshape(outputporo,36000*N,1);


sg=reshape(output,36000,N);
sgporo=reshape(outputporo,36000,N);

disp('  output to ASCII files the states at each time step  ');
sgassimi=permsteps(:,36); 
sgporoassimi=porosteps(:,36);


save('Permall.out','sgassimi','-ascii');
save('Poroall.out','sgporoassimi','-ascii');

permanswers=reshape(sgassimi,36000,N);
poroanswers=reshape(sgporoassimi,36000,N);

for i=1:100
sgsim=zeros(120,60,10);
sgsimporo=zeros(120,60,10);
sgsim(:,:,3:7)=reshape(permanswers(:,i),120,60,5);
sgsimporo(:,:,3:7)=reshape(poroanswers(:,i),120,60,5);

sgsimmijana(:,i)=reshape(sgsim,72000,1);
sgsimporomijana(:,i)=reshape(sgsimporo,72000,1);
end

disp( 'output the permeability and porosity history matched model for the next run')
file = fopen('sgsim.out','w+'); %output the dictionary
for k=1:numel(sgsimmijana)                                                                       
fprintf(file,' %4.4f \n',sgsimmijana(k) );             
end

file2 = fopen('sgsimporo.out','w+'); %output the dictionary
for k=1:numel(sgsimporomijana)                                                                       
fprintf(file2,' %4.4f \n',sgsimporomijana(k) );             
end

 disp('  program executed  ');
%end
 %plot the mean and variance for each timestep
 run('plot3D.m')
 
 