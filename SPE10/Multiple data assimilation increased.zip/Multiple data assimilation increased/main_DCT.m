function [mumyperm,mumyporo]=main_DCT(N,tol,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha);
disp( 'History matching data assimilation technique using DCT ESMDA for SPE10 Reservoir'  ) 
disp( 'PhD Student: Clement Etienam' )
disp( 'Supervisor: Dr Rossmary Villegas' )
disp( 'Co-supervisor: Dr Masoud Babei' )
disp('  import the true data  ');

load sgsim.out; %permeability ensemble
load sgsimporo.out; %porosity ensemble



sgsim=reshape(perm,72000,N);
sgsimporo=reshape(poro,72000,N);
for i=1:N
sgsimuse=reshape(sgsim(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,36000,1);
sg(:,i)=ex;
end

for i=1:N
sgsimporouse=reshape(sgsimporo(:,i),120,60,10);
sgsporo=sgsimporouse(:,:,3:7);
exporo=reshape(sgsporo,36000,1);
sgporo(:,i)=exporo;
end

Sim11=reshape(overallsim,17,history,N);


for i=1:history
 fprintf('Now assimilating timestep %d .\n', i);
 
 Sim1=Sim11(:,i,:);
Sim1=reshape(Sim1,17,N);
 
 
 
disp( 'Get the DCT coefficients')
clement2 = mainDCT(sg, N);
clement2poro = DCTsigned(sgporo, N);


f=observation(:,i);
[sgsim2,DupdateK] = Assimilate_DCT (clement2,clement2poro, f, N,Sim1,tol,alpha);



%condition the data
[output,outputporo] = honour2(rossmary, rossmaryporo, N,sgsim2,DupdateK);
permsteps(:,i)=reshape(output,36000*N,1); 
porosteps(:,i)=reshape(outputporo,36000*N,1);


sg=reshape(output,36000,N);
sgporo=reshape(outputporo,36000,N);

%function Kplot=compareplot(output,outputporo,outputz,effective,rossmary,rossmaryporo,N)

 fprintf('Finished assimilating timestep %d \n', i);
end
disp('  output to ASCII files the states at each time step  ');
sgassimi=permsteps(:,36); 
sgporoassimi=porosteps(:,36);
save('Permall.out','sgassimi','-ascii');
save('Poroall.out','sgporoassimi','-ascii');
permanswers=reshape(sgassimi,36000,N);
poroanswers=reshape(sgporoassimi,36000,N);

for i=1:N
sgsim=zeros(120,60,10);
sgsimporo=zeros(120,60,10);
sgsim(:,:,3:7)=reshape(permanswers(:,i),120,60,5);
sgsimporo(:,:,3:7)=reshape(poroanswers(:,i),120,60,5);

sgsimmijana(:,i)=reshape(sgsim,72000,1);
sgsimporomijana(:,i)=reshape(sgsimporo,72000,1);
end

mumyperm=sgsimmijana;
mumyporo=sgsimporomijana;
end
 %plot the mean and variance for each timestep
 %run('plot3D.m')
 
 