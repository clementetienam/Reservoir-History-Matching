function [clement]=getsigned(sgout,nx,ny,N)


nfacies_en1=sgout;
sdf=zeros(nx,ny);
sgn(nx,ny)=1;
 sdf_dt=zeros(nx,ny,5);
LF=reshape(nfacies_en1,36000,N);
for ii=1:N
    lf=reshape(LF(:,ii),nx,ny,5);
   for j=1:5
     sdf=lf(:,:,j);
     unie=lf(:,:,j);
  unie(unie==1)=1;
  unie(unie==0)=-1;
%   if  lf == 1;
%       sgn= 1;
%   end
  usdf = ac_reinit(sdf,unie);
  usdf=reshape(usdf,7200,1);
  young(:,j)=usdf;
   
   end
   sdfbig=reshape(young,36000,1);
  clement(:,ii)=sdfbig;
end
clement(clement==0)=-1;
disp('  output permeability signed distance  ');
end