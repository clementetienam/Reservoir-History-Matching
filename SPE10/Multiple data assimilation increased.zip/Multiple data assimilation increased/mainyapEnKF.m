%----------------------------------------------------------------------------------
% Running Ensembles
% the code couples ECLIPSE reservoir simulator with MATLAB used to implement my ideas on history matching of
% The SPE 10 Reservoir. Author: Clement Etienam ,PhD Petroleum Engineering 2015-2018
% Supervisor:Dr Rossmary Villegas
% Co-Supervisor: Dr Masoud Babei
% Co-Supervisor: Dr Oliver Dorn
%-----------------------------------------------------------------------------------
%% 

clc
clear

% N - size of ensemble

N=input( ' enter the number of realizations(ensemble size)  ');
history=input(' enter the number of timestep for the history period ');
%history=36; 5timesteps
disp( 'Load the true permeability and porosity')
load rossmary.GRDECL; %true permeability
load rossmaryporo.GRDECL; %True porosity

disp('  import the true observation data  ');
 
 True= importdata('Real.RSM',' ',7);
 True2= importdata('Real.RSM',' ',50);
 True3= importdata('Real.RSM',' ',93);
 True4= importdata('Real.RSM',' ',136);
 
 
 True=True.data;
 True2=True2.data;
 True3=True3.data;
 True4=True4.data;
 
 
  TO1=True(:,3);
 TO2=True(:,4);
 TO3=True(:,5);
 TO4=True(:,6);
 
 
 
 TW1=True2(:,2);
 TW2=True2(:,3);
 TW3=True2(:,4);
 TW4=True2(:,5);
 
  TP1=True3(:,5);
 TP2=True3(:,6);
 TP3=True3(:,7);
 TP4=True3(:,8);
 
 TG1=True3(:,9);
 TG2=True3(:,10);
 TG3=True4(:,2);
 TG4=True4(:,3);
 
 TFOE=True4(:,8);
 
 
 disp(' make the true observation')
 for ihistory=1:history
 obs=zeros(17,1);
 obs(1,:)=TO1(ihistory,:);
 obs(2,:)=TO2(ihistory,:);
 obs(3,:)=TO3(ihistory,:);
 obs(4,:)=TO4(ihistory,:);
 obs(5,:)=TW1(ihistory,:);
 obs(6,:)=TW2(ihistory,:);
 obs(7,:)=TW3(ihistory,:);
 obs(8,:)=TW4(ihistory,:);
 obs(9,:)=TP1(ihistory,:);
 obs(10,:)=TP2(ihistory,:);
 obs(11,:)=TP3(ihistory,:);
 obs(12,:)=TP4(ihistory,:);
 obs(13,:)=TG1(ihistory,:);
 obs(14,:)=TG2(ihistory,:);
 obs(15,:)=TG3(ihistory,:);
 obs(16,:)=TG4(ihistory,:);
 obs(17,:)=TFOE(ihistory,:);
 observation(:,ihistory)=obs;
 end


oldfolder=cd;

%% Creating Folders
disp( 'create the folders')
for j=1:N
f = 'MASTER';
folder = strcat(f, sprintf('%.5d',j));
mkdir(folder);
end

%% Coppying simulation files
disp( 'copy simulation files for the forward problem')
for j=1:N
f = 'MASTER';
folder = strcat(f, sprintf('%.5d',j));
copyfile('ACTNUM.DAT',folder)
copyfile('SPE10_PVTI.PVO',folder)
copyfile('SPE10_PVTI_RSVD.PVO',folder)
copyfile('SPE10_PVTI_WATER.PVO',folder)
copyfile('Eclipse2Matlab.m',folder)
copyfile('resize.m',folder)
copyfile('MASTER0.DATA',folder)
end


tol=input( ' enter the tolerance for pseudo inversion  ');
scheme=input( ' enter the scheme for EnKF assimilation  ');
beta=1;
%% The big history matching loop will start here

for iyobo=1:history
fprintf('Now running the code for assimilating timestep %d .\n', iyobo);   
%% Loading Porosity and Permeability ensemble files
disp(' load the permeability and porosity fields')
if iyobo==1
load sgsimporo.out; %initial porosity
load sgsim.out; %initial permeabiity

perm=reshape(sgsim,72000,N);
poro=reshape(sgsimporo,72000,N);
else
 perm=reshape(mumyperm,72000,N);
 poro=reshape(mumyporo,72000,N);   
end
cd(oldfolder) % setting original directory

%% Saving POROVANCOUVER and KVANCOUVER

for i=1:N %list of folders 
    
    f = 'MASTER';
   folder = strcat(f, sprintf('%.5d',i));
   
    cd(folder) % changing directory 
    
    PORO2=poro(:,i);
    PERMY2=perm(:,i);
    
    save('PERMY2.GRDECL','PERMY2','-ascii');
    save('PORO2.GRDECL','PORO2','-ascii');
    
    cd(oldfolder) % returning to original cd
    
end

%% Inserting KEYWORDS PORO and PERMY 

parfor i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',i));
    cd(folder)

CStr = regexp(fileread('PERMY2.GRDECL'), char(10), 'split');
CStr2 = strrep(CStr, 'toReplace', 'Replacement');
CStr2 = cat(2, {'PERMY'}, CStr2(1:end));
CStr2 = cat(2, CStr2(1:end), {'/'});
FID = fopen('PERMY2.GRDECL', 'w');
if FID < 0, error('Cannot open file'); end
fprintf(FID, '%s\n', CStr2{:});
fclose(FID);

CStr = regexp(fileread('PORO2.GRDECL'), char(10), 'split');
CStr2 = strrep(CStr, 'toReplace', 'Replacement');
CStr2 = cat(2, {'PORO'}, CStr2(1:end));
CStr2 = cat(2, CStr2(1:end), {'/'});
FID = fopen('PORO2.GRDECL', 'w');
if FID < 0, error('Cannot open file'); end
fprintf(FID, '%s\n', CStr2{:});
fclose(FID);

cd(oldfolder) % setting original directory

end


%% Running Simulations
disp( 'Solve the Forward problem' )
cd(oldfolder) % setting original directory

parfor i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',i));
    cd(folder)   

    fid = fopen('MASTER0.bat', 'w');
    fprintf(fid,'@ECHO OFF\n');
    % fprintf(fid,'SET SLBSLS_LICENSE_FILE=27008@eclipse.cc.ic.ac.uk\n');
    fprintf(fid,'SET SLBSLS_LICENSE_FILE=27000@10.99.15.78\n');
    fprintf(fid,'@ECHO OFF\n');
    fprintf(fid,['c:\\ecl\\macros\\$eclipse ', 'MASTER0'],'\n');
    fclose(fid);
    %while ~exist('HM.F0016','file')
        system('MASTER0.bat')
    %end

    cd(oldfolder) % setting original directory
    
end


disp(' plot production profile')
N=100;



oldfolder=cd;
cd(oldfolder) % setting original directory

disp('  start the plotting  ');

    for i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',i));
    %folder=oldfolder;
    %cd 'C:\Work\GSLIB\sgsim\EnKFMATLABRun'   
    cd(folder);
   
        
  
    
    %Saturation data lines [2939-5206]
    A1 = importdata('MASTER0.RSM',' ',7);
    A2 = importdata('MASTER0.RSM',' ',50);
    A3 = importdata('MASTER0.RSM',' ',93);
	A4 = importdata('MASTER0.RSM',' ',136);
    
    A1=A1.data;
    A2=A2.data;
    A3=A3.data;
	A4=A4.data;
    %SO1983=ones(2268,4)-SW1983;
    
    %save('P1983.out','P1983','-ascii');
    %save('SW1983.out','SW1983','-ascii');
    
    
     WOPR1=A1(:,3);
     WOPR2=A1(:,4);
     WOPR3=A1(:,5);
     WOPR4=A1(:,6);
     Time=A1(:,1);
     
     WWCT1=A2(:,2);
     WWCT2=A2(:,3);
     WWCT3=A2(:,4);
     WWCT4=A2(:,5);
     
     BHP1=A3(:,5);
     BHP2=A3(:,6);
     BHP3=A3(:,7);
     BHP4=A3(:,8);
	 
	 GORP1=A3(:,9);
     GORP2=A3(:,10);
     GORP3=A4(:,2);
     GORP4=A4(:,3);
	 
	 
	FOE=A4(:,8);
	 
     
    %Saturation
    
    WOPRA(:,i)=WOPR1;
    WOPRB(:,i)=WOPR2;
    WOPRC(:,i)=WOPR3;
    WOPRD(:,i)=WOPR4;
    
    WCTA(:,i)=WWCT1;
    WCTB(:,i)=WWCT2;
    WCTC(:,i)=WWCT3;
    WCTD(:,i)=WWCT4;
    
    BHPA(:,i)=BHP1;
    BHPB(:,i)=BHP2;
    BHPC(:,i)=BHP3;
    BHPD(:,i)=BHP4;
	
	GORA(:,i)=GORP1;
    GORB(:,i)=GORP2;
    GORC(:,i)=GORP3;
    GORD(:,i)=GORP4;
	
	FOEA(:,i)=FOE;
	
    
    cd(oldfolder);
    end
   cd(oldfolder) % returning to original directory
 %Import true production data
 True= importdata('Real.RSM',' ',7);
 True2= importdata('Real.RSM',' ',50);
 True3= importdata('Real.RSM',' ',93);
 True4= importdata('Real.RSM',' ',136);
 
 True=True.data;
 True2=True2.data;
 True3=True3.data;
  True4=True4.data;
 
 
 TO1=True(:,3);
 TO2=True(:,4);
 TO3=True(:,5);
 TO4=True(:,6);
 
  TW1=True2(:,2);
 TW2=True2(:,3);
 TW3=True2(:,4);
 TW4=True2(:,5);
 
  TP1=True3(:,5);
 TP2=True3(:,6);
 TP3=True3(:,7);
 TP4=True3(:,8);
 
 TG1=True3(:,9);
 TG2=True3(:,10);
 TG3=True4(:,2);
 TG4=True4(:,3);
 
 TFOE=True4(:,8);
 
 
 grey = [0.4,0.4,0.4]; 
 linecolor1 = colordg(4);
%% Plot for oil production rates
 figure()
 %subplot(2,2,1)
 plot(Time,WOPRA(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Q_o(Sm^{3}/day)','FontName','Helvetica', 'Fontsize', 13);
 ylim([0 25000])
title('Producer 1','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TO1,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 25000],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'PRO1_OIL','epsc')
close(figure)
 %subplot(2,2,2)
 figure()
 plot(Time,WOPRB(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Q_o(Sm^{3}/day)','FontName','Helvetica', 'Fontsize', 13);
ylim([0 25000])
title('Producer 2','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TO2,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 25000],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'PRO2_OIL','epsc')
close(figure)

figure()
 %subplot(2,2,3)
 plot(Time,WOPRC(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Q_o(Sm^{3}/day)','FontName','Helvetica', 'Fontsize', 13);
ylim([0 25000])
title('Producer 3','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TO3,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 25000],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'PRO3_OIL','epsc')
close(figure)

figure()
 %subplot(2,2,4)
 plot(Time,WOPRD(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Q_o(Sm^{3}/day)','FontName','Helvetica', 'Fontsize', 13);
ylim([0 25000])
title('Producer 4','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TO4,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 25000],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'PRO4_OIL','epsc')
close(figure)
%% Plot for water cut
figure()
 %subplot(2,2,1)
 plot(Time,WCTA(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Water cut','FontName','Helvetica', 'Fontsize', 13);
title('Producer 1','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TW1,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'PRO1_WATER','epsc')
close(figure)

figure()
 %subplot(2,2,2)
  plot(Time,WCTB(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Water cut','FontName','Helvetica', 'Fontsize', 13);
title('Producer 2','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TW2,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'PRO2_WATER','epsc')
close(figure)

figure()
 %subplot(2,2,3)
  plot(Time,WCTC(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Water cut','FontName','Helvetica', 'Fontsize', 13);
title('Producer 3','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TW3,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'PRO3_WATER','epsc')
close(figure)

figure()
 %subplot(2,2,4)
  plot(Time,WCTD(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Water cut','FontName','Helvetica', 'Fontsize', 13);
title('Producer 4','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TW4,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'PRO4_WATER','epsc')
close(figure)
%% Plot for BHP
figure()
 %subplot(2,2,1)
 plot(Time,BHPA(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('BHP(BARSA)','FontName','Helvetica', 'Fontsize', 13);
title('Injector 1','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TP1,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 500],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'inj1_BHP','epsc')
close(figure)

figure()
 %subplot(2,2,2)
   plot(Time,BHPB(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('BHP(BARSA)','FontName','Helvetica', 'Fontsize', 13);
title('Injector 2','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TP2,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 500],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'inj2_BHP','epsc')
close(figure)

figure()
 %subplot(2,2,3)
   plot(Time,BHPC(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('BHP(BARSA)','FontName','Helvetica', 'Fontsize', 13);
title('Injector 3','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TP3,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 500],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'inj3_BHP','epsc')
close(figure)
figure()
 %subplot(2,2,4)
   plot(Time,BHPD(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('BHP(BARSA)','FontName','Helvetica', 'Fontsize', 13);
title('Injector 4','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TP4,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 500],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'inj4_BHP','epsc')
close(figure)

%% Plot for GOR
figure()
 %subplot(2,2,1)
 plot(Time,GORA(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Gas oil ratio(Sm^{3}/Sm^{3})','FontName','Helvetica', 'Fontsize', 13);
title('Gas oil ratio for producer 1','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TG1,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1000],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'PRO1_GOR','epsc')
close(figure)

figure()
 %subplot(2,2,2)
   plot(Time,GORB(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Gas oil ratio(Sm^{3}/Sm^{3})','FontName','Helvetica', 'Fontsize', 13);
title('Gas oil ratio for producer 2','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TG2,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1000],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'PRO2_GOR','epsc')
close(figure)

figure()
 %subplot(2,2,3)
   plot(Time,GORC(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Gas oil ratio(Sm^{3}/Sm^{3})','FontName','Helvetica', 'Fontsize', 13);
title('Gas oil ratio for producer 3','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TG3,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1000],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'PRO3_GOR','epsc')
close(figure)

figure()
 %subplot(2,2,4)
   plot(Time,GORD(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Gas oil ratio(Sm^{3}/Sm^{3})','FontName','Helvetica', 'Fontsize', 13);
title('Gas oil ratio for producer 4','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TG4,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1000],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'PRO4_GOR','epsc')
close(figure)


 figure()
 plot(Time,FOEA(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Oil recovery ratio','FontName','Helvetica', 'Fontsize', 13);
title('Field oil recovery ratio','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TFOE,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'Oilrecovery','epsc')
close(figure)
for i=1:N
    EWOP1(i,:)=immse(WOPRA(:,i),TO1);
    EWOP2(i,:)=immse(WOPRB(:,i),TO2);
    EWOP3(i,:)=immse(WOPRC(:,i),TO3);
    EWOP4(i,:)=immse(WOPRD(:,i),TO4);
    EWCT1(i,:)=immse(WCTA(:,i),TW1);
    EWCT2(i,:)=immse(WCTB(:,i),TW2);
    EWCT3(i,:)=immse(WCTC(:,i),TW3);
    EWCT4(i,:)=immse(WCTD(:,i),TW4);
    EBHP1(i,:)=immse(BHPA(:,i),TP1);
    EBHP2(i,:)=immse(BHPB(:,i),TP2);
    EBHP3(i,:)=immse(BHPC(:,i),TP3);
    EBHP4(i,:)=immse(BHPD(:,i),TP4);
	EGORP1(i,:)=immse(GORA(:,i),TG1);
    EGORP2(i,:)=immse(GORB(:,i),TG2);
    EGORP3(i,:)=immse(GORC(:,i),TG3);
    EGORP4(i,:)=immse(GORD(:,i),TG4);
end
TOTALERROR=ones(100,1);
TOTALERROR=(EWOP1./std(TO1))+(EWOP2./std(TO2))+(EWOP3./std(TO3))+...
    (EWOP4./std(TO4))+(EWCT1./std(TW1))+(EWCT2./std(TW2))...
    +(EWCT3./std(TW3))+(EWCT4./std(TW4))+(EBHP1./std(TP1))...
    +(EBHP2./std(TP2))+(EBHP3./std(TP3))+(EBHP4./std(TP4))...
	+(EGORP1./std(TG1))+(EGORP2./std(TG2))+(EGORP3./std(TG3))+(EGORP4./std(TG4));
TOTALERROR=TOTALERROR./36;
jj=min(TOTALERROR);
index = TOTALERROR; 
bestnorm = find(index == min(index));
	%Pssim = Pnew(:,bestssim); %best due to ssim
fprintf('The best Norm Realization is number %i with value %4.4f \n',bestnorm,jj);
% JOYLINE=[1:100]';
% figure()
%bar(JOYLINE,TOTALERROR);

reali=[1:100]';

 figure()
 bar(reali,index,'cyan');
 xlabel('Realizations', 'FontName','Helvetica', 'Fontsize', 13);
 ylabel('RMSE value', 'FontName','Helvetica', 'Fontsize', 13);
 title('Cost function for Realizations','FontName','Helvetica', 'Fontsize', 13)
 set(gcf,'color', 'white');
 hold on
 scatter(reali,index,'black','filled');
 xlabel('Realizations', 'FontName','Helvetica', 'Fontsize', 13)
 ylabel('RMSE value', 'FontName','Helvetica', 'Fontsize', 13)
 hold off
 xlim([1,100]);
 saveas(gcf,'RMS','epsc')
close(figure)

 disp('  program almost executed  ');
 file = fopen('normenkf.out','w+'); 
 for k=1:numel(index)                                                                       
 fprintf(file,' %4.4f \n',index(k) );             
 end


 
 
 disp( 'Get the simulated files for all the time step')
 N=100;


oldfolder=cd;
cd(oldfolder) % setting original directory


cd(oldfolder) % setting original directory


overallsim=zeros(17,history,N);
    for ii=1:N %list of folders 
    
      f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',ii));
    cd(folder)   
    
  True= importdata('MASTER0.RSM',' ',7);
  A2 = importdata('MASTER0.RSM',' ',50);
  A3 = importdata('MASTER0.RSM',' ',93);
  A4 = importdata('MASTER0.RSM',' ',136);
 
 
 
 True=True.data;
 A2=A2.data;
 A3=A3.data;
 A4=A4.data;
 
 
 TO1=True(:,3);
 TO2=True(:,4);
 TO3=True(:,5);
 TO4=True(:,6);

     
     WWCT1=A2(:,2);
     WWCT2=A2(:,3);
     WWCT3=A2(:,4);
     WWCT4=A2(:,5);
     
     BHP1=A3(:,5);
     BHP2=A3(:,6);
     BHP3=A3(:,7);
     BHP4=A3(:,8);
	 
	 GORP1=A3(:,9);
     GORP2=A3(:,10);
     GORP3=A4(:,2);
     GORP4=A4(:,3);
	 
	 
	FOE=A4(:,8);

 for i=1:history
 obs=zeros(17,1);
 obs(1,:)=TO1(i,:);
 obs(2,:)=TO2(i,:);
 obs(3,:)=TO3(i,:);
 obs(4,:)=TO4(i,:);
 obs(5,:)=WWCT1(i,:);
 obs(6,:)=WWCT2(i,:);
 obs(7,:)=WWCT3(i,:);
 obs(8,:)=WWCT4(i,:);
 obs(9,:)=BHP1(i,:);
 obs(10,:)=BHP2(i,:);
 obs(11,:)=BHP3(i,:);
 obs(12,:)=BHP4(i,:);
 obs(13,:)=GORP1(i,:);
 obs(14,:)=GORP2(i,:);
 obs(15,:)=GORP3(i,:);
 obs(16,:)=GORP4(i,:);
 obs(17,:)=FOE(i,:);
 
 observationsim(:,i)=obs;
 end
        
   overallsim(:,:,ii)=observationsim; 
    cd(oldfolder) % returning to original directory

    end

cd(oldfolder) % returning to original directory
  
 

% SEn89=reshape(SEn83,36000*history*N,1);
% PEn89=reshape(PEn83,36000*history*N,1);

N=100;


cd(oldfolder) % returning to original directory

[mumyperm,mumyporo]=main_EnKFyap(iyobo,N,tol,scheme,beta,observation,overallsim,rossmary,rossmaryporo,perm,poro,history);
fprintf('Finished assimilating timestep %d .\n', iyobo);
end
response=input('Do you want to plot the permeabilit map');
disp('1=yes')
disp('2=no' )
switch response
    case 1
     run('plot3D.m')
    otherwise
      disp('pixel map not needed')
end
disp('  program executed  ');