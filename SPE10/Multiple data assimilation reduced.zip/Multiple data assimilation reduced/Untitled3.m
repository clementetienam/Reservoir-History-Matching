clc;
clear;
N=100;
load sgsim.out;
sgsim=reshape(sgsim,72000,N);
for i=1:N
sgsimuse=reshape(sgsim(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,36000,1);
sg(:,i)=ex;
end
[clementLL,clementLH,clementHH,clementHL,sX] = DWTobtain(sg, N,120,60,5);

disp('get back')
clementperm = DWTreconstruct(clementLL,clementLH,clementHL,clementHH,N,120,60,5,sX);