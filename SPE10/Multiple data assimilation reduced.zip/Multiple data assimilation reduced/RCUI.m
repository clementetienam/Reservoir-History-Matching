clc;
clear;
load sgsim.out;
N=100;
nx=120;ny=60;nz=5;
sgsim=reshape(sgsim,72000,N);
load sgsimporo.out;
N=100;
%% Get standard deviation of sand and shale facies
for i=1:N
sgsimuse=reshape(sgsim(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,nx*ny*nz,1);
sg(:,i)=ex;
end

for i=1:N
sgsimuse=reshape(sgsim(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,nx*ny*nz,1);
sgyobo(:,i)=ex;
end
a=log(sg);
disp(' Find values greater than 100')
for i=1:N
    %% for permeabiity
    aa=a(:,i);
indices=find(a(:,i)>=4.605);
indices2=find(a(:,i)<4.605);
kk=aa(indices); % permeability greater than 100mD
kk2=aa(indices2); %permeability less than 100mD

stdsandk(:,i)=std(kk);
stdshalek(:,i)=std(kk2);

%% for porosity
end



%%
load sgsimenkf.out;
N=100;
sgsimenkf=reshape(sgsimenkf,72000,N);
%sgsimporo=reshape(poro,72000,N);
for i=1:N
sgsimuse=reshape(sgsimenkf(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,nx*ny*nz,1);
sg(:,i)=ex;
end
nx=120;ny=60;nz=5;
a=log(sg);
% aa=rossmary;
% b=rossmaryporo;

disp(' Find values greater than 100')
for i=1:N
    %% for permeabiity
    aa=a(:,i);
indices=find(a(:,i)>=4.605);
indices2=find(a(:,i)<4.605);
kk=aa(indices); % permeability greater than 100mD
kk2=aa(indices2); %permeability less than 100mD

meansandk(:,i)=mean(kk);
meanshalek(:,i)=mean(kk2);

faciesratio=(numel(kk)/(numel(kk)+numel(kk2)));
faciesr(:,i)=faciesratio;
%% for porosity
end
disp('recover')

for i=1:N
    clem=a(:,i);
    clem=reshape(clem,nx*ny*nz,1);
    facies=faciesr(:,i);
    mKsand=meansandk(:,i);
    mKshale=meanshalek(:,i);
    sksand=stdsandk(:,i);
    skshale=stdshalek(:,i);
    for j=1:nx*ny*nz
        rightK=(clem(j,:)-mKsand)/(sksand*sqrt(2));
        rightK=1+erf(rightK);
        
        righttK=(clem(j,:)-mKshale)/(skshale*sqrt(2));
        righttK=1+erf(righttK);
        clemK(j,:)=((facies/2)*rightK)+(((1-facies)/2)*righttK);
            
    end
    requiredK(:,i)=clemK;
end
for i=1:N
%% COMPUTATION
x = a(:,i);
% Remove missing observations indicated by NaN's.
t = ~isnan(x);
x = x(t);

% Compute empirical cumulative distribution function (cdf)

%x = sort(x);

p = requiredK(:,i);   

% Generate uniform random number between 0 and 1
ur = ypdf(:,i);

% Interpolate ur from empirical cdf and extraplolate for out of range
% values.
[p, index] = unique(p); 
xr = interp1(p,x(index),ur,[],'extrap');
good(:,i)=xr;
end
good=exp(good);
%% get pdf values
for i=1:N
    PDF_on=diff([0; requiredK(:,i)]);
    overallpdf(:,i)=PDF_on;
end

%requiredK=exp(requiredK);
%% Gaussian CDF
% disp('compute the mean an standard deviation of each column')
for i=1:N
     meanfull(:,i)=mean(a(:,i));
end
  for i=1:N
     stdfull(:,i)=std(a(:,i));
  end
disp( 'make the distribution')
for i=1:N
pd(:,i) = makedist('Normal',meanfull(:,i),stdfull(:,i));
end
disp(' fit the distribution to Gaussian')
for i=1:N
ypdf(:,i) = cdf(pd(:,i),a(:,i));
end
unie=requiredK./ypdf;
for i=1:N
    xx=(requiredK(:,i).*a(:,i))./ypdf(:,i);
    yesit(:,i)=xx;
end
yesit=exp(yesit);
yesit(yesit<50)=50;
% disp( 'recover the original distribution')
% for i=1:N
% value11(:,i) = icdf('Normal',ypdf(:,i),meanfull(:,i),stdfull(:,i));
% end
% 
% disp( 'recover the original distribution')
% for i=1:N
% valuebi(:,i) = icdf('Normal',requiredK(:,i),meanfull(:,i),stdfull(:,i));
% end
for i=1:N
    gh=requiredK(:,i);
     aa=a(:,i);
    for j=1:36000
        yy(j,:)=min(aa)+((max(aa)-min(aa))*(((gh(j,:)-min(gh))/(max(gh)-min(gh)))));
        
    end
    mij(:,i)=yy;
end
mij=exp(mij);
mij=mij./10;
mij(mij<50)=50;
load rossmary.GRDECL;

cute=reshape(rossmary,120,60,10);
cute1=cute(:,:,3:7);
cute1=reshape(cute1,36000,1);
valuebi=(mij);
value11=sg;
figure()
subplot(2,2,1)
hist(log(value11(:,1)))
subplot(2,2,2)
hist(log(cute1(:,1)))
subplot(2,2,3)
hist(log(good(:,1)))
permanswers=reshape(good,nx*ny*nz,N);
poroanswers=reshape(value11,nx*ny*nz,N);

for i=1:N
sgsim=zeros(120,60,10);
sgsimporo=zeros(120,60,10);
sgsim(:,:,3:7)=reshape(permanswers(:,i),120,60,5);
sgsimporo(:,:,3:7)=reshape(poroanswers(:,i),120,60,5);

sgsimmijana(:,i)=reshape(sgsim,72000,1);
sgsimporomijana(:,i)=reshape(sgsimporo,72000,1);
end

mumyperm=sgsimmijana;
mumyporo=sgsimporomijana;


disp( 'Well locaions consisting of injector and producer well')
iInj = [30, 58, 90, 101]; % 16 wells configuration, injection wells
jInj = [55, 18, 6, 39]; % 16 wells configuration, injection wells
iProd = [14, 38, 96, 67]; % 16 wells configuration, production wells
jProd = [25, 39, 23, 41]; % 16 wells configuration, production wells
CMRmap=[0 0 0;.3 .15 .75;.6 .2 .50;1 .25 .15;.9 .5 0;.9 .9 .5;1 1 1];


    disp( 'Pixel map needed')
    [bestnorm3,PlogK]=clementPlot(mumyporo,rossmary,N,2,CMRmap);
    xr=reshape(PlogK,120*60,5);
    
plottinglocations(xr, 120, 60,5, 'Layer', iInj, jInj, iProd, jProd, min(xr), max(xr),CMRmap);
% for i=1:N
%     dd=requiredK(:,i);
%     for j=1:nx*ny*nz
%         
%     end
% end


% disp(' Find porosity values greater than 0.1805')
% kkporo=b(indices); % permeability greater than 100
% kkporo2=b(indices2);