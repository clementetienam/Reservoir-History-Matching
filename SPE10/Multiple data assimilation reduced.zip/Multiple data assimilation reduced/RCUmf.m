function [meansandk,meanshalek,faciesr,meansandp,meanshalep,faciesrp]=RCUmf(sg1,sgporo1,N)
disp(' Find values greater than 100 and 0.1805 of current ensemble')
% sgsim=reshape(sg1,72000,N);
% sgsimporo=reshape(sgporo1,72000,N);
% 
% for i=1:N
% sgsimuse=reshape(sgsim(:,i),120,60,10);
% sgs=sgsimuse(:,:,3:7);
% ex=reshape(sgs,36000,1);
% sg(:,i)=ex;
% end
% 
% for i=1:N
% sgsimporouse=reshape(sgsimporo(:,i),120,60,10);
% sgsporo=sgsimporouse(:,:,3:7);
% exporo=reshape(sgsporo,36000,1);
% sgporo(:,i)=exporo;
% end

a=log(sg1);
ap=sgporo1;
for i=1:N
    %% for permeabiity
    aa=a(:,i);
indices=find(a(:,i)>=4.605);
indices2=find(a(:,i)<4.605);
kk=aa(indices); % permeability greater than 100mD
kk2=aa(indices2); %permeability less than 100mD

meansandk(:,i)=mean(kk);
meanshalek(:,i)=mean(kk2);

faciesratio=(numel(kk)/(numel(kk)+numel(kk2)));
faciesr(:,i)=faciesratio;
%% for porosity

    aap=ap(:,i);
indicesp=find(ap(:,i)>=0.1805);
indices2p=find(ap(:,i)<0.1805);
kkp=aap(indicesp); % permeability greater than 100mD
kk2p=aap(indices2p); %permeability less than 100mD

meansandp(:,i)=mean(kkp);
meanshalep(:,i)=mean(kk2p);

faciesratiop=(numel(kkp)/(numel(kkp)+numel(kk2p)));
faciesrp(:,i)=faciesratiop;
end