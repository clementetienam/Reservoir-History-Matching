function outputall=putbackweightsp(iwall,bwall,Lwall,N,sgsim);

for j=1:N
    
     load(['netporo' num2str(j) '.mat']);
%     wb=getwb(net);
% 
% [b,IW,LW]=separatewb(net,wb);
% weights=IW{1,1};
% iwall(:,j)=weights;
  net.iw{1,1} = (iwall(:,j));
  net.b{1,1} = (bwall(:,j));
  net.lw{2,1} = (Lwall(:,j))';
  
  outputs = net(sgsim(:,j)');
  outputall(:,j)=outputs;
  
end

end