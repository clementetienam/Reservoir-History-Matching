function [mumyperm,mumyporo]=main_ESMDA_Localization_NST(N,tol,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha,overallstd,overallstdporo);
%%
% N - size of ensemble

sgsim=reshape(perm,72000,N);
sgsimporo=reshape(poro,72000,N);
for i=1:N
sgsimuse=reshape(sgsim(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,36000,1);
sg(:,i)=ex;
end

for i=1:N
sgsimporouse=reshape(sgsimporo(:,i),120,60,10);
sgsporo=sgsimporouse(:,:,3:7);
exporo=reshape(sgsporo,36000,1);
sgporo(:,i)=exporo;
end


Sim11=reshape(overallsim,17,history,N);
[overallmean,overallmeanporo]=getSTDmean(sg,sgporo,nx,ny,nz,N);

%History matching using ESMDA
for i=1:history
 fprintf('Now assimilating timestep %d .\n', i);

[overalbee,overalbeeporo,overallalupha,overallaluphaporo,transformK,transformporo]=getNST(overallstd,overallstdporo,overallmean,overallmeanporo,sg,sgporo,nx,ny,nz,N);
 
Sim1=Sim11(:,i,:);
Sim1=reshape(Sim1,17,N);

f=observation(:,i);
[transformporo,transformK,overallmean,overallmeanporo] = ESMDA_Localization2_NST (transformK,transformporo,overallmean,overallmeanporo, f, N, Sim1,alpha,10);
disp( 'get the updated bee and alupha value ')
for ii=1:N
overalbee(:,ii)=sqrt(log((1+(overallstd(:,ii).^2)/(overallmean(:,ii).^2))));
overalbeeporo(:,ii)=sqrt(log((1+(overallstdporo(:,ii).^2)/(overallmeanporo(:,ii).^2))));
end
for ii=1:N
overallalupha(:,ii)=log(overallmean(:,ii))-((overalbee(:,ii).^2)/2);
overallaluphaporo(:,ii)=log(overallmeanporo(:,ii))-((overalbeeporo(:,ii).^2)/2);
 end


[DupdateK,sgsim2]=backtransformNST(transformK,transformporo,overalbee,overalbeeporo,overallalupha,overallaluphaporo);
%condition the data
[output,outputporo] = honour2(rossmary, rossmaryporo, N,sgsim2,DupdateK);

sg=reshape(output,36000,N);
sgporo=reshape(outputporo,36000,N);

[overallmean,overallmeanporo]=getSTDmean(sg,sgporo,nx,ny,nz,N);

 fprintf('Finished assimilating timestep %d \n', i);
end


disp('  output to ASCII files the permeability at last timestep  ');
sgassimi=sg; 
sgporoassimi=sgporo;

permanswers=reshape(sgassimi,36000,N);
poroanswers=reshape(sgporoassimi,36000,N);

for i=1:N
sgsim=zeros(120,60,10);
sgsimporo=zeros(120,60,10);
sgsim(:,:,3:7)=reshape(permanswers(:,i),120,60,5);
sgsimporo(:,:,3:7)=reshape(poroanswers(:,i),120,60,5);

sgsimmijana(:,i)=reshape(sgsim,72000,1);
sgsimporomijana(:,i)=reshape(sgsimporo,72000,1);
end
mumyperm=sgsimmijana;
mumyporo=sgsimporomijana;

 disp('  program executed  ');
end
%end
 %plot the mean and variance for each timestep
 %run('plot3D.m')
 
 