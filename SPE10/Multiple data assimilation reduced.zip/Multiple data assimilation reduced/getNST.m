function [overalbee,overalbeeporo,overallalupha,overallaluphaporo,transformK,transformporo]=getNST(overallstd,overallstdporo,overallmean,overallmeanporo,sgsim,sgsimporo,nx,ny,nz,N)
%% Get the normal score transform
 sgsim1=log(sgsim);
% sgz1=log(sgz);

 sgsim11 = reshape(sgsim1,nx*ny*nz,N);
 sgsim11poro = reshape(sgsimporo,nx*ny*nz,N);
disp( 'get the bee and alupha value of permeability and porosity')
for i=1:N
overalbee(:,i)=sqrt(log((1+(overallstd(:,i).^2)/(overallmean(:,i).^2))));
overalbeeporo(:,i)=sqrt(log((1+(overallstdporo(:,i).^2)/(overallmeanporo(:,i).^2))));
end
for i=1:N
overallalupha(:,i)=log(overallmean(:,i))-((overalbee(:,i).^2)/2);
overallaluphaporo(:,i)=log(overallmeanporo(:,i))-((overalbeeporo(:,i).^2)/2);
 end
 
 
 disp('transform permeability and porosity')
 for i=1:N
 transformK(:,i)=(log(sgsim11(:,i))-overallalupha(:,i))./overalbee(:,i);
 transformporo(:,i)=(log(sgsim11poro(:,i))-overallaluphaporo(:,i))./overalbeeporo(:,i);
 end
end