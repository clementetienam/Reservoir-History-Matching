clc;
clear;
load sgsim.out;
load rossmary.GRDECL;
sgsim=((reshape(sgsim,72000,100)));
N=100;
xm = mean(sgsim,2);
Xc = (sgsim - repmat(xm, 1, 100));

%  Find eigenvector and eigenvalues using SVD of data matrix
Y = Xc/sqrt(N-1); % YY' = C
[U, Sig, V] = svd(Y,'econ');
check=U*Sig*V';
Sig = diag(Sig);% convert Sigma from an diagonal matrix to a vector for convinience
reducedDim = 100;
MU=zeros(reducedDim,100);
SIGMA=eye(100,100);
R = mvnrnd(MU,SIGMA);
for i=1:N
    reali=U(:, 1:reducedDim) * diag(Sig(1:reducedDim)) * R(:,i) + xm;
    DupdateK2(:,i)=reali;
end
DupdateK2(DupdateK2<=50)=50;
DupdateK2(DupdateK2>=20000)=20000;

[clement2LL,clement2LH,clement2HH,clementHL] = DWTsigned(sgsim, N);

for i=1:N
end
disp( 'Well locaions consisting of injector and producer well')
iInj = [30, 58, 90, 101]; % 4 wells configuration, injection wells
jInj = [55, 18, 6, 39]; % 4 wells configuration, injection wells
iProd = [14, 38, 96, 67]; % 4 wells configuration, production wells
jProd = [25, 39, 23, 41]; % 4 wells configuration, production wells
CMRmap=[0 0 0;.3 .15 .75;.6 .2 .50;1 .25 .15;.9 .5 0;.9 .9 .5;1 1 1];


    [bestnorm31,PlogK1]=clementPlot(sgsim,rossmary,N,2,CMRmap);
    [bestnorm3,PlogK]=clementPlot(DupdateK2,rossmary,N,2,CMRmap);
    xr=reshape(PlogK,nx*ny,nz);
    
plottinglocations(xr, nx, ny,nz, 'Layer', iInj, jInj, iProd, jProd, min(xr), max(xr),CMRmap);
disp(' green are injector wells and blue are producers')
