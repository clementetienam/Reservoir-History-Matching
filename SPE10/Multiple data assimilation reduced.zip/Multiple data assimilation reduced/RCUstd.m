function [stdsandk,stdshalek,stdsandporo,stdshaleporo]=RCUstd(N,nx,ny,nz,sgsim,sgsimporo)
disp(' Find values greater than 100 and 0.1805 of initial ensemble')
sgsim=reshape(sgsim,72000,N);
sgsimporo=reshape(sgsimporo,72000,N);
%% Get standard deviation of sand and shale facies
for i=1:N
sgsimuse=reshape(sgsim(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,nx*ny*nz,1);
sg(:,i)=ex;
end

for i=1:N
sgsimporouse=reshape(sgsimporo(:,i),120,60,10);
sgsporo=sgsimporouse(:,:,3:7);
exporo=reshape(sgsporo,nx*ny*nz,1);
sgporo(:,i)=exporo;
end
a=log(sg);
aporo=sgporo;
disp(' Find values greater than 100mD and 0.1805')
for i=1:N
    %% for permeabiity
    aa=a(:,i);
indices=find(a(:,i)>=4.605);
indices2=find(a(:,i)<4.605);
kk=aa(indices); % permeability greater than 100mD
kk2=aa(indices2); %permeability less than 100mD

stdsandk(:,i)=std(kk);
stdshalek(:,i)=std(kk2);

%% for porosity
    aaporo=aporo(:,i);
indicesp=find(aporo(:,i)>=0.1805);
indices2p=find(aporo(:,i)<0.1805);
kkp=aaporo(indicesp); % permeability greater than 100mD
kk2p=aaporo(indices2p); %permeability less than 100mD

stdsandporo(:,i)=std(kkp);
stdshaleporo(:,i)=std(kk2p);


end

end