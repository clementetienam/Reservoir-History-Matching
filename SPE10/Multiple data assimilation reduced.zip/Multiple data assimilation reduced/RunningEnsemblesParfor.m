%----------------------------------------------------------------------------------
% Running Ensembles
% the code couples ECLIPSE reservoir simulator with MATLAB used to generate
% multiple Pressure (P) Oil Saturation and Acoustic Impedance realisations.
% Student: Polad Khasayev, M.Eng Petroleum Engineering 2013-2017
% Supervisor:Rossmary Villegas
%-----------------------------------------------------------------------------------
%% 

clc
clear

% N - size of ensemble

N=20;

oldfolder=cd;

%% Creating Folders

for j=1:N
f = 'MASTER';
folder = strcat(f, num2str(j)); 
mkdir(folder);
end

%% Coppying simulation files

for j=1:N
f = 'MASTER';
folder = strcat(f, num2str(j)); 
copyfile('Gassmann.m',folder)
copyfile('field2Metric.m',folder)
copyfile('Eclipse2Matlab.m',folder)
copyfile('HM.data',folder)
copyfile('FAULT.DAT',folder)
copyfile('Matlab2Eclipse.m',folder)
end

%% Loading Porosity and Permeability

load poro20.out;
load perm20.out;

perm=reshape(poro20,9072,N);
poro=reshape(poro20,9072,N);

cd(oldfolder) % setting original directory

%% Saving POROVANCOUVER and KVANCOUVER

for i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, num2str(i)); 
   
    cd(folder) % changing directory 
    
    POROVANCOUVER=poro(:,i);
    KVANCOUVER=perm(:,i);
    
    save('KVANCOUVER.DAT','KVANCOUVER','-ascii');
    save('POROVANCOUVER.DAT','POROVANCOUVER','-ascii');
    
    cd(oldfolder) % returning to original cd
    
end

%% Inserting KEYWORDS PORO and PERMY 

for i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, num2str(i)); 
    cd(folder)

CStr = regexp(fileread('KVANCOUVER.DAT'), char(10), 'split');
CStr2 = strrep(CStr, 'toReplace', 'Replacement');
CStr2 = cat(2, {'PERMY'}, CStr2(1:end));
CStr2 = cat(2, CStr2(1:end), {'/'});
FID = fopen('KVANCOUVER.DAT', 'w');
if FID < 0, error('Cannot open file'); end
fprintf(FID, '%s\n', CStr2{:});
fclose(FID);

CStr = regexp(fileread('POROVANCOUVER.DAT'), char(10), 'split');
CStr2 = strrep(CStr, 'toReplace', 'Replacement');
CStr2 = cat(2, {'PORO'}, CStr2(1:end));
CStr2 = cat(2, CStr2(1:end), {'/'});
FID = fopen('POROVANCOUVER.DAT', 'w');
if FID < 0, error('Cannot open file'); end
fprintf(FID, '%s\n', CStr2{:});
fclose(FID);

cd(oldfolder) % setting original directory

end


%% Running Simulations

cd(oldfolder) % setting original directory

parfor i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, num2str(i)); 
    cd(folder)   

    fid = fopen('HM.bat', 'w');
    fprintf(fid,'@ECHO OFF\n');
    % fprintf(fid,'SET SLBSLS_LICENSE_FILE=27008@eclipse.cc.ic.ac.uk\n');
    fprintf(fid,'SET SLBSLS_LICENSE_FILE=27000@10.99.15.78\n');
    fprintf(fid,'@ECHO OFF\n');
    fprintf(fid,['c:\\ecl\\macros\\$eclipse ', 'HM'],'\n');
    fclose(fid);
    while ~exist('HM.F0016','file')
        system('HM.bat')
    end

    cd(oldfolder) % setting original directory
    
end



%% Saving Pressure & Saturation Ensemble 

cd(oldfolder) % setting original directory

for m=1:2

    for i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, num2str(i)); 
    cd(folder)   
    
    if m==1  % 1983
        
    %Pressure data lines [670-2937]
    P1983 = importdata('HM.F0001',' ',669);
    P1983=P1983.data;
    
    %Saturation data lines [2939-5206]
    SW1983 = importdata('HM.F0001',' ',2938);
    SW1983=SW1983.data;
    SO1983=ones(2268,4)-SW1983;
    
    save('P1983.out','P1983','-ascii');
    save('SO1983.out','SO1983','-ascii');
    
    %Reshape 
    %Pressure
    A=P1983;
    B=Eclipse2Matlab(A);
    PEn83(:,i)=B;
    %Saturation
    A=SO1983;
    B=Eclipse2Matlab(A);
    SEn83(:,i)=B;  
    end
    
    if m==2  % 1989
   
    %Pressure data lines [670-2937]
    P1989 = importdata('HM.F0016',' ',669);
    P1989=P1989.data;
    
    %Saturation data lines [2939-5206]
    SW1989 = importdata('HM.F0016',' ',2938);
    SW1989=SW1989.data;
    SO1989=ones(2268,4)-SW1989;
    
    save('P1989.out','P1989','-ascii');
    save('SO1989.out','SO1989','-ascii');
    
    %Reshape 
    %Pressure
    A=P1989;
    B=Eclipse2Matlab(A);
    PEn89(:,i)=B;
    %Saturation
    A=SO1989;
    B=Eclipse2Matlab(A);
    SEn89(:,i)=B;  
    end
    
    cd(oldfolder) % returning to original directory

    end
end


PEn83=reshape(PEn83,9072*N,1);
SEn83=reshape(SEn83,9072*N,1);

PEn89=reshape(PEn89,9072*N,1);
SEn89=reshape(SEn89,9072*N,1);

cd(oldfolder) % returning to original directory

save('PEn83.out','PEn83','-ascii');
save('SEn83.out','SEn83','-ascii');
save('PEn89.out','PEn89','-ascii');
save('SEn89.out','SEn89','-ascii');

%% Construction of Synthetic Seismic using Gassmann's equation

cd(oldfolder) % returning to original directory

for m=1:2

    for i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, num2str(i)); 
    cd(folder)
    
    %Loading values
    if m==1
    PORO = importdata('POROVANCOUVER.DAT',' ',1);
    PORO=PORO.data;
    Pr=load('P1983.out');
    SO=load('SO1983.out');
    end
    
    if m==2
    PORO = importdata('POROVANCOUVER.DAT',' ',1);
    PORO=PORO.data;
    Pr=load('P1989.out');
    SO=load('SO1989.out');
    end
    
        %Calc Impedance
    ImpP=Gassmann(PORO,Pr,SO);

    %Saving Results
    if m==1
        save('I1983.out','ImpP', '-ascii');
        IEn83(:,i)=reshape(ImpP,2268,1);
    end
    if m==2
        save('I1989.out','ImpP', '-ascii');
        IEn89(:,i)=reshape(ImpP,2268,1);
    end

    cd(oldfolder) % setting original directory
    
    end
end

if m==1
    IEn83=reshape(IEn83,2268*N,1);
end    

if m==2
    IEn89=reshape(IEn89,2268*N,1);
end

save('IEn83.out','IEn83','-ascii');
save('IEn89.out','IEn89','-ascii');

run Assimilate.m % data assimilation
