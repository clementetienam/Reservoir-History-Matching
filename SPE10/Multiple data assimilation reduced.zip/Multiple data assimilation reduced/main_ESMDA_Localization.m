function [mumyperm,mumyporo]=main_ESMDA_Localization(N,tol,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha);
disp( 'History matching data assimilation technique using ES-MDA  with covariance localization for SPE10 Reservoir'  ) 
disp( 'PhD Student: Clement Etienam' )
disp( 'Supervisor: Dr Rossmary Villegas' )
disp( 'Co-supervisor: Dr Masoud Babei' )
disp( 'Co-supervisor: Dr Oliver Dorn' )
disp('  import the true data  ');
% N - size of ensemble



sgsim=reshape(perm,72000,N);
sgsimporo=reshape(poro,72000,N);
for i=1:N
sgsimuse=reshape(sgsim(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,36000,1);
sg(:,i)=ex;
end

for i=1:N
sgsimporouse=reshape(sgsimporo(:,i),120,60,10);
sgsporo=sgsimporouse(:,:,3:7);
exporo=reshape(sgsporo,36000,1);
sgporo(:,i)=exporo;
end

Sim11=reshape(overallsim,17,history,N);


%History matching using ESMDA
for i=1:history
 fprintf('Now assimilating timestep %d .\n', i);

 
Sim1=Sim11(:,i,:);
Sim1=reshape(Sim1,17,N);

f=observation(:,i);
[sgsim2,DupdateK] = ESMDA_Localization2 (sg,sgporo, f, N, Sim1,alpha,10);

%condition the data
[output,outputporo] = honour2(rossmary, rossmaryporo, N,sgsim2,DupdateK);

sg=reshape(output,36000,N);
sgporo=reshape(outputporo,36000,N);


 fprintf('Finished assimilating timestep %d \n', i);
end


disp('  output to ASCII files the permeability at last timestep  ');
sgassimi=sg; 
sgporoassimi=sgporo;

permanswers=reshape(sgassimi,36000,N);
poroanswers=reshape(sgporoassimi,36000,N);

for i=1:N
sgsim=zeros(120,60,10);
sgsimporo=zeros(120,60,10);
sgsim(:,:,3:7)=reshape(permanswers(:,i),120,60,5);
sgsimporo(:,:,3:7)=reshape(poroanswers(:,i),120,60,5);

sgsimmijana(:,i)=reshape(sgsim,72000,1);
sgsimporomijana(:,i)=reshape(sgsimporo,72000,1);
end
mumyperm=sgsimmijana;
mumyporo=sgsimporomijana;

 disp('  program executed  ');
end
%end
 %plot the mean and variance for each timestep
 %run('plot3D.m')
 
 