function [mumyperm,mumyporo]=maintain_Bimodal(orik,oriporo,mumyperm,mumyporo,nx,ny,nz,N,CMRmap)
% load sgsim.out
% load sgsimporo.out;
% load sgsimfinal.out;
% load sgsimporofinal.out;
%% This code is to maintain the bimodal distribution from SGeMS
[stdsandk,stdshalek,stdsandporo,stdshaleporo]=RCUstd(N,nx,ny,nz,orik,oriporo);
sgsim=reshape(orik,72000,N); %original permeability distribution
sgsimporo=reshape(oriporo,72000,N); %original porosity distribution

sgsimf=reshape(mumyperm,72000,N); %history matched permeability
sgsimporof=reshape(mumyporo,72000,N); %history matched porosity

for i=1:N
sgsimuse=reshape(sgsim(:,i),nx,ny,2*nz);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,nx*ny*nz,1);
sg(:,i)=ex;
end

for i=1:N
sgsimporouse=reshape(sgsimporo(:,i),nx,ny,2*nz);
sgsporo=sgsimporouse(:,:,3:7);
exporo=reshape(sgsporo,nx*ny*nz,1);
sgporo(:,i)=exporo;
end

for i=1:N
sgsimuse=reshape(sgsimf(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,nx*ny*nz,1);
sgn(:,i)=ex;
end

for i=1:N
sgsimporouse=reshape(sgsimporof(:,i),120,60,10);
sgsporo=sgsimporouse(:,:,3:7);
exporo=reshape(sgsporo,nx*ny*nz,1);
sgporon(:,i)=exporo;
end
perms=(sgn);
poros=sgporon;
[meansandk,meanshalek,faciesr,meansandp,meanshalep,faciesrp]=RCUmf(perms,poros,N);

disp(' Get the bi-gaussian CDF of updated permeability ensemble')
a=log(perms);
for ii=1:N
    clem=a(:,ii);
    clem=reshape(clem,nx*ny*nz,1);
    facies=faciesr(:,ii);
    mKsand=meansandk(:,ii);
    mKshale=meanshalek(:,ii);
    sksand=stdsandk(:,ii);
    skshale=stdshalek(:,ii);
    for j=1:nx*ny*nz
        rightK=(clem(j,:)-mKsand)/(sksand*sqrt(2));
        rightK=1+erf(rightK);
        
        righttK=(clem(j,:)-mKshale)/(skshale*sqrt(2));
        righttK=1+erf(righttK);
        clemK(j,:)=((facies/2)*rightK)+(((1-facies)/2)*righttK);
            
    end
    requiredK(:,ii)=clemK;
end
disp(' Get the bi-gaussian CDF of updated porosity ensemble')
ap=poros;
for ii=1:N
    clemp=ap(:,ii);
    clemp=reshape(clemp,nx*ny*nz,1);
    faciesp=faciesrp(:,ii);
    mKsandp=meansandp(:,ii);
    mKshalep=meanshalep(:,ii);
    sksandp=stdsandporo(:,ii);
    skshalep=stdshaleporo(:,ii);
    for j=1:nx*ny*nz
        rightKp=(clemp(j,:)-mKsandp)/(sksandp*sqrt(2));
        rightKp=1+erf(rightKp);
        
        righttKp=(clemp(j,:)-mKshalep)/(skshalep*sqrt(2));
        righttKp=1+erf(righttKp);
        clemKp(j,:)=((faciesp/2)*rightKp)+(((1-faciesp)/2)*righttKp);
            
    end
    requiredKp(:,ii)=clemKp;
end
a=log(perms);
disp('Get the gaussian distribution CDF of the updated permeabiity and porosity')
for ii=1:N
     meanfull(:,ii)=mean(a(:,ii));
end
  for ii=1:N
     stdfull(:,ii)=std(a(:,ii));
  end
disp( 'make the distribution')
for ii=1:N
pd(:,ii) = makedist('Normal',meanfull(:,ii),stdfull(:,ii));
end
disp(' fit the distribution to Gaussian')
for ii=1:N
ypdf(:,ii) = cdf(pd(:,ii),a(:,ii));
end

ap=poros;
for ii=1:N
     meanfullp(:,ii)=mean(ap(:,ii));
end
  for ii=1:N
     stdfullp(:,ii)=std(ap(:,ii));
  end
disp( 'make the distribution')
for ii=1:N
pdp(:,ii) = makedist('Normal',meanfullp(:,ii),stdfullp(:,ii));
end
disp(' fit the distribution to Gaussian')
for ii=1:N
ypdfp(:,ii) = cdf(pdp(:,ii),ap(:,ii));
end




disp('Recover the corrected ensmeble folowing a bi-Gaussian distribtion')
a=log(perms);
for ii=1:N
%% COMPUTATION
x = a(:,ii);
% Remove missing observations indicated by NaN's.
t = ~isnan(x);
x = x(t);

p = requiredK(:,ii);   

ur = ypdf(:,ii);

% Interpolate ur from empirical cdf and extraplolate for out of range
% values.
[p, index] = unique(p);
%xr = interp1(x,p,'pchip');
xr = interp1(p,x(index),ur,[],'extrap');
good(:,ii)=xr;
end
DupdateK=exp(good);

%%
ap=poros;
for ii=1:N
%% COMPUTATION
xp = ap(:,ii);
% Remove missing observations indicated by NaN's.
tp = ~isnan(xp);
xp = xp(tp);
pp = requiredKp(:,ii);   

% Generate uniform random number between 0 and 1
urp = ypdfp(:,ii);

% Interpolate ur from empirical cdf and extraplolate for out of range
% values.
[pp, indexp] = unique(pp);
%xrp = interp1(xp,pp,'pchip');
xrp = interp1(pp,xp(indexp),urp,[],'extrap');
goodp(:,ii)=xrp;
end
sgsim2=(goodp);
nemean=mean(log(DupdateK),2);
%% plot histograms
figure
subplot(2,2,1)
hist(log(sg(:,1)))
title('initial from MPS ensemble')

subplot(2,2,2)
hist(log(sgn(:,1)))
title('after history matching ensemble')

subplot(2,2,3)
hist(log(DupdateK(:,1)))
title('corrected ensemble')

subplot(2,2,4)
hist(nemean)
title('mean of corrected ensemble')

[X2,Y2] = meshgrid(1:120,1:60);
model1=reshape(log10(sg(:,1)),120,60,5);
model2=reshape(log10(sgn(:,1)),120,60,5);
model3=reshape(log10(DupdateK(:,1)),120,60,5);
%% plot permeability maps
figure()
for i=1:5
subplot(2,5,i);
surf(X2',Y2',model1(:,:,i))

shading flat
axis([1 120 1 60 ])
grid off
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap(CMRmap)
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
title(['True Layer(' num2str(i) ')'])
set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
end

figure()
for i=1:5
subplot(2,5,i);
surf(X2',Y2',model2(:,:,i))

shading flat
axis([1 120 1 60 ])
grid off
title('Model 2','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap(CMRmap)
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
title(['History matched Layer(' num2str(i) ')'])
set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
end

figure()
for i=1:5
subplot(2,5,i);
surf(X2',Y2',model3(:,:,i))

shading flat
axis([1 120 1 60 ])
grid off
title('Model 2','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap(CMRmap)
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 5])
title(['Restored Layer(' num2str(i) ')'])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
end

for i=1:N
sgsim=zeros(120,60,10);
sgsimporo=zeros(120,60,10);
sgsim(:,:,3:7)=reshape(DupdateK(:,i),120,60,5);
sgsimporo(:,:,3:7)=reshape(sgsim2(:,i),120,60,5);

sgsimmijana(:,i)=reshape(sgsim,72000,1);
sgsimporomijana(:,i)=reshape(sgsimporo,72000,1);
end

mumyperm=sgsimmijana;
mumyporo=sgsimporomijana;

end