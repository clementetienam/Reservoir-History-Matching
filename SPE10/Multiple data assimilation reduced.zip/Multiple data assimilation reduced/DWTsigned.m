%function [clement2LL,clement2LH,clement2HH,clementHL] = DWTsigned(sg, N)
%% DWT domain reduction for permeability field
clc;
clear;
disp('  DWT domain reduction for permeability  ');
%%PhD student: Clement Oku Etienam
%%Supervisor: Dr Rossmary Villegas
%%Co-supervisor: Dr Masoud Babei
%%Collaborator : Dr Oliver Dorn
disp('  Load the relevant files  ');
load sgsim.out;
sgsim=reshape(sgsim,72000,100);
sgsim1=log(sgsim);
N=100;
sgsim1=reshape(sgsim1,72000,N);
%sgsim=(sg);
LF=reshape(sgsim1,72000,N);
disp('  carry out DCT domain reduction  ');
for ii=1:N
    lf=reshape(LF(:,ii),120,60,10);
     
     for jj=1:10
         
         value=lf(:,:,jj);
         sX = size(value);
    [LL,LH,HL,HH]=dwt2(value,'db1');
         
         HH=reshape(HH,1800,1);
         youngHH(:,jj)=HH;
         
         HL=reshape(HL,1800,1);
         youngHL(:,jj)=HL;
         
         LH=reshape(LH,1800,1);
         youngLH(:,jj)=LH;
         
         LL=reshape(LL,1800,1);
         youngLL(:,jj)=LL;
     end
      sdfbigLL=reshape(youngLL,18000,1);
  clementLL(:,ii)=sdfbigLL;
  
    sdfbigLH=reshape(youngLH,18000,1);
  clementLH(:,ii)=sdfbigLH;
  
    sdfbigHL=reshape(youngHL,18000,1);
  clementHL(:,ii)=sdfbigHL;
   
   sdfbigHH=reshape(youngHH,18000,1);
  clementHH(:,ii)=sdfbigHH;
  
end
disp('  extract the significant DWT coefficients  ');

for iii=1:N
    lf2HH=reshape(clementHH(:,iii),60,30,10);
    lf2HL=reshape(clementHL(:,iii),60,30,10);
    lf2LH=reshape(clementLH(:,iii),60,30,10);
    lf2LL=reshape(clementLL(:,iii),60,30,10);
for jjj=1:10
    val1=lf2HH(1:30,1:15,jjj);
    val1=reshape(val1,450,1);
   val2HH(:,jjj)=val1;
   
   val11=lf2HL(1:30,1:15,jjj);
    val11=reshape(val11,450,1);
   val2HL(:,jjj)=val11;
   
    val111=lf2LH(1:30,1:15,jjj);
    val111=reshape(val111,450,1);
   val2LH(:,jjj)=val111;
   
    val1111=lf2LL(1:30,1:15,jjj);
    val1111=reshape(val1111,450,1);
   val2LL(:,jjj)=val1111;
   
   
end
  sdfbig2HH=reshape(val2HH,4500,1);
  clement2HH(:,iii)=sdfbig2HH;
  
  sdfbig2HL=reshape(val2HL,4500,1);
  clement2HL(:,iii)=sdfbig2HL;
  
  sdfbig2LH=reshape(val2LH,4500,1);
  clement2LH(:,iii)=sdfbig2LH;
  
  sdfbig2LL=reshape(val2LL,4500,1);
  clement2LL(:,iii)=sdfbig2LL;
end

[X,Y] = meshgrid(1:60,1:30);


CMRmap=[0 0 0;.3 .15 .75;.6 .2 .50;1 .25 .15;.9 .5 0;.9 .9 .5;1 1 1];
Trueperm=reshape(clementHL(:,2),60,30,10);



figure()
for i=1:10
subplot(2,5,i);
surf(X',Y',Trueperm(:,:,i))

shading flat
axis([1 60 1 30 ])
grid off
title('True Layer 1','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap('jet')
%caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
%set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
end
%%
value1LL=clementLL(1:18000,1:N);
value1LH=clementLH(1:18000,1:N);
value1HL=clementHL(1:18000,1:N);
value1HH=clementHH(1:18000,1:N);


valuepermjoyLL=value1LL;
valuepermjoyLH=value1LH;
valuepermjoyHL=value1HL;
valuepermjoyHH=value1HH;
for ii=1:N
    lf=reshape(valuepermjoyLL(:,ii),60,30,10);
    lfLH=reshape(valuepermjoyLH(:,ii),60,30,10);
    lfHL=reshape(valuepermjoyHL(:,ii),60,30,10);
    lfHH=reshape(valuepermjoyHH(:,ii),60,30,10);
    
     for jj=1:10
         valueperm=lf(:,:,jj);
         valuepermLH=lfLH(:,:,jj);
         valuepermHL=lfLH(:,:,jj);
          valuepermHH=lfHH(:,:,jj);
         
         %bigLL=zeros(60,30,10);
%          bigLH=zeros(60,30,10);
%          bigHL=zeros(60,30,10);
%          bigHH=zeros(60,30,10);
         
        
        LL=valueperm;
        
        
        LH=valuepermLH;
        
        
        HL=valuepermHL;
        
      
        HH= valuepermHH;
        
        rec = idwt2(LL,LH,HL,HH,'db1',sX);
      
        rec=(abs(rec));
         usdf=reshape(rec,7200,1);
         young(:,jj)=usdf;
     end
      sdfbig=reshape(young,72000,1);
  clementperm(:,ii)=sdfbig;
end

sgsim11=exp(clementperm);

DupdateK= sgsim11;
[X1,Y1] = meshgrid(1:120,1:60);

Trueperm1=reshape(log10(DupdateK(:,2)),120,60,10);
Trueperm2=reshape(log10(sgsim(:,2)),120,60,10);
figure()
for i=1:10
subplot(2,5,i);
surf(X1',Y1',Trueperm1(:,:,i))

shading flat
axis([1 120 1 60 ])
grid off
title('True Layer 1','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap('jet')
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
%set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
end

figure()
for i=1:10
subplot(2,5,i);
surf(X1',Y1',Trueperm2(:,:,i))

shading flat
axis([1 120 1 60 ])
grid off
title('True Layer 1','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap('jet')
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
%set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
end


%end