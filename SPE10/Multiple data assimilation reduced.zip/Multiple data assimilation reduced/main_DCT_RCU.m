function [mumyperm,mumyporo]=main_DCT_RCU(N,tol,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha,stdsandk,stdshalek,stdsandp,stdshalep,meansandak,meanshaleak,faciesar,meansandap,meanshaleap,faciesrap);
sgsim=reshape(perm,72000,N);
sgsimporo=reshape(poro,72000,N);
nx=120;
ny=60;
nz=5;
for i=1:N
sgsimuse=reshape(sgsim(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,36000,1);
sg(:,i)=ex;
end

for i=1:N
sgsimporouse=reshape(sgsimporo(:,i),120,60,10);
sgsporo=sgsimporouse(:,:,3:7);
exporo=reshape(sgsporo,36000,1);
sgporo(:,i)=exporo;
end

Sim11=reshape(overallsim,17,history,N);

disp( 'Get the DCT coefficients')
% clement2 = mainDCT(sg, N);
% clement2poro = DCTsigned(sgporo, N);

clement2=(sg);
clement2poro=sgporo;


for i=1:history
 fprintf('Now assimilating timestep %d .\n', i);
 
 Sim1=Sim11(:,i,:);
Sim1=reshape(Sim1,17,N);
 
f=observation(:,i);
disp(' assimilated with ES-MDA')
[clement2,clement2poro] = Assimilate_DCT_RCU (clement2,clement2poro,f, N,Sim1,tol,alpha,10);

 fprintf('Finished assimilating timestep %d \n', i);
end
[meansandk,meanshalek,faciesr,meansandp,meanshalep,faciesrp]=RCUmf(clement2,clement2poro,N);
% meansandk=meansandak;
% meanshalek=meanshaleak;
% faciesr=faciesar;
% meansandp=meansandap;
% meanshalep=meanshaleap;
% faciesrp=faciesrap;

%%
%%
% disp('inverse DCT  history matched permeability coeffcients')
% valuepermjoy=clement2;
% for ii=1:N
%     lf=reshape(valuepermjoy(:,ii),60,30,5);
%      for jj=1:5
%          valueperm=lf(:,:,jj);
%          big=zeros(120,60,5);
% 
%         big(1:60,1:30,jj)=valueperm;
%         kkperm=big(:,:,jj);
%         rec = mirt_idctn(kkperm);
%         rec=(abs(rec));
%          usdf=reshape(rec,7200,1);
%          young(:,jj)=usdf;
%      end
%       sdfbig=reshape(young,36000,1);
%   clementperm(:,ii)=sdfbig;
% end

sgsim11=(clement2);
DupdateK= clement2;
% disp( 'extract the active porosity field ')
% disp('inverse DCT history matched porosity coeffcients')
% valueporojoy=clement2poro;
% for ii=1:N
%     lf=reshape(valueporojoy(:,ii),60,30,5);
%      for jj=1:5
%          valueporo=lf(:,:,jj);
%          big=zeros(120,60,5);
% 
%         big(1:60,1:30,jj)=valueporo;
%         kkporo=big(:,:,jj);
%         rec = mirt_idctn(kkporo);
%         rec=(abs(rec));
%          usdf=reshape(rec,7200,1);
%          youngporo(:,jj)=usdf;
%      end
%       sdfbigporo=reshape(youngporo,36000,1);
%   clementporo(:,ii)=sdfbigporo;
% end

sgsim2=(clement2poro);

%% 
disp(' Get the bi-gaussian CDF of updated permeability ensemble')
a=log(DupdateK);
for ii=1:N
    clem=a(:,ii);
    clem=reshape(clem,nx*ny*nz,1);
    facies=faciesr(:,ii);
    mKsand=meansandk(:,ii);
    mKshale=meanshalek(:,ii);
    sksand=stdsandk(:,ii);
    skshale=stdshalek(:,ii);
    for j=1:nx*ny*nz
        rightK=(clem(j,:)-mKsand)/(sksand*sqrt(2));
        rightK=1+erf(rightK);
        
        righttK=(clem(j,:)-mKshale)/(skshale*sqrt(2));
        righttK=1+erf(righttK);
        clemK(j,:)=((facies/2)*rightK)+(((1-facies)/2)*righttK);
            
    end
    requiredK(:,ii)=clemK;
end
disp(' Get the bi-gaussian CDF of updated porosity ensemble')
ap=sgsim2;
for ii=1:N
    clemp=ap(:,ii);
    clemp=reshape(clemp,nx*ny*nz,1);
    faciesp=faciesrp(:,ii);
    mKsandp=meansandp(:,ii);
    mKshalep=meanshalep(:,ii);
    sksandp=stdsandp(:,ii);
    skshalep=stdshalep(:,ii);
    for j=1:nx*ny*nz
        rightKp=(clemp(j,:)-mKsandp)/(sksandp*sqrt(2));
        rightKp=1+erf(rightKp);
        
        righttKp=(clemp(j,:)-mKshalep)/(skshalep*sqrt(2));
        righttKp=1+erf(righttKp);
        clemKp(j,:)=((faciesp/2)*rightKp)+(((1-faciesp)/2)*righttKp);
            
    end
    requiredKp(:,ii)=clemKp;
end

%% 
a=log(DupdateK);
disp('Get the gaussian distribution CDF of the updated permeabiity and porosity')
for ii=1:N
     meanfull(:,ii)=mean(a(:,ii));
end
  for ii=1:N
     stdfull(:,ii)=std(a(:,ii));
  end
disp( 'make the distribution')
for ii=1:N
pd(:,ii) = makedist('Normal',meanfull(:,ii),stdfull(:,ii));
end
disp(' fit the distribution to Gaussian')
for ii=1:N
ypdf(:,ii) = cdf(pd(:,ii),a(:,ii));
end

ap=sgsim2;
for ii=1:N
     meanfullp(:,ii)=mean(ap(:,ii));
end
  for ii=1:N
     stdfullp(:,ii)=std(ap(:,ii));
  end
disp( 'make the distribution')
for ii=1:N
pdp(:,ii) = makedist('Normal',meanfullp(:,ii),stdfullp(:,ii));
end
disp(' fit the distribution to Gaussian')
for ii=1:N
ypdfp(:,ii) = cdf(pdp(:,ii),ap(:,ii));
end

%%
disp('Recover the corrected ensmeble folowing a bi-Gaussian distribtion')
a=log(DupdateK);
for ii=1:N
%% COMPUTATION
x = a(:,ii);
% Remove missing observations indicated by NaN's.
t = ~isnan(x);
x = x(t);

p = requiredK(:,ii);   

ur = ypdf(:,ii);

% Interpolate ur from empirical cdf and extraplolate for out of range
% values.
[p, index] = unique(p);
%xr = interp1(x,p,'pchip','extrap');
xr = interp1(p,x(index),ur,[],'extrap');
good(:,ii)=xr;
end
DupdateK=exp(good);

%%
ap=sgsim2;
for ii=1:N
%% COMPUTATION
xp = ap(:,ii);
% Remove missing observations indicated by NaN's.
tp = ~isnan(xp);
xp = xp(tp);
pp = requiredKp(:,ii);   

% Generate uniform random number between 0 and 1
urp = ypdfp(:,ii);

% Interpolate ur from empirical cdf and extraplolate for out of range
% values.
[pp, indexp] = unique(pp);
%xrp = interp1(xp,pp,'pchip','extrap');
xrp = interp1(pp,xp(indexp),urp,[],'extrap');
goodp(:,ii)=xrp;
end
sgsim2=(goodp);

%%
%condition the data
[output,outputporo] = honour2(rossmary, rossmaryporo, N,sgsim2,DupdateK);

sg=reshape(output,36000,N);
sgporo=reshape(outputporo,36000,N);

disp('  output to ASCII files the states at each time step  ');
sgassimi=sg; 
sgporoassimi=sgporo;
permanswers=reshape(sgassimi,36000,N);
poroanswers=reshape(sgporoassimi,36000,N);

for i=1:N
sgsim=zeros(120,60,10);
sgsimporo=zeros(120,60,10);
sgsim(:,:,3:7)=reshape(permanswers(:,i),120,60,5);
sgsimporo(:,:,3:7)=reshape(poroanswers(:,i),120,60,5);

sgsimmijana(:,i)=reshape(sgsim,72000,1);
sgsimporomijana(:,i)=reshape(sgsimporo,72000,1);
end

mumyperm=sgsimmijana;
mumyporo=sgsimporomijana;
end
 
 
 