function averagedata = avergaesimulated (perm,poro,nx,ny,nz,N,history)
oldfolder=cd;
perm=reshape(perm,nx*ny*2*nz,N);
poro=reshape(poro,nx*ny*2*nz,N);
 meank=mean(perm,2);
 meanporo=mean(poro,2);
 
 folder = 'MEANFOLDER';
mkdir(folder);

copyfile('ACTNUM.DAT',folder)
copyfile('SPE10_PVTI.PVO',folder)
copyfile('SPE10_PVTI_RSVD.PVO',folder)
copyfile('SPE10_PVTI_WATER.PVO',folder)
copyfile('Eclipse2Matlab.m',folder)
copyfile('resize.m',folder)
copyfile('MASTER0.DATA',folder)

    cd(folder)

    PORO2=meanporo;
    PERMY2=meank;   
    save('PERMY2.GRDECL','PERMY2','-ascii');
    save('PORO2.GRDECL','PORO2','-ascii');
  %cd(oldfolder)
    
CStr = regexp(fileread('PERMY2.GRDECL'), char(10), 'split');
CStr2 = strrep(CStr, 'toReplace', 'Replacement');
CStr2 = cat(2, {'PERMY'}, CStr2(1:end));
CStr2 = cat(2, CStr2(1:end), {'/'});
FID = fopen('PERMY2.GRDECL', 'w');
if FID < 0, error('Cannot open file'); end
fprintf(FID, '%s\n', CStr2{:});
fclose(FID);

CStr = regexp(fileread('PORO2.GRDECL'), char(10), 'split');
CStr2 = strrep(CStr, 'toReplace', 'Replacement');
CStr2 = cat(2, {'PORO'}, CStr2(1:end));
CStr2 = cat(2, CStr2(1:end), {'/'});
FID = fopen('PORO2.GRDECL', 'w');
if FID < 0, error('Cannot open file'); end
fprintf(FID, '%s\n', CStr2{:});
fclose(FID);

  fid = fopen('MASTER0.bat', 'w');
    fprintf(fid,'@ECHO OFF\n');
    % fprintf(fid,'SET SLBSLS_LICENSE_FILE=27008@eclipse.cc.ic.ac.uk\n');
    fprintf(fid,'SET SLBSLS_LICENSE_FILE=27000@10.99.15.78\n');
    fprintf(fid,'@ECHO OFF\n');
    fprintf(fid,['c:\\ecl\\macros\\$eclipse ', 'MASTER0'],'\n');
    fclose(fid);
    %while ~exist('HM.F0016','file')
        system('MASTER0.bat')
 
        True= importdata('MASTER0.RSM',' ',7);
 True2= importdata('MASTER0.RSM',' ',50);
 True3= importdata('MASTER0.RSM',' ',93);
 True4= importdata('MASTER0.RSM',' ',136);
 
 
 True=True.data;
 True2=True2.data;
 True3=True3.data;
 True4=True4.data;
 
 
  TO1=True(:,3);
 TO2=True(:,4);
 TO3=True(:,5);
 TO4=True(:,6);
 
 
 
 TW1=True2(:,2);
 TW2=True2(:,3);
 TW3=True2(:,4);
 TW4=True2(:,5);
 
  TP1=True3(:,5);
 TP2=True3(:,6);
 TP3=True3(:,7);
 TP4=True3(:,8);
 
 TG1=True3(:,9);
 TG2=True3(:,10);
 TG3=True4(:,2);
 TG4=True4(:,3);
 
 TFOE=True4(:,8);
 
 
 disp(' make the true observation')
 for ihistory=1:history
 obs=zeros(17,1);
 obs(1,:)=TO1(ihistory,:);
 obs(2,:)=TO2(ihistory,:);
 obs(3,:)=TO3(ihistory,:);
 obs(4,:)=TO4(ihistory,:);
 obs(5,:)=TW1(ihistory,:);
 obs(6,:)=TW2(ihistory,:);
 obs(7,:)=TW3(ihistory,:);
 obs(8,:)=TW4(ihistory,:);
 obs(9,:)=TP1(ihistory,:);
 obs(10,:)=TP2(ihistory,:);
 obs(11,:)=TP3(ihistory,:);
 obs(12,:)=TP4(ihistory,:);
 obs(13,:)=TG1(ihistory,:);
 obs(14,:)=TG2(ihistory,:);
 obs(15,:)=TG3(ihistory,:);
 obs(16,:)=TG4(ihistory,:);
 obs(17,:)=TFOE(ihistory,:);
 averagedata(:,ihistory)=obs;
 end
 cd(oldfolder)
end