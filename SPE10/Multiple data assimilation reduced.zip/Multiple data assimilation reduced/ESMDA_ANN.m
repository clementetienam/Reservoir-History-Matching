function [iwall,bwall,Lwall,iwallp,bwallp,Lwallp] = ESMDA_ANN (iwall,bwall,Lwall,iwallp,bwallp,Lwallp, f, N, Sim1,alpha,tol);

% Artificial Neural network history matching with ESMDA
%-----------------------------------------------------------------------------
disp( 'History matching data assimilation technique using standard ESMDA for SPE 10 Reservoir'  ) 
disp( 'PhD Student: Clement Etienam' )
disp( 'Supervisor: Dr Rossmary Villegas' )
disp( 'Co-supervisor: Dr Masoud Babei' )
disp( 'Advisor: Dr Oliver Dorn' )
disp('  load the files  ');

disp('  generate Gaussian noise for the observed measurments  ');

 stddWOPR1 = 0.15*f(1,:);
    stddWOPR2 = 0.15*f(2,:);
    stddWOPR3 = 0.15*f(3,:);
    stddWOPR4 = 0.15*f(4,:);

    stddWWCT1 = 0.2*f(5,:);
    stddWWCT2 = 0.2*f(6,:);
    stddWWCT3 =0.2*f(7,:);
    stddWWCT4 = 0.2*f(8,:);

    stddBHP1 = 0.1*f(9,:);
    stddBHP2 = 0.1*f(10,:);
    stddBHP3 = 0.1*f(11,:);
    stddBHP4 = 0.1*f(12,:);
     
    stddGORP1 = 0.15*f(13,:);
    stddGORP2 = 0.15*f(14,:);
    stddGORP3 = 0.15*f(15,:);
    stddGORP4 = 0.15*f(16,:);

    unierec=0.05*f(17,:);

Error1=ones(17,N);
Error1(1,:)=normrnd(0,stddWOPR1,1,N);
Error1(2,:)=normrnd(0,stddWOPR2,1,N);
Error1(3,:)=normrnd(0,stddWOPR3,1,N);
Error1(4,:)=normrnd(0,stddWOPR4,1,N);
Error1(5,:)=normrnd(0,stddWWCT1,1,N);
Error1(6,:)=normrnd(0,stddWWCT2,1,N);
Error1(7,:)=normrnd(0,stddWWCT3,1,N);
Error1(8,:)=normrnd(0,stddWWCT4,1,N);
Error1(9,:)= normrnd(0,stddBHP1,1,N);
Error1(10,:)= normrnd(0,stddBHP2,1,N);
Error1(11,:)= normrnd(0,stddBHP3,1,N);
Error1(12,:)= normrnd(0,stddBHP4,1,N);
Error1(13,:)= normrnd(0,stddGORP1,1,N);
Error1(14,:)= normrnd(0,stddGORP2,1,N);
Error1(15,:)= normrnd(0,stddGORP3,1,N);
Error1(16,:)= normrnd(0,stddGORP4,1,N);
Error1(17,:)= normrnd(0,unierec,1,N);



Cd2 = (Error1*Error1')./(N-1);


for i=1:N
     Dj(:,i)=f+(sqrt(alpha).*Error1(:,i));
	
 end

disp('  generate the ensemble state matrix containing parameters and states  ');

overall=zeros(600,N); %ensemble state for EnKF

overall(1:100,1:N)=iwall;
overall(101:200,1:N)=bwall;
overall(201:300,1:N)=Lwall;
overall(301:400,1:N)=iwallp;
overall(401:500,1:N)=bwallp;
overall(501:600,1:N)=Lwallp;

Y=overall; %State variable,it is important we include simulated measurements in the ensemble state variable

M = mean(Sim1,2);
% Mean of the ensemble state
M2=mean(overall,2);
%M=M'
% Get the ensemble states pertubations
for j=1:N
    S(:,j)=Sim1(:,j)-M;
end
for j=1:N
    yprime(:,j)=overall(:,j)-M2;
end


disp('  update the new ensemble  ');
Cyd=(yprime*S')./((N-1));
Cdd=(S*S')./((N-1));


[Usig,Sig,Vsig] = svd(Cdd+(alpha.*Cd2));
xsmall = diag(Sig);
Bsig = cumsum(xsmall);
valuesig=Bsig(end);
valuesig=valuesig*0.9999;
indices = find(cumsum(xsmall) >= valuesig );
toluse=xsmall(indices,:);
tol=toluse(1,:);

disp('  update the new ensemble  ');
Ynew=Y+(Cyd*pinv((Cdd+(alpha.*Cd2))))*(Dj-Sim1);
%Ynew=Y+(Cyd/(Cdd+(alpha.*Cd)))*(Dj-Sim1);



disp( 'extract the updated weights and biases ')
iwall=Ynew(1:100,1:N);
bwall=Ynew(101:200,1:N);
Lwall=Ynew(201:300,1:N);
iwallp=Ynew(301:400,1:N);
bwallp=Ynew(401:500,1:N);
Lwallp=Ynew(501:600,1:N);



end