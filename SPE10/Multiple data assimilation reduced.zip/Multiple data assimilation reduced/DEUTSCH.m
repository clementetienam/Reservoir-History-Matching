clc;
clear all;
close all;
N=100;
load sgsim.out;
load sgsimporo.out;
 sgsim1=log(sgsim);
% sgz1=log(sgz);

 sgsim11 = reshape(sgsim1,72000,N);
 sgsim11poro = reshape(sgsimporo,72000,N);
 
 disp( 'Normal score transform the permeability and porosity field')
 disp( 'get the mean and standard deviation of each ensemble');
 
 disp( 'for permeability and porosity')
 
 for i=1:N
 overallmean(:,i)=mean(sgsim11(:,i));
 overallstd(:,i)=std(sgsim11(:,i));
 
  overallmeanporo(:,i)=mean(sgsim11poro(:,i));
 overallstdporo(:,i)=std(sgsim11poro(:,i));
 end
 
disp( 'get the bee and alupha value of permeability and porosity')
for i=1:N
overalbee(:,i)=sqrt(log((1+(overallstd(:,i).^2)/(overallmean(:,i).^2))));
overalbeeporo(:,i)=sqrt(log((1+(overallstdporo(:,i).^2)/(overallmeanporo(:,i).^2))));
end
for i=1:N
overallalupha(:,i)=log(overallmean(:,i))-((overalbee(:,i).^2)/2);
overallaluphaporo(:,i)=log(overallmeanporo(:,i))-((overalbeeporo(:,i).^2)/2);
 end
 
 
 disp('transform permeability and porosity')
 for i=1:N
 transformK(:,i)=(log(sgsim11(:,i))-overallalupha(:,i))./overalbee(:,i);
 transformporo(:,i)=(log(sgsim11poro(:,i))-overallaluphaporo(:,i))./overalbeeporo(:,i);
 end
 

sgsimpermalm=transformK;
sgsimporoalm=transformporo;

disp( 'back transform the updated permeability and porosity')
for i=1:N
sgsimperm(:,i)=exp((sgsimpermalm(:,i).*overalbee(:,i))+ overallalupha(:,i));
end
for i=1:N
sgsimporo1(:,i)=exp((sgsimporoalm(:,i).*overalbeeporo(:,i))+ overallaluphaporo(:,i));
end

sgsimperm=exp(sgsimperm);

figure()
subplot(2,2,1)
hist(sgsim11(:,1))
subplot(2,2,3)
hist(transformK(:,1))

load rossmary.GRDECL;
disp( 'Well locaions consisting of injector and producer well')
iInj = [30, 58, 90, 101]; % 16 wells configuration, injection wells
jInj = [55, 18, 6, 39]; % 16 wells configuration, injection wells
iProd = [14, 38, 96, 67]; % 16 wells configuration, production wells
jProd = [25, 39, 23, 41]; % 16 wells configuration, production wells
CMRmap=[0 0 0;.3 .15 .75;.6 .2 .50;1 .25 .15;.9 .5 0;.9 .9 .5;1 1 1];


    disp( 'Pixel map needed')
    [bestnorm3,PlogK]=clementPlot(sgsimperm,rossmary,N,2,CMRmap);
    xr=reshape(PlogK,120*60,5);
    
plottinglocations(xr, 120, 60,5, 'Layer', iInj, jInj, iProd, jProd, min(xr), max(xr),CMRmap);