function [Dj,Cd2,sgsim2,DupdateK] = ESMDA_Sparsity_PhD (sgsparse,sgsparseporo,f, N, Sim1,tol,alpha);
%%History matching data assimilation technique 
%%PhD Student: Clement Etienam
%%Supervisor: Dr Rossmary Villegas
%%Co-supervisor: Dr Masoud Babei
%DESCRIPTION:
%
% PARAMETERS:
%   f           -   True data
%   sgsim           -  ensemble of simulate states
%   N           -   ensemble size
%   Sim      -   Simulated measurments
%
%-----------------------------------------------------------------------------
disp( 'History matching data assimilation technique using standard ESMDA_SELE for SPE10 Reservoir'  ) 
disp( 'PhD Student: Clement Etienam' )
disp( 'Supervisor: Dr Rossmary Villegas' )
disp( 'Co-supervisor: Dr Masoud Babei' )
disp( 'Advisor: Dr Oliver Dorn' )
disp('  load the files  ');

sgsim1=sgsparse;
% sgz1=log(sgz);

 sgsim11 = reshape(sgsim1,1500,N);


 sgsim11poro = reshape(sgsparseporo,1500,N);

disp('  generate Gaussian noise for the observed measurments  ');

 stddWOPR1 = 0.15*f(1,:);
    stddWOPR2 = 0.15*f(2,:);
    stddWOPR3 = 0.15*f(3,:);
    stddWOPR4 = 0.15*f(4,:);

    stddWWCT1 = 0.2*f(5,:);
    stddWWCT2 = 0.2*f(6,:);
    stddWWCT3 =0.2*f(7,:);
    stddWWCT4 = 0.2*f(8,:);

    stddBHP1 = 0.1*f(9,:);
    stddBHP2 = 0.1*f(10,:);
    stddBHP3 = 0.1*f(11,:);
    stddBHP4 = 0.1*f(12,:);
     
    stddGORP1 = 0.15*f(13,:);
    stddGORP2 = 0.15*f(14,:);
    stddGORP3 = 0.15*f(15,:);
    stddGORP4 = 0.15*f(16,:);

    unierec=0.05*f(17,:);

Error1=ones(17,N);
Error1(1,:)=normrnd(0,stddWOPR1,1,N);
Error1(2,:)=normrnd(0,stddWOPR2,1,N);
Error1(3,:)=normrnd(0,stddWOPR3,1,N);
Error1(4,:)=normrnd(0,stddWOPR4,1,N);
Error1(5,:)=normrnd(0,stddWWCT1,1,N);
Error1(6,:)=normrnd(0,stddWWCT2,1,N);
Error1(7,:)=normrnd(0,stddWWCT3,1,N);
Error1(8,:)=normrnd(0,stddWWCT4,1,N);
Error1(9,:)= normrnd(0,stddBHP1,1,N);
Error1(10,:)= normrnd(0,stddBHP2,1,N);
Error1(11,:)= normrnd(0,stddBHP3,1,N);
Error1(12,:)= normrnd(0,stddBHP4,1,N);
Error1(13,:)= normrnd(0,stddGORP1,1,N);
Error1(14,:)= normrnd(0,stddGORP2,1,N);
Error1(15,:)= normrnd(0,stddGORP3,1,N);
Error1(16,:)= normrnd(0,stddGORP4,1,N);
Error1(17,:)= normrnd(0,unierec,1,N);


 Cd2 = (Error1*Error1')./(N-1); % measurement error auto covariance

for i=1:N
     Dj(:,i)=f+Error1(:,i);
	
 end
   
 %simulated measurements
%load Sim.uF; %simulated measurements


%Sim1=reshape(Sim,19,200);
disp('  generate the ensemble state matrix containing parameters and states  ');
overall=zeros(3000,N); %ensemble state


overall(1:1500,1:N)=sgsim11; %sparse permeability
overall(1501:3000,1:N)=sgsim11poro; %sparse porosity


%  disp( 'inflate the ensemble')
%  rho=1.5;
%  Um = mean(overall,2);
% overall = overall - repmat(Um,1,N);
% overall = rho * overall;
% overall = overall + repmat(Um,1,N);
% disp(' done inflating the ensemble')


Y=overall; %State variable,it is important we include simulated measurements in the ensemble state variable



M = mean(Sim1,2);
% Mean of the ensemble state
M2=mean(overall,2);
%M=M'
% Get the ensemble states pertubations
for j=1:N
    S(:,j)=Sim1(:,j)-M;
end
for j=1:N
    yprime(:,j)=overall(:,j)-M2;
end


disp('  update the new ensemble  ');
Cyd=(yprime*S')./((N-1));
Cdd=(S*S')./((N-1));

% [Usig,Sig,Vsig] = svd(Cdd+(alpha.*Cd2));
% xsmall = diag(Sig);
% Bsig = cumsum(xsmall);
% valuesig=Bsig(end);
% valuesig=valuesig*0.9999;
% indices = find(cumsum(xsmall) >= valuesig );
% toluse=xsmall(indices,:);
% tol=toluse(1,:);



disp('  update the new ensemble  ');
Ynew=Y+((Cyd*pinv((Cdd+(alpha.*Cd2))))*(Dj-Sim1));
disp( 'extract the updated states ')
value1=Ynew(1:1500,1:N);


DupdateK=value1;

sgsim2=Ynew(1501:3000,1:N);


end