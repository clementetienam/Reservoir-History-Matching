clc;
clear;
clearvars;
close all;

% N - size of ensemble

N=input( ' enter the number of realizations(ensemble size)  ');


 disp('  import the true data  ');
 
 True= importdata('Real.RSM',' ',7);
 True2= importdata('Real.RSM',' ',50);
 True3= importdata('Real.RSM',' ',93);
 True4= importdata('Real.RSM',' ',136);
 
 
 True=True.data;
 True2=True2.data;
 True3=True3.data;
 True4=True4.data;
 
 
  TO1=True(:,3);
 TO2=True(:,4);
 TO3=True(:,5);
 TO4=True(:,6);
 
 
 
 TW1=True2(:,2);
 TW2=True2(:,3);
 TW3=True2(:,4);
 TW4=True2(:,5);
 
  TP1=True3(:,5);
 TP2=True3(:,6);
 TP3=True3(:,7);
 TP4=True3(:,8);
 
 TG1=True3(:,9);
 TG2=True3(:,10);
 TG3=True4(:,2);
 TG4=True4(:,3);
 
 TFOE=True4(:,8);
 
 
 disp(' make the true observation')
 for i=1:36
 obs=zeros(17,1);
 obs(1,:)=TO1(i,:);
 obs(2,:)=TO2(i,:);
 obs(3,:)=TO3(i,:);
 obs(4,:)=TO4(i,:);
 obs(5,:)=TW1(i,:);
 obs(6,:)=TW2(i,:);
 obs(7,:)=TW3(i,:);
 obs(8,:)=TW4(i,:);
 obs(9,:)=TP1(i,:);
 obs(10,:)=TP2(i,:);
 obs(11,:)=TP3(i,:);
 obs(12,:)=TP4(i,:);
 obs(13,:)=TG1(i,:);
 obs(14,:)=TG2(i,:);
 obs(15,:)=TG3(i,:);
 obs(16,:)=TG4(i,:);
 obs(17,:)=TFOE(i,:);
 observation(:,i)=obs;
 end
 
f=observation(:,1);
disp('  generate Gaussian noise for the observed measurments  ');


 stddWOPR1 = 0.15*f(1,:);
    stddWOPR2 = 0.15*f(2,:);
    stddWOPR3 = 0.15*f(3,:);
    stddWOPR4 = 0.15*f(4,:);

    stddWWCT1 = 0.2*f(5,:);
    stddWWCT2 = 0.2*f(6,:);
    stddWWCT3 =0.2*f(7,:);
    stddWWCT4 = 0.2*f(8,:);

    stddBHP1 = 0.1*f(9,:);
    stddBHP2 = 0.1*f(10,:);
    stddBHP3 = 0.1*f(11,:);
    stddBHP4 = 0.1*f(12,:);
     
    stddGORP1 = 0.15*f(13,:);
    stddGORP2 = 0.15*f(14,:);
    stddGORP3 = 0.15*f(15,:);
    stddGORP4 = 0.15*f(16,:);

    unierec=0.05*f(17,:);
 disp( ' for uncorrelated noise')
v=[stddWOPR1,stddWOPR2, stddWOPR3,stddWOPR4,stddWWCT1,stddWWCT2,stddWWCT3,...
    stddWWCT4,stddBHP1,stddBHP2,stddBHP3,stddBHP4,stddGORP1,stddGORP2,...
    stddGORP3,stddGORP4,unierec];
 v=v.^2;
 %v=[1443.45 2584.1385 2352.3 4076.9205 0.085 0.186 0.185 0.164 17.79 16.3 16.7 17.4 51.9 36.9 64.87 76.43 0.062265];
Cd2 = diag(v)./(N-1);
[a1,b1,c1]=svd(Cd2);
mean1=zeros(1,17);
pertubations = mvnrnd2(mean1,Cd2,N,0);
mij=mean(pertubations);
mij2=cov(pertubations);
%pertubations = mvnrnd(mean,Cd2);
pertubations=pertubations';
zd=mvnrnd2(mean1,eye(17),N,0);
zd=zd';
Truedata = repmat(f,1,100);
     Dj=Truedata+sqrt(6).*(sqrt(Cd2)*zd);



Error1=ones(17,N);
Error1(1,:)=normrnd(0,stddWOPR1,1,N);
Error1(2,:)=normrnd(0,stddWOPR2,1,N);
Error1(3,:)=normrnd(0,stddWOPR3,1,N);
Error1(4,:)=normrnd(0,stddWOPR4,1,N);
Error1(5,:)=normrnd(0,stddWWCT1,1,N);
Error1(6,:)=normrnd(0,stddWWCT2,1,N);
Error1(7,:)=normrnd(0,stddWWCT3,1,N);
Error1(8,:)=normrnd(0,stddWWCT4,1,N);
Error1(9,:)= normrnd(0,stddBHP1,1,N);
Error1(10,:)= normrnd(0,stddBHP2,1,N);
Error1(11,:)= normrnd(0,stddBHP3,1,N);
Error1(12,:)= normrnd(0,stddBHP4,1,N);
Error1(13,:)= normrnd(0,stddGORP1,1,N);
Error1(14,:)= normrnd(0,stddGORP2,1,N);
Error1(15,:)= normrnd(0,stddGORP3,1,N);
Error1(16,:)= normrnd(0,stddGORP4,1,N);
Error1(17,:)= normrnd(0,unierec,1,N);

Cd3=(Error1*Error1')./(N-1);
clement=corrcoef(pertubations);
clement2=corrcoef(Error1);
for i=1:N
     Dj2(:,i)=f+Error1(:,i);
	
 end
[X,Y]=meshgrid(1:17,1:100);

figure()
subplot(2,2,1)
surf(X',Y',pertubations)
shading flat
axis([1 17 1 100 ])
grid off
title('Error 1','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
colormap('jet')
caxis([-20 20])
h = colorbar;
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(2,2,2)
surf(X',Y',Error1)
shading flat
axis([1 17 1 100 ])
grid off
title('Error 2','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
colormap('jet')
caxis([-20 20])
h = colorbar;
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 %Dj=abs(Dj);
 
 %% 
 alpha1=6;
 load Simulateddata.out;
 sim=reshape(Simulateddata,17,N);
 
 disp('method 1')
 M = mean(sim,2);

for j=1:N
    S(:,j)=sim(:,j)-M;
end

Cdd=(S*S')./((N-1));
C1=Cdd+(alpha1.*Cd2);
C2=Cdd+(alpha1.*Cd3);

R1 = chol(Cd2);
Cc=(inv(R1)*Cdd*inv(R1'))+eye(17);
Cbig=R1*Cc*R1';

[Usig,Sig,Vsig] = svd(Cbig);
xsmall = diag(Sig);
Bsig = cumsum(xsmall);
valuesig=Bsig(end);
valuesig=valuesig*0.9999;
indices = find(cumsum(xsmall) >= valuesig );
toluse=xsmall(indices,:);
tol=toluse(1,:);
Cinv=pinv(Cbig,tol);
Cinreq=(inv(R1)')*Cinv*(inv(R1));

%% 2
[Usig,Sig,Vsig] = svd(C2);
xsmall = diag(Sig);
Bsig = cumsum(xsmall);
valuesig=Bsig(end);
valuesig=valuesig*0.9999;
indices = find(cumsum(xsmall) >= valuesig );
toluse=xsmall(indices,:);
tol2=toluse(1,:);
Cinreq2=pinv(C2,tol2);

[X1,Y1]=meshgrid(1:17,1:17);

figure()
subplot(2,2,1)
surf(X1',Y1',Cinreq2)
shading flat
axis([1 17 1 17 ])
grid off
title('cov 2','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
colormap('jet')
caxis([-2e-13 14e-13])
h = colorbar;
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(2,2,2)
surf(X1',Y1',Cinreq)
shading flat
axis([1 17 1 17 ])
grid off
title('cov 1','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
colormap('jet')
caxis([-2e-13 14e-13])
h = colorbar;
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

%%
disp('Get the kalman gain')
load sgsim.out;
sgsim=reshape(sgsim,72000,N);

for i=1:N
sgsimuse=reshape(sgsim(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,36000,1);
sg(:,i)=ex;
end
sg=log(sg);
M2=mean(sg,2);

for j=1:N
    yprime(:,j)=sg(:,j)-M2;
end


disp('  update the stochastic gradient  ');
Cyd=(yprime*S')./((N-1));
Kalman=Cyd*Cinreq;
Kalman2=Cyd*Cinreq2;

figure()
subplot(1,2,1)
plot(Kalman(:,1:17));
colormap('jet');

subplot(1,2,2)
plot(Kalman2(:,1:17));
colormap('jet');

%%
disp('update')
sg1=sg+Kalman*(Dj-sim);
sg2=sg+Kalman2*(Dj2-sim);

[X2,Y2] = meshgrid(1:120,1:60);
model1=reshape(sg1(:,1),120,60,5);
model2=reshape(sg2(:,1),120,60,5);
figure()
for i=1:5
subplot(2,5,i);
surf(X2',Y2',model1(:,:,i))

shading flat
axis([1 120 1 60 ])
grid off
title('Model 1','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap('jet')
caxis([3.9 9])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [3.9 9])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
end

figure()
for i=1:5
subplot(2,5,i);
surf(X2',Y2',model2(:,:,i))

shading flat
axis([1 120 1 60 ])
grid off
title('Model 2','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap('jet')
caxis([3.9 9])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [3.9 9])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
end