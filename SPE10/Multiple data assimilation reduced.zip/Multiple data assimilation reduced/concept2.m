clc;
clear;
N=100;
load sgsim.out;
sgout=zeros(3600000,1);
sgsim=reshape(sgsim,72000,N);
for i=1:N
sgsimuse=reshape(sgsim(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,36000,1);
sg(:,i)=ex;
end

 for ii=1:3600000
    if(sg(ii)>=100)
        sgout(ii)=1;
    end
 end
 		
	fstats=zeros(12,1);	
sgout=reshape(sgout,36000,N);		
 for i=1:N
     BW=sgout(:,i);
     BW=reshape(BW,120,60,5);
     for j=1:5
 stats = regionprops(BW(:,:,j),'Area','ConvexArea','Eccentricity','EquivDiameter',...
    'EulerNumber','Extent','FilledArea','MajorAxisLength','MinorAxisLength',... 
   'Orientation','Perimeter','Solidity' );
  area=stats.Area;
  convexarea=stats.ConvexArea;
  ecc=stats.Eccentricity;
  ED=stats.EquivDiameter;
  ENu=stats.EulerNumber;
  extent=stats.Extent;
  FiA=stats.FilledArea;
  Majlength=stats.MajorAxisLength;
  Minlength=stats.MinorAxisLength;
  orient=stats.Orientation;
  peri=stats.Perimeter;
  Solidicity=stats.Solidity;
  
  fstats(1,:)=area;
  fstats(2,:)=convexarea;
  fstats(3,:)=ecc;
  fstats(4,:)=ED;
  fstats(6,:)=extent;
  fstats(5,:)=ENu;
  fstats(7,:)=FiA;
  fstats(8,:)=Majlength;
  fstats(9,:)=Minlength;
  fstats(10,:)=orient;
  fstats(11,:)=peri;
  fstats(12,:)=Solidicity;
  fstatsall(:,j)=fstats;
     end
     clementstats(:,i)=reshape(fstatsall,60,1);
 end
 %clementstats is the ensemble of statistical value to be updated

load sgsimfinal.out;
sgsimfinal=reshape(sgsimfinal,72000,N);
for i=1:N
sgsimuse=reshape(sgsimfinal(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,36000,1);
sg2(:,i)=ex;
end

updatedperm=zeros(36000*N,1);
for ii=1:36000*N
    if(sg2(ii)>=100)
        updatedperm(ii)=1;
    end
	
	
end

	fstats=zeros(12,1);	
updatedperm=reshape(updatedperm,36000,N);		
 for i=1:N
     BW=updatedperm(:,i);
     BW=reshape(BW,120,60,5);
     for j=1:5
 stats1 = regionprops(BW(:,:,j),'Area','ConvexArea','Eccentricity','EquivDiameter',...
    'EulerNumber','Extent','FilledArea','MajorAxisLength','MinorAxisLength',... 
   'Orientation','Perimeter','Solidity' );
  area=stats1.Area;
  convexarea=stats1.ConvexArea;
  ecc=stats1.Eccentricity;
  ED=stats1.EquivDiameter;
  ENu=stats1.EulerNumber;
  extent=stats1.Extent;
  FiA=stats1.FilledArea;
  Majlength=stats1.MajorAxisLength;
  Minlength=stats1.MinorAxisLength;
  orient=stats1.Orientation;
  peri=stats1.Perimeter;
  Solidicity=stats1.Solidity;
  
  fstats(1,:)=area;
  fstats(2,:)=convexarea;
  fstats(3,:)=ecc;
  fstats(4,:)=ED;
  fstats(6,:)=extent;
  fstats(5,:)=ENu;
  fstats(7,:)=FiA;
  fstats(8,:)=Majlength;
  fstats(9,:)=Minlength;
  fstats(10,:)=orient;
  fstats(11,:)=peri;
  fstats(12,:)=Solidicity;
  fstatsall(:,j)=fstats;
     end
     clementstatsu(:,i)=reshape(fstatsall,60,1);
 end



updatedperm=reshape(updatedperm,36000,N);
disp('get back')
for i=1:N
    clemnelly=clementstats(:,i);
    clemnelly=reshape(clemnelly,12,5);
    nelly=clementstatsu(:,i);
    nelly=reshape(nelly,12,5);
    benter=logical(updatedperm(:,i));
    benter=reshape(benter,120,60,5);
    for j=1:5
        mom=clemnelly(:,j);
        mom2=nelly(:,j);
     Area1=mom(1,:);
  ConvexArea1=mom(2,:);
  Eccentricity1=mom(3,:);
  EquivDiameter1=mom(4,:);
  EulerNumber1=mom(6,:);
  Extent1=mom(5,:);
  FilledArea1=mom(7,:);
  MajorAxisLength1=mom(8,:);
  MinorAxisLength1=mom(9,:);
  Orientation1=mom(10,:);
 Perimeter1=mom(11,:);
  Solidity1=mom(12,:); 
  
  Area2=mom2(1,:);
  ConvexArea2=mom2(2,:);
  Eccentricity2=mom2(3,:);
  EquivDiameter2=mom2(4,:);
  EulerNumber2=mom2(6,:);
  Extent2=mom2(5,:);
  FilledArea2=mom2(7,:);
  MajorAxisLength2=mom2(8,:);
  MinorAxisLength2=mom2(9,:);
  Orientation2=mom2(10,:);
 Perimeter2=mom2(11,:);
  Solidity2=mom2(12,:); 
  
   a=[Area1 Area2];
    a=sort(a);
  
   b=[ConvexArea1 ConvexArea2];
    b=sort(b); 
    
    c=[Eccentricity1 Eccentricity2];
    c=sort(c);

 
     d=[ EquivDiameter1  EquivDiameter2];
    d=sort(d);
    
     e=[EulerNumber1  EulerNumber2];
    e=sort(e); 
    
     f=[Extent1  Extent2];
    f=sort(f);
    
     g=[FilledArea1  FilledArea2];
    g=sort(g);
    
    h=[MajorAxisLength1  MajorAxisLength2];
    h=sort(h); 
    
    I=[MinorAxisLength1  MinorAxisLength2];
    I=sort(I);
    
   J=[Orientation1  Orientation2];
    J=sort(J); 
   
  K=[Perimeter1  Perimeter2];
    K=sort(K);   
  
    %BW2=benter(:,:,j);
  
      
    
     BW2=bwpropfilt(benter(:,:,j),'Area',2);
         
%     
     BW2=bwpropfilt(BW2,'MajorAxisLength',2);
   %BW2=bwpropfilt(BW2,'MinorAxisLength',2);
    BW2=bwpropfilt(BW2,'Orientation',2);
     %BW2=bwpropfilt(benter(:,:,j),'Perimeter',2);

bw2now(:,j)=reshape(BW2,7200,1);
    end
    Ypredicted(:,i)=reshape(bw2now,36000,1);
end
Ypredicted=double(Ypredicted);
sgsim11=reshape(sg2,3600000,1);
requiredK=zeros(36000*N,1);


for iii=1:36000*N

  if (updatedperm(iii)==Ypredicted(iii)) 
    requiredK(iii)=sgsim11(iii);
  end 
  
 
   
  if ((updatedperm(iii) ~= Ypredicted(iii)) && (Ypredicted(iii)==0)) 

        
        requiredK(iii)=95;
  end
   if ((updatedperm(iii)~= Ypredicted(iii)) && (Ypredicted(iii)==1)) 

      
         requiredK(iii)=105;
    end 
 
   
  
end
requiredK=abs(requiredK);




disp( 'Well locaions consisting of injector and producer well')
iInj = [30, 58, 90, 101]; % 16 wells configuration, injection wells
jInj = [55, 18, 6, 39]; % 16 wells configuration, injection wells
iProd = [14, 38, 96, 67]; % 16 wells configuration, production wells
jProd = [25, 39, 23, 41]; % 16 wells configuration, production wells
CMRmap=[0 0 0;.3 .15 .75;.6 .2 .50;1 .25 .15;.9 .5 0;.9 .9 .5;1 1 1];

load rossmary.GRDECL;
requiredK=reshape(requiredK,36000,N);
for i=1:N
sgsim=zeros(120,60,10);
sgsimporo=zeros(120,60,10);
sgsim(:,:,3:7)=reshape(requiredK(:,i),120,60,5);


sgsimmijana(:,i)=reshape(sgsim,72000,1);

end

mumyperm=sgsimmijana;

    [bestnorm3,PlogK]=clementPlot(mumyperm,rossmary,N,2,CMRmap);
    xr=reshape(PlogK,120*60,5);
    
plottinglocations(xr, 120, 60,5, 'Layer', iInj, jInj, iProd, jProd, min(xr), max(xr),CMRmap);
disp(' green are injector wells and blue are producers')
     %run('clementPlot.m')
