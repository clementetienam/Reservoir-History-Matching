clc;
clear all;
close all;
load rossmary.GRDECL;
load sgsim.out;
sgsim=reshape(sgsim,72000,100);
A=rossmary;
[r, c] = size(A);
y = zeros(r,c);
p = zeros(r,c);
for i = 1:c                               %Looping through the column.
    for j = 1:r                           %Looping through the row in that that column.
        y(j,i) = sum(A(:,[i]) == A(j,i)); %Compare each column of the matrix with the entries in that column.
        p(j,i) = y(j,i)/r;                %Probability of each entry of a column within that column.  
    end
end
y = wprctile(A,p*100);
ff=repmat(y,1,100);
ff=reshape(ff,7200000,1);
%B = repmat(A,1,4)
y2 = datasample(reshape(sgsim,7200000,1),7200000,1,'Weights',ff);
y2=reshape(y2,72000,100);

N=100;



disp('1=yes')
disp('2=no' )
response=input('Do you want to plot the permeability map ');

disp( 'Well locaions consisting of injector and producer well')
iInj = [30, 58, 90, 101]; % 16 wells configuration, injection wells
jInj = [55, 18, 6, 39]; % 16 wells configuration, injection wells
iProd = [14, 38, 96, 67]; % 16 wells configuration, production wells
jProd = [25, 39, 23, 41]; % 16 wells configuration, production wells
CMRmap=[0 0 0;.3 .15 .75;.6 .2 .50;1 .25 .15;.9 .5 0;.9 .9 .5;1 1 1];

if response==1
    disp( 'Pixel map needed')
    [bestnorm3,PlogK]=clementPlot(y2,sgsim(:,26),N,2,CMRmap);
    xr=reshape(PlogK,120*60,5);
    
plottinglocations(xr, 120, 60,5, 'Layer', iInj, jInj, iProd, jProd, min(xr), max(xr),CMRmap);
disp(' green are injector wells and blue are producers')
     %run('clementPlot.m')
else
    disp (' pixel map not needed')
end
