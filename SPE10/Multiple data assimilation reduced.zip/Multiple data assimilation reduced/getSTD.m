function [overallstd,overallstdporo]=getSTD(perm,poro,nx,ny,nz,N)
%% Get standard deviation of initial ensemble of permeability and porosity field
 sgsim=reshape(perm,72000,N);
sgsimporo=reshape(poro,72000,N);
for i=1:N
sgsimuse=reshape(sgsim(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,36000,1);
sg(:,i)=ex;
end

for i=1:N
sgsimporouse=reshape(sgsimporo(:,i),120,60,10);
sgsporo=sgsimporouse(:,:,3:7);
exporo=reshape(sgsporo,36000,1);
sgporo(:,i)=exporo;
end
sgsim1=log(sg);

 sgsim11 = reshape(sgsim1,nx*ny*nz,N);
 sgsim11poro = reshape(sgporo,nx*ny*nz,N);
 for i=1:N
 
 overallstd(:,i)=std(sgsim11(:,i));
 
 
 overallstdporo(:,i)=std(sgsim11poro(:,i));
 end
end