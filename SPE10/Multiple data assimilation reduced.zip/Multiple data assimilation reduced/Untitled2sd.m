clc;
clear;
load sgsim.out
load sgsimporo.out;
load sgsimfinal.out;
load sgsimporofinal.out;
nx=120;
ny=60;
nz=5;
N=100;
CMRmap=[0 0 0;.3 .15 .75;.6 .2 .50;1 .25 .15;.9 .5 0;.9 .9 .5;1 1 1];
[mumyperm,mumyporo]=maintain_Bimodal(sgsim,sgsimporo,sgsimfinal,sgsimporofinal,nx,ny,nz,N,CMRmap);