clc;
clear;
load sgsim.out;
N=100;
sgsim=reshape(sgsim,72000,N);
for i=1:N
[normscore_org,o_nscore]=nscore(sgsim(:,i),1,1,5,20000,1);
nall(:,i)=normscore_org;
oall(:,i)=o_nscore;
end
%nall=nall+1.5;
disp('recover')
for i=1:N
d_out=inscore(nall(:,i),oall(:,i),'pchip');
values(:,i)=d_out;
end