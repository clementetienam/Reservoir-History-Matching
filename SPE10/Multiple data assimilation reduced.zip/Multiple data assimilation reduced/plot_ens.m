
function plot_ens(A,N,tag)
    A=log(A);
for i=1:N
sgsimuse=reshape(A(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,36000,1);
sg(:,i)=ex;
end
A=sg;
%     firsttime = ~exist('f0', 'var') | isempty(f0);
% 
%     if firsttime
%         f = figure;
%         firsttime = 1;
%         r = 0;
%     else
        %set(0, 'CurrentFigure', f0);
        r = max(abs(ylim)');
   % end
     figure()
    plot(A);
    r = max(r, max(abs(ylim)));
    rr = max(max(abs(A)));
    if rr < r / 2
        r = r / 2;
    end
    ylim([-r r]);
    title(tag);
    
   % pause;
    
end