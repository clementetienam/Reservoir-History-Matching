function [mumyperm,mumyporo]=main_RLM_Levelset(nx,ny,nz,N,tol,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alu,averagedata);
disp( 'History matching data assimilation technique using RLM+Level set for SPE10 Reservoir'  ) 

disp( 'permeability and porosity are the petro-physical properies of interest'  ) 
disp( 'PhD Student: Clement Etienam' )
disp( 'Supervisor: Dr Rossmary Villegas' )
disp( 'Co-supervisor: Dr Masoud Babei' )
disp( 'Co-supervisor: Dr Oliver Dorn' )

disp(' extract the active grid cells' )
%%
sgsim=reshape(perm,72000,N);
sgsimporo=reshape(poro,72000,N);
for i=1:N
sgsimuse=reshape(sgsim(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,36000,1);
sg(:,i)=ex;
end

for i=1:N
sgsimporouse=reshape(sgsimporo(:,i),120,60,10);
sgsporo=sgsimporouse(:,:,3:7);
exporo=reshape(sgsporo,36000,1);
sgporo(:,i)=exporo;
end

Sim11=reshape(overallsim,17,36,N);


sgout=zeros(36000*N,1);
sgoutporo=zeros(36000*N,1);

 for ii=1:36000*N
    if(sg(ii)>=100)
        sgout(ii)=1;
    end
end

 for ii=1:36000*N
    if(sgporo(ii)>=0.1805)
        sgoutporo(ii)=1;
    end
end


disp (' get the signed distance of permeability and porosity fields')
clement=getsigned(sgout,nx,ny,N);
clementporo=getsigned(sgoutporo,nx,ny,N);

%% History matching using ESMDA and Level set starts here
 for i=1:history
 fprintf('Now assimilating timestep %d .\n', i);
 
 f=observation(:,i); %true observation
 M=averagedata(:,i);
 Sim1=Sim11(:,i,:);
Sim1=reshape(Sim1,17,N); %simulated data

disp('assimilate the historical production data')

[sgsim2,DupdateK,updatedlevelset,updatedlevelsetporo] = RLM_Levelset(sg,sgporo,f, N,Sim1,clement,clementporo,alu,M);

clement=getsigned(updatedlevelset,nx,ny,N);

clementporo=getsigned(updatedlevelsetporo,nx,ny,N);

sg=DupdateK;
sgporo=sgsim2;
 fprintf('Finished assimilating timestep %d \n', i);
 end
%% maintain connectivity of facies
% for ii=1:N  
%     benter=logical(updatedlevelset(:,ii));
%     benter=reshape(benter,nx,ny,nz);
%     for jj=1:5
%     BW2=bwpropfilt(benter(:,:,jj),'Area',2);     
%      BW2=bwpropfilt(BW2,'MajorAxisLength',2); 
%     BW2=bwpropfilt(BW2,'Orientation',2);
%      bw2now(:,jj)=reshape(BW2,7200,1);
%     end
%     updatedlevelset2(:,ii)=reshape(bw2now,36000,1);
% end
% updatedlevelset=updatedlevelset2;
% updatedlevelset=double(updatedlevelset);
% 
% for ii=1:N  
%     benterp=logical(updatedlevelsetporo(:,ii));
%     benterp=reshape(benterp,nx,ny,nz);
%     for jj=1:5
%     BW2p=bwpropfilt(benterp(:,:,jj),'Area',2);     
%      BW2p=bwpropfilt(BW2p,'MajorAxisLength',2); 
%     BW2p=bwpropfilt(BW2p,'Orientation',2);
%      bw2nowp(:,jj)=reshape(BW2p,7200,1);
%     end
%     updatedlevelset2p(:,ii)=reshape(bw2nowp,36000,1);
% end
% updatedlevelsetporo=updatedlevelset2p;
% updatedlevelsetporo=double(updatedlevelsetporo);
%% update discrepancy
 
sgsim11=(DupdateK);
disp( 'rectify the conflict of permeability and porosity fields with updated Level set')
sgsim11=reshape(sgsim11,36000*N,1);
sgsim2=reshape(sgsim2,36000*N,1);
updatedlevelset=reshape(updatedlevelset,36000*N,1);
updatedlevelsetporo=reshape(updatedlevelsetporo,36000*N,1);
updatedperm=zeros(36000*N,1);
updatedporo=zeros(36000*N,1);

for ii=1:36000*N
    if(sgsim11(ii)>=100)
        updatedperm(ii)=1;
    end
	if(sgsim2(ii)>=0.1805)
        updatedporo(ii)=1;
    end
	
end


requiredK=zeros(36000*N,1);
requiredporo=zeros(36000*N,1);

for iii=1:36000*N

  if (updatedperm(iii)==updatedlevelset(iii)) 
    requiredK(iii)=sgsim11(iii);
  end 
  
  if (updatedporo(iii)==updatedlevelsetporo(iii)) 
    requiredporo(iii)=sgsim2(iii);
  end 
  
  
  if ((updatedperm(iii) ~= updatedlevelset(iii)) && (updatedlevelset(iii)==0)) 

        
        requiredK(iii)=95;
  end
   if ((updatedperm(iii)~= updatedlevelset(iii)) && (updatedlevelset(iii)==1)) 

      
         requiredK(iii)=105;
    end 
 
  
  
  if ((updatedporo(iii) ~= updatedlevelsetporo(iii)) && (updatedlevelsetporo(iii)==0)) 

        
        requiredporo(iii)=0.1795 ;
  end
   if ((updatedporo(iii)~= updatedlevelsetporo(iii)) && (updatedlevelsetporo(iii)==1)) 

      
         requiredporo(iii)=0.1895;
    end 
  
  
end
requiredK=abs(requiredK);
requiredporo=abs(requiredporo);
%% Honour and output

disp( 'condition the field and honour')
[output,outputporo] = honour2(rossmary, rossmaryporo, N,requiredporo,requiredK);
permsteps=reshape(output,36000*N,1); 
porosteps=reshape(outputporo,36000*N,1);

sgassimi=permsteps; 
sgporoassimi=porosteps;

permanswers=reshape(sgassimi,36000,N);
poroanswers=reshape(sgporoassimi,36000,N);

for i=1:N
sgsim=zeros(120,60,10);
sgsimporo=zeros(120,60,10);
sgsim(:,:,3:7)=reshape(permanswers(:,i),120,60,5);
sgsimporo(:,:,3:7)=reshape(poroanswers(:,i),120,60,5);

sgsimmijana(:,i)=reshape(sgsim,72000,1);
sgsimporomijana(:,i)=reshape(sgsimporo,72000,1);
end

mumyperm=sgsimmijana;
mumyporo=sgsimporomijana;
end
 