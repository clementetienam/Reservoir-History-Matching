clc;
clear;
clc;
clear;
load sgsim.out;
load sgsimporo2.out
load rossmary.GRDECL;
load rossmaryporo.GRDECL;
N=100;
sgsim=reshape(sgsim,72000,N);
sgsimporo=reshape(sgsimporo2,72000,N);

for i=1:N
sgsimuse=reshape(sgsim(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,36000,1);
sg(:,i)=ex;
end

for i=1:N
sgsimporouse=reshape(sgsimporo(:,i),120,60,10);
sgsporo=sgsimporouse(:,:,3:7);
exporo=reshape(sgsporo,36000,1);
sgporo(:,i)=exporo;
end
get_stats_ensemble(sgsim,sgsimporo,N,1,rossmary,rossmaryporo);