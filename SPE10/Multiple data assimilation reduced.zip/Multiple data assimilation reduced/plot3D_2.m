clc;
clear all;
close all;
load rossmary.GRDECL;
load Truephi.dat;
load Truefacies.dat;
load TrueNB.dat;
rossmary=reshape(rossmary,120,60,10);
rossmary2=rossmary(:,:,3:7);
rossmary2=reshape(rossmary2,36000,1);
CMRmap=[0 0 0;.3 .15 .75;.6 .2 .50;1 .25 .15;.9 .5 0;.9 .9 .5;1 1 1];


map2=pmkmp(6,'LinearL'	  );
disp (' 3D for SPE10 reservoir')
hfig=figure();
G2=cartGrid([120 60 5]);
plotCellData(G2,log10(rossmary2));
view(3)
%h=colorbar('vertical');
axis equal on
grid off
shading flat
caxis([1 5])
colormap(CMRmap)
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 5])
hold on
plot3([30 30],[55 55],[1 -50],'k','Linewidth',2);
text(30,55,-40,'I1','Fontsize', 11)
title('True','FontName','Helvetica', 'Fontsize', 16);
%title('I1','FontName','Helvetica', 'Fontsize', 18);
hold on
plot3([58 58],[18 18],[1 -50],'k','Linewidth',2);
text(58,18 ,-45,'I2','Fontsize', 11)
hold on
plot3([90 90],[6 6],[1 -50],'k','Linewidth',2);
text(90,6 , -45,'I3','Fontsize', 11)
hold on
plot3([101 101],[39 39],[1 -50],'k','Linewidth',2);
text(101 ,39, -25,'I4','Fontsize', 11)
hold on
plot3([14 14],[25 25],[1 -50],'r','Linewidth',2);
% text(x1(i,1),y1(i,1),z1(i,1),['   ' ...
% num2str(time(i,1))],'HorizontalAlignment','left','FontSize',8);
text(  14,25,-52,'P1','HorizontalAlignment','left','FontSize',11)
hold on
plot3([38 38],[39 39],[1 -50],'r','Linewidth',2);
text(  38,39, -44,'P2','Fontsize', 11)
hold on
plot3([96 96],[23 23],[1 -30],'r','Linewidth',2);
text(96 ,23, -28,'P3','Fontsize', 11)
hold on
plot3([67 67],[41 41],[1 -50],'r','Linewidth',2)
text(  67,41, -30,'P4','Fontsize', 11)
%title( 'PERMX 3D')
%colormap jet

set(gcf,'color','white')
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca,'zticklabel',[])
hfig = tightfig(hfig);

% chizzy=reshape(log10(rossmary2),120,60,5);
% hh=figure();
% for i=1:5
% subplot(2,3,i)
% G3=cartGrid([120 60]);
% plotCellData(G3,reshape(chizzy(:,:,i),7200,1));
% view(3)
% %h=colorbar('vertical');
% axis equal on
% title(['Layer(' num2str(i) ')'])
% grid off
% shading flat
% caxis([1 5])
% colormap(CMRmap)
% set(gcf,'color','white')
% set(gcf,'color','white')
% set(gca,'xticklabel',[])
% set(gca,'yticklabel',[])
% set(gca,'zticklabel',[])
% end
% hfig = tightfig(hh);
disp (' 2D for SPE10 reservoir')

yobo=figure();

subplot(5,4,1)
plotSlice(G2,log10(rossmary2),1,3)
%view(3)
%title(['Layer(' num2str(i) ')'],'FontName','Helvetica', 'Fontsize', 13)
title('Layer 1','FontName','Helvetica', 'Fontsize', 13)
grid off
shading flat
 caxis([1 5])
 colormap(CMRmap)
set(gcf,'color','white')
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca,'zticklabel',[])




subplot(5,4,5)
plotSlice(G2,log10(rossmary2),2,3)
%view(3)
%title(['Layer(' num2str(i) ')'],'FontName','Helvetica', 'Fontsize', 13)
title('Layer 2','FontName','Helvetica', 'Fontsize', 13)
grid off
shading flat
 caxis([1 5])
 colormap(CMRmap)
set(gcf,'color','white')
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca,'zticklabel',[])


subplot(5,4,9)
plotSlice(G2,log10(rossmary2),3,3)
%view(3)
%title(['Layer(' num2str(i) ')'],'FontName','Helvetica', 'Fontsize', 13)
title('Layer 3','FontName','Helvetica', 'Fontsize', 13)
grid off
shading flat
 caxis([1 5])
 colormap(CMRmap)
set(gcf,'color','white')
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca,'zticklabel',[])

subplot(5,4,13)
plotSlice(G2,log10(rossmary2),4,3)
%view(3)
%title(['Layer(' num2str(i) ')'],'FontName','Helvetica', 'Fontsize', 13)
title('Layer 4','FontName','Helvetica', 'Fontsize', 13)
grid off
shading flat
 caxis([1 5])
 colormap(CMRmap)
set(gcf,'color','white')
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca,'zticklabel',[])


subplot(5,4,17)
plotSlice(G2,log10(rossmary2),5,3)
%view(3)
%title(['Layer(' num2str(i) ')'],'FontName','Helvetica', 'Fontsize', 13)
title('Layer 5','FontName','Helvetica', 'Fontsize', 13)
grid off
shading flat
 caxis([1 5])
 colormap(CMRmap)
set(gcf,'color','white')
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca,'zticklabel',[])















hfig2 = tightfig(yobo);






































disp (' 3D for punq reservoir')
load punq.GRDECL;
load effective.out;
punq1=punq.*effective;
punq1(punq1==0)=NaN;

hfig19=figure();
G2punq=cartGrid([19 28 5]);
plotCellData(G2punq,log10(punq1));
view(3)
%h=colorbar('vertical');
axis equal on
grid off
shading flat
caxis([1 3])
colormap('jet')
hold on
plot3([10 10],[22 22],[1 -8],'r','Linewidth',2);
text(  10,22,-7,'P1','HorizontalAlignment','left','FontSize',11)
hold on
plot3([9 9],[17 17],[1 -8],'r','Linewidth',2);
text(  9,17, -9,'P4','Fontsize', 11)
hold on
plot3([17 17],[11 11],[1 -8],'r','Linewidth',2);
text(  17,11, -9,'P5','Fontsize', 11)
hold on
plot3([11 11],[24 24],[1 -12],'r','Linewidth',2);
text(11 ,24, -5,'P11','Fontsize', 11)
hold on
plot3([15 15],[12 12],[1 -8],'r','Linewidth',2)
text(  15,12, -9,'P12','Fontsize', 11)
hold on
plot3([17 17],[22 22],[1 -8],'r','Linewidth',2)
text(  17,22, -4,'P4','Fontsize', 11)
%title( 'PERMX 3D')
%colormap jet

set(gcf,'color','white')
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca,'zticklabel',[])
hfig199 = tightfig(hfig19);

punq1=reshape(log10(punq1),19,28,5);

[X,Y] = meshgrid(1:19,1:28);

unie=figure();
for i=1:5
subplot(2,3,i);
surf(X',Y',punq1(:,:,i))

shading flat
axis([1 19 1 28 ])
grid off
title(['Layer(' num2str(i) ')'],'FontName','Helvetica', 'Fontsize', 13)
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
caxis([1 3])
colormap('jet')
% h = colorbar;
% ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
% set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
end
 unief = tightfig(unie);