clc;
clear all;
close all;
N=input( ' enter the number of realizations(ensemble size)  ');
nx=input( ' enter the number of grid blocks in x direction  ');
ny=input( ' enter the number of grid blocks in y direction  ');
nz=input( ' enter the number of grid blocks in z direction  ');

load sgsimporo.out; %permeability ensemble

sgsim=reshape(sgsimporo,72000,N);

for i=1:N
sgsimuse=reshape(sgsim(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,36000,1);
sg(:,i)=ex;
end

sgout=zeros(3600000,1);
sgoutporo=zeros(3600000,1);

 for ii=1:3600000
    if(sg(ii)>=0.185)
        sgout(ii)=1;
    end
end

disp( 'Convert the facies field to signed distance transform')
clement=signedD(sgout,nx,ny);

disp( 'Get the DCT coefficients of the signed distance transform')
clementDCTsigned = DCTsigned(clement, N);

valuepermjoy=clementDCTsigned;
disp( 'extract the inverse DCT of the signed distance field')
for ii=1:N
    lf=reshape(valuepermjoy(:,ii),60,30,5);
     for jj=1:5
         valueperm=lf(:,:,jj);
         big=zeros(120,60,5);

        big(1:60,1:30,jj)=valueperm;
        kkperm=big(:,:,jj);
        rec = mirt_idctn(kkperm);
        rec=(abs(rec));
         usdf=reshape(rec,7200,1);
         young(:,jj)=usdf;
     end
      sdfbig=reshape(young,36000,1);
  clementperm(:,ii)=sdfbig;
end

clementperm(clementperm<=0.54)=0;
disp( 'reclassify the signed distance field to facies indicator field')
for ii=1:N
    lf=reshape(clementperm(:,ii),120,60,5);
     for jj=1:5
         value=lf(:,:,jj);
        
         usdf=value<=0;
		 usdf=double(usdf);
         usdf=reshape(usdf,7200,1);
         young(:,jj)=usdf;
     end
      sdfbig=reshape(young,36000,1);
  clementpermL(:,ii)=sdfbig;
end
sgout=reshape(sgout,36000,N);
yobo=isequal(sgout,clementpermL);
disp(yobo);