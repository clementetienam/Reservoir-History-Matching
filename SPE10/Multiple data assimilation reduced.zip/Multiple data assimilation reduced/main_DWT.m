function [mumyperm,mumyporo]=main_DWT(nx,ny,nz,N,tol,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha);
disp( 'History matching data assimilation technique using DWT ESMDA for SPE10 Reservoir'  ) 

sgsim=reshape(perm,72000,N);
sgsimporo=reshape(poro,72000,N);
for i=1:N
sgsimuse=reshape(sgsim(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,36000,1);
sg(:,i)=ex;
end

for i=1:N
sgsimporouse=reshape(sgsimporo(:,i),120,60,10);
sgsporo=sgsimporouse(:,:,3:7);
exporo=reshape(sgsporo,36000,1);
sgporo(:,i)=exporo;
end

Sim11=reshape(overallsim,17,history,N);


for i=1:history
 fprintf('Now assimilating timestep %d .\n', i);
 
 Sim1=Sim11(:,i,:);
Sim1=reshape(Sim1,17,N);
 
 
disp( 'Get the DWT coefficients')
[clementLL,clementLH,clementHH,clementHL,sX] = DWTobtain(log(sg), N,nx,ny,nz);
[clementLLp,clementLHp,clementHHp,clementHLp,sXp] = DWTobtain(sgporo, N,nx,ny,nz);

f=observation(:,i);
[clementLLp,clementLHp,clementHHp,clementHLp,clementLL,clementLH,clementHH,clementHL] = Assimilate_DWT (clementLL,clementLH,clementHH,clementHL,sX,clementLLp,clementLHp,clementHHp,clementHLp, f, N,Sim1,tol,alpha);

DupdateK = DWTreconstruct(clementLL,clementLH,clementHL,clementHH,N,nx,ny,nz,sX);
DupdateK=exp(DupdateK);

sgsim2= DWTreconstruct(clementLLp,clementLHp,clementHLp,clementHHp,N,nx,ny,nz,sX);
%condition the data
[output,outputporo] = honour2(rossmary, rossmaryporo, N,sgsim2,DupdateK);

sg=reshape(output,36000,N);
sgporo=reshape(outputporo,36000,N);

%function Kplot=compareplot(output,outputporo,outputz,effective,rossmary,rossmaryporo,N)

 fprintf('Finished assimilating timestep %d \n', i);
end
disp('  output to ASCII files the states at each time step  ');
sgassimi=sg; 
sgporoassimi=sgporo;
save('Permall.out','sgassimi','-ascii');
save('Poroall.out','sgporoassimi','-ascii');
permanswers=reshape(sgassimi,36000,N);
poroanswers=reshape(sgporoassimi,36000,N);

for i=1:N
sgsim=zeros(120,60,10);
sgsimporo=zeros(120,60,10);
sgsim(:,:,3:7)=reshape(permanswers(:,i),120,60,5);
sgsimporo(:,:,3:7)=reshape(poroanswers(:,i),120,60,5);

sgsimmijana(:,i)=reshape(sgsim,72000,1);
sgsimporomijana(:,i)=reshape(sgsimporo,72000,1);
end

mumyperm=sgsimmijana;
mumyporo=sgsimporomijana;
end
 %plot the mean and variance for each timestep
 %run('plot3D.m')
 
 