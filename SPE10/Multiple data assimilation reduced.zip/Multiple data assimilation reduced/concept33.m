clc;
clear;
N=100;
load sgsim.out;
sgout=zeros(7200000,1);
sgsim=reshape(sgsim,72000*N,1);
 for ii=1:7200000
    if(sgsim(ii)>=100)
        sgout(ii)=1;
    end
 end
 		
	fstats=zeros(120,60);	
sgout=reshape(sgout,72000,N);		
 for i=1:N
     BW=sgout(:,i);
     BW=reshape(BW,120,60,10);
     for j=1:10
  L = bwlabel(BW(:,:,j));       
 stats = regionprops(L,'Area' );
  area=[stats.Area];
 
%   ED=[stats.EquivDiameter];
%  
%   orient=[stats.Orientation];
%   peri=[stats.Perimeter];
 
  
  fstats=area;
%   fstats(:,:,3)=orient;
%   fstats(:,:,4)=peri;
%   fstats(:,:,2)=ED;
  
  fstatsal=(fstats);
   maxlen = 48;
fstatsal(end+1:maxlen) = 1;

  fstatsall(:,j)=fstatsal';
     end
     clementstats(:,i)=reshape(fstatsall,480,1);
 end
 %clementstats is the ensemble of statistical value to be updated

load sgsimenkf.out;
updatedperm=zeros(72000*N,1);
for ii=1:72000*N
    if(sgsimenkf(ii)>=100)
        updatedperm(ii)=1;
    end
	
	
end

	fstats=zeros(120,60);	
updatedperm=reshape(updatedperm,72000,N);		
 for i=1:N
     BW=updatedperm(:,i);
     BW=reshape(BW,120,60,10);
     for j=1:10
     L = bwlabel(BW(:,:,j));
     Lall(:,j)=reshape(L,7200,1);
 stats1 = regionprops(L,'Area' );      

  area=stats1.Area;
  
  ED=stats1.EquivDiameter;
 
  orient=stats1.Orientation;
  peri=stats1.Perimeter;

  
  fstats=area;
%   fstats(:,:,2)=ED;
%   fstats(:,:,3)=orient;
%   fstats(:,:,4)=peri;
   fstatsal=reshape(fstats,7200,1);
  fstatsall(:,j)=reshape(fstatsal,7200,1);
     end
     clementstatsu(:,i)=reshape(fstatsall,72000,1);
     Lout(:,i)=reshape(Lall,72000,1);
 end



updatedperm=reshape(updatedperm,72000,N);
disp('get back')
for i=1:N
    clemnelly=clementstats(:,i);
    clemnelly=reshape(clemnelly,7200,10);
    nelly=clementstatsu(:,i);
    nelly=reshape(nelly,7200,10);
    Lin=Lout(:,i);
    Lin=reshape(Lin,120,60,10);
    benter=logical(updatedperm(:,i));
    benter=reshape(benter,120,60,10);
    for j=1:10
        
        Lv=Lin(:,:,j);
        
        mom=clemnelly(:,j);
        mom2=nelly(:,j);
      
        mom=reshape(mom,7200,1);
        minmom=min(mom);
        maxmom=max(mom);
      
        mom=reshape(mom,120,60);
      
    mom2=reshape(mom2,7200,1);
        minmom2=min(mom2);
        maxmom2=max(mom2);
      
        mom2=reshape(mom2,120,60);    
        
        minav=(minmom+minmom2)/2;
        maxav=(maxmom+maxmom2)/2;
        
     %Area1=mom(1,:);
%   ConvexArea1=mom(2,:);
%   Eccentricity1=mom(3,:);
%   EquivDiameter1=mom(4,:);
%   EulerNumber1=mom(6,:);
%   Extent1=mom(5,:);
%   FilledArea1=mom(7,:);
%   MajorAxisLength1=mom(8,:);
%   MinorAxisLength1=mom(9,:);
%   Orientation1=mom(10,:);
%  Perimeter1=mom(11,:);
%   Solidity1=mom(12,:); 
  
  %Area2=mom2(1,:);
%   ConvexArea2=mom2(2,:);
%   Eccentricity2=mom2(3,:);
%   EquivDiameter2=mom2(4,:);
%   EulerNumber2=mom2(6,:);
%   Extent2=mom2(5,:);
%   FilledArea2=mom2(7,:);
%   MajorAxisLength2=mom2(8,:);
%   MinorAxisLength2=mom2(9,:);
%   Orientation2=mom2(10,:);
%  Perimeter2=mom2(11,:);
%   Solidity2=mom2(12,:); 
  
idx = find((minav <= mom2) & (mom2 <= maxav));
BW2 = ismember(Lv, idx);


   a=[Area1 Area2];
    a=sort(a);
  
   b=[ConvexArea1 ConvexArea2];
    b=sort(b); 
    
    c=[Eccentricity1 Eccentricity2];
    c=sort(c);

 
     d=[ EquivDiameter1  EquivDiameter2];
    d=sort(d);
    
     e=[EulerNumber1  EulerNumber2];
    e=sort(e); 
    
     f=[Extent1  Extent2];
    f=sort(f);
    
     g=[FilledArea1  FilledArea2];
    g=sort(g);
    
    h=[MajorAxisLength1  MajorAxisLength2];
    h=sort(h); 
    
    I=[MinorAxisLength1  MinorAxisLength2];
    I=sort(I);
    
   J=[Orientation1  Orientation2];
    J=sort(J); 
   
  K=[Perimeter1  Perimeter2];
    K=sort(K);   
  
    %BW2=benter(:,:,j);
  
      %BW2 = bwpropfilt(benter(:,:,j),'Area',a);
    
     % BW2=bwpropfilt(benter(:,:,j),'EquivDiameter',d);
%     BW2=bwpropfilt(BW2,'EulerNumber',f);
%     BW2=bwpropfilt(BW2,'Extent',e);
%     BW2=bwpropfilt(BW2,'FilledArea',g);
   
%     
%     BW2=bwpropfilt(BW2,'MinorAxisLength',I);
%   
%    BW2=bwpropfilt(BW2,'Orientation',J);
    %BW2=bwpropfilt(benter(:,:,j),'Perimeter',K);

bw2now(:,j)=reshape(BW2,7200,1);
    end
    Ypredicted(:,i)=reshape(bw2now,72000,1);
end
Ypredicted=double(Ypredicted);
sgsim11=sgsimenkf;
requiredK=zeros(72000*N,1);


for iii=1:72000*N

  if (updatedperm(iii)==Ypredicted(iii)) 
    requiredK(iii)=sgsim11(iii);
  end 
  
 
   
  if ((updatedperm(iii) ~= Ypredicted(iii)) && (Ypredicted(iii)==0)) 

        
        requiredK(iii)=95;
  end
   if ((updatedperm(iii)~= Ypredicted(iii)) && (Ypredicted(iii)==1)) 

      
         requiredK(iii)=105;
    end 
 
   
  
end
requiredK=abs(requiredK);




disp( 'Well locaions consisting of injector and producer well')
iInj = [30, 58, 90, 101]; % 16 wells configuration, injection wells
jInj = [55, 18, 6, 39]; % 16 wells configuration, injection wells
iProd = [14, 38, 96, 67]; % 16 wells configuration, production wells
jProd = [25, 39, 23, 41]; % 16 wells configuration, production wells
CMRmap=[0 0 0;.3 .15 .75;.6 .2 .50;1 .25 .15;.9 .5 0;.9 .9 .5;1 1 1];

load rossmary.GRDECL;
requiredK=reshape(requiredK,72000,N);
    [bestnorm3,PlogK]=clementPlot(requiredK,rossmary,N,2,CMRmap);
    xr=reshape(PlogK,120*60,5);
    
plottinglocations(xr, 120, 60,5, 'Layer', iInj, jInj, iProd, jProd, min(xr), max(xr),CMRmap);
disp(' green are injector wells and blue are producers')
     %run('clementPlot.m')
