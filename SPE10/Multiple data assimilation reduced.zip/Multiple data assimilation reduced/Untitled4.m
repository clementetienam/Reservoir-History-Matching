clc;
clear;
load rossmary.GRDECL;
load rossmaryporo.GRDECL;
load sgsim.out;
load sgsimporo.out;
% [r, p, n] = movcorr(log10(rossmary), rossmaryporo, 72000);
R = corrcoef(log(rossmary),rossmaryporo);
%R = [1 0.9; 0.9 1];
% 
% disp( 'recover the porosity now')
% s2=std((rossmaryporo));
% %for i=1:72000
% y = s2 * (R * log10(rossmary) + sqrt(1 - R^2) ) + mean(log10(rossmary),1);
% %end
% tf=issqual(y,rossmaryporo);
% usee=reshape(rossmary,120,60,10);
% for j=1:10
% R = chol(usee(:,:,j));
% Rtotal=reshape(R,7200,1);
% Rclement(:,j)=Rtotal;
% end
% ross=reshape(log10(rossmary),120,60,10);
% C=zeros(120,60);
% for j=1:10
% C = cov(ross(:,:,j));
% call(:,j)=reshape(C,3600,1);
% end
% %R = mvnrnd(rossmaryporo,C);
% ensemble=100;
% for kk=1:ensemble;
% for j=1:10
%     cout=call(:,j);
%     cout=reshape(cout,60,60);
%     sigma=cout;
%     yap=(ross(:,:,j));
%    Rout = mvnrnd(yap,sigma);
%    
%     rensemble(:,j)=reshape(Rout,7200,1);
% end
% rensemble2(:,kk)=abs(reshape(rensemble,72000,1));
% end
% rensemble2=(10.^(rensemble2));

aa=log(sgsim);
vall=zeros(7200000,2);
val(:,2)=aa;
val(:,1)=sgsimporo;
% mu = mean((rossmaryporo));
% sigma = std((rossmaryporo));
M = val;

L = chol(R);
M = M*L;
x = M(:,1);
y = M(:,2);
ddd=corr(x,y);
CMRmap=[0 0 0;.3 .15 .75;.6 .2 .50;1 .25 .15;.9 .5 0;.9 .9 .5;1 1 1];
[X,Y] = meshgrid(1:120,1:60);

x=reshape(x,72000,100);



% for kkk=1:2
%     clem=x(:,kkk);
%     figure()
% for i=1:10
%     clem=reshape(clem,120,60,10);
% subplot(2,5,i);
% surf(X',Y',(clem(:,:,i)))
% 
% shading flat
% axis([1 120 1 60 ])
% grid off
% title('True Layer 1','FontName','Helvetica', 'Fontsize', 13);
% ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
% xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
% colormap(CMRmap)
% caxis([0.1 0.4])
% h = colorbar;
% ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
% set(h, 'ylim', [0.1 0.4])
% set(gca, 'FontName','Helvetica', 'Fontsize', 13)
% set(gcf,'color','white')
% set(gca,'xticklabel',[])
% set(gca,'yticklabel',[])
% end
% end
ggg2=sgsimporo;
sgsimporo=reshape(sgsimporo,72000,100);

for kkk=1:2
    clem=sgsimporo(:,kkk);
    figure()
for i=1:10
    clem=reshape(clem,120,60,10);
subplot(2,5,i);
surf(X',Y',(clem(:,:,i)))

shading flat
axis([1 120 1 60 ])
grid off
title('True Layer 1','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap(CMRmap)
caxis([0.1 0.4])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [0.1 0.4])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
end
end

sgg=reshape(sgsim,72000,100);
gggg=reshape(ggg2,72000,100);
for kv=1:100
    sgc=log10(sgg(:,kv));
    ggc=gggg(:,kv);
for j=1:10
    sgsub=reshape(sgc,7200,10);
    ggsub=reshape(ggc,7200,10);
p = polyfit(sgsub(:,j),ggsub(:,j),10);
dsa=sgsub(:,j);
outside=(p(:,1).*(dsa.^10))+(p(:,2).*(dsa.^9))+(p(:,3).*(dsa.^8))+(p(:,4).*(dsa.^7))+(p(:,5).*(dsa.^6))+(p(:,6).*(dsa.^5))...
    +(p(:,7).*(dsa.^4))+(p(:,8).*(dsa.^3))+(p(:,9).*(dsa.^2))+(p(:,10).*(dsa.^1))+p(:,11);


outsidee(:,j)=reshape(outside,7200,1);
end
outsidew(:,kv)=reshape(outsidee,72000,1);
end
 for kkk=1:2
    clem=outsidew(:,kkk);
    figure()
for i=1:10
    clem=reshape(clem,120,60,10);
subplot(2,5,i);
surf(X',Y',(clem(:,:,i)))

shading flat
axis([1 120 1 60 ])
grid off
title('True Layer 1','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap(CMRmap)
caxis([0.1 0.4])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [0.1 0.4])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
end
end 
% %R = mvnrnd(MU,SIGMA);