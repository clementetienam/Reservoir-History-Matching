%----------------------------------------------------------------------------------
% History matching using serveral methods with ESMDA (Ensemble smoother
% multiple data assimilation)
% In this code, we want to choose from a reduced ensemble initially
% Running Ensembles
% the code couples ECLIPSE reservoir simulator with MATLAB used to implement my ideas on history matching of
% The SPE 10 Reservoir. 
% Author: Clement Etienam ,PhD Petroleum Engineering 2015-2018
% Supervisor:Dr Rossmary Villegas
% Co-Supervisor: Dr Masoud Babei
% Co-Supervisor: Dr Oliver Dorn
%-----------------------------------------------------------------------------------
%% 

clc
clear
disp('choose from the methods listed below for history matching with ESMDA')
disp('1-main_Levelset')
disp('2- main_DCT( discrete cosine transform method coupled with ESMDA)')
disp('3-main_sparsity(compressed sensing) with ESMDA')
disp('4-SELE_PhD (My method coupling machine learning with Level set)')
disp('5-main_DCT_Levelset(My method coupling DCT with Level set)')
disp('6-main_DCT_LS2 (Level set and DCT update)')
disp('7-main_sparsity_LS(Level set update)') 
disp('8-main_Levelset_Boundary ')
disp('9-main_Velocity_LS')
disp('10-main_ESMDA_Localization-covariance localization')
disp('11-main_Levelset_Cov-covariance localization with Levelset')
disp('12-main_Levelset_Cov-covariance localization with Levelset but permeability constant')
disp('13-main_Levelset_Cov-covariance localization with Levelset/Normal score')
disp('14-main_Levelset_Cov-covariance localization with Levelset/Varying alpha')
disp('15-main_ANN-Supervised learning history matching with neural networks')
disp('16-main_RLM_Levelset')
disp('17-main_DWT')
disp('18-Normal score Deutsch')
disp('19-Normal score Recurssive updtes')
method=input(' Enter the  required data assimilation scheme method  ');

%% Query 
disp(' Now the smoothing query from the user ')
disp('Enter- 1 if needed smoothing of the pixel maps')
disp('Enter 2 -if you dont need smoothing of the pixel maps')
needed=input(' Do you want to smooth the pixel maps after history matching?  ');
disp(' Now the number of times to smooth it ')

numberoftimes=input(' Number of times to clean?  ');
% cleaning the maps up to 2 times for ESMDA is good enough
% N - size of ensemble

Nn=input( ' enter the initial number of realizations(ensemble size)  '); %100
nx=input( ' enter the number of grid blocks in x direction  '); %120
ny=input( ' enter the number of grid blocks in y direction  '); %60
nz=input( ' enter the number of grid blocks in z direction  '); % 5
tol=input( ' enter the tolerance for pseudo inversion  ');
alpha=input( ' enter the alpha value  '); %4,8 or 10.Anything more than 10 is waste
% alpha is the number of iteration and damping coefficient
history=input(' enter the number of timestep for the history period '); %36
N=input(' enter the number of realisations you want chosen (reduced)'); %50
disp(' Now the maintain connectivity query from the user ')
disp('Enter- 1 if needed channel connectivity')
disp('Enter 2 -if you dont need to maintain channel connectivity')
maintainit=input(' Do you want to maintain channel connectivity?  ');
%% Save the true model
disp(' varying alpha scenario')
alpha4=[9.333,7,4,2];
alpha8=[20.719,19,17,16,15,9,5,2.5];
alpha10=[57.017,35,25,20,18,15,12,8,5,3];
disp( 'Load the true permeability and porosity')
load rossmary.GRDECL; %true permeability field
load rossmaryporo.GRDECL; %True porosity field
oldfolder=cd;
cd(oldfolder) % setting original directory
disp('  import the true observation data  ');
 
 True= importdata('Real.RSM',' ',7);
 True2= importdata('Real.RSM',' ',50);
 True3= importdata('Real.RSM',' ',93);
 True4= importdata('Real.RSM',' ',136);
 
 
 True=True.data;
 True2=True2.data;
 True3=True3.data;
 True4=True4.data;
 
 
  TO1=True(:,3);
 TO2=True(:,4);
 TO3=True(:,5);
 TO4=True(:,6);
 
 
 
 TW1=True2(:,2);
 TW2=True2(:,3);
 TW3=True2(:,4);
 TW4=True2(:,5);
 
  TP1=True3(:,5);
 TP2=True3(:,6);
 TP3=True3(:,7);
 TP4=True3(:,8);
 
 TG1=True3(:,9);
 TG2=True3(:,10);
 TG3=True4(:,2);
 TG4=True4(:,3);
 
 TFOE=True4(:,8);
 
 
 disp(' make the true observation')
 for ihistory=1:history
 obs=zeros(17,1);
 obs(1,:)=TO1(ihistory,:);
 obs(2,:)=TO2(ihistory,:);
 obs(3,:)=TO3(ihistory,:);
 obs(4,:)=TO4(ihistory,:);
 obs(5,:)=TW1(ihistory,:);
 obs(6,:)=TW2(ihistory,:);
 obs(7,:)=TW3(ihistory,:);
 obs(8,:)=TW4(ihistory,:);
 obs(9,:)=TP1(ihistory,:);
 obs(10,:)=TP2(ihistory,:);
 obs(11,:)=TP3(ihistory,:);
 obs(12,:)=TP4(ihistory,:);
 obs(13,:)=TG1(ihistory,:);
 obs(14,:)=TG2(ihistory,:);
 obs(15,:)=TG3(ihistory,:);
 obs(16,:)=TG4(ihistory,:);
 obs(17,:)=TFOE(ihistory,:);
 observation(:,ihistory)=obs;
 end


oldfolder=cd;

%% Creating Folders
disp( 'create the folders')
for j=1:Nn
f = 'MASTER';
folder = strcat(f, sprintf('%.5d',j));
mkdir(folder);
end

%% Coppying simulation files
disp( 'copy simulation files for the forward problem')
for j=1:Nn
f = 'MASTER';
folder = strcat(f, sprintf('%.5d',j));
copyfile('ACTNUM.DAT',folder)
copyfile('SPE10_PVTI.PVO',folder)
copyfile('SPE10_PVTI_RSVD.PVO',folder)
copyfile('SPE10_PVTI_WATER.PVO',folder)
copyfile('Eclipse2Matlab.m',folder)
copyfile('resize.m',folder)
copyfile('MASTER0.DATA',folder)
end
%% Unsupervised Machine Learning part
disp( 'Loading the overcomplete dictionary of permeability and porosity')
load Yes2.out; %Permeability dictionary
load Yes2poro.out; %porosity dictionary
disp( 'Loading the overcomplete dictionary of signed distance of permeability and porosity')
load Yes2signed.out; %permeability signed distance
load Yes2signedporo.out; %porosity signed distance


%% The initial run to selct the top models starts here
tic;
disp(' Get the initial run of the 100 models and get from the models choose the best') 

disp(' load the intial permeability and porosity fields')

load sgsimporo2.out; %initial porosity
load sgsim.out; %initial permeabiity

perm=reshape(sgsim,72000,Nn);
poro=reshape(sgsimporo2,72000,Nn);

cd(oldfolder) % setting original directory

%% Saving POROVANCOUVER and KVANCOUVER

for i=1:Nn %list of folders 
    
    f = 'MASTER';
   folder = strcat(f, sprintf('%.5d',i));
   
    cd(folder) % changing directory 
    
    PORO2=poro(:,i);
    PERMY2=perm(:,i);
    
    save('PERMY2.GRDECL','PERMY2','-ascii');
    save('PORO2.GRDECL','PORO2','-ascii');
    
    cd(oldfolder) % returning to original cd
    
end

%% Inserting KEYWORDS PORO and PERMY 

parfor i=1:Nn %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',i));
    cd(folder)

CStr = regexp(fileread('PERMY2.GRDECL'), char(10), 'split');
CStr2 = strrep(CStr, 'toReplace', 'Replacement');
CStr2 = cat(2, {'PERMY'}, CStr2(1:end));
CStr2 = cat(2, CStr2(1:end), {'/'});
FID = fopen('PERMY2.GRDECL', 'w');
if FID < 0, error('Cannot open file'); end
fprintf(FID, '%s\n', CStr2{:});
fclose(FID);

CStr = regexp(fileread('PORO2.GRDECL'), char(10), 'split');
CStr2 = strrep(CStr, 'toReplace', 'Replacement');
CStr2 = cat(2, {'PORO'}, CStr2(1:end));
CStr2 = cat(2, CStr2(1:end), {'/'});
FID = fopen('PORO2.GRDECL', 'w');
if FID < 0, error('Cannot open file'); end
fprintf(FID, '%s\n', CStr2{:});
fclose(FID);

cd(oldfolder) % setting original directory

end


%% Running Simulations
disp( 'Solve the Non-Linear fluid flow Forward Problem' )
cd(oldfolder) % setting original directory

parfor i=1:Nn %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',i));
    cd(folder)   

    fid = fopen('MASTER0.bat', 'w');
    fprintf(fid,'@ECHO OFF\n');
    % fprintf(fid,'SET SLBSLS_LICENSE_FILE=27008@eclipse.cc.ic.ac.uk\n');
    fprintf(fid,'SET SLBSLS_LICENSE_FILE=27000@10.99.15.78\n');
    fprintf(fid,'@ECHO OFF\n');
    fprintf(fid,['c:\\ecl\\macros\\$eclipse ', 'MASTER0'],'\n');
    fclose(fid);
    %while ~exist('HM.F0016','file')
        system('MASTER0.bat')
    %end

    cd(oldfolder) % setting original directory
    
end

 %% Plot the Production profile of ensemble
for i=1:Nn %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',i));
    %folder=oldfolder;
    %cd 'C:\Work\GSLIB\sgsim\EnKFMATLABRun'   
    cd(folder);
   
        
  
    
    %Saturation data lines [2939-5206]
    A1 = importdata('MASTER0.RSM',' ',7);
    A1=A1.data;
  
    
    
     WOPR11=A1(:,3);
     WOPR21=A1(:,4);
     WOPR31=A1(:,5);
     WOPR41=A1(:,6);
 
     
     
    %Saturation
    
    WOPRA1(:,i)=WOPR11;
    WOPRB1(:,i)=WOPR21;
    WOPRC1(:,i)=WOPR31;
    WOPRD1(:,i)=WOPR41;
      
    cd(oldfolder);
    end
   cd(oldfolder) % returning to original directory
 %Import true production data
 True= importdata('Real.RSM',' ',7);

 
 True=True.data;

 
 
 TO11=True(:,3);
 TO21=True(:,4);
 TO31=True(:,5);
 TO41=True(:,6);
 
 
disp(' get the cost function to oil production rate')
for i=1:Nn
    EWOP11(i,:)=immse(WOPRA1(:,i),TO11);
    EWOP21(i,:)=immse(WOPRB1(:,i),TO21);
    EWOP31(i,:)=immse(WOPRC1(:,i),TO31);
    EWOP41(i,:)=immse(WOPRD1(:,i),TO41);
end
TOTALERROR1=ones(Nn,1);
TOTALERROR1=(EWOP11./std(TO11))+(EWOP21./std(TO21))+(EWOP31./std(TO31))+...
    (EWOP41./std(TO41));
TOTALERROR1=TOTALERROR1./36;
jj=min(TOTALERROR1);
index = TOTALERROR1;
index=reshape(index,Nn,1);
[sd,r]=sort(index,'ascend');
disp(' get the realizations with the least mismatch to oil rate')
yapperm=perm(:,r(1:N));
yapporo=poro(:,r(1:N));
%%
% disp( 'delete the created the folders')
% for j=51:Nn
% f = 'MASTER';
% folder = strcat(f, sprintf('%.5d',j));
% rmdir(folder);
% end
disp(' now use the reduced ensemble to start the history matching')
for inelly=1:alpha
fprintf('Now running the code for iteration %d .\n', inelly);   
%% Loading Porosity and Permeability ensemble files
disp(' load the permeability and porosity fields')
if inelly==1
    disp( 'permeability loaded from initial ensemble')
%load sgsimporo2.out; %initial porosity
%load sgsim.out; %initial permeabiity

perm=reshape(yapperm,72000,N);
poro=reshape(yapporo,72000,N);
oriK=perm;
oriporo=poro;
if method==18 % standard deviation of the initial ensemble
    [overallstd,overallstdporo]=getSTD(perm,poro,nx,ny,nz,N);
end

if method==19 % Get the standard deviation for method 19, initial ensemble
    disp('obtain the standard deviation of the initial statistics from SGeMS') 
    [stdsandk,stdshalek,stdsandporo,stdshaleporo]=RCUstd(N,nx,ny,nz,perm,poro);
  disp('obtain the mean and facies ratio of the initial statistics from SGeMS')   
 [meansandk,meanshalek,faciesr,meansandp,meanshalep,faciesrp]=RCUmf2(perm,poro,N);
 disp('obtain the maximum average of the mean and facies ratioof  initial statistics from SGeMS') 
  [meansandak,meanshaleak,faciesar,meansandap,meanshaleap,faciesrap]=RCUmfmean(meansandk,meanshalek,faciesr,meansandp,meanshalep,faciesrp);

end
else
 disp( 'permeability loaded from UPDATED ensemble')
 perm=reshape(mumyperm,72000,N);
 poro=reshape(mumyporo,72000,N);   
end
cd(oldfolder) % setting original directory

%% Saving POROVANCOUVER and KVANCOUVER

for i=1:N %list of folders 
    
    f = 'MASTER';
   folder = strcat(f, sprintf('%.5d',i));
   
    cd(folder) % changing directory 
    
    PORO2=poro(:,i);
    PERMY2=perm(:,i);
    
    save('PERMY2.GRDECL','PERMY2','-ascii');
    save('PORO2.GRDECL','PORO2','-ascii');
    
    cd(oldfolder) % returning to original cd
    
end

%% Inserting KEYWORDS PORO and PERMY 

parfor i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',i));
    cd(folder)

CStr = regexp(fileread('PERMY2.GRDECL'), char(10), 'split');
CStr2 = strrep(CStr, 'toReplace', 'Replacement');
CStr2 = cat(2, {'PERMY'}, CStr2(1:end));
CStr2 = cat(2, CStr2(1:end), {'/'});
FID = fopen('PERMY2.GRDECL', 'w');
if FID < 0, error('Cannot open file'); end
fprintf(FID, '%s\n', CStr2{:});
fclose(FID);

CStr = regexp(fileread('PORO2.GRDECL'), char(10), 'split');
CStr2 = strrep(CStr, 'toReplace', 'Replacement');
CStr2 = cat(2, {'PORO'}, CStr2(1:end));
CStr2 = cat(2, CStr2(1:end), {'/'});
FID = fopen('PORO2.GRDECL', 'w');
if FID < 0, error('Cannot open file'); end
fprintf(FID, '%s\n', CStr2{:});
fclose(FID);

cd(oldfolder) % setting original directory

end


%% Running Simulations
disp( 'Solve the Non-Linear fluid flow Forward Problem' )
cd(oldfolder) % setting original directory

parfor i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',i));
    cd(folder)   

    fid = fopen('MASTER0.bat', 'w');
    fprintf(fid,'@ECHO OFF\n');
    % fprintf(fid,'SET SLBSLS_LICENSE_FILE=27008@eclipse.cc.ic.ac.uk\n');
    fprintf(fid,'SET SLBSLS_LICENSE_FILE=27000@10.99.15.78\n');
    fprintf(fid,'@ECHO OFF\n');
    fprintf(fid,['c:\\ecl\\macros\\$eclipse ', 'MASTER0'],'\n');
    fclose(fid);
    %while ~exist('HM.F0016','file')
        system('MASTER0.bat')
    %Bend

    cd(oldfolder) % setting original directory
    
end


disp(' plot production profile')
%N=100;
oldfolder=cd;
cd(oldfolder) % setting original directory
 %% Plot the Production profile of ensemble
disp('  start the plotting  ');

    for i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',i));
    %folder=oldfolder;
    %cd 'C:\Work\GSLIB\sgsim\EnKFMATLABRun'   
    cd(folder);
   
        
  
    
    %Saturation data lines [2939-5206]
    A1 = importdata('MASTER0.RSM',' ',7);
    A2 = importdata('MASTER0.RSM',' ',50);
    A3 = importdata('MASTER0.RSM',' ',93);
	A4 = importdata('MASTER0.RSM',' ',136);
    
    A1=A1.data;
    A2=A2.data;
    A3=A3.data;
	A4=A4.data;
    %SO1983=ones(2268,4)-SW1983;
    
    %save('P1983.out','P1983','-ascii');
    %save('SW1983.out','SW1983','-ascii');
    
    
     WOPR1=A1(:,3);
     WOPR2=A1(:,4);
     WOPR3=A1(:,5);
     WOPR4=A1(:,6);
     Time=A1(:,1);
     
     WWCT1=A2(:,2);
     WWCT2=A2(:,3);
     WWCT3=A2(:,4);
     WWCT4=A2(:,5);
     
     BHP1=A3(:,5);
     BHP2=A3(:,6);
     BHP3=A3(:,7);
     BHP4=A3(:,8);
	 
	 GORP1=A3(:,9);
     GORP2=A3(:,10);
     GORP3=A4(:,2);
     GORP4=A4(:,3);
	 
	 
	FOE=A4(:,8);
	 
     
    %Saturation
    
    WOPRA(:,i)=WOPR1;
    WOPRB(:,i)=WOPR2;
    WOPRC(:,i)=WOPR3;
    WOPRD(:,i)=WOPR4;
    
    WCTA(:,i)=WWCT1;
    WCTB(:,i)=WWCT2;
    WCTC(:,i)=WWCT3;
    WCTD(:,i)=WWCT4;
    
    BHPA(:,i)=BHP1;
    BHPB(:,i)=BHP2;
    BHPC(:,i)=BHP3;
    BHPD(:,i)=BHP4;
	
	GORA(:,i)=GORP1;
    GORB(:,i)=GORP2;
    GORC(:,i)=GORP3;
    GORD(:,i)=GORP4;
	
	FOEA(:,i)=FOE;
	
    
    cd(oldfolder);
    end
   cd(oldfolder) % returning to original directory
 %Import true production data
 True= importdata('Real.RSM',' ',7);
 True2= importdata('Real.RSM',' ',50);
 True3= importdata('Real.RSM',' ',93);
 True4= importdata('Real.RSM',' ',136);
 
 True=True.data;
 True2=True2.data;
 True3=True3.data;
  True4=True4.data;
 
 
 TO1=True(:,3);
 TO2=True(:,4);
 TO3=True(:,5);
 TO4=True(:,6);
 
  TW1=True2(:,2);
 TW2=True2(:,3);
 TW3=True2(:,4);
 TW4=True2(:,5);
 
  TP1=True3(:,5);
 TP2=True3(:,6);
 TP3=True3(:,7);
 TP4=True3(:,8);
 
 TG1=True3(:,9);
 TG2=True3(:,10);
 TG3=True4(:,2);
 TG4=True4(:,3);
 
 TFOE=True4(:,8);
 
 
 %grey = [0.4,0.4,0.4]; 
 linecolor1 = colordg(4);
%% Plot for oil production rates
 figure()
 %subplot(2,2,1)
 plot(Time,WOPRA(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Q_o(Sm^{3}/day)','FontName','Helvetica', 'Fontsize', 13);
 ylim([0 25000])
title('Producer 1','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TO1,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 25000],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,sprintf('PRO1_OIL_iter%d.fig',inelly))
close(figure)
 %subplot(2,2,2)
 figure()
 plot(Time,WOPRB(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Q_o(Sm^{3}/day)','FontName','Helvetica', 'Fontsize', 13);
ylim([0 25000])
title('Producer 2','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TO2,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 25000],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
%saveas(gcf,'PRO2_OIL','epsc')
saveas(gcf,sprintf('PRO2_OIL_iter%d.fig',inelly))
close(figure)

figure()
 %subplot(2,2,3)
 plot(Time,WOPRC(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Q_o(Sm^{3}/day)','FontName','Helvetica', 'Fontsize', 13);
ylim([0 25000])
title('Producer 3','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TO3,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 25000],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
%saveas(gcf,'PRO3_OIL','epsc')
saveas(gcf,sprintf('PRO3_OIL_iter%d.fig',inelly))
close(figure)

figure()
 %subplot(2,2,4)
 plot(Time,WOPRD(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Q_o(Sm^{3}/day)','FontName','Helvetica', 'Fontsize', 13);
ylim([0 25000])
title('Producer 4','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TO4,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 25000],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
%saveas(gcf,'PRO4_OIL','epsc')
saveas(gcf,sprintf('PRO4_OIL_iter%d.fig',inelly))
close(figure)
%% Plot for water cut
figure()
 %subplot(2,2,1)
 plot(Time,WCTA(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Water cut','FontName','Helvetica', 'Fontsize', 13);
title('Producer 1','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TW1,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
%saveas(gcf,'PRO1_WATER','epsc')
saveas(gcf,sprintf('PRO1_WATER_iter%d.fig',inelly))
close(figure)

figure()
 %subplot(2,2,2)
  plot(Time,WCTB(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Water cut','FontName','Helvetica', 'Fontsize', 13);
title('Producer 2','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TW2,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
%saveas(gcf,'PRO2_WATER','epsc')
saveas(gcf,sprintf('PRO2_WATER_iter%d.fig',inelly))
close(figure)

figure()
 %subplot(2,2,3)
  plot(Time,WCTC(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Water cut','FontName','Helvetica', 'Fontsize', 13);
title('Producer 3','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TW3,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
%saveas(gcf,'PRO3_WATER','epsc')
saveas(gcf,sprintf('PRO3_WATER_iter%d.fig',inelly))
close(figure)

figure()
 %subplot(2,2,4)
  plot(Time,WCTD(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Water cut','FontName','Helvetica', 'Fontsize', 13);
title('Producer 4','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TW4,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
%saveas(gcf,'PRO4_WATER','epsc')
saveas(gcf,sprintf('PRO4_WATER_iter%d.fig',inelly))
close(figure)
%% Plot for BHP
figure()
 %subplot(2,2,1)
 plot(Time,BHPA(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('BHP(BARSA)','FontName','Helvetica', 'Fontsize', 13);
title('Injector 1','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TP1,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 500],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
%saveas(gcf,'inj1_BHP','epsc')
saveas(gcf,sprintf('inj1_BHP_iter%d.fig',inelly))
close(figure)

figure()
 %subplot(2,2,2)
   plot(Time,BHPB(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('BHP(BARSA)','FontName','Helvetica', 'Fontsize', 13);
title('Injector 2','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TP2,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 500],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
%saveas(gcf,'inj2_BHP','epsc')
saveas(gcf,sprintf('inj2_BHP_iter%d.fig',inelly))
close(figure)

figure()
 %subplot(2,2,3)
   plot(Time,BHPC(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('BHP(BARSA)','FontName','Helvetica', 'Fontsize', 13);
title('Injector 3','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TP3,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 500],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
%saveas(gcf,'inj3_BHP','epsc')
saveas(gcf,sprintf('inj3_BHP_iter%d.fig',inelly))
close(figure)
figure()
 %subplot(2,2,4)
   plot(Time,BHPD(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('BHP(BARSA)','FontName','Helvetica', 'Fontsize', 13);
title('Injector 4','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TP4,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 500],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
%saveas(gcf,'inj4_BHP','epsc')
saveas(gcf,sprintf('inj4_BHP_iter%d.fig',inelly))
close(figure)

%% Plot for GOR
figure()
 %subplot(2,2,1)
 plot(Time,GORA(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Gas oil ratio(Sm^{3}/Sm^{3})','FontName','Helvetica', 'Fontsize', 13);
title('Gas oil ratio for producer 1','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TG1,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1000],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
%saveas(gcf,'PRO1_GOR','epsc')
saveas(gcf,sprintf('PRO1_GOR_iter%d.fig',inelly))
close(figure)

figure()
 %subplot(2,2,2)
   plot(Time,GORB(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Gas oil ratio(Sm^{3}/Sm^{3})','FontName','Helvetica', 'Fontsize', 13);
title('Gas oil ratio for producer 2','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TG2,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1000],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
%saveas(gcf,'PRO2_GOR','epsc')
saveas(gcf,sprintf('PRO2_GOR_iter%d.fig',inelly))
close(figure)

figure()
 %subplot(2,2,3)
   plot(Time,GORC(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Gas oil ratio(Sm^{3}/Sm^{3})','FontName','Helvetica', 'Fontsize', 13);
title('Gas oil ratio for producer 3','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TG3,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1000],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
%saveas(gcf,'PRO3_GOR','epsc')
saveas(gcf,sprintf('PRO3_GOR_iter%d.fig',inelly))
close(figure)

figure()
 %subplot(2,2,4)
   plot(Time,GORD(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Gas oil ratio(Sm^{3}/Sm^{3})','FontName','Helvetica', 'Fontsize', 13);
title('Gas oil ratio for producer 4','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TG4,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1000],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
%saveas(gcf,'PRO4_GOR','epsc')
saveas(gcf,sprintf('PRO4_GOR_iter%d.fig',inelly))
close(figure)


 figure()
 plot(Time,FOEA(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Oil recovery ratio','FontName','Helvetica', 'Fontsize', 13);
title('Field oil recovery ratio','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TFOE,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
%saveas(gcf,'Oilrecovery','epsc')
saveas(gcf,sprintf('Oilrecovery_iter%d.fig',inelly))

disp(' get the skewness,kourtoisis,mean of ensemble in iteration')
get_stats_ensemble(perm,poro,N,inelly,rossmary,rossmaryporo);
%saveas(h,sprintf('FIG%d.png',k))
%% Get the Norm to production data 
disp( 'Get the Norm to production data mismatch')

close(figure)
for i=1:N
    EWOP1(i,:)=immse(WOPRA(:,i),TO1);
    EWOP2(i,:)=immse(WOPRB(:,i),TO2);
    EWOP3(i,:)=immse(WOPRC(:,i),TO3);
    EWOP4(i,:)=immse(WOPRD(:,i),TO4);
    EWCT1(i,:)=immse(WCTA(:,i),TW1);
    EWCT2(i,:)=immse(WCTB(:,i),TW2);
    EWCT3(i,:)=immse(WCTC(:,i),TW3);
    EWCT4(i,:)=immse(WCTD(:,i),TW4);
    EBHP1(i,:)=immse(BHPA(:,i),TP1);
    EBHP2(i,:)=immse(BHPB(:,i),TP2);
    EBHP3(i,:)=immse(BHPC(:,i),TP3);
    EBHP4(i,:)=immse(BHPD(:,i),TP4);
	EGORP1(i,:)=immse(GORA(:,i),TG1);
    EGORP2(i,:)=immse(GORB(:,i),TG2);
    EGORP3(i,:)=immse(GORC(:,i),TG3);
    EGORP4(i,:)=immse(GORD(:,i),TG4);
end
TOTALERROR=ones(N,1);
TOTALERROR=(EWOP1./std(TO1))+(EWOP2./std(TO2))+(EWOP3./std(TO3))+...
    (EWOP4./std(TO4))+(EWCT1./std(TW1))+(EWCT2./std(TW2))...
    +(EWCT3./std(TW3))+(EWCT4./std(TW4))+(EBHP1./std(TP1))...
    +(EBHP2./std(TP2))+(EBHP3./std(TP3))+(EBHP4./std(TP4))...
	+(EGORP1./std(TG1))+(EGORP2./std(TG2))+(EGORP3./std(TG3))+(EGORP4./std(TG4));
TOTALERROR=TOTALERROR./36;
jj=min(TOTALERROR);
index = TOTALERROR; 
bestnorm = find(index == min(index));
	%Pssim = Pnew(:,bestssim); %best due to ssim
fprintf('The best Norm Realization is number %i with value %4.4f \n',bestnorm,jj);
% JOYLINE=[1:100]';
% figure()
%bar(JOYLINE,TOTALERROR);

reali=[1:N]';

 figure()
 bar(reali,index,'cyan');
 xlabel('Realizations', 'FontName','Helvetica', 'Fontsize', 13);
 ylabel('RMSE value', 'FontName','Helvetica', 'Fontsize', 13);
 title('Cost function for Realizations','FontName','Helvetica', 'Fontsize', 13)
 set(gcf,'color', 'white');
 hold on
 scatter(reali,index,'black','filled');
 xlabel('Realizations', 'FontName','Helvetica', 'Fontsize', 13)
 ylabel('RMSE value', 'FontName','Helvetica', 'Fontsize', 13)
 hold off
 xlim([1,N]);
 %saveas(gcf,'RMS','epsc')
 saveas(gcf,sprintf('RMS_iter%d.fig',inelly))
close(figure)

 disp('  program almost executed  ');


decreasingnorm(:,inelly)=index;
 
 
 disp( 'Get the simulated files for all the time step')
 %N=100;


oldfolder=cd;
cd(oldfolder) % setting original directory


overallsim=zeros(17,history,N);
    for ii=1:N %list of folders 
    
      f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',ii));
    cd(folder)   
    
  True= importdata('MASTER0.RSM',' ',7);
  A2 = importdata('MASTER0.RSM',' ',50);
  A3 = importdata('MASTER0.RSM',' ',93);
  A4 = importdata('MASTER0.RSM',' ',136);
 
 
 
 True=True.data;
 A2=A2.data;
 A3=A3.data;
 A4=A4.data;
 
 
 TO1=True(:,3);
 TO2=True(:,4);
 TO3=True(:,5);
 TO4=True(:,6);

     
     WWCT1=A2(:,2);
     WWCT2=A2(:,3);
     WWCT3=A2(:,4);
     WWCT4=A2(:,5);
     
     BHP1=A3(:,5);
     BHP2=A3(:,6);
     BHP3=A3(:,7);
     BHP4=A3(:,8);
	 
	 GORP1=A3(:,9);
     GORP2=A3(:,10);
     GORP3=A4(:,2);
     GORP4=A4(:,3);
	 
	 
	FOE=A4(:,8);

 for i=1:history
 obs=zeros(17,1);
 obs(1,:)=TO1(i,:);
 obs(2,:)=TO2(i,:);
 obs(3,:)=TO3(i,:);
 obs(4,:)=TO4(i,:);
 obs(5,:)=WWCT1(i,:);
 obs(6,:)=WWCT2(i,:);
 obs(7,:)=WWCT3(i,:);
 obs(8,:)=WWCT4(i,:);
 obs(9,:)=BHP1(i,:);
 obs(10,:)=BHP2(i,:);
 obs(11,:)=BHP3(i,:);
 obs(12,:)=BHP4(i,:);
 obs(13,:)=GORP1(i,:);
 obs(14,:)=GORP2(i,:);
 obs(15,:)=GORP3(i,:);
 obs(16,:)=GORP4(i,:);
 obs(17,:)=FOE(i,:);
 
 observationsim(:,i)=obs;
 end
        
   overallsim(:,:,ii)=observationsim; 
    cd(oldfolder) % returning to original directory

    end

cd(oldfolder) % returning to original directory
%% Enter the assimilation loop
disp('now entering the assimilation loop')
  
switch method
%     case 1
%  disp( 'method 1 specified-standard ESMDA')
% [mumyperm,mumyporo]=main_ESMDA(N,tol,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha);
  
  case 1
  disp( 'method 1 specified-ESMDA and Levelset')   
[mumyperm,mumyporo]=main_Levelset(nx,ny,nz,N,tol,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha);
    
    case 2
 disp( 'method 2 specified-DCT')   
[mumyperm,mumyporo]=main_DCT(N,tol,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha);
 
    case 3
     disp( 'method 3 specified-Sparsity')    
[mumyperm,mumyporo]=main_sparsity(N,tol,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha);
      
    case 4
    disp( 'method 4 specified-Sparsity and Levelset')     
[mumyperm,mumyporo]=SELE_PhD(nx,ny,nz,Yes2,Yes2poro,N,tol,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha);
      
    case 5
   disp( 'method 5 specified-DCT and Level set')       
[mumyperm,mumyporo]=main_DCT_Levelset(nx,ny,nz,N,tol,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha);
       
    case 6
   disp( 'method 6 specified- DCT and Level set 2')       
[mumyperm,mumyporo]=main_DCT_LS2(nx,ny,nz,N,tol,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha);
  	
	 case 7
   disp( 'method 7 specified-Sparsity and LS')       
[mumyperm,mumyporo]=main_sparsity_LS(Yes2signed,Yes2signedporo,nx,ny,nz,Yes2,Yes2poro,N,tol,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha);
      
    case 8
    disp( 'method 8 specified-Lvelset upadate with Boundary')      
[mumyperm,mumyporo]=main_Levelset_Boundary(nx,ny,nz,N,tol,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha);
    
    case 9
   disp( 'method 9 specified-Velocity and LS')       
[mumyperm,mumyporo]=main_Velocity_LS(nx,ny,nz,N,tol,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha);
       
    case 10
   disp( 'method 10 specified-Localization with ESMDA')       
[mumyperm,mumyporo]=main_ESMDA_Localization(N,tol,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha);
   
    case 11
   disp( 'method 11 specified-Localization with ESMDA and Levelset') 
[mumyperm,mumyporo]=main_Levelset_Cov(nx,ny,nz,N,tol,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha);
   case 12
   disp( 'method 12 specified-Localization with ESMDA and Levelset,permeability only vale in states') 
[mumyperm,mumyporo]=main_Levelset_Cov_Perm(nx,ny,nz,N,tol,observation,overallsim,rossmary,rossmaryporo,perm,history,alpha);  
   case 13
   disp( 'method 13 specified-Localization with ESMDA and Levelset/Normal score')
   if alpha==4
   alpha=alpha4(inelly);
   end
   if alpha==8
    alpha=alpha8(inelly);
   end
   if alpha==10
       alpha=alpha10(inelly);
   end
[mumyperm,mumyporo]=main_Levelset_Cov_NS(nx,ny,nz,N,tol,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha); 
    case 14
   disp( 'method 14 specified-Localization with ESMDA and Levelset/varying alpha')
   if alpha==4
   alpha=alpha4(inelly);
   end
   if alpha==8
    alpha=alpha8(inelly);
   end
   if alpha==10
       alpha=alpha10(inelly);
   end      
  [mumyperm,mumyporo]=main_Levelset_Cov(nx,ny,nz,N,tol,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha);    
    case 15
        disp('method 15 specified using Artificial Neural Network')
  [mumyperm,mumyporo]=main_ANN(nx,ny,nz,N,tol,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha);      
    case 16
        disp(' method 16 specified, xiadong Luo Minimum average cost method')
        if inelly==1
            alu=1;
        else
            alu=0.9*alu;
        end
        disp(' get the simulated data from the mean of the ensmeble')    
     averagedata = avergaesimulated (perm,poro,120,60,5,N,history);   
  [mumyperm,mumyporo]=main_RLM_Levelset(120,60,5,N,tol,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha,averagedata);     
    case 17  
  disp( 'method 17 specified-DWT-Discrete wavelet transform')   
[mumyperm,mumyporo]=main_DWT(nx,ny,nz,N,tol,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha);
    case 18 
   disp( 'Normal score transform CV Deutsch styel with ESMDA')     
[mumyperm,mumyporo]=main_ESMDA_Localization_NST(N,tol,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha,overallstd,overallstdporo);
    case 19
  disp('Dynamic update with channel information and covaraice localization')      
 [mumyperm,mumyporo]=main_DCT_RCU(N,tol,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha,stdsandk,stdshalek,stdsandporo,stdshaleporo,meansandak,meanshaleak,faciesar,meansandap,meanshaleap,faciesrap);      
    otherwise
        disp('method not specified correctly')
end

perm=reshape(mumyperm,72000,N);
 poro=reshape(mumyporo,72000,N);

 
fprintf('Finished Iteration %d .\n', inelly);
end
 %% Exit the loop
 %% Now run the code to see the final history matcing step
 disp( 'now run the code after the last Iteration to see how good')
 fprintf('Get the RMS after iteration %d .\n', inelly);   
 %%
cd(oldfolder) % setting original directory

%% Saving POROVANCOUVER and KVANCOUVER

for i=1:N %list of folders 
    
    f = 'MASTER';
   folder = strcat(f, sprintf('%.5d',i));
   
    cd(folder) % changing directory 
    
    PORO2=poro(:,i);
    PERMY2=perm(:,i);
    
    save('PERMY2.GRDECL','PERMY2','-ascii');
    save('PORO2.GRDECL','PORO2','-ascii');
    
    cd(oldfolder) % returning to original cd
    
end

%% Inserting KEYWORDS PORO and PERMY 

parfor i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',i));
    cd(folder)

CStr = regexp(fileread('PERMY2.GRDECL'), char(10), 'split');
CStr2 = strrep(CStr, 'toReplace', 'Replacement');
CStr2 = cat(2, {'PERMY'}, CStr2(1:end));
CStr2 = cat(2, CStr2(1:end), {'/'});
FID = fopen('PERMY2.GRDECL', 'w');
if FID < 0, error('Cannot open file'); end
fprintf(FID, '%s\n', CStr2{:});
fclose(FID);

CStr = regexp(fileread('PORO2.GRDECL'), char(10), 'split');
CStr2 = strrep(CStr, 'toReplace', 'Replacement');
CStr2 = cat(2, {'PORO'}, CStr2(1:end));
CStr2 = cat(2, CStr2(1:end), {'/'});
FID = fopen('PORO2.GRDECL', 'w');
if FID < 0, error('Cannot open file'); end
fprintf(FID, '%s\n', CStr2{:});
fclose(FID);

cd(oldfolder) % setting original directory

end


%% Running Simulations
disp( 'Solve the Non-Linear fluid flow Forward Problem' )
cd(oldfolder) % setting original directory

parfor i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',i));
    cd(folder)   

    fid = fopen('MASTER0.bat', 'w');
    fprintf(fid,'@ECHO OFF\n');
    % fprintf(fid,'SET SLBSLS_LICENSE_FILE=27008@eclipse.cc.ic.ac.uk\n');
    fprintf(fid,'SET SLBSLS_LICENSE_FILE=27000@10.99.15.78\n');
    fprintf(fid,'@ECHO OFF\n');
    fprintf(fid,['c:\\ecl\\macros\\$eclipse ', 'MASTER0'],'\n');
    fclose(fid);
    %while ~exist('HM.F0016','file')
        system('MASTER0.bat')
    %end

    cd(oldfolder) % setting original directory
    
end


disp(' plot production profile')
%N=100;



oldfolder=cd;
cd(oldfolder) % setting original directory
 %% Plot the Production profile of ensemble
disp('  start the plotting  ');

    for i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',i));
    %folder=oldfolder;
    %cd 'C:\Work\GSLIB\sgsim\EnKFMATLABRun'   
    cd(folder);
   
        
  
    
    %Saturation data lines [2939-5206]
    A1 = importdata('MASTER0.RSM',' ',7);
    A2 = importdata('MASTER0.RSM',' ',50);
    A3 = importdata('MASTER0.RSM',' ',93);
	A4 = importdata('MASTER0.RSM',' ',136);
    
    A1=A1.data;
    A2=A2.data;
    A3=A3.data;
	A4=A4.data;
    %SO1983=ones(2268,4)-SW1983;
    
    %save('P1983.out','P1983','-ascii');
    %save('SW1983.out','SW1983','-ascii');
    
    
     WOPR1=A1(:,3);
     WOPR2=A1(:,4);
     WOPR3=A1(:,5);
     WOPR4=A1(:,6);
     Time=A1(:,1);
     
     WWCT1=A2(:,2);
     WWCT2=A2(:,3);
     WWCT3=A2(:,4);
     WWCT4=A2(:,5);
     
     BHP1=A3(:,5);
     BHP2=A3(:,6);
     BHP3=A3(:,7);
     BHP4=A3(:,8);
	 
	 GORP1=A3(:,9);
     GORP2=A3(:,10);
     GORP3=A4(:,2);
     GORP4=A4(:,3);
	 
	 
	FOE=A4(:,8);
	 
     
    %Saturation
    
    WOPRA(:,i)=WOPR1;
    WOPRB(:,i)=WOPR2;
    WOPRC(:,i)=WOPR3;
    WOPRD(:,i)=WOPR4;
    
    WCTA(:,i)=WWCT1;
    WCTB(:,i)=WWCT2;
    WCTC(:,i)=WWCT3;
    WCTD(:,i)=WWCT4;
    
    BHPA(:,i)=BHP1;
    BHPB(:,i)=BHP2;
    BHPC(:,i)=BHP3;
    BHPD(:,i)=BHP4;
	
	GORA(:,i)=GORP1;
    GORB(:,i)=GORP2;
    GORC(:,i)=GORP3;
    GORD(:,i)=GORP4;
	
	FOEA(:,i)=FOE;
	
    
    cd(oldfolder);
    end
   cd(oldfolder) % returning to original directory
 %Import true production data
 True= importdata('Real.RSM',' ',7);
 True2= importdata('Real.RSM',' ',50);
 True3= importdata('Real.RSM',' ',93);
 True4= importdata('Real.RSM',' ',136);
 
 True=True.data;
 True2=True2.data;
 True3=True3.data;
  True4=True4.data;
 
 
 TO1=True(:,3);
 TO2=True(:,4);
 TO3=True(:,5);
 TO4=True(:,6);
 
  TW1=True2(:,2);
 TW2=True2(:,3);
 TW3=True2(:,4);
 TW4=True2(:,5);
 
  TP1=True3(:,5);
 TP2=True3(:,6);
 TP3=True3(:,7);
 TP4=True3(:,8);
 
 TG1=True3(:,9);
 TG2=True3(:,10);
 TG3=True4(:,2);
 TG4=True4(:,3);
 
 TFOE=True4(:,8);
 
 
 grey = [0.4,0.4,0.4]; 
 linecolor1 = colordg(4);
%% Plot for oil production rates
 figure()
 %subplot(2,2,1)
 plot(Time,WOPRA(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Q_o(Sm^{3}/day)','FontName','Helvetica', 'Fontsize', 13);
 ylim([0 25000])
title('Producer 1','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TO1,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 25000],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'PRO1_OILfinal','epsc')
saveas(gcf,'PRO1_OILfinal','fig')
close(figure)
 %subplot(2,2,2)
 figure()
 plot(Time,WOPRB(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Q_o(Sm^{3}/day)','FontName','Helvetica', 'Fontsize', 13);
ylim([0 25000])
title('Producer 2','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TO2,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 25000],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'PRO2_OILfinal','epsc')
saveas(gcf,'PRO2_OILfinal','fig')
close(figure)

figure()
 %subplot(2,2,3)
 plot(Time,WOPRC(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Q_o(Sm^{3}/day)','FontName','Helvetica', 'Fontsize', 13);
ylim([0 25000])
title('Producer 3','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TO3,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 25000],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'PRO3_OILfinal','epsc')
saveas(gcf,'PRO3_OILfinal','fig')
close(figure)

figure()
 %subplot(2,2,4)
 plot(Time,WOPRD(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Q_o(Sm^{3}/day)','FontName','Helvetica', 'Fontsize', 13);
ylim([0 25000])
title('Producer 4','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TO4,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 25000],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'PRO4_OILfinal','epsc')
saveas(gcf,'PRO4_OILfinal','fig')
close(figure)
%% Plot for water cut
figure()
 %subplot(2,2,1)
 plot(Time,WCTA(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Water cut','FontName','Helvetica', 'Fontsize', 13);
title('Producer 1','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TW1,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'PRO1_WATERfinal','epsc')
saveas(gcf,'PRO1_WATERfinal','fig')
close(figure)

figure()
 %subplot(2,2,2)
  plot(Time,WCTB(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Water cut','FontName','Helvetica', 'Fontsize', 13);
title('Producer 2','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TW2,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'PRO2_WATERfinal','epsc')
saveas(gcf,'PRO2_WATERfinal','fig')
close(figure)

figure()
 %subplot(2,2,3)
  plot(Time,WCTC(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Water cut','FontName','Helvetica', 'Fontsize', 13);
title('Producer 3','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TW3,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'PRO3_WATERfinal','epsc')
saveas(gcf,'PRO3_WATERfinal','fig')
close(figure)

figure()
 %subplot(2,2,4)
  plot(Time,WCTD(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Water cut','FontName','Helvetica', 'Fontsize', 13);
title('Producer 4','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TW4,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'PRO4_WATERfinal','epsc')
saveas(gcf,'PRO4_WATERfinal','fig')
close(figure)
%% Plot for BHP
figure()
 %subplot(2,2,1)
 plot(Time,BHPA(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('BHP(BARSA)','FontName','Helvetica', 'Fontsize', 13);
title('Injector 1','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TP1,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 500],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'inj1_BHPfinal','epsc')
saveas(gcf,'inj1_BHPfinal','fig')
close(figure)

figure()
 %subplot(2,2,2)
   plot(Time,BHPB(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('BHP(BARSA)','FontName','Helvetica', 'Fontsize', 13);
title('Injector 2','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TP2,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 500],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'inj2_BHPfinal','epsc')
saveas(gcf,'inj2_BHPfinal','fig')
close(figure)

figure()
 %subplot(2,2,3)
   plot(Time,BHPC(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('BHP(BARSA)','FontName','Helvetica', 'Fontsize', 13);
title('Injector 3','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TP3,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 500],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'inj3_BHPfinal','epsc')
saveas(gcf,'inj3_BHPfinal','fig')
close(figure)
figure()
 %subplot(2,2,4)
   plot(Time,BHPD(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('BHP(BARSA)','FontName','Helvetica', 'Fontsize', 13);
title('Injector 4','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TP4,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 500],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'inj4_BHPfinal','epsc')
saveas(gcf,'inj4_BHPfinal','fig')
close(figure)

%% Plot for GOR
figure()
 %subplot(2,2,1)
 plot(Time,GORA(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Gas oil ratio(Sm^{3}/Sm^{3})','FontName','Helvetica', 'Fontsize', 13);
title('Gas oil ratio for producer 1','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TG1,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1000],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'PRO1_GORfinal','epsc')
saveas(gcf,'PRO1_GORfinal','fig')
close(figure)

figure()
 %subplot(2,2,2)
   plot(Time,GORB(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Gas oil ratio(Sm^{3}/Sm^{3})','FontName','Helvetica', 'Fontsize', 13);
title('Gas oil ratio for producer 2','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TG2,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1000],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'PRO2_GORfinal','epsc')
saveas(gcf,'PRO2_GORfinal','fig')
close(figure)

figure()
 %subplot(2,2,3)
   plot(Time,GORC(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Gas oil ratio(Sm^{3}/Sm^{3})','FontName','Helvetica', 'Fontsize', 13);
title('Gas oil ratio for producer 3','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TG3,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1000],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'PRO3_GORfinal','epsc')
saveas(gcf,'PRO3_GORfinal','fig')
close(figure)

figure()
 %subplot(2,2,4)
   plot(Time,GORD(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Gas oil ratio(Sm^{3}/Sm^{3})','FontName','Helvetica', 'Fontsize', 13);
title('Gas oil ratio for producer 4','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TG4,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1000],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'PRO4_GORfinal','epsc')
saveas(gcf,'PRO4_GORfinal','fig')
close(figure)


 figure()
 plot(Time,FOEA(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Oil recovery ratio','FontName','Helvetica', 'Fontsize', 13);
title('Field oil recovery ratio','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TFOE,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'Oilrecoveryfinal','epsc')
saveas(gcf,'Oilrecoveryfinal','fig')
%saveas(h,sprintf('FIG%d.png',k))
%% Get the Norm to production data 
disp( 'Get the Norm to production data mismatch')

close(figure)
for i=1:N
    EWOP1(i,:)=immse(WOPRA(:,i),TO1);
    EWOP2(i,:)=immse(WOPRB(:,i),TO2);
    EWOP3(i,:)=immse(WOPRC(:,i),TO3);
    EWOP4(i,:)=immse(WOPRD(:,i),TO4);
    EWCT1(i,:)=immse(WCTA(:,i),TW1);
    EWCT2(i,:)=immse(WCTB(:,i),TW2);
    EWCT3(i,:)=immse(WCTC(:,i),TW3);
    EWCT4(i,:)=immse(WCTD(:,i),TW4);
    EBHP1(i,:)=immse(BHPA(:,i),TP1);
    EBHP2(i,:)=immse(BHPB(:,i),TP2);
    EBHP3(i,:)=immse(BHPC(:,i),TP3);
    EBHP4(i,:)=immse(BHPD(:,i),TP4);
	EGORP1(i,:)=immse(GORA(:,i),TG1);
    EGORP2(i,:)=immse(GORB(:,i),TG2);
    EGORP3(i,:)=immse(GORC(:,i),TG3);
    EGORP4(i,:)=immse(GORD(:,i),TG4);
end
TOTALERROR=ones(N,1);
TOTALERROR=(EWOP1./std(TO1))+(EWOP2./std(TO2))+(EWOP3./std(TO3))+...
    (EWOP4./std(TO4))+(EWCT1./std(TW1))+(EWCT2./std(TW2))...
    +(EWCT3./std(TW3))+(EWCT4./std(TW4))+(EBHP1./std(TP1))...
    +(EBHP2./std(TP2))+(EBHP3./std(TP3))+(EBHP4./std(TP4))...
	+(EGORP1./std(TG1))+(EGORP2./std(TG2))+(EGORP3./std(TG3))+(EGORP4./std(TG4));
TOTALERROR=TOTALERROR./36;
jj=min(TOTALERROR);
indexfinal = TOTALERROR; 
bestnorm = find(indexfinal == min(indexfinal));
	%Pssim = Pnew(:,bestssim); %best due to ssim
fprintf('The best Norm Realization is number %i with value %4.4f \n',bestnorm,jj);
% JOYLINE=[1:100]';
% figure()
%bar(JOYLINE,TOTALERROR);
%decreasingnorm(:,iyobo)=index;
decreasingseries=zeros(N,inelly+1);
decreasingseries(:,1:inelly)=decreasingnorm;
decreasingseries(:,inelly+1)=indexfinal;
reali=[1:N]';

 figure()
 bar(reali,indexfinal,'cyan');
 xlabel('Realizations', 'FontName','Helvetica', 'Fontsize', 13);
 ylabel('RMSE value', 'FontName','Helvetica', 'Fontsize', 13);
 title('Cost function for Realizations','FontName','Helvetica', 'Fontsize', 13)
 set(gcf,'color', 'white');
 hold on
 scatter(reali,index,'black','filled');
 xlabel('Realizations', 'FontName','Helvetica', 'Fontsize', 13)
 ylabel('RMSE value', 'FontName','Helvetica', 'Fontsize', 13)
 hold off
 xlim([1,N]);
 saveas(gcf,'RMSfinal','epsc')
 saveas(gcf,'RMSfinal','fig')
close(figure)
CMRmap=[0 0 0;.3 .15 .75;.6 .2 .50;1 .25 .15;.9 .5 0;.9 .9 .5;1 1 1];
 disp('  Final RMS computation executed  ');
 
 disp('maintain bimodal distribution')
 [mumyperm,mumyporo]=maintain_Bimodal(oriK,oriporo,mumyperm,mumyporo,nx,ny,nz,N,CMRmap);
 disp('  Smooth the final permeability and porosity Maps  ');
if needed==1
for ki=1:numberoftimes
  [mumyperm,mumyporo]=clean(nx,ny,nz,N,mumyperm,mumyporo,rossmary,rossmaryporo);
 end
end
get_stats_ensemble(mumyperm,mumyporo,N,inelly+1,rossmary,rossmaryporo);
disp(' plot ensemble')
%plot_ens(mumyperm,N,'final ensemble');
if maintainit==1
    [mumyperm,mumyporo]=maintainconn(mumyperm,mumyporo,N,nx,ny,nz,rossmary,rossmaryporo);
end
disp( 'output the permeability and porosity history matched model for the last iteration')
file = fopen('sgsimfinal.out','w+'); %output the dictionary
for k=1:numel(mumyperm)                                                                       
fprintf(file,' %4.6f \n',mumyperm(k) );             
end

file2 = fopen('sgsimporofinal.out','w+'); %output the dictionary
for k=1:numel(mumyporo)                                                                       
fprintf(file2,' %4.6f \n',mumyporo(k) );             
end

file3 = fopen('genesisNorm.out','w+');
 for k=1:numel(decreasingnorm)                                                                       
 fprintf(file3,' %4.4f \n',decreasingnorm(k) );             
 end
 
 file4 = fopen('evolvingNorm.out','w+');
 for k=1:numel(decreasingseries)                                                                       
 fprintf(file4,' %4.4f \n',decreasingseries(k) );             
 end
disp('1=yes')
disp('2=no' )
response=input('Do you want to plot the permeability map ');

disp( 'Well locaions consisting of injector and producer well')
iInj = [30, 58, 90, 101]; % 4 wells configuration, injection wells
jInj = [55, 18, 6, 39]; % 4 wells configuration, injection wells
iProd = [14, 38, 96, 67]; % 4 wells configuration, production wells
jProd = [25, 39, 23, 41]; % 4 wells configuration, production wells


if response==1
    disp( 'Pixel map needed')
    [bestnorm3,PlogK]=clementPlot(mumyperm,rossmary,N,bestnorm,CMRmap);
    xr=reshape(PlogK,nx*ny,nz);
    
plottinglocations(xr, nx, ny,nz, 'Layer', iInj, jInj, iProd, jProd, min(xr), max(xr),CMRmap);
disp(' green are injector wells and blue are producers')
     %run('clementPlot.m')
else
    disp (' pixel map not needed')
end

fprintf('Finished Iterations with the History matching method %d .\n', method);

if method==1
disp('The method used was ESMDA with Levelset impelemented with main_Levelset')
elseif method==2
disp('The method used was ESMDA impelemented with main_DCT( discrete cosine transform method coupled with ESMDA)')
elseif method==3
disp('The method used was compressed sensing ESMDA impelemented with main_sparsity(compressed sensing)')
elseif method==4
disp('The method used was SELE_PhD (My method coupling machine learning with Level set)')
elseif method==5
disp('The method used was main_DCT_Levelset(My method coupling DCT with Level set)')
elseif method==6
disp('The method used was main_DCT_LS2 (Level set and DCT update)')
elseif method==7
disp('The method used was main_sparsity_LS(Level set update)') 
elseif method==8
disp('The method used was main_Levelset_Boundary ')
elseif method==9
disp('The method used was main_Velocity_LS')
elseif method==10
disp('The method used was main_ESMDA_Localization-covariance localization')
elseif method==11
disp('The method used was main_Levelset_Cov-covariance localization with Levelset')
elseif method==12
  disp('The method used was main_Levelset_Cov-covariance localization with Levelset perm only')  
elseif method==13
  disp( 'The method 13 specified-Localization with ESMDA and Levelset/Normal score')
elseif method==14
    disp( 'The method 14 specified-Localization with ESMDA and Levelset varying alpha')
elseif method==15
    disp(' The method 15 using Artificial neural network was used')
elseif method==16
    disp( 'The method 16 was specified denting ELM with Levelset')
elseif method==17
    disp( 'The method used was discret wavelet transform')
elseif method==18
    disp( 'The method used was CV deutsch Normal score transform')
else
    disp(' The method used was recusrsive channel update')
end
disp('  The overall program has been executed and the history matched files saved in the folder  ');
toc