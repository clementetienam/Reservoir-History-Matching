function [overallmean,overallmeanporo]=getSTDmean(perm,poro,nx,ny,nz,N)
%% Get mean of ensemble of  log permeability and porosity field
disp(' extract the active grid cells' )
 sgsim1=log(perm);

 sgsim11 = reshape(sgsim1,nx*ny*nz,N);
 sgsim11poro = reshape(poro,nx*ny*nz,N);
 for i=1:N
 overallmean(:,i)=mean(sgsim11(:,i));

 
  overallmeanporo(:,i)=mean(sgsim11poro(:,i));
 
 end
end