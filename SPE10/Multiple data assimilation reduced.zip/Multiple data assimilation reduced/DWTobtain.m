function [clementLL,clementLH,clementHH,clementHL,sX] = DWTobtain(sg, N,nx,ny,nz)
%% DWT domain reduction for permeability field
disp('  DWT domain reduction  ');
%%PhD student: Clement Oku Etienam
%%Supervisor: Dr Rossmary Villegas
%%Co-supervisor: Dr Masoud Babei
%%Collaborator : Dr Oliver Dorn
%%
disp('  Load the relevant files  ');

sgsim1=reshape(sg,nx*ny*nz,N);

sgsim1=reshape(sgsim1,nx*ny*nz,N);
%sgsim=(sg);
LF=reshape(sgsim1,nx*ny*nz,N);
disp('  carry out DCT domain reduction  ');
for ii=1:N
    lf=reshape(LF(:,ii),nx,ny,nz);
     
     for jj=1:nz
         
         value=lf(:,:,jj);
         sX = size(value);
    [LL,LH,HL,HH]=dwt2(value,'db1');
         
         HH=reshape(HH,1800,1);
         youngHH(:,jj)=HH;
         
         HL=reshape(HL,1800,1);
         youngHL(:,jj)=HL;
         
         LH=reshape(LH,1800,1);
         youngLH(:,jj)=LH;
         
         LL=reshape(LL,1800,1);
         youngLL(:,jj)=LL;
     end
      sdfbigLL=reshape(youngLL,9000,1);
  clementLL(:,ii)=sdfbigLL;
  
    sdfbigLH=reshape(youngLH,9000,1);
  clementLH(:,ii)=sdfbigLH;
  
    sdfbigHL=reshape(youngHL,9000,1);
  clementHL(:,ii)=sdfbigHL;
   
   sdfbigHH=reshape(youngHH,9000,1);
  clementHH(:,ii)=sdfbigHH;
  
end