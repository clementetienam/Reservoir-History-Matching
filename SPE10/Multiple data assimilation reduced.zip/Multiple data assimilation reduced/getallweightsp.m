function [iwall,bwall,Lwall]=getallweightsp(N);

for j=1:N
    
     load(['netporo' num2str(j) '.mat']);
    wb=getwb(net);

[b,IW,LW]=separatewb(net,wb);

 weights=IW{1,1};
 biass=b{1,1};
 layweight=LW{2,1};
 
 iwall(:,j)=weights;
 bwall(:,j)=biass;
 Lwall(:,j)=layweight;
 end

end