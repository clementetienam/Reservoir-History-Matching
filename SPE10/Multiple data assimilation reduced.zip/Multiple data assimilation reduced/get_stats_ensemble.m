function get_stats_ensemble(A,Aporo,N,iyobo,rossmary,rossmaryporo);
A=log(A);
for i=1:N
sgsimuse=reshape(A(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,36000,1);
sg(:,i)=ex;
end

for i=1:N
sgsimporouse=reshape(Aporo(:,i),120,60,10);
sgsporo=sgsimporouse(:,:,3:7);
exporo=reshape(sgsporo,36000,1);
sgporo(:,i)=exporo;
end
rossmary=reshape(rossmary,120,60,10);
rossmaryporo=reshape(rossmaryporo,120,60,10);
ross=log(rossmary(:,:,3:7));
ross=reshape(ross,36000,1);
rossp=rossmaryporo(:,:,3:7);
rossp=reshape(rossp,36000,1);
M2=mean(sg,2);
M2p=mean(sgporo,2);
for j=1:N
    A1(:,j)=sg(:,j)-M2;
    A1p(:,j)=sgporo(:,j)-M2p;
end
ne1skew = skewness(A1);
ne2kourt = kurtosis(A1);

ne1skewp = skewness(A1p);
ne2kourtp = kurtosis(A1p);

figure()
subplot(2,3,1)
plot(ne1skew,'r');
hold on
plot(ne2kourt,'b');
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
title('Skewness and Kourtoisis of permeability','FontName','Helvetica', 'Fontsize', 13)
legend('Skewness','kurtosis','location','northeast');

subplot(2,3,2)
plot(ne1skewp,'r');
hold on
plot(ne2kourtp,'b');
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
title('Skewness and Kourtoisis of porosity','FontName','Helvetica', 'Fontsize', 13)
legend('Skewness','kurtosis','location','northeast');



subplot(2,3,3)
hist(ross);

set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
title('True permeability ','FontName','Helvetica', 'Fontsize', 13)
legend('True','location','northeast');


subplot(2,3,4);

hist(M2);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
title('Mean permeability of Ensemble','FontName','Helvetica', 'Fontsize', 13)
legend('Ensemble mean','location','northeast');

subplot(2,3,5)
hist(rossp);

set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
title('True porosity ','FontName','Helvetica', 'Fontsize', 13)
legend('True','location','northeast');


subplot(2,3,6);

hist(M2p);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
title('Mean porosity of Ensemble','FontName','Helvetica', 'Fontsize', 13)
legend('Ensemble mean','location','northeast');

saveas(gcf,sprintf('Statsmean2%d.fig',iyobo))
close(figure)
 end