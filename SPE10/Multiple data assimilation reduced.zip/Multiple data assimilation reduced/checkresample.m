clc;
clear all;
close all;
load sgsim.out;
load sgsimenkf.out;

N=100;
sgsim=reshape(sgsim,72000,N);
sgsimenkf=reshape(sgsimenkf,72000,N);
% for i=1:N
% sgsimuse=reshape(sgsim(:,i),120,60,10);
% sgs=sgsimuse(:,:,3:7);
% ex=reshape(sgs,36000,1);
% sg(:,i)=ex;
% end
y = datasample(sgsim,300,2);
y2 = randsample(sgsim,300);

for i=1:N
    I=mat2gray(reshape(sgsimenkf(:,i),120,60,10));
    ref=mat2gray(reshape(sgsim(:,i),120,60,10));
    for j=1:10
    J = imhistmatch(I(:,:,j),ref(:,:,j));
    jj(:,j)=reshape(J,7200,1);
    end
    allj(:,i)=reshape(jj,72000,1);
end
allj(allj>0)=1000;
allj(allj==0)=50;
disp('1=yes')
disp('2=no' )
response=input('Do you want to plot the permeability map ');

disp( 'Well locaions consisting of injector and producer well')
iInj = [30, 58, 90, 101]; % 16 wells configuration, injection wells
jInj = [55, 18, 6, 39]; % 16 wells configuration, injection wells
iProd = [14, 38, 96, 67]; % 16 wells configuration, production wells
jProd = [25, 39, 23, 41]; % 16 wells configuration, production wells
CMRmap=[0 0 0;.3 .15 .75;.6 .2 .50;1 .25 .15;.9 .5 0;.9 .9 .5;1 1 1];

if response==1
    disp( 'Pixel map needed')
    [bestnorm3,PlogK]=clementPlot(allj,sgsim(:,26),N,2,CMRmap);
    xr=reshape(PlogK,120*60,5);
    
plottinglocations(xr, 120, 60,5, 'Layer', iInj, jInj, iProd, jProd, min(xr), max(xr),CMRmap);
disp(' green are injector wells and blue are producers')
     %run('clementPlot.m')
else
    disp (' pixel map not needed')
end
