function [mumyperm,mumyporo]=main_sparsity_LS(Yes2signed,Yes2signedporo,nx,ny,nz,Yes2,Yes2poro,N,tol,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha);
close all;
disp( 'History matching data assimilation technique using Sparity enhancement on the Level set-ES-MDA for SPE10 Reservoir'  ) 
disp( 'PhD Student: Clement Etienam' )
disp( 'Supervisor: Dr Rossmary Villegas' )
disp( 'Co-supervisor: Dr Masoud Babei' )
disp('  import the true data  ');
% N - size of ensemble


oldfolder=cd;
cd(oldfolder) % setting original directory
 


sgsim=reshape(perm,72000,N);
sgsimporo=reshape(poro,72000,N);
for i=1:N
sgsimuse=reshape(sgsim(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,36000,1);
sg(:,i)=ex;
end

for i=1:N
sgsimporouse=reshape(sgsimporo(:,i),120,60,10);
sgsporo=sgsimporouse(:,:,3:7);
exporo=reshape(sgsporo,36000,1);
sgporo(:,i)=exporo;
end

disp( ' covert spatial permeability and porosity to sparse')
sgpermsparse=Sparse(sg,Yes2);
sgporosparse=Sparse(sgporo,Yes2poro);

Sim11=reshape(overallsim,17,history,N);
 cd(oldfolder)

sgout=zeros(36000*N,1);
sgoutporo=zeros(36000*N,1);

 for ii=1:36000*N
    if(sg(ii)>=100)
        sgout(ii)=1;
    end
end

 for ii=1:36000*N
    if(sgporo(ii)>=0.1805)
        sgoutporo(ii)=1;
    end
end
disp( 'Convert the facies field to signed distance transform')
clement=getsigned(sgout,nx,ny,N);
clementporo=getsigned(sgoutporo,nx,ny,N);

disp( 'Convert the signed distance transform to sparse')
clement=double(clement);
clementporo=double(clementporo);
sgsparse=Sparse(clement,Yes2signed);
sgsparseporo=Sparse(clementporo,Yes2signedporo);
 cd(oldfolder)
for i=1:history
 fprintf('Now assimilating timestep %d .\n', i);
 
Sim1=Sim11(:,i,:);
Sim1=reshape(Sim1,17,N);

f=observation(:,i);
[sgsim2,DupdateK,sgpermsparse2,sgporosparse2] = ESMDA_Sparsity_LS(sgsparse,sgsparseporo,f, N, Sim1,alpha,tol,sgpermsparse,sgporosparse);
sgsparse=DupdateK;
sgsparseporo=sgsim2;
sgpermsparse=sgpermsparse2;
sgporosparse=sgporosparse2;
%condition the data

 fprintf('Finished assimilating timestep %d \n', i);
end
disp( 'recover the full signed distance field')
joyy=reshape(Yes2signed,36000,1500)*sgsparse;
joyyporo=reshape(Yes2signedporo,36000,1500)*sgsparseporo;

clementperm=joyy;
clementporo=joyyporo;

disp( 'recover the full permeability and porosity field')
yobo=reshape(Yes2,36000,1500)*sgpermsparse;
yoboporo=reshape(Yes2poro,36000,1500)*sgporosparse;

yobo=reshape(yobo,36000*N,1);
yoboporo=reshape(yoboporo,36000*N,1);

updatedperm=zeros(36000*N,1);
updatedporo=zeros(36000*N,1);

for ii=1:36000*N
    if(yobo(ii)>=100)
        updatedperm(ii)=1;
    end
	 if(yoboporo(ii)>=0.1805)
        updatedporo(ii)=1;
    end
	
end

disp( 'reclassify the signed distance field to facies indicator field')
for ii=1:N
    lf=reshape(clementperm(:,ii),120,60,5);
     for jj=1:5
         value=lf(:,:,jj);
		 usdf=value<=0;
		 usdf=double(usdf);
         usdf=reshape(usdf,7200,1);
         young(:,jj)=usdf;
     end
      sdfbig=reshape(young,36000,1);
  clementpermL(:,ii)=sdfbig;
  
end
 clementpermL=reshape( clementpermL,36000*N,1);

for ii=1:N
    lf=reshape(clementporo(:,ii),120,60,5);
     for jj=1:5
         value=lf(:,:,jj);
		 usdf=value<=0;
		 usdf=double(usdf);
         usdf=reshape(usdf,7200,1);
         young(:,jj)=usdf;
     end
      sdfbig=reshape(young,36000,1);
  clementporoL(:,ii)=sdfbig;
end
clementporoL=reshape(clementporoL,36000*N,1);


%disp( 'Convert to continuous pixel values using the right mean and standard deviation')
%zz=[2 -0.01];
%zz2=[1 0.09];

requiredK=zeros(36000*N,1);
requiredporo=zeros(36000*N,1);

for iii=1:36000*N

  if (updatedperm(iii)== clementpermL(iii)) 
    requiredK(iii)=yobo(iii);
  end 
  
  if (updatedporo(iii)==clementporoL(iii)) 
    requiredporo(iii)=yoboporo(iii);
  end 
  
  
  if ((updatedperm(iii) ~= clementpermL(iii)) && (clementpermL(iii)==0)) 

        
        requiredK(iii)=95;
  end
   if ((updatedperm(iii)~= clementpermL(iii)) && (clementpermL(iii)==1)) 

      
         requiredK(iii)=105;
    end 
 
  
  
  if ((updatedporo(iii) ~= clementporoL(iii)) && (clementporoL(iii)==0)) 

        
        requiredporo(iii)=0.1795 ;
  end
   if ((updatedporo(iii)~= clementporoL(iii)) && (clementporoL(iii)==1)) 

      
         requiredporo(iii)=0.1895;
    end 
  
  
end

requiredK=abs(requiredK);
requiredporo=abs(requiredporo);
%requiredporo= filter(1,zz2,requiredporo);

disp( 'condition the field and honour')
[output,outputporo] = honour2(rossmary, rossmaryporo, N,requiredporo,requiredK);
permsteps=reshape(output,36000*N,1); 
porosteps=reshape(outputporo,36000*N,1);

disp('  output to ASCII files the states at each time step  ');
sgassimi=permsteps; 
sgporoassimi=porosteps;

permanswers=reshape(sgassimi,36000,N);
poroanswers=reshape(sgporoassimi,36000,N);

for i=1:N
sgsim=zeros(120,60,10);
sgsimporo=zeros(120,60,10);
sgsim(:,:,3:7)=reshape(permanswers(:,i),120,60,5);
sgsimporo(:,:,3:7)=reshape(poroanswers(:,i),120,60,5);

sgsimmijana(:,i)=reshape(sgsim,72000,1);
sgsimporomijana(:,i)=reshape(sgsimporo,72000,1);
end

mumyperm=sgsimmijana;
mumyporo=sgsimporomijana;
 disp('  The program has been executed  ');

end