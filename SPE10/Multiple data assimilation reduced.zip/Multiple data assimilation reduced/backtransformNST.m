function [sgsimperm,sgsimporo1]=backtransformNST(transformK,transformporo,overalbee,overalbeeporo,overallalupha,overallaluphaporo);
sgsimpermalm=transformK;
sgsimporoalm=transformporo;

disp( 'back transform the updated permeability and porosity')
for i=1:N
sgsimperm(:,i)=exp((sgsimpermalm(:,i).*overalbee(:,i))+ overallalupha(:,i));
end
for i=1:N
sgsimporo1(:,i)=exp((sgsimporoalm(:,i).*overalbeeporo(:,i))+ overallaluphaporo(:,i));
end

sgsimperm=exp(sgsimperm);
end