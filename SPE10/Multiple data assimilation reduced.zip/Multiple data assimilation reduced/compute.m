clc;
clear all;
close all;
% compute the mean of measurements and discrpancy
load sgsim1.out;
load f.dat;
load H.out;
H=reshape(H,12,72000);
sgsim=reshape(sgsim1,72000,100);
M = mean(sgsim,2);
%M=M'
for j=1:100
    S(:,j)=sgsim(:,j)-M;
end
si=H*S;

% read true permeability well value

% 

% output=reshape(B,120*60*10,100);
%output permeability conditioned ensemble
 file = fopen('chizzy.out','w+'); 
 for k=1:numel(S)                                                                       
 fprintf(file,' %4.4f \n',S(k) );             
 end
 file = fopen('si.out','w+'); 
 for k=1:numel(si)                                                                       
 fprintf(file,' %4.4f \n',si(k) );             
 end
