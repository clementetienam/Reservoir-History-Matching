function [meansandak,meanshaleak,faciesar,meansandap,meanshaleap,faciesrap]=RCUmfmean(meansandk,meanshalek,faciesr,meansandp,meanshalep,faciesrp)
meansandak=mean(meansandk,2);
meanshaleak=mean(meanshalek,2);
faciesar=mean(faciesr,2);
meansandap=mean(meansandp,2);
meanshaleap=mean(meanshalep,2);
faciesrap=mean(faciesrp,2);
end