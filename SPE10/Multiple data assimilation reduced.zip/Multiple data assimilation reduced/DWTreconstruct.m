function clementperm = DWTreconstruct(clementLL,clementLH,clementHL,clementHH,N,nx,ny,nz,sX)
disp('  inverse DWT  ');
%%PhD student: Clement Oku Etienam
%%Supervisor: Dr Rossmary Villegas
%%Co-supervisor: Dr Masoud Babei
%%Collaborator : Dr Oliver Dorn
%%
value1LL=clementLL(1:9000,1:N);
value1LH=clementLH(1:9000,1:N);
value1HL=clementHL(1:9000,1:N);
value1HH=clementHH(1:9000,1:N);


valuepermjoyLL=value1LL;
valuepermjoyLH=value1LH;
valuepermjoyHL=value1HL;
valuepermjoyHH=value1HH;
for ii=1:N
    lf=reshape(valuepermjoyLL(:,ii),60,30,nz);
    lfLH=reshape(valuepermjoyLH(:,ii),60,30,nz);
    lfHL=reshape(valuepermjoyHL(:,ii),60,30,nz);
    lfHH=reshape(valuepermjoyHH(:,ii),60,30,nz);
    
     for jj=1:nz
         valueperm=lf(:,:,jj);
         valuepermLH=lfLH(:,:,jj);
         valuepermHL=lfHL(:,:,jj);
          valuepermHH=lfHH(:,:,jj);
                 
        LL=valueperm;
        
        
        LH=valuepermLH;
        
        
        HL=valuepermHL;
        
      
        HH= valuepermHH;
        
        rec = idwt2(LL,LH,HL,HH,'db1',sX);
      
        rec=(abs(rec));
         usdf=reshape(rec,nx*ny,1);
         young(:,jj)=usdf;
     end
      sdfbig=reshape(young,nx*ny*nz,1);
  clementperm(:,ii)=sdfbig;
end
%clementperm=exp(clementperm);
end