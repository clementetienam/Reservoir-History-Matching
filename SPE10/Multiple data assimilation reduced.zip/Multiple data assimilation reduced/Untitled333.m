clc;
clear;
load rossmary.GRDECL;
rossmary=log10(rossmary);
true=reshape(rossmary,120,60,10);
trueuse=true(:,:,1);
for j=1:60
    model(:,j)=trueuse(:,j);
end
[RotMat,TransVec2,dataOut]=icp(model,trueuse);
clee=RotMat*trueuse';
for i=1:120
clem(:,i)=clee(:,i)+TransVec2;
end
clem=clem';
dataOut=dataOut';
CMRmap=[0 0 0;.3 .15 .75;.6 .2 .50;1 .25 .15;.9 .5 0;.9 .9 .5;1 1 1];
[X2,Y2] = meshgrid(1:120,1:60);
figure()
subplot(2,2,1);
surf(X2',Y2',dataOut)
shading flat
axis([1 120 1 60 ])
grid off
title('initial','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap(CMRmap)
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 5])
title('Restored Layer')
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(2,2,2);
surf(X2',Y2',trueuse)
shading flat
axis([1 120 1 60 ])
grid off
title('Model 2','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap(CMRmap)
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 5])
title('Restored Layer')
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

r = normrnd(0,0.5,120,60)+model;
[RotMat,TransVec,datar]=icp((r),dataOut);
datar=datar';
subplot(2,2,3);
surf(X2',Y2',datar)
shading flat
axis([1 120 1 60 ])
grid off
title('Model pertubed','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap(CMRmap)
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 5])
title('Restored Layer')
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(2,2,4);
surf(X2',Y2',clem)
shading flat
axis([1 120 1 60 ])
grid off
title('Model pertubed','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap(CMRmap)
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 5])
title('Restored Layer')
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])