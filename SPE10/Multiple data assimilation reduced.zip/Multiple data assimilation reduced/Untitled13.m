load sgsim.out;
load sgsimporo.out;
averagedata = avergaesimulated (sgsim,sgsimporo,120,60,5,100,36);