close all;
clear all; 
clc;
format compact
N=200;
nx=19;
ny=28;
nz=5;
load sgsim.out; %initial permeabiity
trunc=4.90;
sgout=zeros(nx*ny*nz*N,1);


 for ii=1:nx*ny*nz*N
    if(sgsim(ii)>=trunc)
        sgout(ii)=1;
    end
 end

perm=reshape(sgsim,2660,N);
sgout=reshape(sgout,2660,N);
load sgsimfinal.out;

%  net = newrb(perm',perm');
perm2=reshape(sgsimfinal,2660,N);
%---------------------------------
% no hidden layers
net = feedforwardnet(10);
net = train(net,perm,sgout);
%---------------------------------
% view net
view (net)
% simulate a network over complete input range
Y = net(perm);
% plot network response
figure(fig)
plot(perm(:,1),Y(:,1),'color',[1 .4 0])
legend('original function','available data','Linear regression','location','northwest')