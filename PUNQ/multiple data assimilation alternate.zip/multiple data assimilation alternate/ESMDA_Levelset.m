function [DupdateK,updatedlevelset,clement] = ESMDA_Levelset (sgactual,f, N, Sim1,alpha,tol,indices,clement,nbandall,effective);
%Get the localization for all the wells
c=3;
A=zeros(19,28,5);
for j=1:5
    A(10,22,j)=1;
    A(9,17,j)=1;
    A(17,11,j)=1;
    A(11,24,j)=1;
    A(15,17,j)=1;
    A(17,22,j)=1;
    
    
end
disp( 'calculate the euclidean distance function to the 6 producer wells')
    lf=reshape(A,19,28,5);
   for j=1:5;
     sdf=lf(:,:,j);
  [usdf,IDX] = bwdist(sdf);
  usdf=reshape(usdf,532,1);
  young(:,j)=usdf;
   
   end
   sdfbig=reshape(young,2660,1);
   sdfbig1=abs(sdfbig);
   z=sdfbig1;
   % the value of the range should be computed accurately.
   %c=range(z);
  
  
   c0OIL1=zeros(2660,1);
   disp( 'compute the gaspari-cohn coefficent')
  for i=1:2660;
 if (0<=z(i,:) || z(i,:)<=c)
  c0OIL1(i,:)=-0.25*(z(i,:)/c)^5+0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3-(5.0/3.0)*(z(i,:)/c)^2+1;
elseif z < 2*c
  c0OIL1(i,:)=(1.0/12.0)*(z(i,:)/c)^5-0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3+(5.0/3.0)*(z(i,:)/c)^2-5*(z(i,:)/c)+4-(2.0/3.0)*(c/z(i,:));
 elseif (c<=z(i,:) || z(i,:)<=2*c)
     c0OIL1(i,:)=-5*(z(i,:)/c)+4-0.667*(c/z(i,:));
 else
     c0OIL1(i,:)=0;
 end
  
  end
  
c0OIL1(c0OIL1<0)=0;
  %[c0OIL1] = calc_loccoeffs(c, 'Gaspari_Cohn', z); 

 disp(' get the gaspari cohn for Cyd') 
 
    schur=c0OIL1;
      Bsch = repmat(schur,1,18);
  
  
   yoboschur=Bsch;
   covuse=ones(5320,18);
   covuse(1:2660,:)=yoboschur;
   
  Bsch2 = repmat(effective,1,N);  
sgsim1=(sgactual);
% sgz1=log(sgz);
 sgsim11 = reshape(sgsim1,2660,N);
clement=reshape(clement,2660,N);
fuse=f(2:19,:);
 Simuse=Sim1(2:19,:);
 Sim1=Simuse;
 f=fuse;
nobs = length(f);
noise = randn(max(10000,nobs),1);
 
 
disp('  generate Gaussian noise for the observed measurments  ');


    %stddFOE =    0.1*f(1,:);
	
	stddBHP1 = 0.1*f(1,:);
    stddBHP2 = 0.1*f(2,:);
    stddBHP3 = 0.1*f(3,:);
    stddBHP4 = 0.1*f(4,:);
	stddBHP5 = 0.1*f(5,:);
	stddBHP6 = 0.1*f(6,:);
	
	stddGORP1 = 0.15*f(7,:);
    stddGORP2 = 0.15*f(8,:);
    stddGORP3 = 0.15*f(9,:);
    stddGORP4 = 0.15*f(10,:);
	stddGORP5 = 0.15*f(11,:);
    stddGORP6 = 0.15*f(12,:);
  

    stddWWCT1 = 0.2*f(13,:);
    stddWWCT2 = 0.2*f(14,:);
    stddWWCT3 =0.2*f(15,:);
    stddWWCT4 = 0.2*f(16,:);
	stddWWCT5 = 0.2*f(17,:);
	stddWWCT6 = 0.2*f(18,:);

  
Error1=ones(18,1);
Error1(1,:)=stddBHP1;
Error1(2,:)=stddBHP2;
Error1(3,:)=stddBHP3;
Error1(4,:)=stddBHP4;
Error1(5,:)=stddBHP5;
Error1(6,:)=stddBHP6;
Error1(7,:)= stddGORP1;
Error1(8,:)= stddGORP2;
Error1(9,:)= stddGORP3;
Error1(10,:)= stddGORP4;
Error1(11,:)= stddGORP5;
Error1(12,:)= stddGORP6;
Error1(13,:)=stddWWCT1;
Error1(14,:)=stddWWCT2;
Error1(15,:)=stddWWCT3;
Error1(16,:)=stddWWCT4;
Error1(17,:)=stddWWCT5;
Error1(18,:)=stddWWCT6;


sig=Error1;
for i = 1 : length(f)
           f(i) = f(i) + sig(i)*noise(end-nobs+i);
end
R = sig.^2;
  Dj = repmat(f, 1, N);
           for i = 1:size(Dj,1)
             rndm(i,:) = randn(1,N); 
             rndm(i,:) = rndm(i,:) - mean(rndm(i,:)); 
             rndm(i,:) = rndm(i,:) / std(rndm(i,:));
             Dj(i,:) = Dj(i,:) + sqrt(alpha)*sqrt(R(i)) * rndm(i,:);
           end


Cd2 =diag(R);

nbandall=reshape(nbandall,2660,N);
nbandI=ones(5320,N); %narrow band matrix
%nbandI(1:2660,1:N)=yoboschur;
nbandI(2661:5320,1:N)=nbandall;

disp('  generate the ensemble state matrix containing parameters and states  ');
%Saturation,Pressure,SaturationG,RSG
overall=zeros(5320,N); 

overall(1:2660,1:N)=sgsim11;
overall(2661:5320,1:N)=clement;

Yens=overall; %State variable,it is important we include simulated measurements in the ensemble state variable
% number of state variables
ns = size(Yens,1);

% measurements
y = mean(Dj,2);
m = numel(y);

% ensemble of measurement perurbations
E = Dj - repmat(y,1,N);
%Cd2=E*E'/(N-1);
% simulated measurement anomaly matrix
S = Sim1-repmat(mean(Sim1,2),1,N);
Cyd=((Yens - repmat(mean(Yens,2),1,N))*S')./(N-1);
Cdd=(S*S')./(N-1);
down=Cdd+(alpha.*Cd2);
Cyd=covuse.*(Cyd);
Kalman=Cyd*pinv2(down);
Residual=Dj-Sim1;
update=Kalman*Residual;

disp('  update the new ensemble  ');
Ynew=Yens+(nbandI.*(update));

disp( 'extract the active permeability field ')
value1=Ynew(1:2660,1:N);


DupdateK=(value1);
clement=Ynew(2661:5320,1:N);

updatedlevelset=Ynew(2661:5320,1:N);

updatedlevelset(updatedlevelset>0)=1;
updatedlevelset(updatedlevelset<=0)=0;
end