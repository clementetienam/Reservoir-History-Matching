function nbandall=regionband(sgout,N,nx,ny,nz)
sgout=reshape(sgout,2660,N);
for ii=1:N
    lf=reshape(sgout(:,ii),nx,ny,nz);
   for j=1:5
     sdf=lf(:,:,j);
 
  usdf = boundarymask(sdf);
  usdf=reshape(usdf,532,1);
  young(:,j)=usdf;
   
   end
   sdfbig=reshape(young,2660,1);
   sdfbig=double(sdfbig);
  nbandall(:,ii)=sdfbig;
end
end