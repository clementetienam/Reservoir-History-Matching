function [mumyperm,mumyporo,mumypermz]=main_ESMDA_Levelset(nx,ny,nz,N,tol,observation,overallsim,rossmary,rossmaryporo,rossmaryz2,perm,history,alpha,effective);
sgsim=reshape(perm,nx*ny*nz,N);
sgactual=log(sgsim);
sg=sgactual;
Sim11=reshape(overallsim,19,history,N);
indices=find(effective);
% [SWn83,PEn83,SGn83,RSEn83]=getstatesallenkf(N,1);
% 
%  SWn83=reshape(SWn83,1764,N);
% PEn83=reshape(PEn83,1764,N);
% SGn83=reshape(SGn83,1764,N);
% RSEn83=reshape(RSEn83,1764,N);
% 
% Saturation=SWn83;
% 
% Pressure=PEn83;
% 
% SaturationG=SGn83;
% 
% RSG=RSEn83;
%History matching using ESMDA

trunc=3.69;
sgout=zeros(nx*ny*nz*N,1);


 for ii=1:nx*ny*nz*N
    if(sg(ii)>=trunc)
        sgout(ii)=1;
    end
 end

 disp (' get the signed distance of permeability and porosity fields')
clement=getsigned(sgout,nx,ny,N);


disp( 'get the narrowband function of permeability and porosity fields')
 nbandall=regionband(sgout,N,nx,ny,nz);

for i=1:history
 fprintf('Now assimilating timestep %d .\n', i);

 
Sim1=Sim11(:,i,:);
Sim1=reshape(Sim1,19,N);

f=observation(:,i);
[DupdateK,updatedlevelset,clement] = ESMDA_Levelset (sgactual,f, N, Sim1,alpha,tol,indices,clement,nbandall,effective);
nbandall=regionband(updatedlevelset,N,nx,ny,nz);
sgactual=DupdateK;

 fprintf('Finished assimilating timestep %d \n', i);
end
disp( 'rectify the conflict of permeabilit and porosity fields with updated Level set')
sgsim11=reshape(DupdateK,2660*N,1);

updatedlevelset=reshape(updatedlevelset,2660*N,1);

updatedperm=zeros(2660*N,1);


for ii=1:2660*N
    if(sgsim11(ii)>=trunc)
        updatedperm(ii)=1;
    end
	
	
end


requiredK=zeros(2660*N,1);


for iii=1:2660*N

  if (updatedperm(iii)==updatedlevelset(iii)) 
    requiredK(iii)=sgsim11(iii);
  end 
  

  
  
  if ((updatedperm(iii) ~= updatedlevelset(iii)) && (updatedlevelset(iii)==0)) 

        
        requiredK(iii)=3.6;
  end
   if ((updatedperm(iii)~= updatedlevelset(iii)) && (updatedlevelset(iii)==1)) 

      
         requiredK(iii)=4;
    end 
 
  
  
  
  
  
end
requiredK=abs(requiredK);


disp('recover the full permeability field')

DupdateK2=exp(requiredK);

DupdateK2=reshape(DupdateK2,2660,N);
disp('  recover the porosity and permz field from Logs  ');
for ii=1:N;
    Knew=reshape(DupdateK2(:,ii),nx,ny,nz);
   for j=1:5;
 pore(:,:,1)=0.040228*log(Knew(:,:,1))-0.03101;
pore(:,:,2)=0.022608*log(Knew(:,:,2))+0.0066038;
pore(:,:,3)=0.046974*log(Knew(:,:,3))-0.072764;
pore(:,:,4)=0.025312*log(Knew(:,:,4))+0.01088;
pore(:,:,5)=0.039746*log(Knew(:,:,5))-0.038238;


permz(:,:,1)=0.88227*log(Knew(:,:,1))-0.29112;
permz(:,:,2)=0.89976*log(Knew(:,:,2))-1.1289;
permz(:,:,3)=0.69049*log(Knew(:,:,3))+1.0074;
permz(:,:,4)=0.82778*log(Knew(:,:,4))-0.56077;
permz(:,:,5)=0.97173*log(Knew(:,:,5))-0.74865;

   end
   bigporo=reshape(pore,nx*ny*nz,1);
   bigpermz=reshape(permz,nx*ny*nz,1);
  clementporo(:,ii)=bigporo;
   clementpermz(:,ii)=bigpermz;
end
clementporo(clementporo<0.01024)=0.01024;
clementporo(clementporo>=0.2992)=0.2992;
sgsim2=clementporo;

disp('  output the perm z field from Logs  ');
sgz1=exp(clementpermz);
sgz1(sgz1<=0.1478)=0.1478;
sgz1(sgz1>=498.4011)=498.4011;

sgsim2=sgsim2.*repmat(effective,1,N);
sgz1=sgz1.*repmat(effective,1,N);

[output,outputporo,outputz] = honour2(rossmary, rossmaryporo,rossmaryz2, N,sgz1,sgsim2,DupdateK2);



mumyperm=output;
mumyporo=outputporo;
mumypermz=outputz;

 disp('  program executed  ');
end
 