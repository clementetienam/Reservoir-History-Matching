function [DupdateK] = ESMDA_PCA (sgactual,f, N, Sim1,alpha,tol);
%%History matching data assimilation technique 
%%PhD Student: Clement Etienam
%%Supervisor: Dr Rossmary Villegas
%%Co-supervisor: Dr Masoud Babei

%-----------------------------------------------------------------------------
disp( 'History matching data assimilation technique using standard ESMDA for PUNQ Reservoir'  ) 
disp( 'PhD Student: Clement Etienam' )
disp( 'Supervisor: Dr Rossmary Villegas' )
disp( 'Co-supervisor: Dr Masoud Babei' )
disp( 'Advisor: Dr Oliver Dorn' )
disp('  load the files  ');

sgsim1=(sgactual);
% sgz1=log(sgz);

 sgsim11 = reshape(sgsim1,N,N);

 fuse=f(2:19,:);
 Simuse=Sim1(2:19,:);
 Sim1=Simuse;
 f=fuse;
nobs = length(f);
noise = randn(max(10000,nobs),1);
 
 
disp('  generate Gaussian noise for the observed measurments  ');


    %stddFOE =    0.1*f(1,:);
	
    stddBHP1 = 0.05*f(1,:);
    stddBHP2 = 0.05*f(2,:);
    stddBHP3 = 0.05*f(3,:);
    stddBHP4 = 0.05*f(4,:);
	stddBHP5 = 0.05*f(5,:);
	stddBHP6 = 0.05*f(6,:);
	
	stddGORP1 = 0.05*f(7,:);
    stddGORP2 = 0.05*f(8,:);
    stddGORP3 = 0.05*f(9,:);
    stddGORP4 = 0.05*f(10,:);
	stddGORP5 = 0.05*f(11,:);
    stddGORP6 = 0.05*f(12,:);
  

    stddWWCT1 = 0.05*f(13,:);
    stddWWCT2 = 0.05*f(14,:);
    stddWWCT3 =0.05*f(15,:);
    stddWWCT4 = 0.05*f(16,:);
	stddWWCT5 = 0.05*f(17,:);
	stddWWCT6 = 0.05*f(18,:);

  
Error1=ones(18,1);
Error1(1,:)=stddBHP1;
Error1(2,:)=stddBHP2;
Error1(3,:)=stddBHP3;
Error1(4,:)=stddBHP4;
Error1(5,:)=stddBHP5;
Error1(6,:)=stddBHP6;
Error1(7,:)= stddGORP1;
Error1(8,:)= stddGORP2;
Error1(9,:)= stddGORP3;
Error1(10,:)= stddGORP4;
Error1(11,:)= stddGORP5;
Error1(12,:)= stddGORP6;
Error1(13,:)=stddWWCT1;
Error1(14,:)=stddWWCT2;
Error1(15,:)=stddWWCT3;
Error1(16,:)=stddWWCT4;
Error1(17,:)=stddWWCT5;
Error1(18,:)=stddWWCT6;


sig=Error1;
for i = 1 : length(f)
           f(i) = f(i) + sig(i)*noise(end-nobs+i);
end
R = sig.^2;
  Dj = repmat(f, 1, N);
           for i = 1:size(Dj,1)
             rndm(i,:) = randn(1,N); 
             rndm(i,:) = rndm(i,:) - mean(rndm(i,:)); 
             rndm(i,:) = rndm(i,:) / std(rndm(i,:));
             Dj(i,:) = Dj(i,:) + sqrt(alpha)*sqrt(R(i)) * rndm(i,:);
           end


Cd2 =diag(R);



disp('  generate the ensemble state matrix containing parameters and states  ');

overall=zeros(N,N); 

overall(1:N,1:N)=sgsim11;

Yens=overall; %State variable,it is important we include simulated measurements in the ensemble state variable
% number of state variables
ns = size(Yens,1);

% measurements
y = mean(Dj,2);
m = numel(y);

% ensemble of measurement perurbations
E = Dj - repmat(y,1,N);
%Cd2=E*E'/(N-1);
% simulated measurement anomaly matrix
S = Sim1-repmat(mean(Sim1,2),1,N);
Cyd=((Yens - repmat(mean(Yens,2),1,N))*S')./(N-1);
Cdd=(S*S')./(N-1);
down=Cdd+(alpha.*Cd2);
Kalman=Cyd*pinv2(down);
Residual=Dj-Sim1;
update=Kalman*Residual;

disp('  update the new ensemble  ');
Ynew=Yens+update;

disp( 'extract the active permeability field ')
value1=Ynew(1:N,1:N);


DupdateK=(value1);

end