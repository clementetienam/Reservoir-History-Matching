function  sgsparse=Sparse(sg,Yes2,N);
disp('  add necessary file path  ');
addpath(genpath('C:\Work\GSLIB\sgsim\ETIENAM answers SPE 10\ompbox10'))
%addpath(genpath('C:\Work\GSLIB\sgsim\ETIENAM answers SPE 10\ksvdbox13'))
addpath(genpath('C:\Work\GSLIB\sgsim\ETIENAM SPE 10 SPARSITY'))



disp('  Load the relevant files  ');


%sgsim=(sgsim);
sgsim=reshape(sg,2660,N);
X=sgsim;

disp(' ');
disp('  **********  Orthogonal matching pursuit of permeability  **********');
%[m,n] = size(X);
D=reshape(Yes2,2660,1500);
 G=D'*D;
  T=1000; %70 is the best
  %EPSILON=1;
 
% %EPSILON=0.00001;
  gammaperm = omp(D,X,G,T,'messages',1);
  

 

sparseperm=full(gammaperm);
yusuf=sparseperm;
sgsparse=yusuf;
%% show results %%

figure;
% subplot(1,2,1)
stem(gammaperm);
title('sparse coefficients of permeability','FontName','Helvetica', 'Fontsize', 13);
xlabel('Weights','FontName','Helvetica', 'Fontsize', 13);
ylabel('Basis index','FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')

end