function  [DupdateK2] = inflateensemble (DupdateK2,lara,N);
overall=zeros(2660,N); 

overall(1:2660,1:N)=log(DupdateK2);


Ynew=overall;
for i=1:N
    lause=lara(:,i);
    for j=1:N
        la2(j,:)=((lause(j,:)-mean(lause))^2);
    end
    laout(:,i)=sqrt(sum(la2)/(N-1));
end

rho=1/(sum(laout)/N);
%rho(rho<1)=1.01;

%rho=1.01;
Um = mean(Ynew,2);
Ynew = Ynew - repmat(Um,1,N);
Ynew = rho * Ynew;
Ynew = Ynew + repmat(Um,1,N);


disp( 'extract the active permeability field after inflation ')
value1=Ynew(1:2660,1:N);

DupdateK2=exp(value1);

end