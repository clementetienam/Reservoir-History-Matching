clc;
clear;
close all;
c=10;
A=zeros(19,28,5);
for j=1:5
    A(10,22,j)=1;
    A(9,17,j)=1;
    A(17,11,j)=1;
    A(11,24,j)=1;
    A(15,17,j)=1;
    A(17,22,j)=1;
    
    
end
disp( 'calculate the euclidean distance function to the 6 producer wells')
    lf=reshape(A,19,28,5);
   for j=1:5;
     sdf=lf(:,:,j);
  [usdf,IDX] = bwdist(sdf);
  usdf=reshape(usdf,532,1);
  young(:,j)=usdf;
   
   end
   sdfbig=reshape(young,2660,1);
   sdfbig1=abs(sdfbig);
   z=sdfbig1;
   % the value of the range should be computed accurately.
   %c=range(z);
  
  
   c0OIL1=zeros(2660,1);
   disp( 'compute the gaspari-cohn coefficent')
  for i=1:2660;
 if (0<=z(i,:) || z(i,:)<=c)
  c0OIL1(i,:)=-0.25*(z(i,:)/c)^5+0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3-(5.0/3.0)*(z(i,:)/c)^2+1;
elseif z < 2*c
  c0OIL1(i,:)=(1.0/12.0)*(z(i,:)/c)^5-0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3+(5.0/3.0)*(z(i,:)/c)^2-5*(z(i,:)/c)+4-(2.0/3.0)*(c/z(i,:));
 elseif (c<=z(i,:) || z(i,:)<=2*c)
     c0OIL1(i,:)=-5*(z(i,:)/c)+4-0.667*(c/z(i,:));
 else
     c0OIL1(i,:)=0;
 end
  
  end
  
c0OIL1(c0OIL1<0)=0;
  %[c0OIL1] = calc_loccoeffs(c, 'Gaspari_Cohn', z); 

 disp(' get the gaspari cohn for Cyd') 
 
    schur=c0OIL1;
    schur=reshape(schur,19,28,5);
    
[X,Y] = meshgrid(1:19,1:28);



figure()
for i=1:5
subplot(2,3,i);
surf(X',Y',schur(:,:,i))

shading flat
axis([1 19 1 28 ])
grid off
title('True Layer 1','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap('jet')
caxis([0 1])
h = colorbar;
ylabel(h, 'Gaspari Coeff','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [0 1])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
end