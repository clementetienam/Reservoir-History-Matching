function[mumyperm,mumyporo,mumypermz]=main_dynamic(nx,ny,nz,N,tol,observation,overallsim,rossmary,rossmaryporo,rossmaryz2,perm,history,alpha,effective,stdsandk,stdshalek,innermethod2); 
sgsim=reshape(perm,nx*ny*nz,N);


 sgactual=sgsim;


Sim11=reshape(overallsim,19,history,N);

%History matching using ESMDA
for i=1:history
 fprintf('Now assimilating timestep %d .\n', i);

 
Sim1=Sim11(:,i,:);
Sim1=reshape(Sim1,19,N);

f=observation(:,i);

if innermethod2==1
[DupdateK] = directI (sgactual,f, N, Sim1,alpha,tol,effective,history);

elseif innermethod2==2
[DupdateK] = transistion (sgactual,f, N, Sim1,alpha,tol,effective,history);
else
 [DupdateK] = deterministic2 (sgactual,f, N, Sim1,alpha,tol,effective,history);


sgactual=DupdateK;

 fprintf('Finished assimilating timestep %d \n', i);
end
[meansandk,meanshalek,faciesr]=RCUmf(DupdateK,N);
%sgsim11=(clement2);
disp(' Get the bi-gaussian CDF of updated permeability ensemble')
a=log(DupdateK);
for ii=1:N
    clem=a(:,ii);
    clem=reshape(clem,nx*ny*nz,1);
    facies=faciesr(:,ii);
    mKsand=meansandk(:,ii);
    mKshale=meanshalek(:,ii);
    sksand=stdsandk(:,ii);
    skshale=stdshalek(:,ii);
    for j=1:nx*ny*nz
        rightK=(clem(j,:)-mKsand)/(sksand*sqrt(2));
        rightK=1+erf(rightK);
        
        righttK=(clem(j,:)-mKshale)/(skshale*sqrt(2));
        righttK=1+erf(righttK);
        clemK(j,:)=((facies/2)*rightK)+(((1-facies)/2)*righttK);
            
    end
    requiredK(:,ii)=clemK;
end
a=log(DupdateK);
disp('Get the gaussian distribution CDF of the updated permeabiity and porosity')
for ii=1:N
     meanfull(:,ii)=mean(a(:,ii));
end
  for ii=1:N
     stdfull(:,ii)=std(a(:,ii));
  end
disp( 'make the distribution')
for ii=1:N
pd(:,ii) = makedist('Normal',meanfull(:,ii),stdfull(:,ii));
end
disp(' fit the distribution to Gaussian')
for ii=1:N
ypdf(:,ii) = cdf(pd(:,ii),a(:,ii));
end

disp('Recover the corrected ensmeble folowing a bi-Gaussian distribtion')
a=log(DupdateK);
for ii=1:N
%% COMPUTATION
x = a(:,ii);
% Remove missing observations indicated by NaN's.
t = ~isnan(x);
x = x(t);

p = requiredK(:,ii);   

ur = ypdf(:,ii);

% Interpolate ur from empirical cdf and extraplolate for out of range
% values.
[p, index] = unique(p);
%xr = interp1(x,p,'pchip','extrap');
xr = interp1(p,x(index),ur,[],'extrap');
good(:,ii)=xr;
end
DupdateK=exp(good);

disp('recover the full permeability field')

DupdateK2=DupdateK;

disp('  recover the porosity and permz field from Logs  ');
for ii=1:N;
    Knew=reshape(DupdateK2(:,ii),nx,ny,nz);
   for j=1:5;
 pore(:,:,1)=0.040228*log(Knew(:,:,1))-0.03101;
pore(:,:,2)=0.022608*log(Knew(:,:,2))+0.0066038;
pore(:,:,3)=0.046974*log(Knew(:,:,3))-0.072764;
pore(:,:,4)=0.025312*log(Knew(:,:,4))+0.01088;
pore(:,:,5)=0.039746*log(Knew(:,:,5))-0.038238;


permz(:,:,1)=0.88227*log(Knew(:,:,1))-0.29112;
permz(:,:,2)=0.89976*log(Knew(:,:,2))-1.1289;
permz(:,:,3)=0.69049*log(Knew(:,:,3))+1.0074;
permz(:,:,4)=0.82778*log(Knew(:,:,4))-0.56077;
permz(:,:,5)=0.97173*log(Knew(:,:,5))-0.74865;

   end
   bigporo=reshape(pore,nx*ny*nz,1);
   bigpermz=reshape(permz,nx*ny*nz,1);
  clementporo(:,ii)=bigporo;
   clementpermz(:,ii)=bigpermz;
end
clementporo(clementporo<0.01024)=0.01024;
clementporo(clementporo>=0.2992)=0.2992;
sgsim2=clementporo;

disp('  output the perm z field from Logs  ');
sgz1=exp(clementpermz);
sgz1(sgz1<=0.1478)=0.1478;
sgz1(sgz1>=498.4011)=498.4011;


[output,outputporo,outputz] = honour2(rossmary, rossmaryporo,rossmaryz2, N,sgz1,sgsim2,DupdateK2);



mumyperm=output;
mumyporo=outputporo;
mumypermz=outputz;

 disp('  program executed  ');
end
 