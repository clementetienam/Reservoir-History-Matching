function [meansandak,meanshaleak,faciesar]=RCUmfmean(meansandk,meanshalek,faciesr)
meansandak=mean(meansandk,2);
meanshaleak=mean(meanshalek,2);
faciesar=mean(faciesr,2);

end