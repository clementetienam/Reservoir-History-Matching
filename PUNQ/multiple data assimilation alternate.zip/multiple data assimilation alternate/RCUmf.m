function [meansandk,meanshalek,varsand,varshale]=RCUmf(sg1,trunc,N,nx,ny,nz)
a=reshape(sg1,nx*ny*nz,N);

for i=1:N
    %% for permeabiity
    aa=a(:,i);
indices=find(a(:,i)>=trunc);
indices2=find(a(:,i)<trunc);
kk=aa(indices); % sand
kk2=aa(indices2); %shale

meansandk(:,i)=mean(kk);
meanshalek(:,i)=mean(kk2);

varsand(:,i)=var(kk);
varshale(:,i)=var(kk2);

end