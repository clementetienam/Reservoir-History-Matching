function [mumyperm,mumyporo,mumypermz]=main_DCT(nx,ny,nz,N,tol,observation,overallsim,rossmary,rossmaryporo,rossmaryz2,perm,history,alpha,effective);
disp( 'History matching data assimilation technique using DCT ESMDA for SPE10 Reservoir'  ) 
disp( 'PhD Student: Clement Etienam' )
disp( 'Supervisor: Dr Rossmary Villegas' )
disp( 'Co-supervisor: Dr Masoud Babei' )
disp('  import the true data  ');

sgsim=reshape(perm,nx*ny*nz,N);

Sim11=reshape(overallsim,19,history,N);
% SWn83=reshape(SWn83,1764,history,N);
% PEn83=reshape(PEn83,1764,history,N);
% SGn83=reshape(SGn83,1764,history,N);
% RSEn83=reshape(RSEn83,1764,history,N);

clement2 = mainDCT(sgsim, N);

for i=1:history
 fprintf('Now assimilating timestep %d .\n', i);
  
 
Sim1=Sim11(:,i,:);
Sim1=reshape(Sim1,19,N);


f=observation(:,i);
[DupdateK] = Assimilate_DCT (clement2, f, N,Sim1,tol,alpha);

clement2=DupdateK;

 fprintf('Finished assimilating timestep %d \n', i);
end
valuepermjoy=clement2;
for ii=1:N
    lf=reshape(valuepermjoy(:,ii),10,20,nz);
     for jj=1:5
         valueperm=lf(:,:,jj);
         big=zeros(nx,ny,nz);

        big(1:10,1:20,jj)=valueperm;
        kkperm=big(:,:,jj);
        rec = mirt_idctn(kkperm);
        rec=(abs(rec));
         usdf=reshape(rec,532,1);
         young(:,jj)=usdf;
     end
      sdfbig=reshape(young,2660,1);
  clementperm(:,ii)=sdfbig;
end

sgsim11=exp(clementperm);

DupdateK= sgsim11;
%DupdateK= sgsim1;
disp('  recover the porosity and permz field from Logs  ');
for ii=1:N;
    Knew=reshape(DupdateK(:,ii),nx,ny,nz);
   for j=1:5;
 pore(:,:,1)=0.040228*log(Knew(:,:,1))-0.03101;
pore(:,:,2)=0.022608*log(Knew(:,:,2))+0.0066038;
pore(:,:,3)=0.046974*log(Knew(:,:,3))-0.072764;
pore(:,:,4)=0.025312*log(Knew(:,:,4))+0.01088;
pore(:,:,5)=0.039746*log(Knew(:,:,5))-0.038238;


permz(:,:,1)=0.88227*log(Knew(:,:,1))-0.29112;
permz(:,:,2)=0.89976*log(Knew(:,:,2))-1.1289;
permz(:,:,3)=0.69049*log(Knew(:,:,3))+1.0074;
permz(:,:,4)=0.82778*log(Knew(:,:,4))-0.56077;
permz(:,:,5)=0.97173*log(Knew(:,:,5))-0.74865;

   end
   bigporo=reshape(pore,nx*ny*nz,1);
   bigpermz=reshape(permz,nx*ny*nz,1);
  clementporo(:,ii)=bigporo;
   clementpermz(:,ii)=bigpermz;
end
clementporo(clementporo<0.01024)=0.01024;
clementporo(clementporo>=0.2992)=0.2992;
sgsim2=clementporo;

disp('  output the perm z field from Logs  ');
sgz1=exp(clementpermz);
sgz1(sgz1<=0.1478)=0.1478;
sgz1(sgz1>=498.4011)=498.4011;

sgsim2=sgsim2.*repmat(effective,1,N);
sgz1=sgz1.*repmat(effective,1,N);

[output,outputporo,outputz] = honour2(rossmary, rossmaryporo,rossmaryz2, N,sgz1,sgsim2,DupdateK);



mumyperm=output;
mumyporo=outputporo;
mumypermz=outputz;


end
 %plot the mean and variance for each timestep
 %run('plot3D.m')
 
 