clc;
clear all;
close all;
c=10;



%Get the localization for oil1 Well P1
A=zeros(120,60,5);
for j=1:5
    A(14,25,j)=1;
    A(38,39,j)=1;
    A(96,23,j)=1;
    A(67,41,j)=1;
    A(30,55,j)=1;
    A(58,18,j)=1;
    A(90,6,j)=1;
    A(14,25,j)=1;
    A(101,39,j)=1;
    
    
    
end

disp( 'calculate the euclidean distance function to the 6 producer wells')
    lf=reshape(A,120,60,5);
   for j=1:5;
     sdf=lf(:,:,j);
  [usdf,IDX] = bwdist(sdf);
  usdf=reshape(usdf,7200,1);
  young(:,j)=usdf;
   
   end
   sdfbig=reshape(young,36000,1);
   sdfbig1=abs(sdfbig);
   z=sdfbig1;
   % the value of the range should be computed accurately.
   %c=range(z);
  
  
   c0OIL1=zeros(36000,1);
   disp( 'compute the gaspari-cohn coefficent')
  for i=1:36000;
 if (0<=z(i,:) || z(i,:)<=c)
  c0OIL1(i,:)=-0.25*(z(i,:)/c)^5+0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3-(5.0/3.0)*(z(i,:)/c)^2+1;
elseif z < 2*c
  c0OIL1(i,:)=(1.0/12.0)*(z(i,:)/c)^5-0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3+(5.0/3.0)*(z(i,:)/c)^2-5*(z(i,:)/c)+4-(2.0/3.0)*(c/z(i,:));
 elseif (c<=z(i,:) || z(i,:)<=2*c)
     c0OIL1(i,:)=-5*(z(i,:)/c)+4-0.667*(c/z(i,:));
 else
     c0OIL1(i,:)=0;
 end
  
  end
  
c0OIL1=reshape(c0OIL1,120,60,5);
c0OIL1(c0OIL1<=0)=0;
figure();
redd=slice(c0OIL1,[1 60],[1 120],[1 5]);
axis equal on
%axis([1 27 1 84 1 4 ])
% xlim([1 84])
% ylim([1 27])
% zlim([0 4])
shading flat
grid off
%title('Covariance Localization','FontName','Helvetica', 'Fontsize', 12);
%colormap('jet')
caxis([0 1])
colorbar
xlabel('X','FontName','Helvetica', 'Fontsize', 16)
ylabel('Y','FontName','Helvetica', 'Fontsize', 16)
zlabel('Z','FontName','Helvetica', 'Fontsize', 16)

set(gca, 'FontName','Helvetica', 'Fontsize', 16)
set(gcf,'color','white')
hold on
plot3([55 55],[30 30],[1 50],'k','Linewidth',2);
text(55,30,55,'I1','Fontsize', 11)
%title('I1','FontName','Helvetica', 'Fontsize', 18);
hold on
plot3([18 18],[58 58],[1 50],'k','Linewidth',2);
text(18 ,58 ,52,'I2','Fontsize', 11)
hold on
plot3([6 6],[90 90],[1 50],'k','Linewidth',2);
text(6 ,90 , 51,'I3','Fontsize', 11)
hold on
plot3([39 39],[101 101],[1 50],'k','Linewidth',2);
text(39 ,101 , 31,'I4','Fontsize', 11)
hold on
plot3([25 25],[14 14],[1 50],'r','Linewidth',2);
% text(x1(i,1),y1(i,1),z1(i,1),['   ' ...
% num2str(time(i,1))],'HorizontalAlignment','left','FontSize',8);
text( 25, 14,52,'P1','HorizontalAlignment','left','FontSize',11)
hold on
plot3([39 39],[38 38],[1 50],'r','Linewidth',2);
text( 39, 38, 52,'P2','Fontsize', 11)
hold on
plot3([23 23],[96 96],[1 30],'r','Linewidth',2);
text(23 ,96 , 35,'P3','Fontsize', 11)
hold on
plot3([41 41],[67 67],[1 50],'r','Linewidth',2)
text( 41, 67, 45,'P4','Fontsize', 11)
% direction = [0 1 0];
% rotate(redd,direction,180)
set(gcf,'color','white')
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca,'zticklabel',[])




saveas(gcf,'covariance1','fig')
close(figure)

