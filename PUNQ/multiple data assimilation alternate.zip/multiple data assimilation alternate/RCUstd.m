function [stdsandk,stdshalek]=RCUstd(N,nx,ny,nz,sgsim)
disp(' Find values greater than 100 and 0.1805 of initial ensemble')
sgsim=reshape(sgsim,nx*ny*nz,N);

%% Get standard deviation of sand and shale facies
sg=sgsim;
trunc=4.90;

a=log(sg);

disp(' Find values greater than 100mD and 0.1805')
for i=1:N
    %% for permeabiity
    aa=a(:,i);
indices=find(a(:,i)>=trunc);
indices2=find(a(:,i)<trunc);
kk=aa(indices); % permeability greater than 100mD
kk2=aa(indices2); %permeability less than 100mD

stdsandk(:,i)=std(kk);
stdshalek(:,i)=std(kk2);



end

end