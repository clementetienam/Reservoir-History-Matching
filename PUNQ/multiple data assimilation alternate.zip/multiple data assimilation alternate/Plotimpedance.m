clc;
clear;
close all;
N=1;
oldfolder=cd;
cd(oldfolder) % setting original directory
for i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',i));
  
    copyfile('read_ecl.m',folder)
    copyfile('field2Metric.m',folder)
    copyfile('Gassmann2.m',folder)
    copyfile('effective.out',folder)
    cd(folder);
out = read_ecl('MASTER0.UNRST');
    PORO = importdata('PORO2.GRDECL',' ',1);
    PORO=PORO.data;
    effective=importdata('effective.out');
    indices=find(effective);
    %% obtain the dynamic states
    pressure=out.PRESSURE;
    Water=out.SWAT;
    gas=out.SGAS;
    oil=1-(Water+gas);
    
    %% Dynamic states at time step 40
    pres40=pressure(:,40);
    gas40=gas(:,40);
    oil40=oil(:,40);
    
 
    bb=ones(2660,1);  
    aperm=pres40;
   bb(indices)=aperm;
    press1=bb;

  
    bb=ones(2660,1);  
    aperm=gas40;
   bb(indices)=aperm;
    gas1=bb;
    
 
    bb=ones(2660,1);  
    aperm=oil40;
   bb(indices)=aperm;
    oil1=bb;
    
    [ImpP40, ImpS40, VP40, VS40]=Gassmann2(PORO,press1,oil1,gas1);
    
   
  
    %% Obtain dynamic states at step 80
 
    pres80=pressure(:,80);
    gas80=gas(:,80);
    oil80=oil(:,80);
    bb=ones(2660,1);  
    aperm=pres80;
   bb(indices)=aperm;
    press2=bb;

  
    bb=ones(2660,1);  
    aperm=gas80;
   bb(indices)=aperm;
    gas2=bb;
    
 
    bb=ones(2660,1);  
    aperm=oil80;
   bb(indices)=aperm;
    oil2=bb;
    
    [ImpP80, ImpS80, VP80, VS80]=Gassmann2(PORO,press2,oil2,gas2);
    
 %% plot figures
 

 ImpS40=reshape(ImpS40,532,1).*effective(1:532);

  VS40=reshape(VS40,532,1).*effective(1:532); 
  
 [X,Y] = meshgrid(1:19,1:28);
figure()

subplot(2,2,1);
surf(X',Y',log10(reshape(ImpS40,19,28)))

shading flat
axis([1 19 1 28 ])
grid off
title('ImpP(ft/s)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap('jet')
caxis([3.66 3.67])
h = colorbar;
ylabel(h, 'log10(ImpP(ft/s))','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [3.66 3.67])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])


subplot(2,2,2);
surf(X',Y',log10(reshape(VS40,19,28)))

shading flat
axis([1 19 1 28 ])
grid off
title('VP(ft/s)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap('jet')
caxis([3.305 3.315])
h = colorbar;
ylabel(h, 'log10(VS(ft/s))','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [3.305 3.315])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

saveas(gcf,'Impedance40','fig')

%%
ImpS80=reshape(ImpS80,532,1).*effective(1:532);

  VS80=reshape(VS80,532,1).*effective(1:532); 
  
 [X,Y] = meshgrid(1:19,1:28);
figure()

subplot(2,2,1);
surf(X',Y',log10(reshape(ImpS80,19,28)))

shading flat
axis([1 19 1 28 ])
grid off
title('ImpP(ft/s)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap('jet')
caxis([3.66 3.67])
h = colorbar;
ylabel(h, 'log10(ImpP(ft/s))','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [3.66 3.67])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])


subplot(2,2,2);
surf(X',Y',log10(reshape(VS80,19,28)))

shading flat
axis([1 19 1 28 ])
grid off
title('VP(ft/s)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap('jet')
caxis([3.305 3.315])
h = colorbar;
ylabel(h, 'log10(VS(ft/s))','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [3.305 3.315])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
saveas(gcf,'Impedance80','fig')
 cd(oldfolder);
end
