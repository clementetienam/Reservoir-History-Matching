clc;
clear;
load rossmary.GRDECL;
true=reshape(rossmary,120,60,10);
for j=1:10
Q = dct2(true(:,:,j));

Roveral(:,j)=reshape(Q,7200,1);
end
for jj=1:10
[XX,ind] = sort(abs(Roveral(:,j)),'descend');
sorted(:,jj)=XX;
end
% for jj=1:10
% xsmall = sorted(:,jj);
% Bsig = cumsum(xsmall);
% valuesig=Bsig(end);
% valuesig=valuesig*0.99;
% indices = find(cumsum(xsmall) >= valuesig );
% indicesall(:,jj)=indices;
% % toluse=xsmall(indices,:);
% % tol=toluse(1,:);
% end

for jj=1:10
    a=sorted(:,jj);
    b=a(1:6255,:);
    boverall(:,jj)=b;
end
disp('recosntruct')
image=zeros(7200,10);
image(1:6255,:)=boverall;
for jj=1:10    
 K = idct2(boverall(:,jj));
 Kout(:,jj)=K;
end


CMRmap=[0 0 0;.3 .15 .75;.6 .2 .50;1 .25 .15;.9 .5 0;.9 .9 .5;1 1 1];
b2=reshape(Kout,120,60,10);
figure
for i=1:10
subplot(2,5,i)
imshow(((b2(:,:,i))),[])
%colormap(gca,jet(64))
colorbar
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
end
% J(abs(J) < 10) = 0;
% for j=1:10
% K = idct2(J(:,:,j));
% kyobo(:,j)=reshape(K,7200,1);
% end



% [X,Y] = meshgrid(1:120,1:60);



% 
% CMRmap=[0 0 0;.3 .15 .75;.6 .2 .50;1 .25 .15;.9 .5 0;.9 .9 .5;1 1 1];
% Trueperm=reshape(log10(rossmary),120,60,10);
% Trueporo=reshape(rossmaryporo,120,60,10);
% 
% 
% figure()
% for i=1:5
% subplot(2,5,1);
% surf(X',Y',Trueperm(:,:,i))
% 
% shading flat
% axis([1 120 1 60 ])
% grid off
% title('True Layer 1','FontName','Helvetica', 'Fontsize', 13);
% ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
% xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
% colormap(CMRmap)
% caxis([1 5])
% h = colorbar;
% ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
% set(h, 'ylim', [1 5])
% set(gca, 'FontName','Helvetica', 'Fontsize', 13)
% set(gcf,'color','white')
% set(gca,'xticklabel',[])
% set(gca,'yticklabel',[])
% end