function [meansandk,meanshalek,faciesr]=RCUmf2(sg1,N)
disp(' Find values greater than 100 and 0.1805 of current ensemble')
sgsim=reshape(sg1,2660,N);

sg=sgsim;
trunc=4.90;


a=log(sg);

for i=1:N
    %% for permeabiity
    aa=a(:,i);
indices=find(a(:,i)>=trunc);
indices2=find(a(:,i)<trunc);
kk=aa(indices); % permeability greater than 100mD
kk2=aa(indices2); %permeability less than 100mD

meansandk(:,i)=mean(kk);
meanshalek(:,i)=mean(kk2);

faciesratio=(numel(kk)/(numel(kk)+numel(kk2)));
faciesr(:,i)=faciesratio;

end