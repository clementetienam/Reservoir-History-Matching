clc;
clear;
close all;
history=81;
% disp('  import the true observation data  ');
%  
%   True= importdata('Real.RSM',' ',7);
%  True2= importdata('Real.RSM',' ',95);
%  True3= importdata('Real.RSM',' ',183);
%  
%  
%  True=True.data;
%  True2=True2.data;
%  True3=True3.data;
%  
%  
%   TP1=True(:,4);
%  TP2=True(:,5);
%  TP3=True(:,6);
%  TP4=True(:,7);
%   TP5=True(:,8);
%    TP6=True(:,9);
%  
%  
%  TG1=True(:,10);
%  TG2=True2(:,2);
%  TG3=True2(:,3);
%  TG4=True2(:,4);
%  TG5=True2(:,5);
%   TG6=True2(:,6);
%  
%  
%  
%  
%   TW1=True2(:,7);
%  TW2=True2(:,8);
%  TW3=True2(:,9);
%  TW4=True2(:,10);
%   TW5=True3(:,2);
%    TW6=True3(:,3);
%  
%  
%  
% 
%  TFOE=True(:,3);
%  disp(' make the true observation')
%  for ihistory=1:history
%  obs=zeros(19,1);
%  obs(1,:)=TFOE(ihistory,:);
%  obs(2,:)=TP1(ihistory,:);
%  obs(3,:)=TP2(ihistory,:);
%  obs(4,:)=TP3(ihistory,:);
%  obs(5,:)=TP4(ihistory,:);
%  obs(6,:)=TP5(ihistory,:);
%  obs(7,:)=TP6(ihistory,:);
%  obs(8,:)=TG1(ihistory,:);
%  obs(9,:)=TG2(ihistory,:);
%  obs(10,:)=TG3(ihistory,:);
%  obs(11,:)=TG4(ihistory,:);
%  obs(12,:)=TG5(ihistory,:);
%  obs(13,:)=TG6(ihistory,:);
%  obs(14,:)=TW1(ihistory,:);
%  obs(15,:)=TW2(ihistory,:);
%  obs(16,:)=TW3(ihistory,:);
%  obs(17,:)=TW4(ihistory,:);
%  obs(18,:)=TW5(ihistory,:);
%  obs(19,:)=TW6(ihistory,:);
%  observation(:,ihistory)=obs;
%  end
%  for i=1:18
%  noisevar(i,:) = estimatenoise(observation(:,i));
%  end
disp( 'Well locaions consisting of producer well')
load effective.out;
iProd = [10, 9, 17, 11, 15, 17]; % 6 wells configuration, production wells
jProd = [22, 17, 11, 24, 12 22]; % 6 wells configuration, production wells
%CMRmap=[0 0 0;.3 .15 .75;.6 .2 .50;1 .25 .15;.9 .5 0;.9 .9 .5;1 1 1];
effective=reshape(effective,2660,1);
nx=19;ny=28;nz=5;N2=200;N=100;
load sgsim.out; %initial porosity

sgsim=reshape(sgsim,nx*ny*nz,N2);

[U,S,V]=svd(sgsim,'econ');
new=U(:,1:N)*S(1:N,1:N)*(V(1:N,1:N))';
sgsimnew=abs(new);
sgtemp=reshape(sgsim,532000,1);
load rossmary.GRDECL; %true permeability field
indices=find(effective);

  
 sgactual=rossmary(indices);
upmax=max(rossmary);
upmin=min(rossmary);
permlogit=zeros(size(sgtemp));
for i= 1:532000
  if (sgtemp(i)>upmax)||(sgtemp(i)<upmin)
      if (sgtemp(i)>upmax)
          permlogit(i,:)=roundtowardvec(sgtemp(i),upmax);
      end
       if (sgtemp(i)<upmax)
          permlogit(i,:)=roundtowardvec(sgtemp(i),upmin);
      end
      
%     up=sgtemp(i)-upmin;
%     down=upmax-sgtemp(i);
%     permlogit(i,:)=(((up/down)));
  else
      permlogit(i,:)=(sgtemp(i));
  end

end
permnow=reshape((permlogit),2660,200);
 testclementPlot(nx,ny,nz, iProd, jProd,sgsim(:,1),permnow(:,1),effective);