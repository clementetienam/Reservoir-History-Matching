function [DupdateK] = Assimilate2 (sgactual,f, N, Sim1,alpha,tol,indices2);

sgsim1=log(sgactual);

 sgsim11 = reshape(sgsim1,2660,N);
fuse=f(2:19,:);
 Simuse=Sim1(2:19,:);
 Sim1=Simuse;
 f=fuse;
nobs = length(f);
noise = randn(max(10000,nobs),1);
disp('  generate Gaussian noise for the observed measurments  ');


  stddFOE =    0.1*f(1,:);
	
	stddBHP1 = 0.1*f(2,:);
    stddBHP2 = 0.1*f(3,:);
    stddBHP3 = 0.1*f(4,:);
    stddBHP4 = 0.1*f(5,:);
	stddBHP5 = 0.1*f(6,:);
	stddBHP6 = 0.1*f(7,:);
	
	stddGORP1 = 0.15*f(8,:);
    stddGORP2 = 0.15*f(9,:);
    stddGORP3 = 0.15*f(10,:);
    stddGORP4 = 0.15*f(11,:);
	stddGORP5 = 0.15*f(12,:);
    stddGORP6 = 0.15*f(13,:);
  

    stddWWCT1 = 0.2*f(14,:);
    stddWWCT2 = 0.2*f(15,:);
    stddWWCT3 = 0.2*f(16,:);
    stddWWCT4 = 0.2*f(17,:);
	stddWWCT5 = 0.2*f(18,:);
	stddWWCT6 = 0.2*f(19,:);

  
Error1=ones(18,N);
Error1(1,:)=normrnd(0,stddBHP1,1,N);
Error1(2,:)=normrnd(0,stddBHP2,1,N);
Error1(3,:)=normrnd(0,stddBHP3,1,N);
Error1(4,:)=normrnd(0,stddBHP4,1,N);
Error1(5,:)=normrnd(0,stddBHP5,1,N);
Error1(6,:)=normrnd(0,stddBHP6,1,N);
Error1(7,:)= normrnd(0,stddGORP1,1,N);
Error1(8,:)= normrnd(0,stddGORP2,1,N);
Error1(9,:)= normrnd(0,stddGORP3,1,N);
Error1(10,:)= normrnd(0,stddGORP4,1,N);
Error1(11,:)= normrnd(0,stddGORP5,1,N);
Error1(12,:)= normrnd(0,stddGORP6,1,N);
Error1(13,:)=normrnd(0,stddWWCT1,1,N);
Error1(14,:)=normrnd(0,stddWWCT2,1,N);
Error1(15,:)=normrnd(0,stddWWCT3,1,N);
Error1(16,:)=normrnd(0,stddWWCT4,1,N);
Error1(17,:)=normrnd(0,stddWWCT5,1,N);
Error1(18,:)=normrnd(0,stddWWCT6,1,N);


for i=1:N
    Dj(:,i)=f+(Error1(:,i));
	
 end
% for i=1:N
%      Dj(:,i)=f+(sqrt(alpha).*(Error1(:,i)));
% 	
%  end
disp('  generate the ensemble state matrix containing parameters and states  ');
%Saturation,Pressure,SaturationG,RSG
overall=zeros(2660,N); 

overall(1:2660,1:N)=sgsim11;

Y=overall; %State variable,it is important we include simulated measurements in the ensemble state variable

yprime = Y-repmat(mean(Y,2),1,N);


unie=Sim1-repmat(mean(Sim1,2),1,N);;
%unie=H*yprime;
%Sim=H*Y;
unie2=unie+Error1;
%[U0,Z0,V0] = svd(unie2,'econ');
[U0,Z0,V0] = svd(unie2);
joy2=Z0*Z0';
X1=pinv2(joy2)*U0';
% Residual vector
X2=X1*(Dj-Sim1);

X3=U0*X2;

X4=unie'*X3;
%Update the ensemble state

Ynew=Y+(yprime*X4);


disp( 'extract the active permeability field ')
value1=Ynew(1:1761,1:N);


DupdateK=exp(value1);


end