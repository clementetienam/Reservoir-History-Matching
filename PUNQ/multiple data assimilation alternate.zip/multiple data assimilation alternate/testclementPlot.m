%%This code is to plot all the ensemble permeability field data at once

function testclementPlot(nx,ny,nz, iProd, jProd,mumyperm,rossmary,effective);


disp(' extract the active grid cells' )
sgsim=reshape(mumyperm,2660,1);

perm=sgsim;


True=log10(rossmary);
True=True.*effective;
%True(True==0)=NaN;


Ause=perm;
A1=log10(Ause);
B = effective;
A1=A1.*B;

 PlogK = reshape(A1,19,28,5);
 PlogK(PlogK==0)=NaN;

Trueperm=reshape(True,19,28,5);
Trueperm(Trueperm==0)=NaN;

yobo1=figure()

h1=subplot(2,5,1);

%surf(X',Y',Trueperm(:,:,1))
imagesc(reshape(Trueperm(:,:,1), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('True Layer 1','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h1,direction,180)
 
 
h2=subplot(2,5,2);
imagesc(reshape(Trueperm(:,:,2), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('True Layer 2','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h2,direction,180)

h3=subplot(2,5,3);
imagesc(reshape(Trueperm(:,:,3), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('True Layer 4','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h3,direction,180)
 
h4=subplot(2,5,4);
imagesc(reshape(Trueperm(:,:,4), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('True Layer 4','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h4,direction,180)

h5=subplot(2,5,5);

imagesc(reshape(Trueperm(:,:,5), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('True Layer 5','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h5,direction,180)
	
	
h6=subplot(2,5,6);
imagesc(reshape(PlogK(:,:,1), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('BestLog(K)-1','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h6,direction,180)

h7=subplot(2,5,7);
imagesc(reshape(PlogK(:,:,2), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('BestLog(K)-2','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h7,direction,180)

h8=subplot(2,5,8);
imagesc(reshape(PlogK(:,:,3), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('BestLog(K)-3','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h8,direction,180)


h9=subplot(2,5,9);
imagesc(reshape(PlogK(:,:,4), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('BestLog(K)-4','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h9,direction,180)

h10=subplot(2,5,10);
imagesc(reshape(PlogK(:,:,5), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('BestLog(K)-5','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h10,direction,180)




G2=cartGrid([19 28 5]);

yobo1=figure();
subplot(2,2,1);
plotCellData(G2,reshape(Trueperm,2660,1));
view(3)
axis equal on
title('True','FontName','Helvetica', 'Fontsize', 13);
grid off
shading flat
caxis([1 3])
colormap('jet')
% h = colorbar;
% ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
% set(h, 'ylim', [1 5])
hold on
plot3([10 10],[22 22],[1 -8],'r','Linewidth',2);
text(  10,22,-10,'P1','HorizontalAlignment','left','FontSize',11)
hold on
plot3([9 9],[17 17],[1 -8],'r','Linewidth',2);
text(  9,17, -9,'P4','Fontsize', 11)
hold on
plot3([17 17],[11 11],[1 -8],'r','Linewidth',2);
text(  17,11, -10,'P5','Fontsize', 11)
hold on
plot3([11 11],[24 24],[1 -12],'r','Linewidth',2);
text(11 ,24, -14,'P11','Fontsize', 11)
hold on
plot3([15 15],[12 12],[1 -8],'r','Linewidth',2)
text(  15,12, -14,'P12','Fontsize', 11)
hold on
plot3([17 17],[22 22],[1 -8],'r','Linewidth',2)
text(  17,22, -12,'P4','Fontsize', 11)

set(gcf,'color','white')
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca,'zticklabel',[])






subplot(2,2,2);
%redd=slice(PlogK,[1 60],[1 120],[1 5]);
plotCellData(G2,reshape(PlogK,2660,1));
view(3)
axis equal on
title('Best Log','FontName','Helvetica', 'Fontsize', 13);
grid off
shading flat
caxis([1 3])
colormap('jet')
hold on
% h = colorbar;
% ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
% set(h, 'ylim', [1 5])
plot3([10 10],[22 22],[1 -8],'r','Linewidth',2);
text(  10,22,-10,'P1','HorizontalAlignment','left','FontSize',11)
hold on
plot3([9 9],[17 17],[1 -8],'r','Linewidth',2);
text(  9,17, -9,'P4','Fontsize', 11)
hold on
plot3([17 17],[11 11],[1 -8],'r','Linewidth',2);
text(  17,11, -10,'P5','Fontsize', 11)
hold on
plot3([11 11],[24 24],[1 -12],'r','Linewidth',2);
text(11 ,24, -14,'P11','Fontsize', 11)
hold on
plot3([15 15],[12 12],[1 -8],'r','Linewidth',2)
text(  15,12, -14,'P12','Fontsize', 11)
hold on
plot3([17 17],[22 22],[1 -8],'r','Linewidth',2)
text(  17,22, -12,'P4','Fontsize', 11)
%title( 'PERMX 3D')
%colormap jet

set(gcf,'color','white')
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca,'zticklabel',[])


end
%run('testvar.m')