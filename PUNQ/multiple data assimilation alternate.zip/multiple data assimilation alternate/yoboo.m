clc;
clear all;

load Yes2m.out; %Permeability dictionary
% load Yes2porom.out; %porosity dictionary
load sgsimporo.out; %initial porosity
load sgsim.out; %initial permeabiity
oldfolder=cd;
cd(oldfolder) % setting original directory
N=100;
perm=reshape(sgsim,72000,N);
poro=reshape(sgsimporo,72000,N);
sgsim=reshape(perm,72000,N);
sgsimporo=reshape(poro,72000,N);
for i=1:N
sgsimuse=reshape(sgsim(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,36000,1);
sg(:,i)=ex;
end

for i=1:N
sgsimporouse=reshape(sgsimporo(:,i),120,60,10);
sgsporo=sgsimporouse(:,:,3:7);
exporo=reshape(sgsporo,36000,1);
sgporo(:,i)=exporo;
end
sgclem=log(sg);

disp( 'get the dct coefficnets of the field')
sgenter = DCTsigned(sgclem, N);
disp( ' covert spatial permeability and porosity to sparse')
sgsparse=Sparsemachine(sgenter,Yes2m);





joyy=reshape(Yes2m,9000,1500)*sgsparse;


disp( 'carry out the inverse DCT' )
for ii=1:N
    lf=reshape(joyy(:,ii),60,30,5);
     for jj=1:5
         valueperm=lf(:,:,jj);
         big=zeros(120,60,5);

        big(1:60,1:30,jj)=valueperm;
        kkperm=big(:,:,jj);
        rec = mirt_idctn(kkperm);
        rec=(abs(rec));
         usdf=reshape(rec,7200,1);
         young(:,jj)=usdf;
     end
      sdfbig=reshape(young,36000,1);
  clementperm(:,ii)=sdfbig;
end

sgsim11=exp(clementperm);
% sgsim12=reshape(log(abs(sgsim11)),3600000,1);

% disp( ' covert spatial permeability to sparse')
% sgsparse=Sparse(log(sg),Yes2);
% sgsparseporo=Sparse(sgporo,Yes2poro);
%  cd(oldfolder)
% 
% joyy=reshape(Yes2,36000,1500)*sgsparse;
% joyyporo=reshape(Yes2poro,36000,1500)*sgsparseporo;
% 
% sgsim11=exp(joyy);
% sgsim2=joyyporo;

CMRmap=[0 0 0;.3 .15 .75;.6 .2 .50;1 .25 .15;.9 .5 0;.9 .9 .5;1 1 1];
Trueperm=reshape(log10(sgsim11(:,1)),120,60,5);
Trueporo=reshape(log10(sg(:,1)),120,60,5);
[X,Y] = meshgrid(1:120,1:60);

figure()
for i=1:5
subplot(2,5,i);
surf(X',Y',Trueperm(:,:,i))

shading flat
axis([1 120 1 60 ])
grid off
title('recovered','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap(CMRmap)
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
end

figure()
for i=1:5
subplot(2,5,i);
surf(X',Y',Trueporo(:,:,i))

shading flat
axis([1 120 1 60 ])
grid off
title('True','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
colormap(CMRmap)
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
end