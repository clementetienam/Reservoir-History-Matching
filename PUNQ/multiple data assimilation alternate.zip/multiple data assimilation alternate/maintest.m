clc;
clear all;
close all;
disp( 'History matching data assimilation technique using EnKF for PUNQ Reservoir'  ) 
disp( 'PhD Student: Clement Etienam' )
disp( 'Supervisor: Dr Rossmary Villegas' )
disp( 'Co-supervisor: Dr Masoud Babei' )
disp('  import the true data  ');
% N - size of ensemble

N=input( ' enter the number of realizations(ensemble size)  ');
 %Import true data
 
 True= importdata('Real.RSM',' ',7);
 True2= importdata('Real.RSM',' ',95);
 True3= importdata('Real.RSM',' ',183);
 
 
 True=True.data;
 True2=True2.data;
 True3=True3.data;
 
 
  TP1=True(:,4);
 TP2=True(:,5);
 TP3=True(:,6);
 TP4=True(:,7);
  TP5=True(:,8);
   TP6=True(:,9);
 
 
 TG1=True(:,10);
 TG2=True2(:,2);
 TG3=True2(:,3);
 TG4=True2(:,4);
 TG5=True2(:,5);
  TG6=True2(:,6);
 
 
 
 
  TW1=True2(:,7);
 TW2=True2(:,8);
 TW3=True2(:,9);
 TW4=True2(:,10);
  TW5=True3(:,2);
   TW6=True3(:,3);
 
 
 

 TFOE=True(:,3);
 disp(' make the true observation')
 for i=1:81
 obs=zeros(19,1);
 obs(1,:)=TFOE(i,:);
 obs(2,:)=TP1(i,:);
 obs(3,:)=TP2(i,:);
 obs(4,:)=TP3(i,:);
 obs(5,:)=TP4(i,:);
 obs(6,:)=TP5(i,:);
 obs(7,:)=TP6(i,:);
 obs(8,:)=TG1(i,:);
 obs(9,:)=TG2(i,:);
 obs(10,:)=TG3(i,:);
 obs(11,:)=TG4(i,:);
 obs(12,:)=TG5(i,:);
 obs(13,:)=TG6(i,:);
 obs(14,:)=TW1(i,:);
 obs(15,:)=TW2(i,:);
 obs(16,:)=TW3(i,:);
 obs(17,:)=TW4(i,:);
 obs(18,:)=TW5(i,:);
 obs(19,:)=TW6(i,:);
 observation(:,i)=obs;
 end
 
 disp(' for initial ensemble states load the files')
load sgsim.out; %permeability ensemble
load pressureensemble.out; % ensemble state of pressure
PE=reshape(pressureensemble,1764,N);

load saturationensemble.out; %water saturation ensemble
SW=reshape(saturationensemble,1764,N);
load SGensemble.out; %gas saturation ensemble
SG=reshape(SGensemble,1764,N);
load RSensemble.out % solution gas ensemble
RS=reshape(RSensemble,1764,N);
sgsim=reshape(sgsim,2660,N);
load Simulateddata.out;
Sim1=reshape(Simulateddata,19,N);
load effective.out;
load rossmary.GRDECL;
load rossmaryporo.GRDECL;
load rossmaryz2.GRDECL;
for i=1:81
 fprintf('Now assimilating timestep %d .\n', i);



f=observation(:,i);
[PE,SW,SG,RS,sgz1,Sim1,sgsim2,DupdateK] = Assimilate2 (sgsim, f, N, PE,SW,SG,RS, Sim1);
Psteps(:,i)=reshape(PE,1764*N,1);
SWsteps(:,i)=reshape(SW,1764*N,1);
SGsteps(:,i)=reshape(SG,1764*N,1);
RSsteps(:,i)=reshape(RS,1764*N,1);
Sim1steps(:,i)=reshape(Sim1,19*N,1);


%condition the data
[output,outputporo,outputz] = honour2(rossmary, rossmaryporo,rossmaryz2, N,sgz1,sgsim2,DupdateK);
permsteps(:,i)=reshape(output,2660*N,1); 
porosteps(:,i)=reshape(outputporo,2660*N,1);
zsteps(:,i)=reshape(outputz,2660*N,1);

sgsim=reshape(output,2660,N);

%function Kplot=compareplot(output,outputporo,outputz,effective,rossmary,rossmaryporo,N)

Joyeffective= repmat(effective,1,N);
Joyeffective=reshape(Joyeffective,2660,N);
Pnew = reshape(output,2660,N);
Pnew2=Pnew.*Joyeffective;
Pnewporo=reshape(outputporo,2660,N);
Pnewporo=Pnewporo.*Joyeffective;
Pnewz=reshape(outputz,2660,N);
Pnewz=Pnewz.*Joyeffective;

 
 %run Assimilate.m
 
 
 Trueperm=reshape(rossmary,19,28,5);
 Trueporo=reshape(rossmaryporo,19,28,5);
 Truepermz=reshape(rossmaryz2,19,28,5);
 Trueperm=Trueperm.*reshape(effective,19,28,5);
 Trueporo=Trueporo.*reshape(effective,19,28,5);
 Truepermz=Truepermz.*reshape(effective,19,28,5);
 Ssim = ones(1,N);
 %% SSIM INDEX COMPARISON
% COMPARISON OF THE ENSEMBLES USING SSIM
 for j=1:N

        % reshaping each member in 3D
        
  
        P1 = reshape(Pnew(:,j),19,28,5);
        P1=P1.*reshape(effective,19,28,5);
        for jj=1:5 
        
        % calculating ssim index for each layer

        P2 = ssim(P1(:,:,jj),Trueperm(:,:,jj));
        
        % multiplication of layer indices
        
        Ssim(j) = Ssim(j) * P2;
       

        end
    end

    % multiplication of P and S indices
    
    index = Ssim; 
    index=index';
    
    % choosing between two best members
    
    bestssim = find(index == max(index));
	Pssim = Pnew2(:,bestssim); %best due to ssim
    porobest=Pnewporo(:,bestssim);
    pzbest=Pnewz(:,bestssim);
	
	Pssim=reshape(Pssim,19,28,5);  
    porobest=reshape(porobest,19,28,5);
    pzbest=reshape(pzbest,19,28,5);
	
	
	
	
	%[X,Y] = meshgrid(1:120,1:60);


	
	
Trueperm=log10(Trueperm);
Pssim=log10(Pssim);

Truepermz=log10(Truepermz);
pzbest=log10(pzbest);

Trueperm(Trueperm==-Inf)=NaN;
Pssim(Pssim==-Inf)=NaN;

Trueporo(Trueporo==0)=NaN;
porobest(porobest==0)=NaN;

Truepermz(Truepermz==-Inf)=NaN;
pzbest(pzbest==-Inf)=NaN;


[X,Y] = meshgrid(1:19,1:28);





h1=figure;
subplot(6,5,1);
surf(X',Y',Trueperm(:,:,1))

shading flat
axis([1 19 1 28 ])
grid off
title('True Layer 1','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,2);
surf(X',Y',Trueperm(:,:,2))

shading flat
axis([1 19 1 28 ])
grid off
title('True perm 2','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,3);
surf(X',Y',Trueperm(:,:,3))

shading flat
axis([1 19 1 28 ])
grid off
title('True perm 3','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,4);
surf(X',Y',Trueperm(:,:,4))

shading flat
axis([1 19 1 28 ])
grid off
title('True perm 4','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,5);

surf(X',Y',Trueperm(:,:,5))

shading flat
axis([1 19 1 28 ])
grid off
title('True perm 5','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
	
	

subplot(6,5,6);
surf(X',Y',Pssim(:,:,1))

shading flat
axis([1 19 1 28 ])
grid off
title('Layer 1','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])	


subplot(6,5,7);
surf(X',Y',Pssim(:,:,2))

shading flat
axis([1 19 1 28 ])
grid off
title('Layer 2','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])	


subplot(6,5,8);
surf(X',Y',Pssim(:,:,3))

shading flat
axis([1 19 1 28 ])
grid off
title('Layer 3','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,9);
surf(X',Y',Pssim(:,:,4))

shading flat
axis([1 19 1 28 ])
grid off
title('Layer 4','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,10);
surf(X',Y',Pssim(:,:,5))

shading flat
axis([1 19 1 28 ])
grid off
title('Layer 5','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,11);
surf(X',Y',Trueporo(:,:,1))

shading flat
axis([1 19 1 28 ])
grid off
title('True Layer 1','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([0.1 0.4])
h = colorbar;
ylabel(h, 'porosity','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [0.1 0.4])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,12);
surf(X',Y',Trueporo(:,:,2))

shading flat
axis([1 19 1 28 ])
grid off
title('True poro 2','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([0.1 0.4])
h = colorbar;
ylabel(h, 'porosity','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [0.1 0.4])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,13);
surf(X',Y',Trueporo(:,:,3))

shading flat
axis([1 19 1 28 ])
grid off
title('True poro 3','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([0.1 0.4])
h = colorbar;
ylabel(h, 'porosity','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [0.1 0.4])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,14);
surf(X',Y',Trueporo(:,:,4))

shading flat
axis([1 19 1 28 ])
grid off
title('True poro 4','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([0.1 0.4])
h = colorbar;
ylabel(h, 'porosity','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [0.1 0.4])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,15);
surf(X',Y',Trueporo(:,:,5))

shading flat
axis([1 19 1 28 ])
grid off
title('True poro 5','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([0.1 0.4])
h = colorbar;
ylabel(h, 'porosity','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [0.1 0.4])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,16);
surf(X',Y',porobest(:,:,1))

shading flat
axis([1 19 1 28 ])
grid off
title('Layer 1','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([0.1 0.4])
h = colorbar;
ylabel(h, 'porosity','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [0.1 0.4])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,17);
surf(X',Y',porobest(:,:,2))

shading flat
axis([1 19 1 28 ])
grid off
title('Layer 2','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([0.1 0.4])
h = colorbar;
ylabel(h, 'porosity','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [0.1 0.4])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,18);
surf(X',Y',porobest(:,:,3))

shading flat
axis([1 19 1 28 ])
grid off
title('Layer 3','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([0.1 0.4])
h = colorbar;
ylabel(h, 'porosity','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [0.1 0.4])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,19);
surf(X',Y',porobest(:,:,4))

shading flat
axis([1 19 1 28 ])
grid off
title('Layer 4','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([0.1 0.4])
h = colorbar;
ylabel(h, 'porosity','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [0.1 0.4])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,20);
surf(X',Y',porobest(:,:,5))

shading flat
axis([1 19 1 28 ])
grid off
title('Layer 5','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([0.1 0.4])
h = colorbar;
ylabel(h, 'porosity','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [0.1 0.4])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,21);
surf(X',Y',Truepermz(:,:,1))

shading flat
axis([1 19 1 28 ])
grid off
title('True permz 1','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([0 2])
h = colorbar;
ylabel(h, 'Log Kz(mD)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [0 2])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,22);
surf(X',Y',Truepermz(:,:,2))

shading flat
axis([1 19 1 28 ])
grid off
title('True permz 2','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([0 2])
h = colorbar;
ylabel(h, 'Log Kz(mD)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [0 2])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,23);
surf(X',Y',Truepermz(:,:,3))

shading flat
axis([1 19 1 28 ])
grid off
title('True permz 3','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([0 2])
h = colorbar;
ylabel(h, 'Log Kz(mD)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [0 2])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,24);
surf(X',Y',Truepermz(:,:,4))

shading flat
axis([1 19 1 28 ])
grid off
title('True permz 4','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([0 2])
h = colorbar;
ylabel(h, 'Log Kz(mD)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [0 2])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,25);
surf(X',Y',Truepermz(:,:,5))

shading flat
axis([1 19 1 28 ])
grid off
title('True permz 5','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([0 2])
h = colorbar;
ylabel(h, 'Log Kz(mD)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [0 2])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,26);
surf(X',Y',pzbest(:,:,1))

shading flat
axis([1 19 1 28 ])
grid off
title('Layer 1','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([0 2])
h = colorbar;
ylabel(h, 'Log Kz(mD)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [0 2])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,27);
surf(X',Y',pzbest(:,:,2))

shading flat
axis([1 19 1 28 ])
grid off
title('Layer 2','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([0 2])
h = colorbar;
ylabel(h, 'Log Kz(mD)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [0 2])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,28);
surf(X',Y',pzbest(:,:,3))

shading flat
axis([1 19 1 28 ])
grid off
title('Layer 3','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([0 2])
h = colorbar;
ylabel(h, 'Log Kz(mD)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [0 2])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,29);
surf(X',Y',pzbest(:,:,4))

shading flat
axis([1 19 1 28 ])
grid off
title('Layer 4','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([0 2])
h = colorbar;
ylabel(h, 'Log Kz(mD)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [0 2])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(6,5,30);
surf(X',Y',pzbest(:,:,5))

shading flat
axis([1 19 1 28 ])
grid off
title('Layer 5','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([0 2])
h = colorbar;
ylabel(h, 'Log Kz(mD)','FontName','Helvetica', 'Fontsize', 11);
set(h, 'ylim', [0 2])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])


saveas(h1,sprintf('progress%d.fig',i));
saveas(h1,sprintf('progress(b)%d.jpeg',i));
% filename=sprintf('progress%d.fig',i);
% imshow(sprintf('progress%d.fig',i),'border','tight','InitialMagnification',100);
% idx = strfind(sprintf('progress%d.fig',i),'.');
% filename = [filename(1:idx) 'fig'];
% print(gcf,'-dfig',filename)
% close
Trueperm1=Trueperm;
%Trueperm1(Trueperm1==-Inf)=NaN;	
h2=figure;
 subplot(2,3,1);
slice(Trueperm1,[1 28],[1 19],[1 5])
axis equal on
%axis([1 27 1 84 1 4 ])
% xlim([1 84])
% ylim([1 27])
% zlim([0 4])
shading flat
grid off
title('3D true permeability','FontName','Helvetica', 'Fontsize', 11);
caxis([1 3])
h = colorbar;
xlabel('X','FontName','Helvetica', 'Fontsize', 11)
ylabel('Y','FontName','Helvetica', 'Fontsize', 11)
zlabel('Z','FontName','Helvetica', 'Fontsize', 11)
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 11);
hold on
plot3([22 22],[10 10],[1 50],'k','Linewidth',2);
hold on
plot3([17 17],[9 9],[1 50],'k','Linewidth',2);
hold on
plot3([11 11],[17 17],[1 50],'k','Linewidth',2);
hold on
plot3([24 24],[11 11],[1 50],'k','Linewidth',2);
hold on
plot3([12 12],[15 15],[1 50],'k','Linewidth',2);
hold on
plot3([22 22],[17 17],[1 50],'k','Linewidth',2);
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca,'zticklabel',[])

perm1=Pssim;
perm1(perm1==-Inf)=NaN;

subplot(2,3,4);
slice(perm1,[1 28],[1 19],[1 5])
axis equal on
%axis([1 27 1 84 1 4 ])
% xlim([1 84])
% ylim([1 27])
% zlim([0 4])
shading flat
grid off
title('3D reconstructed permeability','FontName','Helvetica', 'Fontsize', 11);
caxis([1 3])
h = colorbar;
xlabel('X','FontName','Helvetica', 'Fontsize', 11)
ylabel('Y','FontName','Helvetica', 'Fontsize', 11)
zlabel('Z','FontName','Helvetica', 'Fontsize', 11)
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 11);
hold on
plot3([22 22],[10 10],[1 50],'k','Linewidth',2);
hold on
plot3([17 17],[9 9],[1 50],'k','Linewidth',2);
hold on
plot3([11 11],[17 17],[1 50],'k','Linewidth',2);
hold on
plot3([24 24],[11 11],[1 50],'k','Linewidth',2);
hold on
plot3([12 12],[15 15],[1 50],'k','Linewidth',2);
hold on
plot3([22 22],[17 17],[1 50],'k','Linewidth',2);
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca,'zticklabel',[])

subplot(2,3,2);
slice(Trueporo,[1 28],[1 19],[1 5])
axis equal on
%axis([1 27 1 84 1 4 ])
% xlim([1 84])
% ylim([1 27])
% zlim([0 4])
shading flat
grid off
title('3D true porosity','FontName','Helvetica', 'Fontsize', 11);
caxis([0.1 0.4])
h = colorbar;
xlabel('X','FontName','Helvetica', 'Fontsize', 11)
ylabel('Y','FontName','Helvetica', 'Fontsize', 11)
zlabel('Z','FontName','Helvetica', 'Fontsize', 11)
set(h, 'ylim', [0.1 0.4])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
ylabel(h, 'porosity','FontName','Helvetica', 'Fontsize', 11);
hold on
plot3([22 22],[10 10],[1 50],'k','Linewidth',2);
hold on
plot3([17 17],[9 9],[1 50],'k','Linewidth',2);
hold on
plot3([11 11],[17 17],[1 50],'k','Linewidth',2);
hold on
plot3([24 24],[11 11],[1 50],'k','Linewidth',2);
hold on
plot3([12 12],[15 15],[1 50],'k','Linewidth',2);
hold on
plot3([22 22],[17 17],[1 50],'k','Linewidth',2);
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca,'zticklabel',[])

subplot(2,3,3);
slice(Truepermz,[1 28],[1 19],[1 5])
axis equal on
%axis([1 27 1 84 1 4 ])
% xlim([1 84])
% ylim([1 27])
% zlim([0 4])
shading flat
grid off
title('3D true Kz','FontName','Helvetica', 'Fontsize', 11);
caxis([0 2])
h = colorbar;
xlabel('X','FontName','Helvetica', 'Fontsize', 11)
ylabel('Y','FontName','Helvetica', 'Fontsize', 11)
zlabel('Z','FontName','Helvetica', 'Fontsize', 11)
set(h, 'ylim', [0 2])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 11);
hold on
plot3([22 22],[10 10],[1 50],'k','Linewidth',2);
hold on
plot3([17 17],[9 9],[1 50],'k','Linewidth',2);
hold on
plot3([11 11],[17 17],[1 50],'k','Linewidth',2);
hold on
plot3([24 24],[11 11],[1 50],'k','Linewidth',2);
hold on
plot3([12 12],[15 15],[1 50],'k','Linewidth',2);
hold on
plot3([22 22],[17 17],[1 50],'k','Linewidth',2);
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca,'zticklabel',[])

subplot(2,3,5);
slice(porobest,[1 28],[1 19],[1 5])
axis equal on
%axis([1 27 1 84 1 4 ])
% xlim([1 84])
% ylim([1 27])
% zlim([0 4])
shading flat
grid off
title('Reconstructed porosity','FontName','Helvetica', 'Fontsize', 11);
caxis([0.1 0.4])
h = colorbar;
xlabel('X','FontName','Helvetica', 'Fontsize', 11)
ylabel('Y','FontName','Helvetica', 'Fontsize', 11)
zlabel('Z','FontName','Helvetica', 'Fontsize', 11)
set(h, 'ylim', [0.1 0.4])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
ylabel(h, 'porosity','FontName','Helvetica', 'Fontsize', 11);
hold on
plot3([22 22],[10 10],[1 50],'k','Linewidth',2);
hold on
plot3([17 17],[9 9],[1 50],'k','Linewidth',2);
hold on
plot3([11 11],[17 17],[1 50],'k','Linewidth',2);
hold on
plot3([24 24],[11 11],[1 50],'k','Linewidth',2);
hold on
plot3([12 12],[15 15],[1 50],'k','Linewidth',2);
hold on
plot3([22 22],[17 17],[1 50],'k','Linewidth',2);
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca,'zticklabel',[])

subplot(2,3,6);
slice(pzbest,[1 28],[1 19],[1 5])
axis equal on
%axis([1 27 1 84 1 4 ])
% xlim([1 84])
% ylim([1 27])
% zlim([0 4])
shading flat
grid off
title('3D Kz recon','FontName','Helvetica', 'Fontsize', 11);
caxis([0 2])
h = colorbar;
xlabel('X','FontName','Helvetica', 'Fontsize', 11)
ylabel('Y','FontName','Helvetica', 'Fontsize', 11)
zlabel('Z','FontName','Helvetica', 'Fontsize', 11)
set(h, 'ylim', [0 2])
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
ylabel(h, 'Log Kz(mD)','FontName','Helvetica', 'Fontsize', 11);
hold on
plot3([22 22],[10 10],[1 50],'k','Linewidth',2);
hold on
plot3([17 17],[9 9],[1 50],'k','Linewidth',2);
hold on
plot3([11 11],[17 17],[1 50],'k','Linewidth',2);
hold on
plot3([24 24],[11 11],[1 50],'k','Linewidth',2);
hold on
plot3([12 12],[15 15],[1 50],'k','Linewidth',2);
hold on
plot3([22 22],[17 17],[1 50],'k','Linewidth',2);
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca,'zticklabel',[])



saveas(h2,sprintf('3Dprogress%d.fig',i));
saveas(h2,sprintf('3Dprogress(b)%d.jpeg',i));
 fprintf('Finished assimilating timestep %d \n', i);
end
disp('  output to ASCII files the states at each time step  ');
save('Permall.out','permsteps','-ascii');
save('Poroall.out','porosteps','-ascii');
save('zall.out','zsteps','-ascii');
 disp('  program executed  ');
%end
 %plot the mean and variance for each timestep
 run('testvar.m')
 
 