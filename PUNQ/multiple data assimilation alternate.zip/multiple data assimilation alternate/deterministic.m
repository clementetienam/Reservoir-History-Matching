function [DupdateK,Saturation,Pressure,SaturationG,RSG] = deterministic (sgactual,f, N, Sim1,alpha,tol,indices2,Saturation,Pressure,SaturationG,RSG);

sgsim1=log(sgactual);
 sgsim11 = reshape(sgsim1,2660,N);
disp('  generate Gaussian noise for the observed measurments  ');


  stddFOE =    0.1*f(1,:);
	
	stddBHP1 = 0.1*f(2,:);
    stddBHP2 = 0.1*f(3,:);
    stddBHP3 = 0.1*f(4,:);
    stddBHP4 = 0.1*f(5,:);
	stddBHP5 = 0.1*f(6,:);
	stddBHP6 = 0.1*f(7,:);
	
	stddGORP1 = 0.15*f(8,:);
    stddGORP2 = 0.15*f(9,:);
    stddGORP3 = 0.15*f(10,:);
    stddGORP4 = 0.15*f(11,:);
	stddGORP5 = 0.15*f(12,:);
    stddGORP6 = 0.15*f(13,:);
  

    stddWWCT1 = 0.2*f(14,:);
    stddWWCT2 = 0.2*f(15,:);
    stddWWCT3 = 0.2*f(16,:);
    stddWWCT4 = 0.2*f(17,:);
	stddWWCT5 = 0.2*f(18,:);
	stddWWCT6 = 0.2*f(19,:);

  
Error1=ones(19,N);
Error1(1,:)=normrnd(0,stddFOE,1,N);
Error1(2,:)=normrnd(0,stddBHP1,1,N);
Error1(3,:)=normrnd(0,stddBHP2,1,N);
Error1(4,:)=normrnd(0,stddBHP3,1,N);
Error1(5,:)=normrnd(0,stddBHP4,1,N);
Error1(6,:)=normrnd(0,stddBHP5,1,N);
Error1(7,:)=normrnd(0,stddBHP6,1,N);
Error1(8,:)= normrnd(0,stddGORP1,1,N);
Error1(9,:)= normrnd(0,stddGORP2,1,N);
Error1(10,:)= normrnd(0,stddGORP3,1,N);
Error1(11,:)= normrnd(0,stddGORP4,1,N);
Error1(12,:)= normrnd(0,stddGORP5,1,N);
Error1(13,:)= normrnd(0,stddGORP6,1,N);
Error1(14,:)=normrnd(0,stddWWCT1,1,N);
Error1(15,:)=normrnd(0,stddWWCT2,1,N);
Error1(16,:)=normrnd(0,stddWWCT3,1,N);
Error1(17,:)=normrnd(0,stddWWCT4,1,N);
Error1(18,:)=normrnd(0,stddWWCT5,1,N);
Error1(19,:)=normrnd(0,stddWWCT6,1,N);


%Cd2 = (Error1*Error1')./(N-1);

disp('pertub the historical observations' )
for i=1:N
     Dj(:,i)=f+Error1(:,i);
 end

% Information matirx
H=zeros(19,9735);
H(1:19,9717:9735)=eye(19);
%H=reshape(H,12,72000);
overall=zeros(9735,N); %ensemble state for EnKF

overall(1:2660,1:N)=sgsim11;
overall(2661:4424,1:N)=Saturation;
overall(4425:6188,1:N)=Pressure;
overall(6189:7952,1:N)=SaturationG;
overall(7953:9716,1:N)=RSG;
overall(9717:9735,1:N)=Sim1;




Y=overall; %State variable,it is important we include simulated measurements in the ensemble state variable

 M = mean(Sim1,2);
% Mean of the ensemble state
M2=mean(overall,2);
for j=1:N
    S(:,j)=Sim1(:,j)-M;
end
for j=1:N
    yprime(:,j)=overall(:,j)-M2;
end
disp('  update the new ensemble  ');
Cyd=(yprime*S')./((N-1));
Cdd=(S*S')./((N-1));

disp('compute the kalman gain')
Kg=(Cyd*pinv(Cdd+(alpha.*Cd2)));
disp('  update the ensemble mean new ensemble  ');
M2new=M2+(Kg*(f-M));

disp('update the ensemble deviations')
yprimenew=yprime-(0.5*Kg*S);

disp('update the ensmble')
for i=1:N
Ynew(:,i)=yprimenew(:,i)+M2new;
end


value1=Ynew(1:2660,1:N);


sgsim11=value1;
% sgsim2=value2;
% sgz1=value3;

DupdateK=exp(sgsim11);
DupdateK(DupdateK<=0.4967)=0.4967;
DupdateK(DupdateK>=9500)=9500;


Saturation=Ynew(1762:3525,1:N);
Pressure=Ynew(3526:5289,1:N);
SaturationG=Ynew(5290:7053,1:N);
RSG=Ynew(7054:8817,1:N);

Saturation(Saturation>=1)=1;

SaturationG(SaturationG>=1)=1;




end