clc;
clear;
[SWn83,PEn83,SGn83,RSEn83]=getstatesallenkf(200,81);