function [DupdateK,Saturation,Pressure,SaturationG,RSG] = transistion (sgactual,f, N, Sim1,alpha,tol,indices2,Saturation,Pressure,SaturationG,RSG,history);

sgsim1=log(sgactual);
 sgsim11 = reshape(sgsim1,2660,N);
  fuse=f(2:19,:);
 Simuse=Sim1(2:19,:);
 Sim1=Simuse;
 f=fuse;
disp('  generate Gaussian noise for the observed measurments  ');

stddFOE =    0.15*f(1,:);
	
	stddBHP1 = 0.15*f(2,:);
    stddBHP2 = 0.15*f(3,:);
    stddBHP3 = 0.15*f(4,:);
    stddBHP4 = 0.15*f(5,:);
	stddBHP5 = 0.15*f(6,:);
	stddBHP6 = 0.15*f(7,:);

if history <20
	stddGORP1 = 0.15*f(8,:);
    stddGORP2 = 0.15*f(9,:);
    stddGORP3 = 0.15*f(10,:);
    stddGORP4 = 0.15*f(11,:);
	stddGORP5 = 0.15*f(12,:);
    stddGORP6 = 0.15*f(13,:);
else
    stddGORP1 = 0.25*f(8,:);
    stddGORP2 = 0.25*f(9,:);
    stddGORP3 = 0.25*f(10,:);
    stddGORP4 = 0.25*f(11,:);
	stddGORP5 = 0.25*f(12,:);
    stddGORP6 = 0.25*f(13,:);
end

if history <25
    stddWWCT1 = 0.2*f(14,:);
    stddWWCT2 = 0.2*f(15,:);
    stddWWCT3 = 0.2*f(16,:);
    stddWWCT4 = 0.2*f(17,:);
	stddWWCT5 = 0.2*f(18,:);
	stddWWCT6 = 0.2*f(19,:);
else
    stddWWCT1 = 0.21*f(14,:);
    stddWWCT2 = 0.21*f(15,:);
    stddWWCT3 = 0.21*f(16,:);
    stddWWCT4 = 0.21*f(17,:);
	stddWWCT5 = 0.21*f(18,:);
	stddWWCT6 = 0.21*f(19,:);
end    
 tope=60;
  
Error1=ones(18,N);

Error1(1,:)=normrnd(0,stddBHP1,1,N);
Error1(2,:)=normrnd(0,stddBHP2,1,N);
Error1(3,:)=normrnd(0,stddBHP3,1,N);
Error1(4,:)=normrnd(0,stddBHP4,1,N);
Error1(5,:)=normrnd(0,stddBHP5,1,N);
Error1(6,:)=normrnd(0,stddBHP6,1,N);
Error1(7,:)= normrnd(0,stddGORP1,1,N);
Error1(8,:)= normrnd(0,stddGORP2,1,N);
Error1(9,:)= normrnd(0,stddGORP3,1,N);
Error1(10,:)= normrnd(0,stddGORP4,1,N);
Error1(11,:)= normrnd(0,stddGORP5,1,N);
Error1(12,:)= normrnd(0,stddGORP6,1,N);
Error1(13,:)=normrnd(0,stddWWCT1,1,N);
Error1(14,:)=normrnd(0,stddWWCT2,1,N);
Error1(15,:)=normrnd(0,stddWWCT3,1,N);
Error1(16,:)=normrnd(0,stddWWCT4,1,N);
Error1(17,:)=normrnd(0,stddWWCT5,1,N);
Error1(18,:)=normrnd(0,stddWWCT6,1,N);
% 
% x=[stddFOE,stddBHP1,stddBHP2,stddBHP3,stddBHP4,stddBHP5,stddBHP6,stddGORP1...
%  stddGORP2,stddGORP3,stddGORP4,stddGORP5,stddGORP6,stddWWCT1,stddWWCT2...
%  stddWWCT3,stddWWCT4,stddWWCT5,stddWWCT6];
%  Cd3 = diag(x);
%   Cd2=Cd3;
% mu=zeros(N,19);
%  Error1=mvnrnd(mu,Cd2);
%  Error1=Error1'; 
% for i=1:N
%     Dj(:,i)=f+(Error1(:,i));
% 	
%  end



disp('pertub the historical observations' )
for i=1:N
     Dj(:,i)=f+Error1(:,i);
 end

% Information matirx
H=zeros(18,2678);
H(1:18,2661:2678)=eye(18);
%H=reshape(H,12,72000);
overall=zeros(2678,N); %ensemble state for EnKF

overall(1:2660,1:N)=sgsim11;

overall(2661:2678,1:N)=Sim1;




Y=overall; %State variable,it is important we include simulated measurements in the ensemble state variable
S = Sim1-repmat(mean(Sim1,2),1,N);


% Mean of the ensemble state
M2=mean(overall,2);

C=(S*S')+(Error1*Error1');
%%
[Usig,Sig,Vsig] = svd(C);
xsmall = diag(Sig);
Bsig = cumsum(xsmall);
valuesig=Bsig(end);
valuesig=valuesig*0.999999;
indices = find(cumsum(xsmall) >= valuesig );
toluse=xsmall(indices,:);
tol=toluse(1,:);
Xtrans=eye(N)+(S'*pinv2(C)*(Dj - Sim1));
%             D = sqrt(200 / (200 - 1)) * (D - repmat(d, 1, 200));
   disp( 'update the ensemble ')
            Ynew = Y*Xtrans;
           


value1=Ynew(1:2660,1:N);


sgsim11=value1;
% sgsim2=value2;
% sgz1=value3;

DupdateK=exp(sgsim11);
 DupdateK(DupdateK<=0.4967)=0.4967;
 DupdateK(DupdateK>=9500)=9500;


end