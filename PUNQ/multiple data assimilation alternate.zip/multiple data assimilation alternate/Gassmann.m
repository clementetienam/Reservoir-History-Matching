function [ImpP, ImpS]=Gassmann(PORO,Pr,SO)
%Poro - porosity (array shape)
%P - pressure (psi, eclipse formatted)
%SO - oil saturation (eclispe formatted)

    % Temperature (degrees Celsius)
    % 217 F
    T = 103; % C

 %Importing porosity and permeability values
    %load('POROVANCOUVER.DAT')
    %load('KVANCOUVER.DAT')
    
    POROVANCOUVER = PORO;
    
    %Data analysis
    avePorosity = mean(POROVANCOUVER);
    minPorosity = min(POROVANCOUVER);
    maxPorosity = max(POROVANCOUVER);
    stDevPorosity = std(POROVANCOUVER);

    %%
    % sorting out indices
    for i = 1:size(POROVANCOUVER)
    zIndex(i) = idivide(int16(i)-1,2268) + 1;
    xyIndex(i) = mod(int16(i)-1,2268)+1;
    yIndex(i) = idivide(int16(xyIndex(i))-1,84) + 1;
    xIndex(i) = mod(xyIndex(i)-1,84) +1;
    % {z}(x,y)
    porosity{zIndex(i)}(xIndex(i),yIndex(i)) = POROVANCOUVER(i);
    
    end

    % Read in pressure and oil saturation files

    PressureAfter1Year=Pr;
    OilSatAfter1Year=SO;

    % labeling the imported data
    for i = 1:2268   %84*27
        for j = 1:4
            aux(i,j) = (i - 1)*4 + j;
            xyIndex2(i,j) = mod(aux(i,j) - 1, 2268) + 1;
            yIndex2(i,j) = idivide(int16(xyIndex2(i,j))-1,84) + 1;
            xIndex2(i,j) = mod(xyIndex2(i,j) - 1,84) +1;
            zIndex2(i,j) = idivide(int16(aux(i,j) - 1),2268) + 1;
            % psia to MPa            
                pressure{zIndex2(i,j)}(xIndex2(i,j),yIndex2(i,j)) = ...
                    field2Metric(PressureAfter1Year(i,j), 'psi')*1E-6;
                saturation{zIndex2(i,j)}(xIndex2(i,j),yIndex2(i,j)) = ...
                    OilSatAfter1Year(i,j);                  
        end
    end
    %% 
    %%%%%%Water data%%%%%%
    % The water formation volume factor at the reference pressure
    BWater = 1.029; % rb/stb
    
    % Compressibility
    CWater = 3.13E-6; % 1/psi
    
    % Density
    rhoWater = field2Metric(64.00, 'lbft3'); % kg/m3
    %%%%%%%%%%%%%%%%%%%%%%
    
    %%%%%%Oil data%%%%%%%%
    
    % Gas Specific gravity
    G = 0.8515;
    
    % 600 SCF/BBL ->  m3/m3
    RG = 0; %600*0.0283168466/0.158987295;
    
    % Oil API
    API = 141.5/G - 131.5; % need rhoOil in g/cm^3
    %%%%%%%%%%%%%%%%%%%%%%
    
    %%%%%%Matrix data%%%%%%
    
    % From permeability - porosity graphs, assumed made of quartz and feldspar
    % quartz dominant
    
    % Compressibility
    CMatrix = 0.30E-05; % 1/psi ;
    
    % Density
    % From Carmichael (1986)
    % Try different percentage of quartz
    SQuartz = 0.6;
    SFeldspar = 1 - SQuartz;
    rhoQuartz = 2.65*1000; % kg/m3
    KQuartz = 37E9; % Pa
    GQuartz = 44E9; % Pa
    rhoFeldspar = 2.62*1000; % kg/m3
    KFeldspar = 37.5E9; % Pa
    GFeldspar = 15E9; % Pa
    KMatrix = ones(84,27)*(SQuartz.*KQuartz + SFeldspar.*KFeldspar)/2 + ...
        (SQuartz./KQuartz + SFeldspar./KFeldspar).^(-1)/2;
    %%%%%%%%%%%%%%%%%%%%%%
    
    %%%%%%%%Frame data%%%%
    
    % Lab data
    rhoDry = ones(84,27)*2169;
    KDry = ones(84,27)*field2Metric(2E6, 'psi') ;
    GDry = ones(84,27)*field2Metric(1.368E6, 'psi');
    
    % Calculate parameters from input data for each z value
    for i = 1:4
        P = pressure{i};
        SOil = saturation{i};
        phi = porosity{i};
        
        % Oil data (Batzle and Wang)
        rho0 = 141.5/(API + 131.5); % g/cm3
        
        % volume formation factor
        B0 = 0.972 + 0.00038*(2.4*RG*sqrt(G/rho0)+ T + 17.8).^(1.175);
        
        % pseudo density
        rhopseudo = rho0/B0*(1+0.001*RG)^-1; % g/cm3
        
        % density of oil with gas
        rhoG = (rho0 + 0.0012*G*RG)/B0; % g/cm3
        
        % density corrected for pressure and temperature
        rhoOil = 1000*(rho0 + (0.00277.*P - 1.71E-7.*P.^3)*(rhoG - 1.15).^2 + ...
            P.*3.49E-4)/(0.972 + 3.81E-4*(T + 17.78)^1.175); % kg/m3
        
        % Oil velocity from API (Batzle and Wang)
        % Simplified version of the equation in the report
        VOil = 2096*(rhopseudo/(2.6 - rhopseudo))^0.5 - 3.7*T + 4.64*P +...
            0.0115*T.*P*(4.12*(1.08/rhopseudo - 1).^0.5 - 1); %m/s
        
        % Bulk modulus of oil
        KOil = rhoOil.*VOil.^2; % Pa
        
        % Bulk modulus of water
        KWater = field2Metric(1./CWater, 'psi'); % Pa
        
        % Woodcock's equation
        KFluid = ((1 - SOil)./KWater + SOil./KOil).^(-1); %Pa
        rhoFluid = (1 - SOil).*rhoWater + SOil.*rhoOil; % kg/m3
        
        % Gassmann equations (in SI units)
        KSat{i} = KDry + ...
            (1 - KDry./KMatrix).^2./(phi./KFluid + (1 - phi)./KMatrix - KDry./KMatrix.^2);
        GSat = GDry;
        % Density equation
        rhoSat{i} = rhoDry + phi.*rhoFluid;
    end
    
    %%
    % Backus Average
    for i = 1:max(xIndex)
        for j = 1:max(yIndex)
            for k = 1:max(zIndex)
                element(k) = 1/(KSat{k}(i,j) + 4/3*GSat(i,j));
                density(k) = rhoSat{k}(i,j);
            end
            D(i,j) = GSat(i,j);
            C(i,j) = mean(element)^(-1);
            rho(i,j) = mean(density);
        end
    end
    
    % P and S wave velocities 
    VP = (C./rho).^0.5; % m/s
    VS = (D./rho).^0.5;
    
    % Seismic data (output) 
    VP = field2Metric(VP, 'ms'); % ft/s
    VS = field2Metric(VS, 'ms');
    
    rho = rho/1000; % g/cm3
    
    % Impedance
    ImpP = rho.*VP;
    ImpS = rho.*VS;
        
    % mean values 
    VPMean = mean(mean(VP));
    VSMean = mean(mean(VS));
    ImpPMean = mean(mean(ImpP));
    ImpSMean = mean(mean(ImpS));
    rhoSatMean = mean(mean(rho));
    
    % Difference from mean value
    VPD = (VP - VPMean)./VPMean*100;
    VSD = (VS - VSMean)./VSMean*100;
    ImpPD = (ImpP - ImpPMean)./ImpPMean*100;
    ImpSD = (ImpS - ImpSMean)./ImpSMean*100;
    rhoSatD = (rho - rhoSatMean)./rhoSatMean*100;
    
end