clc;
clear all;
close all;
load sgsim.out;
load effective.out;
sgsim=reshape(sgsim,2660,200);
sgsim=sgsim.*repmat(effective,1,200);
indices=find(sgsim(:,1));
for i=1:200
    a=sgsim(:,i);
 sgactual(:,i)=a(indices);
end