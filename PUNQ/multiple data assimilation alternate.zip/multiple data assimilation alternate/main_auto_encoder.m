function [z]=main_auto_encoder(nx,ny,nz,N,tol,observation,overallsim,perm,history,alpha);
disp( 'History matching data assimilation technique using ES-MDA with Autoencoder for PUNQ Reservoir'  ) 
disp( 'Author: Dr Clement Etienam' )

disp('  import the true data  ');
% N - size of ensemble


sgactual=reshape(perm,nx*ny*nz,N);


Sim11=reshape(overallsim,19,history,N);

for i=1:history
 fprintf('Now assimilating timestep %d .\n', i);

 
Sim1=Sim11(:,i,:);
Sim1=reshape(Sim1,19,N);

f=observation(:,i);
[DupdateK] = ESMDA_Autoencoder (sgactual,f, N, Sim1,alpha);
%[DupdateK,Saturation,Pressure,SaturationG,RSG] = Assimilate2 (sgactual,f, N, Sim1,alpha,tol,indices,Saturation,Pressure,SaturationG,RSG);
sgactual=DupdateK;

 fprintf('Finished assimilating timestep %d \n', i);
end
z=sgactual;

 disp('  program executed  ');
end
 