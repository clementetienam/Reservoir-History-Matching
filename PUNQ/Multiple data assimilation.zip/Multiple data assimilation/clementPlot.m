%%This code is to plot all the ensemble permeability field data at once

function [bestnorm3,PlogK]=clementPlot(nx,ny,nz, iProd, jProd,mumyperm,rossmary,N,bestnorm33,effective);
disp( 'PhD Student: Clement Etienam' )
disp( 'Supervisor: Dr Rossmary Villegas' )
disp( 'Co-supervisor: Dr Masoud Babei' )
disp( 'Co-supervisor: Dr Oliver Dorn' )
disp('  Load the relevant files  ');
% N - size of ensemble

%N=100;


%load sgsim.out; %permeability ensemble


disp(' extract the active grid cells' )
sgsim=reshape(mumyperm,2660,N);



perm=sgsim;




   disp(' get the dissimilarity for permeability reconstruction')
 
%load sgsim.out;


%A=reshape(sgsim,2660,100);

True=log10(rossmary);
True=True.*effective;
%True(True==0)=NaN;


Ause=perm;
A1=log10(Ause);
B = repmat(effective,1,N);
A1=A1.*B;

for i=1:N
    J(:,i)=sqrt(((A1(:,i)-True).^2)./2660);
end
for i=1:N
test(i,:)=sum(abs((J(:,i))));
end
reali=[1:N]';

jj3=min(test);
index3 = test; 
bestnorm3 = find(index3 == min(index3));
	%Pssim = Pnew(:,bestssim); %best due to ssim

fprintf('The best Norm Realization for Log(K) reconstruction  is number %i with value %4.4f \n',bestnorm3,jj3);




 PlogK = reshape(A1(:,3),19,28,5);
 PlogK(PlogK==0)=NaN;

  



Trueperm=reshape(True,19,28,5);
Trueperm(Trueperm==0)=NaN;

yobo1=figure()

h1=subplot(4,5,1);

%surf(X',Y',Trueperm(:,:,1))
imagesc(reshape(Trueperm(:,:,1), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('True Layer 1','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h1,direction,180)
 
 
h2=subplot(4,5,2);
imagesc(reshape(Trueperm(:,:,2), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('True Layer 2','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h2,direction,180)

h3=subplot(4,5,3);
imagesc(reshape(Trueperm(:,:,3), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('True Layer 4','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h3,direction,180)
 
h4=subplot(4,5,4);
imagesc(reshape(Trueperm(:,:,4), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('True Layer 4','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h4,direction,180)

h5=subplot(4,5,5);

imagesc(reshape(Trueperm(:,:,5), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('True Layer 5','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h5,direction,180)
	
	
h6=subplot(4,5,6);
imagesc(reshape(PlogK(:,:,1), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('BestLog(K)-1','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h6,direction,180)

h7=subplot(4,5,7);
imagesc(reshape(PlogK(:,:,2), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('BestLog(K)-2','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h7,direction,180)

h8=subplot(4,5,8);
imagesc(reshape(PlogK(:,:,3), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('BestLog(K)-3','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h8,direction,180)


h9=subplot(4,5,9);
imagesc(reshape(PlogK(:,:,4), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('BestLog(K)-4','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h9,direction,180)

h10=subplot(4,5,10);
imagesc(reshape(PlogK(:,:,5), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('BestLog(K)-5','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h10,direction,180)



disp(' plot the mean of the ensemble')
A1=reshape(A1,2660,N);
A12mean=mean(A1,2);
A12mean=reshape(A12mean,19,28,5);
A12mean(A12mean==0)=NaN;
A1mean=reshape(A1(:,bestnorm33),19,28,5);
A1mean(A1mean==0)=NaN;

h11=subplot(4,5,11);
imagesc(reshape(A1mean(:,:,1), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('Layer 1-prod','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h11,direction,180)

h12=subplot(4,5,12);
imagesc(reshape(A1mean(:,:,2), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('Layer 2-prod','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h12,direction,180)

h13=subplot(4,5,13);
imagesc(reshape(A1mean(:,:,3), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('Layer 3-prod','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h13,direction,180)

h14=subplot(4,5,14);
imagesc(reshape(A1mean(:,:,4), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('Layer 4-prod','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h14,direction,180)

h15=subplot(4,5,15);
imagesc(reshape(A1mean(:,:,5), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('Layer 5-prod','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h15,direction,180)

h16=subplot(4,5,16);

imagesc(reshape(A12mean(:,:,1), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('Layer 1-mean','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h11,direction,180)

h17=subplot(4,5,17);
imagesc(reshape(A12mean(:,:,2), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('Layer 2-mean','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h17,direction,180)

h18=subplot(4,5,18);
imagesc(reshape(A12mean(:,:,3), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('Layer 1-mean','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h18,direction,180)

 h19=subplot(4,5,19);
 imagesc(reshape(A12mean(:,:,4), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('Layer 1-mean','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h19,direction,180)
 
 
  h20=subplot(4,5,20);
 imagesc(reshape(A12mean(:,:,4), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('Layer 5-mean','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h20,direction,180)
 
%hfig = tightfig(yobo1);
saveas(gcf,'analyse2D','fig')
saveas(gcf,'analyse2D','jpg')
saveas(gcf,'analyse2D','epsc')


G2=cartGrid([19 28 5]);

yobo1=figure();
subplot(2,2,1);
plotCellData(G2,reshape(Trueperm,2660,1));
view(3)
axis equal on
title('True','FontName','Helvetica', 'Fontsize', 13);
grid off
shading flat
caxis([1 3])
colormap('jet')
% h = colorbar;
% ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
% set(h, 'ylim', [1 5])
hold on
plot3([10 10],[22 22],[1 -8],'r','Linewidth',2);
text(  10,22,-10,'P1','HorizontalAlignment','left','FontSize',11)
hold on
plot3([9 9],[17 17],[1 -8],'r','Linewidth',2);
text(  9,17, -9,'P4','Fontsize', 11)
hold on
plot3([17 17],[11 11],[1 -8],'r','Linewidth',2);
text(  17,11, -10,'P5','Fontsize', 11)
hold on
plot3([11 11],[24 24],[1 -12],'r','Linewidth',2);
text(11 ,24, -14,'P11','Fontsize', 11)
hold on
plot3([15 15],[12 12],[1 -8],'r','Linewidth',2)
text(  15,12, -14,'P12','Fontsize', 11)
hold on
plot3([17 17],[22 22],[1 -8],'r','Linewidth',2)
text(  17,22, -12,'P4','Fontsize', 11)

set(gcf,'color','white')
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca,'zticklabel',[])


% subplot(2,2,2);
% %redd=slice(A1mean,[1 60],[1 120],[1 5]);
% plotCellData(G2,reshape(A1mean,36000,1));
% view(3)
% axis equal on
% grid off
% shading flat
% caxis([1 5])
% colormap(CMRmap)
% % h = colorbar;
% % ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
% % set(h, 'ylim', [1 5])
% hold on
% plot3([30 30],[55 55],[1 -50],'k','Linewidth',2);
% text(30,55,-40,'I1','Fontsize', 11)
% title('Mean','FontName','Helvetica', 'Fontsize', 16);
% %title('I1','FontName','Helvetica', 'Fontsize', 18);
% hold on
% plot3([58 58],[18 18],[1 -50],'k','Linewidth',2);
% text(58,18 ,-45,'I2','Fontsize', 11)
% hold on
% plot3([90 90],[6 6],[1 -50],'k','Linewidth',2);
% text(90,6 , -45,'I3','Fontsize', 11)
% hold on
% plot3([101 101],[39 39],[1 -50],'k','Linewidth',2);
% text(101 ,39, -25,'I4','Fontsize', 11)
% hold on
% plot3([14 14],[25 25],[1 -50],'r','Linewidth',2);
% % text(x1(i,1),y1(i,1),z1(i,1),['   ' ...
% % num2str(time(i,1))],'HorizontalAlignment','left','FontSize',8);
% text(  14,25,-52,'P1','HorizontalAlignment','left','FontSize',11)
% hold on
% plot3([38 38],[39 39],[1 -50],'r','Linewidth',2);
% text(  38,39, -44,'P2','Fontsize', 11)
% hold on
% plot3([96 96],[23 23],[1 -30],'r','Linewidth',2);
% text(96 ,23, -28,'P3','Fontsize', 11)
% hold on
% plot3([67 67],[41 41],[1 -50],'r','Linewidth',2)
% text(  67,41, -30,'P4','Fontsize', 11)
% %title( 'PERMX 3D')
% %colormap jet
% 
% set(gcf,'color','white')
% set(gcf,'color','white')
% set(gca,'xticklabel',[])
% set(gca,'yticklabel',[])
% set(gca,'zticklabel',[])



subplot(2,2,2);
%redd=slice(PlogK,[1 60],[1 120],[1 5]);
plotCellData(G2,reshape(PlogK,2660,1));
view(3)
axis equal on
title('Best Log','FontName','Helvetica', 'Fontsize', 13);
grid off
shading flat
caxis([1 3])
colormap('jet')
hold on
% h = colorbar;
% ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
% set(h, 'ylim', [1 5])
plot3([10 10],[22 22],[1 -8],'r','Linewidth',2);
text(  10,22,-10,'P1','HorizontalAlignment','left','FontSize',11)
hold on
plot3([9 9],[17 17],[1 -8],'r','Linewidth',2);
text(  9,17, -9,'P4','Fontsize', 11)
hold on
plot3([17 17],[11 11],[1 -8],'r','Linewidth',2);
text(  17,11, -10,'P5','Fontsize', 11)
hold on
plot3([11 11],[24 24],[1 -12],'r','Linewidth',2);
text(11 ,24, -14,'P11','Fontsize', 11)
hold on
plot3([15 15],[12 12],[1 -8],'r','Linewidth',2)
text(  15,12, -14,'P12','Fontsize', 11)
hold on
plot3([17 17],[22 22],[1 -8],'r','Linewidth',2)
text(  17,22, -12,'P4','Fontsize', 11)
%title( 'PERMX 3D')
%colormap jet

set(gcf,'color','white')
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca,'zticklabel',[])

subplot(2,2,3);
%redd=slice(PlogK,[1 60],[1 120],[1 5]);
plotCellData(G2,reshape(A1mean,2660,1));
view(3)
axis equal on
title('Best Production','FontName','Helvetica', 'Fontsize', 13);
grid off
shading flat
caxis([1 3])
colormap('jet')
% h = colorbar;
% ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
% set(h, 'ylim', [1 5])
hold on
plot3([10 10],[22 22],[1 -8],'r','Linewidth',2);
text(  10,22,-10,'P1','HorizontalAlignment','left','FontSize',11)
hold on
plot3([9 9],[17 17],[1 -8],'r','Linewidth',2);
text(  9,17, -9,'P4','Fontsize', 11)
hold on
plot3([17 17],[11 11],[1 -8],'r','Linewidth',2);
text(  17,11, -10,'P5','Fontsize', 11)
hold on
plot3([11 11],[24 24],[1 -12],'r','Linewidth',2);
text(11 ,24, -14,'P11','Fontsize', 11)
hold on
plot3([15 15],[12 12],[1 -8],'r','Linewidth',2)
text(  15,12, -14,'P12','Fontsize', 11)
hold on
plot3([17 17],[22 22],[1 -8],'r','Linewidth',2)
text(  17,22, -12,'P4','Fontsize', 11)
%title( 'PERMX 3D')
%colormap jet

set(gcf,'color','white')
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca,'zticklabel',[])

subplot(2,2,4);
%redd=slice(PlogK,[1 60],[1 120],[1 5]);
plotCellData(G2,reshape(A12mean,2660,1));
view(3)
axis equal on
title('Mean','FontName','Helvetica', 'Fontsize', 13);
grid off
shading flat
caxis([1 3])
colormap('jet')
% h = colorbar;
% ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
% set(h, 'ylim', [1 5])
hold on
plot3([10 10],[22 22],[1 -8],'r','Linewidth',2);
text(  10,22,-10,'P1','HorizontalAlignment','left','FontSize',11)
hold on
plot3([9 9],[17 17],[1 -8],'r','Linewidth',2);
text(  9,17, -9,'P4','Fontsize', 11)
hold on
plot3([17 17],[11 11],[1 -8],'r','Linewidth',2);
text(  17,11, -10,'P5','Fontsize', 11)
hold on
plot3([11 11],[24 24],[1 -12],'r','Linewidth',2);
text(11 ,24, -14,'P11','Fontsize', 11)
hold on
plot3([15 15],[12 12],[1 -8],'r','Linewidth',2)
text(  15,12, -14,'P12','Fontsize', 11)
hold on
plot3([17 17],[22 22],[1 -8],'r','Linewidth',2)
text(  17,22, -12,'P4','Fontsize', 11)
%title( 'PERMX 3D')
%colormap jet

set(gcf,'color','white')
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca,'zticklabel',[])

hfig = tightfig(yobo1);
saveas(gcf,'analyse','eps')
saveas(gcf,'analyse','jpg')
saveas(gcf,'analyse','fig')
close(figure)

file2 = fopen('bestlog.out','w+'); %output the dictionary
for k=1:numel(PlogK)                                                                       
fprintf(file2,' %4.6f \n',PlogK(k) );             
end

% file = fopen('meanK.out','w+');
%  for k=1:numel(A1mean)                                                                       
%  fprintf(file,' %4.6f \n',A1mean(k) );             
%  end
 
 file3 = fopen('bestRMS.out','w+');
 for k=1:numel(A1mean)                                                                       
 fprintf(file3,' %4.6f \n',A1mean(k) );             
 end
end
%run('testvar.m')