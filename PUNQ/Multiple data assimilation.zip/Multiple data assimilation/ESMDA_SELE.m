function [sgsim2,DupdateK,updatedlevelset,updatedlevelsetporo,clement,clementporo] = ESMDA_SELE (sgsparse,sgsparseporo,f, N, Sim1,tol,alpha,clement,clementporo,nbandall,nbandallporo,SWe,Pe);
%%History matching data assimilation technique 
%%PhD Student: Clement Etienam
%%Supervisor: Dr Rossmary Villegas
%%Co-supervisor: Dr Masoud Babei
%DESCRIPTION:
%
% PARAMETERS:
%   f           -   True data
%   sgsim           -  ensemble of simulate states
%   N           -   ensemble size
%   Sim      -   Simulated measurments
%
%-----------------------------------------------------------------------------
disp( 'History matching data assimilation technique using standard ESMDA_SELE for SPE10 Reservoir'  ) 
disp( 'PhD Student: Clement Etienam' )
disp( 'Supervisor: Dr Rossmary Villegas' )
disp( 'Co-supervisor: Dr Masoud Babei' )
disp( 'Advisor: Dr Oliver Dorn' )
disp('  load the files  ');

sgsim1=sgsparse;
% sgz1=log(sgz);

 sgsim11 = reshape(sgsim1,1500,N);
clement=reshape(clement,36000,N);

 sgsim11poro = reshape(sgsparseporo,1500,N);

disp('  generate Gaussian noise for the observed measurments  ');

Error1=ones(17,N);
Error1(1,:)=normrnd(0,481.15,1,N);
Error1(2,:)=normrnd(0,861.3795,1,N);
Error1(3,:)=normrnd(0,784.1,1,N);
Error1(4,:)=normrnd(0,1358.9735,1,N);
Error1(5,:)=normrnd(0,0.085,1,N);
Error1(6,:)=normrnd(0,0.186,1,N);
Error1(7,:)=normrnd(0,0.185,1,N);
Error1(8,:)=normrnd(0,0.164,1,N);
Error1(9,:)= normrnd(0,17.79,1,N);
Error1(10,:)= normrnd(0,16.3,1,N);
Error1(11,:)= normrnd(0,16.7,1,N);
Error1(12,:)= normrnd(0,17.4,1,N);
Error1(13,:)= normrnd(0,51.9,1,N);
Error1(14,:)= normrnd(0,36.9,1,N);
Error1(15,:)= normrnd(0,64.87,1,N);
Error1(16,:)= normrnd(0,76.43,1,N);
Error1(17,:)= normrnd(0,0.062265,1,N);

 Cd2 = (Error1*Error1')./(N-1); % measurement error auto covariance

for i=1:N
     Dj(:,i)=f+Error1(:,i);
	
 end
   
 %simulated measurements
%load Sim.uF; %simulated measurements


%Sim1=reshape(Sim,19,200);
disp('  generate the ensemble state matrix containing parameters and states  ');
overall=zeros(147017,N); %ensemble state


overall(1:36000,1:N)=SWe; %water saturation fields
overall(36001:72000,1:N)=Pe; %pressure fields
overall(72001:73500,1:N)=sgsim11; %sparse permeability
overall(73501:75000,1:N)=sgsim11poro; %sparse porosity
overall(75001:111000,1:N)=clement; %signed distance permeability
overall(111001:147000,1:N)=clementporo; %signed distance porosity
overall(147001:147017,1:N)=Sim1; %simulated data

Y=overall; %State variable,it is important we include simulated measurements in the ensemble state variable


nbandall=reshape(nbandall,36000,N);

nbandI=ones(147017,N); %narrow band matrix
nbandI(75001:111000,1:N)=nbandall; %permeability narrow band
nbandI(111001:147000,1:N)=nbandallporo; %porosity narrow band


M = mean(Sim1,2);
% Mean of the ensemble state
M2=mean(overall,2);
%M=M'
% Get the ensemble states pertubations
for j=1:N
    S(:,j)=Sim1(:,j)-M;
end
for j=1:N
    yprime(:,j)=overall(:,j)-M2;
end


disp('  update the new ensemble  ');
Cyd=(yprime*S')./((N-1));
Cdd=(S*S')./((N-1));

[Usig,Sig,Vsig] = svd(Cdd+(alpha.*Cd2));
xsmall = diag(Sig);
Bsig = cumsum(xsmall);
valuesig=Bsig(end);
valuesig=valuesig*0.9999;
indices = find(cumsum(xsmall) >= valuesig );
toluse=xsmall(indices,:);
tol=toluse(1,:);



disp('  update the new ensemble  ');
Ynew=Y+((Cyd*pinv((Cdd+(alpha.*Cd2)),tol))*(Dj-Sim1)).*nbandI;
disp( 'extract the updated states ')
value1=Ynew(72001:73500,1:N);


DupdateK=value1;

updatedlevelset=Ynew(75001:111000,1:N);
clement=Ynew(75001:111000,1:N);
updatedlevelset(updatedlevelset>0)=1;
updatedlevelset(updatedlevelset<=0)=0;


sgsim2=Ynew(73501:75000,1:N);;

updatedlevelsetporo=Ynew(111001:147000,1:N);
clementporo=Ynew(111001:147000,1:N);
updatedlevelsetporo(updatedlevelsetporo>0)=1;
updatedlevelsetporo(updatedlevelsetporo<=0)=0;

end