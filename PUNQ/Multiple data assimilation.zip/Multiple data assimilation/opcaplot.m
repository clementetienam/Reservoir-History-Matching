clc;
clear all;
% N=100;
 load sgsim.out;
 load rossmary.GRDECL;
 N=100;
sgsim=reshape(sgsim,72000,N);

for i=1:N
sgsimuse=reshape(sgsim(:,i),120,60,10);
sgs=sgsimuse(:,:,3:7);
ex=reshape(sgs,36000,1);
sg(:,i)=ex;
end
nx = 120; % number of gridblocks in "x" direction
ny = 60; % number of gridblocks in "y" direction
iInj = [30, 58, 90, 101]; % 16 wells configuration, injection wells
jInj = [55, 18, 6, 39]; % 16 wells configuration, injection wells
iProd = [14, 38, 96, 67]; % 16 wells configuration, production wells
jProd = [25, 39, 23, 41]; % 16 wells configuration, production wells
%xr=log10(sg(:,2));
nz=5;
CMRmap=[0 0 0;.3 .15 .75;.6 .2 .50;1 .25 .15;.9 .5 0;.9 .9 .5;1 1 1];
% xr=reshape(xr,7200,Nz);
% 
%  figure
% for ii=1:Nz
%  subplot(2,3,ii)
% plotting(xr(:,ii), Nx, Ny, 'Layer', iInj, jInj, iProd, jProd, min(xr(:,ii)), max(xr(:,ii)));
% end
bestnorm3=clementPlot(sgsim,rossmary,N,4,CMRmap);
xr=log10((sg(:,bestnorm3)));
xr=reshape(xr,nx*ny,nz);
plottinglocations(xr, nx, ny,nz, 'Layer', iInj, jInj, iProd, jProd, min(xr), max(xr),CMRmap);