clc;
clear;
close all;
load sgsim.out;
trueperm=reshape(sgsim,2660,200);
sgsim=(reshape(sgsim,2660,200));
hiddenSize = 200;
autoenc = trainAutoencoder(sgsim',hiddenSize,...
        'L2WeightRegularization',0.004,...
        'SparsityRegularization',4,...
        'SparsityProportion',0.15,'MaxEpochs',20020000);
    Z = encode(autoenc,sgsim');
z=Z';    

Y = (decode(autoenc,z'))';
y=(Y);

mseError = mse(trueperm-y);
    