clc;
clear;
clearvars;
close all;

% N - size of ensemble

N=input( ' enter the number of realizations(ensemble size)  ');


 disp('  import the true data  ');
 
 True= importdata('Real.RSM',' ',7);
 True2= importdata('Real.RSM',' ',50);
 True3= importdata('Real.RSM',' ',93);
 True4= importdata('Real.RSM',' ',136);
 
 
 True=True.data;
 True2=True2.data;
 True3=True3.data;
 True4=True4.data;
 
 
  TO1=True(:,3);
 TO2=True(:,4);
 TO3=True(:,5);
 TO4=True(:,6);
 
 
 
 TW1=True2(:,2);
 TW2=True2(:,3);
 TW3=True2(:,4);
 TW4=True2(:,5);
 
  TP1=True3(:,5);
 TP2=True3(:,6);
 TP3=True3(:,7);
 TP4=True3(:,8);
 
 TG1=True3(:,9);
 TG2=True3(:,10);
 TG3=True4(:,2);
 TG4=True4(:,3);
 
 TFOE=True4(:,8);
 
 
 disp(' make the true observation')
 for i=1:36
 obs=zeros(17,1);
 obs(1,:)=TO1(i,:);
 obs(2,:)=TO2(i,:);
 obs(3,:)=TO3(i,:);
 obs(4,:)=TO4(i,:);
 obs(5,:)=TW1(i,:);
 obs(6,:)=TW2(i,:);
 obs(7,:)=TW3(i,:);
 obs(8,:)=TW4(i,:);
 obs(9,:)=TP1(i,:);
 obs(10,:)=TP2(i,:);
 obs(11,:)=TP3(i,:);
 obs(12,:)=TP4(i,:);
 obs(13,:)=TG1(i,:);
 obs(14,:)=TG2(i,:);
 obs(15,:)=TG3(i,:);
 obs(16,:)=TG4(i,:);
 obs(17,:)=TFOE(i,:);
 observation(:,i)=obs;
 end
 
f=observation(:,1);

 disp( ' for uncorrelated noise')
 v=[1443.45 2584.1385 2352.3 4076.9205 0.085 0.186 0.185 0.164 17.79 16.3 16.7 17.4 51.9 36.9 64.87 76.43 0.062265];
Cd2 = diag(v)./sqrt(N-1);
mean1=zeros(1,17);
pertubations = mvnrnd2(mean1,Cd2,N,0);
mij=mean(pertubations);
mij2=cov(pertubations);
%pertubations = mvnrnd(mean,Cd2);
pertubations=pertubations';
zd=mvnrnd2(mean1,eye(17),N,0);
zd=zd';
Truedata = repmat(f,1,100);
     Dj=Truedata+sqrt(6).*(sqrt(Cd2)*zd);

 Error1=ones(17,N);
Error1(1,:)=normrnd(0,481.15,1,N);
Error1(2,:)=normrnd(0,861.3795,1,N);
Error1(3,:)=normrnd(0,784.1,1,N);
Error1(4,:)=normrnd(0,1358.9735,1,N);
Error1(5,:)=normrnd(0,0.085,1,N);
Error1(6,:)=normrnd(0,0.186,1,N);
Error1(7,:)=normrnd(0,0.185,1,N);
Error1(8,:)=normrnd(0,0.164,1,N);
Error1(9,:)= normrnd(0,17.79,1,N);
Error1(10,:)= normrnd(0,16.3,1,N);
Error1(11,:)= normrnd(0,16.7,1,N);
Error1(12,:)= normrnd(0,17.4,1,N);
Error1(13,:)= normrnd(0,51.9,1,N);
Error1(14,:)= normrnd(0,36.9,1,N);
Error1(15,:)= normrnd(0,64.87,1,N);
Error1(16,:)= normrnd(0,76.43,1,N);
Error1(17,:)= normrnd(0,0.062265,1,N);
Error1=Error1./(N-1);
Cd3=(Error1*Error1')./(N-1);
clement=corrcoef(pertubations);
clement2=corrcoef(Error1);

[X,Y]=meshgrid(1:17,1:100);

figure()
subplot(2,2,1)
surf(X',Y',pertubations)
shading flat
axis([1 17 1 100 ])
grid off
title('Error 1','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([-20 20])
h = colorbar;
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(2,2,2)
surf(X',Y',Error1)
shading flat
axis([1 17 1 100 ])
grid off
title('Error 2','FontName','Helvetica', 'Fontsize', 11);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 11);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 11);
caxis([-20 20])
h = colorbar;
set(gca, 'FontName','Helvetica', 'Fontsize', 11)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 %Dj=abs(Dj);