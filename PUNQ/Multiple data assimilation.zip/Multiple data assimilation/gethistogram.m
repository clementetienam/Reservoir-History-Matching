clc;
clear all;
close all;
load rossmary.GRDECL;
Trueperm=reshape(log10(rossmary),120,60,10);
load rossmaryporo.GRDECL;
Trueporo=reshape((rossmaryporo),120,60,10);
clement=zeros(72000,1);
clementporo=zeros(72000,1);
for i=1:72000
    if (rossmary(i)>=100)
        clement(i)=1;
    end
        
end

for i=1:72000
    if (rossmaryporo(i)>=0.1805)
        clementporo(i)=1;
    end
        
end
 [X,Y] = meshgrid(1:120,1:60);
   
a=(rossmary);
a2=a;
b=rossmaryporo;
b2=b;
disp(' Get the channel and non area')
a(a<100)=[];
a2(a2>=100)=[];
b(b<0.1805)=[];
b2(b2>=0.1805)=[];

yobo=mean(a);
yobostd=std(a);
yoboporo=mean(b);
yoboporostd=std(b);

yobosmall=mean(a2);
yobosmallstd=std(a2);
yoboporosmall=mean(b2);
yoboporosmallstd=std(b2);

required=zeros(72000,1);
for i=1:72000
    if (clement(i)==1)
        required(i)=normrnd(891.8315,1803.4);
    else
        required(i)=normrnd(49.9960,10.3141);
    end
end
required=abs(required);
zz=[2 -0.01];
zz2=[1 0.09];
z = filter(1,zz,required);
requiredplot=reshape(log10(abs(required)),120,60,10);

requiredporo=zeros(72000,1);
for i=1:72000
    if (clementporo(i)==1)
        requiredporo(i)=normrnd(0.2612,0.0498);
    else
        requiredporo(i)=normrnd(0.1495,0.0097);
    end
end
requiredporo=abs(requiredporo);
 requiredporo= filter(1,zz2,requiredporo);
requiredplotporo=reshape((abs(requiredporo)),120,60,10);

    
    required=z;

z=reshape(log10(abs(required)),120,60,10);
figure()
subplot(2,5,1);
surf(X',Y',Trueperm(:,:,3))

shading flat
axis([1 120 1 60 ])
grid off
title('True Layer 1','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])

subplot(2,5,2);
surf(X',Y',Trueporo(:,:,3))

shading flat
axis([1 120 1 60 ])
grid off
title('smooth','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
caxis([0.1 0.4])
h = colorbar;
ylabel(h, 'porosity','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [0.1 0.4])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])



subplot(2,5,6);
surf(X',Y',z(:,:,3))

shading flat
axis([1 120 1 60 ])
grid off
title('rough','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
caxis([1 5])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 5])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])


subplot(2,5,7);
surf(X',Y',requiredplotporo(:,:,3))

shading flat
axis([1 120 1 60 ])
grid off
title('rough','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
caxis([0.1 0.4])
h = colorbar;
ylabel(h, 'porosity','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [0.1 0.4])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])