clc;
clear;
load rossmary.GRDECL;
load effective.out;
load sgsim.out;
iProd = [10, 9, 17, 11, 15, 17]; % 16 wells configuration, production wells
jProd = [22, 17, 11, 24, 12 22];
[bestnorm3,PlogK]=clementPlot(19,28,5, iProd, jProd,sgsim,rossmary,200,5,effective);