function [mumyperm,mumyporo,mumypermz,R]=main_OPCA_ESMDA(R,nx,ny,nz,N,tol,observation,overallsim,rossmary,rossmaryporo,rossmaryz2,perm,history,alpha,effective,SWn83,PEn83,SGn83,RSEn83);
disp( 'History matching data assimilation technique using ES-MDA for PUNQ Reservoir'  ) 
disp( 'PhD Student: Clement Etienam' )
disp( 'Supervisor: Dr Rossmary Villegas' )
disp( 'Co-supervisor: Dr Masoud Babei' )
disp( 'Co-supervisor: Dr Oliver Dorn' )
disp('  import the true data  ');
% N - size of ensemble
addpath(genpath('C:\Work\GSLIB\sgsim\PhD Petroleum Engineering\Dulorfsky'))
% SWn83=reshape(SWn83,1764,history,N);
% PEn83=reshape(PEn83,1764,history,N);
% SGn83=reshape(SGn83,1764,history,N);
% RSEn83=reshape(RSEn83,1764,history,N);

sgsim=reshape(perm,nx*ny*nz,N);
X=log(sgsim);
[Nc, Nr] = size(X);
xm = mean(X, 2);
Xc = (X - repmat(xm, 1, Nr));

%  Find eigenvector and eigenvalues using SVD of data matrix
Y = Xc/sqrt(Nr-1); % YY' = C
[U, Sig, V] = svd(Y); % SVD of Y
Sig = diag(Sig);% convert Sigma from an diagonal matrix to a vector for convinience
%reducedDim = 200;
%MU=zeros(reducedDim,200);
%SIGMA=eye(200,200);
%R = mvnrnd(MU,SIGMA);

Sim11=reshape(overallsim,19,history,N);
cle=mean(X,2);
%X=reshape(X,3600000,1);
logkMin  = min(cle); % min average of the training set
logkMax  =   max(cle); % max average of the training set

optGamma =  1; % weight of the regularization term
sg=reshape(X,nx*ny*nz*N,1);
trunc=4.90;

[meansandk,meanshalek,varsand,varshale]=RCUmf(sg,trunc,N,nx,ny,nz);


%History matching using ESMDA
for i=1:history
 fprintf('Now assimilating timestep %d .\n', i);

[SWn83,PEn83,SGn83,RSEn83]=getstatesallenkf(N,i);
 SWn83=reshape(SWn83,1764,N);
PEn83=reshape(PEn83,1764,N);
SGn83=reshape(SGn83,1764,N);
RSEn83=reshape(RSEn83,1764,N);
 
 
Sim1=Sim11(:,i,:);
Sim1=reshape(Sim1,19,N);

Saturation=SWn83;
Saturation=reshape(Saturation,1764,N);
Pressure=PEn83;
Pressure=reshape(Pressure,1764,N);
SaturationG=SGn83;
SaturationG=reshape(SaturationG,1764,N);
RSG=RSEn83;
RSG=reshape(RSG,1764,N);

f=observation(:,i);
DupdateK = ESMDA_PCA (R,f, N, Sim1,alpha,tol,Saturation,Pressure,SaturationG,RSG);

R=DupdateK;

 fprintf('Finished assimilating timestep %d \n', i);
end
disp('recover the full permeability field from OPCA covariance matrix')
for i=1:N
optMu1   =   meanshalek(:,i); % mean of Gaussian distribution within shale facies
optMu2   =    meansandk(:,i); % mean of Gaussian distribution within sand facies
optV1    =  varshale(:,i); % variance of of Gaussian distribution within shale facies
optV2    =  varsand(:,i); % variance of Gaussian distribution within sand facies
 optParaVector = [optGamma, optV1, optV2, optMu1, optMu2];   
xGen = generateOPCARealizationBimodal(U, Sig, 200, R(:,i), xm, optParaVector, logkMin, logkMax);
allrealOPCA(:,i)=reshape(xGen,2660,1);
end


%for i=1:N
 %   reali=U(:, 1:reducedDim) * diag(Sig(1:reducedDim)) * R(:,i) + xm;
 %   DupdateK2(:,i)=reali;
%end
DupdateK2=exp(allrealOPCA);
DupdateK2=abs(DupdateK2);

disp('  recover the porosity and permz field from Logs  ');
for ii=1:N;
    Knew=reshape(DupdateK2(:,ii),nx,ny,nz);
   for j=1:5;
 pore(:,:,1)=0.040228*log(Knew(:,:,1))-0.03101;
pore(:,:,2)=0.022608*log(Knew(:,:,2))+0.0066038;
pore(:,:,3)=0.046974*log(Knew(:,:,3))-0.072764;
pore(:,:,4)=0.025312*log(Knew(:,:,4))+0.01088;
pore(:,:,5)=0.039746*log(Knew(:,:,5))-0.038238;


permz(:,:,1)=0.88227*log(Knew(:,:,1))-0.29112;
permz(:,:,2)=0.89976*log(Knew(:,:,2))-1.1289;
permz(:,:,3)=0.69049*log(Knew(:,:,3))+1.0074;
permz(:,:,4)=0.82778*log(Knew(:,:,4))-0.56077;
permz(:,:,5)=0.97173*log(Knew(:,:,5))-0.74865;

   end
   bigporo=reshape(pore,nx*ny*nz,1);
   bigpermz=reshape(permz,nx*ny*nz,1);
  clementporo(:,ii)=bigporo;
   clementpermz(:,ii)=bigpermz;
end
clementporo(clementporo<0.01024)=0.01024;
clementporo(clementporo>=0.2992)=0.2992;
sgsim2=abs(clementporo);

disp('  output the perm z field from Logs  ');
sgz1=exp(clementpermz);
sgz1(sgz1<=0.1478)=0.1478;
sgz1(sgz1>=498.4011)=498.4011;

sgsim2=sgsim2.*repmat(effective,1,N);
sgz1=sgz1.*repmat(effective,1,N);

[output,outputporo,outputz] = honour2(rossmary, rossmaryporo,rossmaryz2, N,sgz1,sgsim2,DupdateK2);



mumyperm=abs(output);
mumyporo=abs(outputporo);
mumypermz=abs(outputz);

 disp('  program executed  ');
end
 