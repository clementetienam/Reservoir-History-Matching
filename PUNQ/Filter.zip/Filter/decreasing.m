clc;
clear all;
close all;
disp(' this code is to get the decreasing steps for alpha ')
alpha=input( ' enter the alpha value  ');

a=0.1;
b=10;
maxitn=500;
tol=0.0000152;
FA = func(a);
p = (b+a)/2.0;
FP = func(p);
if (FA * FP) < 0
b = p;
else
a = p;
FA = FP;
end;
fprintf('i=%3g a=%-15.10g b=%-15.10g p=%-15.10g F(p)=%-15.10e\n', ...
i,a,b,p,FP)
while ((i<maxitn) & (abs((b-a)/a)>tol) & (FP ~= 0.0))
i=i+1;
p = (b+a)/2.0;
FP = func(p);
if (FA * FP) < 0
b = p;
else
a = p;
FA = FP;
end
fprintf('i=%3g a=%-15.10g b=%-15.10g p=%-15.10g F(p)=%-15.10e\n', ...
i,a,b,p,FP)
end
ans = p;