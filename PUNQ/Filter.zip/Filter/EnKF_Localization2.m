function [DupdateK] = EnKF_Localization2 (sgactual, f, N, Sim1,c,effective,indices,Saturation,Pressure,SaturationG,RSG);
%-----------------------------------------------------------------------------
%disp( 'History matching data assimilation technique using covariance localization with ESMDA for PUNQ Reservoir'  ) 
disp( 'PhD Student: Clement Etienam' )
disp( 'Supervisor: Dr Rossmary Villegas' )
disp( 'Co-supervisor: Dr Masoud Babei' )
disp( 'Advisor: Dr Oliver Dorn' )
disp('  load the files  ');

%Get the localization for all the wells

A=zeros(19,28,5);
for j=1:5
    A(10,22,j)=1;
    A(9,17,j)=1;
    A(17,11,j)=1;
    A(11,24,j)=1;
    A(15,17,j)=1;
    A(17,22,j)=1;
    
    
end
disp( 'calculate the euclidean distance function to the 6 producer wells')
    lf=reshape(A,19,28,5);
   for j=1:5;
     sdf=lf(:,:,j);
  [usdf,IDX] = bwdist(sdf);
  usdf=reshape(usdf,532,1);
  young(:,j)=usdf;
   
   end
   sdfbig=reshape(young,2660,1);
   sdfbig1=abs(sdfbig);
   z=sdfbig1;
   % the value of the range should be computed accurately.
   %c=range(z);
  
  
   c0OIL1=zeros(2660,1);
   disp( 'compute the gaspari-cohn coefficent')
  for i=1:2660;
 if (0<=z(i,:) || z(i,:)<=c)
  c0OIL1(i,:)=-0.25*(z(i,:)/c)^5+0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3-(5.0/3.0)*(z(i,:)/c)^2+1;
elseif z < 2*c
  c0OIL1(i,:)=(1.0/12.0)*(z(i,:)/c)^5-0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3+(5.0/3.0)*(z(i,:)/c)^2-5*(z(i,:)/c)+4-(2.0/3.0)*(c/z(i,:));
 elseif (c<=z(i,:) || z(i,:)<=2*c)
     c0OIL1(i,:)=-5*(z(i,:)/c)+4-0.667*(c/z(i,:));
 else
     c0OIL1(i,:)=0;
 end
  
  end
  
c0OIL1(c0OIL1<0)=0;
  %[c0OIL1] = calc_loccoeffs(c, 'Gaspari_Cohn', z); 

 disp(' get the gaspari cohn for Cyd') 
 
    schur=c0OIL1;
   schuruse =schur(indices); 
  %schur=schur.*effective;
 %indices=find(effective);
  
 
   %schuruse =schur;
    
  Bsch = repmat(schuruse,1,N);
  
  yoboschur=ones(8836,N);
 
  yoboschur(1:1761,:)=Bsch;
  
  
  
sgsim1=log(sgactual);
% sgz1=log(sgz);

 sgsim11 = reshape(sgsim1,1761,N);


disp('  generate Gaussian noise for the observed measurments  ');

stddFOE =    0.1*f(1,:);
	
	stddBHP1 = 0.15*f(2,:);
    stddBHP2 = 0.15*f(3,:);
    stddBHP3 = 0.15*f(4,:);
    stddBHP4 = 0.15*f(5,:);
	stddBHP5 = 0.15*f(6,:);
	stddBHP6 = 0.15*f(7,:);
	
	stddGORP1 = 0.15*f(8,:);
    stddGORP2 = 0.15*f(9,:);
    stddGORP3 = 0.15*f(10,:);
    stddGORP4 = 0.15*f(11,:);
	stddGORP5 = 0.15*f(12,:);
    stddGORP6 = 0.15*f(13,:);
  

    stddWWCT1 = 0.2*f(14,:);
    stddWWCT2 = 0.2*f(15,:);
    stddWWCT3 =0.2*f(16,:);
    stddWWCT4 = 0.2*f(17,:);
	stddWWCT5 = 0.2*f(18,:);
	stddWWCT6 = 0.2*f(19,:);

  
Error1=ones(19,N);
Error1(1,:)=normrnd(0,stddFOE,1,N);
Error1(2,:)=normrnd(0,stddBHP1,1,N);
Error1(3,:)=normrnd(0,stddBHP2,1,N);
Error1(4,:)=normrnd(0,stddBHP3,1,N);
Error1(5,:)=normrnd(0,stddBHP4,1,N);
Error1(6,:)=normrnd(0,stddBHP5,1,N);
Error1(7,:)=normrnd(0,stddBHP6,1,N);
Error1(8,:)= normrnd(0,stddGORP1,1,N);
Error1(9,:)= normrnd(0,stddGORP2,1,N);
Error1(10,:)= normrnd(0,stddGORP3,1,N);
Error1(11,:)= normrnd(0,stddGORP4,1,N);
Error1(12,:)= normrnd(0,stddGORP5,1,N);
Error1(13,:)= normrnd(0,stddGORP6,1,N);
Error1(14,:)=normrnd(0,stddWWCT1,1,N);
Error1(15,:)=normrnd(0,stddWWCT2,1,N);
Error1(16,:)=normrnd(0,stddWWCT3,1,N);
Error1(17,:)=normrnd(0,stddWWCT4,1,N);
Error1(18,:)=normrnd(0,stddWWCT5,1,N);
Error1(19,:)=normrnd(0,stddWWCT6,1,N);

% mijana=[480 862 784 1359 0.085 0.186 0.185 0.164 17.79 16.3 16.7 17.4 51.9 36.9 65 76 0.06]';
% Cd2=diag(mijana)./(N-1);
    
Cd2 = (Error1*Error1')./(N-1);


for i=1:N
     Dj(:,i)=f+Error1(:,i);
     
	
 end

disp('  generate the ensemble state matrix containing parameters and states  ');

overall=zeros(8836,N); 

overall(1:1761,1:N)=sgsim11;
overall(1762:3525,1:N)=Saturation;
overall(3526:5289,1:N)=Pressure;
overall(5290:7053,1:N)=SaturationG;
overall(7054:8817,1:N)=RSG;
overall(8818:8836,1:N)=Sim1;

[m22,n22] = size(Sim1);
Y=overall; %State variable,it is important we include simulated measurements in the ensemble state variable

M = mean(Sim1,2);
% Mean of the ensemble state
M2=mean(overall,2);
%M=M'
% Get the ensemble states pertubations
for j=1:N
    S(:,j)=Sim1(:,j)-M;
end
for j=1:N
    yprime(:,j)=overall(:,j)-M2;
end

H=zeros(19,8836);
H(1:19,8818:8836)=eye(19);
unie=H*yprime;
Sim=H*Y;
unie2=unie+Error1;
[U0,Z0,V0] = svd(unie2,'econ');
joy2=Z0*Z0';

[Usig,Sig,Vsig] = svd(joy2);
xsmall = diag(Sig);
Bsig = cumsum(xsmall);
valuesig=Bsig(end);
valuesig=valuesig*0.9999;
indices = find(cumsum(xsmall) >= valuesig );
toluse=xsmall(indices,:);
tol=toluse(1,:);


X1=pinv(joy2,tol)*U0';
% Residual vector
X2=X1*(Dj-Sim);

X3=U0*X2;

X4=unie'*X3;
%Update the ensemble state
disp('  update the new ensemble  ');
Ynew=Y+yoboschur.*(yprime*X4);


%Ynew=Y+yoboschur.*((Cyd)*pinv((Cdd+(alpha.*Cd2)))*(Dj-Sim1));
%Ynew=Y+yoboschur.*((Cyd*denominator)*(Dj-Sim1));
disp( 'extract the active permeability field ')
value1=Ynew(1:1761,1:N);


DupdateK=exp(value1);

end