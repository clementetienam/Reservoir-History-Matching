function[SWn83,PEn83]=getstatesall(N,history);
%%This code is to obtain the dynamic states for the ensemble for the entire
%%history

%%PhD student: Clement Oku Etienam
%%Supervisor: Dr Rossmary Viellegas
%%Co-supervisor: Dr Masoud Babei
%%Advisor: Dr Oliver Dorn


% N - size of ensemble

disp('Copy necessary files into the ensemble member folder')
for j=1:N
f = 'MASTER';
%folder = strcat(f, num2str('%.5d',j));
folder = strcat(f, sprintf('%.5d',j));
%copyfile('field2Metric.m',folder)
copyfile('Eclipse2Matlab.m',folder)
copyfile('resize.m',folder)
%copyfile('Gassmann.m',folder)
end

oldfolder=cd;
cd(oldfolder) % setting original directory


    for i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',i));
    cd(folder)   
    
    
    parfor j=1:history %desired time steps
        
	ff = 'MASTER0.F';   
    %Pressure data lines
    P1 = importdata(strcat(ff, sprintf('%.4d',j)),' ',9752);	
    %P1 = importdata('MASTER0.F0001',' ',9752);
    P1=P1.data;
	P112=Eclipse2Matlab(P1);
    P112(isnan(P112))=0;
    P11=P112;
    P(:,j)=P11;
	end
	Ppad = resize(P,[1764,history]);
	
    % water Saturation data lines 
	parfor j=1:history
     ff = 'MASTER0.F';    
    SW = importdata(strcat(ff, sprintf('%.4d',j)),' ',10194);
    %SW = importdata('MASTER0.F0001',' ',10194);
    SW=SW.data;
	SW112=Eclipse2Matlab(SW);
    SW112(isnan(SW112))=0;
    SW11=SW112;
    SWW(:,j)=SW11;
	end
	SWpad = resize(SWW,[1764,history]);
    % Gas Saturation data lines 
% 	parfor j=1:history
%       ff = 'MASTER0.F';   
%     SG = importdata(strcat(ff, sprintf('%.4d',j)),' ',10636);
%     SG=SG.data;
%     SG112=Eclipse2Matlab(SG);
%     SG112(isnan(SG112))=0;
%     SG11=SG112;
%     SGG(:,j)=SG11;
% 	end
% 	SGpad = resize(SGG,[1764,history]);
	
    % RS data lines
%     parfor j=1:history
%         ff = 'MASTER0.F'; 
%     RS = importdata(strcat(ff, sprintf('%.4d',j)),' ',11078);	
%     %RS = importdata('MASTER0.F0001',' ',11078);
%     RS=RS.data;
%     RS112=Eclipse2Matlab(RS);
%     RS112(isnan(RS112))=0;
%     RS11=RS112;
%     RGG(:,j)=RS11;
% 	end
% 	RSpad = resize(RGG,[1764,history]);
    
    SWn83(:,:,i)=SWpad;
%     RSEn83(:,:,i)=RSpad;
% 	SGn83(:,:,i)=SGpad;
    PEn83(:,:,i)=Ppad;

    cd(oldfolder);

    end


cd(oldfolder) % returning to original directory
disp( 'programme to get the dynamic states has been executed')
end



