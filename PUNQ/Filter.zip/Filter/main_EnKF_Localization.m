function [mumyperm,mumyporo,mumypermz]=main_EnKF_Localization(nx,ny,nz,N,tol,observation,overallsim,rossmary,rossmaryporo,rossmaryz2,perm,history,iyobo,effective,SWn83,PEn83,SGn83,RSEn83); 
disp( 'History matching data assimilation technique using ES-MDA  with covariance localization for SPE10 Reservoir'  ) 
disp( 'PhD Student: Clement Etienam' )
disp( 'Supervisor: Dr Rossmary Villegas' )
disp( 'Co-supervisor: Dr Masoud Babei' )
disp( 'Co-supervisor: Dr Oliver Dorn' )
disp('  import the true data  ');
% sgsim=reshape(perm,nx*ny*nz,N);
% %sgsim=sgsim.*repmat(effective,1,N);
% % indices=find(sgsim(:,1));
% % for i=1:N
% %     a=sgsim(:,i);
% %  sgactual(:,i)=a(indices);
% % end
SWn83=reshape(SWn83,1764,N);
PEn83=reshape(PEn83,1764,N);
SGn83=reshape(SGn83,1764,N);
RSEn83=reshape(RSEn83,1764,N);

sgsim=reshape(perm,nx*ny*nz,N);
sgsim=sgsim.*repmat(effective,1,N);
indices=find(effective);
for i=1:N
    a=sgsim(:,i);
 sgactual(:,i)=a(indices);
end
Sim11=reshape(overallsim,19,history,N);


%History matching using ESMDA with Localization
 i=iyobo;
 fprintf('Now assimilating timestep %d .\n', i);

Sim1=Sim11(:,i,:);
Sim1=reshape(Sim1,19,N);

Saturation=SWn83;
Saturation=reshape(Saturation,1764,N);
Pressure=PEn83;
Pressure=reshape(Pressure,1764,N);
SaturationG=SGn83;
SaturationG=reshape(SaturationG,1764,N);
RSG=RSEn83;
RSG=reshape(RSG,1764,N);

f=observation(:,i);
[DupdateK] = EnKF_Localization2 (sgactual, f, N, Sim1,3,effective,indices,Saturation,Pressure,SaturationG,RSG);




 fprintf('Finished assimilating timestep %d \n', i);


disp('recover the full permeability field')

DupdateK2=ones(2660,N);
bb=ones(2660,1);
for ii=1:N
    
    aperm=DupdateK(:,ii);
   bb(indices)=aperm;
 DupdateK2(:,ii)=bb;

end



DupdateK2(DupdateK2<=0.5073)=0.5073;
DupdateK2(DupdateK2>=999.1116)=999.1116;


disp('  recover the porosity and permz field from Logs  ');
for ii=1:N;
    Knew=reshape(DupdateK2(:,ii),nx,ny,nz);
   for j=1:5;
 pore(:,:,1)=0.040228*log(Knew(:,:,1))-0.03101;
pore(:,:,2)=0.022608*log(Knew(:,:,2))+0.0066038;
pore(:,:,3)=0.046974*log(Knew(:,:,3))-0.072764;
pore(:,:,4)=0.025312*log(Knew(:,:,4))+0.01088;
pore(:,:,5)=0.039746*log(Knew(:,:,5))-0.038238;


permz(:,:,1)=0.88227*log(Knew(:,:,1))-0.29112;
permz(:,:,2)=0.89976*log(Knew(:,:,2))-1.1289;
permz(:,:,3)=0.69049*log(Knew(:,:,3))+1.0074;
permz(:,:,4)=0.82778*log(Knew(:,:,4))-0.56077;
permz(:,:,5)=0.97173*log(Knew(:,:,5))-0.74865;

   end
   bigporo=reshape(pore,nx*ny*nz,1);
   bigpermz=reshape(permz,nx*ny*nz,1);
  clementporo(:,ii)=bigporo;
   clementpermz(:,ii)=bigpermz;
end
clementporo(clementporo<0.01024)=0.01024;
clementporo(clementporo>=0.2992)=0.2992;
sgsim2=clementporo;

disp('  output the perm z field from Logs  ');
sgz1=exp(clementpermz);
sgz1(sgz1<=0.1478)=0.1478;
sgz1(sgz1>=498.4011)=498.4011;

 sgsim2=sgsim2.*repmat(effective,1,N);
 sgz1=sgz1.*repmat(effective,1,N);
DupdateK2=DupdateK2.*repmat(effective,1,N);
[output,outputporo,outputz] = honour2(rossmary, rossmaryporo,rossmaryz2, N,sgz1,sgsim2,DupdateK2);



mumyperm=output;
mumyporo=outputporo;
mumypermz=outputz;

 disp('  program executed  ');
end
%end
 %plot the mean and variance for each timestep
 %run('plot3D.m')
 
 