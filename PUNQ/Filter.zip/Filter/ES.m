function [sgsim2,DupdateK,updatedlevelset,updatedlevelsetporo,clement,clementporo] = ES(sg,sgporo,f, N,Sim1,clement,clementporo,nbandall,nbandallporo,tol,Pe,SWe);
%-----------------------------------------------------------------------------
disp( 'History matching data assimilation technique using ES for SPE 10 Reservoir'  ) 
disp( 'PhD Student: Clement Etienam' )
disp( 'Supervisor: Dr Rossmary Villegas' )
disp( 'Co-supervisor: Dr Masoud Babei' )
disp( 'Advisor: Dr Oliver Dorn' )
disp('  load the files  ');

sgsim1=log(sg);
% sgz1=log(sgz);
clement=reshape(clement,36000,N);
clementporo=reshape(clementporo,36000,N);
 sgsim11 = reshape(sgsim1,36000,N);
 sgsim11poro = reshape(sgporo,36000,N);

disp('  generate Gaussian noise for the observed measurments  ');


Error1=ones(17,N);
Error1(1,:)=normrnd(0,481.15,1,N);
Error1(2,:)=normrnd(0,861.3795,1,N);
Error1(3,:)=normrnd(0,784.1,1,N);
Error1(4,:)=normrnd(0,1358.9735,1,N);
Error1(5,:)=normrnd(0,0.085,1,N);
Error1(6,:)=normrnd(0,0.186,1,N);
Error1(7,:)=normrnd(0,0.185,1,N);
Error1(8,:)=normrnd(0,0.164,1,N);
Error1(9,:)= normrnd(0,17.79,1,N);
Error1(10,:)= normrnd(0,16.3,1,N);
Error1(11,:)= normrnd(0,16.7,1,N);
Error1(12,:)= normrnd(0,17.4,1,N);
Error1(13,:)= normrnd(0,51.9,1,N);
Error1(14,:)= normrnd(0,36.9,1,N);
Error1(15,:)= normrnd(0,64.87,1,N);
Error1(16,:)= normrnd(0,76.43,1,N);
Error1(17,:)= normrnd(0,0.062265,1,N);

 Cd2 = (Error1*Error1')./(N-1);

for i=1:N
     Dj(:,i)=f+Error1(:,i);
	
 end
   
 %simulated measurements
%load Sim.uF; %simulated measurements


%Sim1=reshape(Sim,19,200);
disp('  generate the ensemble state matrix containing parameters and states  ');
overall=zeros(216017,N); %ensemble state for EnKF

overall(1:36000,1:N)=SWe;
overall(36001:72000,1:N)=Pe;
overall(72001:108000,1:N)=sgsim11;
overall(108001:144000,1:N)=sgsim11poro;
overall(144001:180000,1:N)=clement;
overall(180001:216000,1:N)=clementporo;
overall(216001:216017,1:N)=Sim1;

Y=overall; %State variable,it is important we include simulated measurements in the ensemble state variable


nbandall=reshape(nbandall,36000,N);
nbandallporo=reshape(nbandallporo,36000,N);

nbandI=ones(216017,N); %narrow band matrix
nbandI(144001:180000,1:N)=nbandall;
nbandI(180001:216000,1:N)=nbandallporo;

M = mean(Sim1,2);
% Mean of the ensemble state
M2=mean(overall,2);
%M=M'
% Get the ensemble states pertubations
for j=1:N
    S(:,j)=Sim1(:,j)-M;
end
for j=1:N
    yprime(:,j)=overall(:,j)-M2;
end


disp('  update the stochastic gradient  ');
Cyd=(yprime*S')./((N-1));
Cdd=(S*S')./((N-1));


% Get the tolerance range for the pseduo inversion
[Usig,Sig,Vsig] = svd(Cdd+(alpha.*Cd2));
xsmall = diag(Sig);
Bsig = cumsum(xsmall);
valuesig=Bsig(end);
valuesig=valuesig*0.9999;
indices = find(cumsum(xsmall) >= valuesig );
toluse=xsmall(indices,:);
tol=toluse(1,:);
%tol=0.01;

disp('  update the new ensemble  ');
Ynew=Y+(Cyd*pinv((Cdd+(Cd2)),tol))*(Dj-Sim1);
disp( 'extract the updated states ')
value1=Ynew(72001:108000,1:N);


DupdateK=exp(value1);
sgsim2=Ynew(108001:144000,1:N);


updatedlevelset=Ynew(144001:180000,1:N);
clement=Ynew(144001:180000,1:N);
updatedlevelset(updatedlevelset>0)=1;
updatedlevelset(updatedlevelset<=0)=0;


updatedlevelsetporo=Ynew(180001:216000,1:N);
clementporo=Ynew(180001:216000,1:N);
updatedlevelsetporo(updatedlevelsetporo>0)=1;
updatedlevelsetporo(updatedlevelsetporo<=0)=0;
end