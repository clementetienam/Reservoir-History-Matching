clc
clear all

%load julian.out;
%load conductivity37.out;
%load condsmooth.out;
%load conductivity28942.out
load cond28new.out
%a=julian;
%s=0.000000006;
%a=conductivity37;
S = 0.0000003;
%a=condsmooth;
a=cond28new;
D=reshape(a,28,9,42);
[X,Y] = meshgrid(1:28,1:9);


figure
surf(X',Y',D(:,:,1))
shading flat
axis([0 28 0 9 ])
title('Noisy data','FontName','Helvetica', 'Fontsize', 18);
xlabel('distance', 'FontName','Helvetica', 'Fontsize', 18);
%ylabel('m', 'FontName','Helvetica', 'Fontsize', 18);
%ylabel('y', 'Fontsize', 18);
grid off
h = colorbar;
% ylabel = get(h,'YTickLabel');
%  mD = repmat(' Siemens/m',size(ylabel,1),1);
%  ylabel = [ylabel mD];
% set(h,'YTickLabel',ylabel)
set(gca, 'FontName','Helvetica', 'Fontsize', 18)
set(gcf,'color','white')

%z=smoothn(D,'robust');
z=smoothn(D);

figure(2)
surf(X',Y',z(:,:,1))
shading flat
axis([0 28 0 9 ])
title('smooth data','FontName','Helvetica', 'Fontsize', 18);
xlabel('distance', 'FontName','Helvetica', 'Fontsize', 18);
%ylabel('m', 'FontName','Helvetica', 'Fontsize', 18);
%ylabel('y', 'Fontsize', 18);
grid off
h = colorbar;
% ylabel = get(h,'YTickLabel');
%  mD = repmat(' Siemens/m',size(ylabel,1),1);
%  ylabel = [ylabel mD];
% set(h,'YTickLabel',ylabel)
set(gca, 'FontName','Helvetica', 'Fontsize', 18)
set(gcf,'color','white')

% %z=abs(z);
% if z<=40
%     z==40;
% end
file = fopen('cond28new.out','w+'); 
for k=1:numel(z)                                                                       
fprintf(file,' %4.4f \n',z(k) );             
end