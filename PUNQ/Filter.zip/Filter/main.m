%----------------------------------------------------------------------------------
% History matching using serveral methods with EnKF 
% Running Ensembles
% the code couples ECLIPSE reservoir simulator with MATLAB used to implement my ideas on history matching of
% The PUNQ Reservoir. 
% Author: Clement Etienam ,PhD Petroleum Engineering 2015-2018
% Supervisor:Dr Rossmary Villegas
% Co-Supervisor: Dr Masoud Babei
% Co-Supervisor: Dr Oliver Dorn
%-----------------------------------------------------------------------------------
%% 

clc
clear
disp('choose from the methods listed below for history matching with ESMDA')
disp('1-main_EnKF')
disp('2-main_EnKF_Localization-covariance localization')
disp('3- main_DCT( discrete cosine transform method coupled with ESMDA)')
disp('4-main_sparsity(compressed sensing) with ESMDA')
disp('5-main_PCA-EnKF')
disp('6-main_OPCA-EnKF')
disp('7-main_EnKF_Localization-covariance localization with Bootstrap resampling')


method=input(' Enter the  required data assimilation scheme method  ');

% N - size of ensemble

N=input( ' enter the number of realizations(ensemble size)  '); %200
nx=input( ' enter the number of grid blocks in x direction  '); %19
ny=input( ' enter the number of grid blocks in y direction  '); %28
nz=input( ' enter the number of grid blocks in z direction  '); % 5
tol=input( ' enter the tolerance for pseudo inversion  ');
%alpha=input( ' enter the alpha value  '); %4-8
% alpha is the number of iteration and damping coefficient
history=input(' enter the number of timestep for the history period '); %81
disp('1=yes')
disp('2=no' )
response=input('Do you want to plot the permeability map ');
disp( 'Load the true permeability and porosity')
load rossmary.GRDECL; %true permeability field
load rossmaryporo.GRDECL; %True porosity field
load rossmaryz2.GRDECL; %True vertical permeability field
load effective.out;
oldfolder=cd;
cd(oldfolder) % setting original directory
disp('  import the true observation data  ');
 
  True= importdata('Real.RSM',' ',7);
 True2= importdata('Real.RSM',' ',95);
 True3= importdata('Real.RSM',' ',183);
 
 
 True=True.data;
 True2=True2.data;
 True3=True3.data;
 
 
  TP1=True(:,4);
 TP2=True(:,5);
 TP3=True(:,6);
 TP4=True(:,7);
  TP5=True(:,8);
   TP6=True(:,9);
 
 
 TG1=True(:,10);
 TG2=True2(:,2);
 TG3=True2(:,3);
 TG4=True2(:,4);
 TG5=True2(:,5);
  TG6=True2(:,6);
 
 
 
 
  TW1=True2(:,7);
 TW2=True2(:,8);
 TW3=True2(:,9);
 TW4=True2(:,10);
  TW5=True3(:,2);
   TW6=True3(:,3);
 
 
 

 TFOE=True(:,3);
 disp(' make the true observation')
 for ihistory=1:history
 obs=zeros(19,1);
 obs(1,:)=TFOE(ihistory,:);
 obs(2,:)=TP1(ihistory,:);
 obs(3,:)=TP2(ihistory,:);
 obs(4,:)=TP3(ihistory,:);
 obs(5,:)=TP4(ihistory,:);
 obs(6,:)=TP5(ihistory,:);
 obs(7,:)=TP6(ihistory,:);
 obs(8,:)=TG1(ihistory,:);
 obs(9,:)=TG2(ihistory,:);
 obs(10,:)=TG3(ihistory,:);
 obs(11,:)=TG4(ihistory,:);
 obs(12,:)=TG5(ihistory,:);
 obs(13,:)=TG6(ihistory,:);
 obs(14,:)=TW1(ihistory,:);
 obs(15,:)=TW2(ihistory,:);
 obs(16,:)=TW3(ihistory,:);
 obs(17,:)=TW4(ihistory,:);
 obs(18,:)=TW5(ihistory,:);
 obs(19,:)=TW6(ihistory,:);
 observation(:,ihistory)=obs;
 end
 

oldfolder=cd;

%% Creating Folders
disp( 'create the folders')
for j=1:N
f = 'MASTER';
folder = strcat(f, sprintf('%.5d',j));
mkdir(folder);
end

%% Coppying simulation files
disp( 'copy simulation files for the forward problem')
for j=1:N
f = 'MASTER';
folder = strcat(f, sprintf('%.5d',j));
copyfile('MASTER0_GGO.INC',folder)
copyfile('MASTER0_GHDR.INC',folder)
copyfile('MASTER0_GOPP.INC',folder)
copyfile('MASTER0_GOTH.INC',folder)
copyfile('MASTER0_GPRO.INC',folder)
copyfile('MASTER0_INIT.INC',folder)
copyfile('MASTER0_PVT.INC',folder)
copyfile('MASTER0_REG.INC',folder)
copyfile('MASTER0_SCAL.INC',folder)
copyfile('MASTER0_SCH.INC',folder)
copyfile('MASTER0_SUM.INC',folder)
copyfile('MASTER0.DATA',folder)
end
%% Machine Learning part
disp( 'Loading the overcomplete dictionary of permeability')
load Yes2PUNQ.out; %Permeability dictionary


%% The big history matching iterative loop will start here
tic;
for inelly=1:history
fprintf('Now running the code for iteration %d .\n', inelly);   
%% Loading Porosity and Permeability ensemble files
disp(' load the permeability and porosity fields')
if inelly==1
    disp( 'permeability loaded from initial ensemble')
load sgsimporo.out; %initial porosity
load sgsim.out; %initial permeabiity
load sgz.out;

perm=reshape(sgsim,2660,N);
poro=reshape(sgsimporo,2660,N);
permz=reshape(sgz,2660,N);

if method== 5||6
reducedDim = N;
MU=zeros(reducedDim,N);
SIGMA=eye(N,N);
Rens = mvnrnd(MU,SIGMA);
end
else
 disp( 'permeability loaded from UPDATED ensemble')
 perm=reshape(mumyperm,2660,N);
 poro=reshape(mumyporo,2660,N);
 permz=reshape(mumypermz,2660,N);
end
cd(oldfolder) % setting original directory

%% Saving POROVANCOUVER and KVANCOUVER

for i=1:N %list of folders 
    
    f = 'MASTER';
   folder = strcat(f, sprintf('%.5d',i));
   
    cd(folder) % changing directory 
    
    PORO2=poro(:,i);
    PERMX2=perm(:,i);
    PERMX2Z=permz(:,i);
    
    save('PERMX2.GRDECL','PERMX2','-ascii');
    save('PERMZ2.GRDECL','PERMX2Z','-ascii');
    save('PORO2.GRDECL','PORO2','-ascii');
    
    cd(oldfolder) % returning to original cd
    
end

%% Inserting KEYWORDS PORO and PERMY 

parfor i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',i));
    cd(folder)

CStr = regexp(fileread('PERMX2.GRDECL'), char(10), 'split');
CStr2 = strrep(CStr, 'toReplace', 'Replacement');
CStr2 = cat(2, {'PERMX'}, CStr2(1:end));
CStr2 = cat(2, CStr2(1:end), {'/'});
FID = fopen('PERMX2.GRDECL', 'w');
if FID < 0, error('Cannot open file'); end
fprintf(FID, '%s\n', CStr2{:});
fclose(FID);

CStr = regexp(fileread('PERMZ2.GRDECL'), char(10), 'split');
CStr2 = strrep(CStr, 'toReplace', 'Replacement');
CStr2 = cat(2, {'PERMZ'}, CStr2(1:end));
CStr2 = cat(2, CStr2(1:end), {'/'});
FID = fopen('PERMZ2.GRDECL', 'w');
if FID < 0, error('Cannot open file'); end
fprintf(FID, '%s\n', CStr2{:});
fclose(FID);


CStr = regexp(fileread('PORO2.GRDECL'), char(10), 'split');
CStr2 = strrep(CStr, 'toReplace', 'Replacement');
CStr2 = cat(2, {'PORO'}, CStr2(1:end));
CStr2 = cat(2, CStr2(1:end), {'/'});
FID = fopen('PORO2.GRDECL', 'w');
if FID < 0, error('Cannot open file'); end
fprintf(FID, '%s\n', CStr2{:});
fclose(FID);

cd(oldfolder) % setting original directory

end


%% Running Simulations
disp( 'Solve the Non-Linear fluid flow Forward Problem' )
cd(oldfolder) % setting original directory

parfor i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',i));
    cd(folder)   

    fid = fopen('MASTER0.bat', 'w');
    fprintf(fid,'@ECHO OFF\n');
    % fprintf(fid,'SET SLBSLS_LICENSE_FILE=27008@eclipse.cc.ic.ac.uk\n');
    fprintf(fid,'SET SLBSLS_LICENSE_FILE=27000@10.99.15.78\n');
    fprintf(fid,'@ECHO OFF\n');
    fprintf(fid,['c:\\ecl\\macros\\$eclipse ', 'MASTER0'],'\n');
    fclose(fid);
    %while ~exist('HM.F0016','file')
        system('MASTER0.bat')
    %end

    cd(oldfolder) % setting original directory
    
end


disp(' plot production profile for the run')
N=200;



oldfolder=cd;
cd(oldfolder) % setting original directory
 %% Plot the Production profile of ensemble
disp('  start the plotting  ');

    for i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',i));
    %folder=oldfolder;
    %cd 'C:\Work\GSLIB\sgsim\EnKFMATLABRun'   
    cd(folder);
   
        
  
    
    %Saturation data lines [2939-5206]
    A1 = importdata('MASTER0.RSM',' ',7);
    A2 = importdata('MASTER0.RSM',' ',95);
    A3 = importdata('MASTER0.RSM',' ',183);
	
    
    A1=A1.data;
    A2=A2.data;
    A3=A3.data;
	
    %SO1983=ones(2268,4)-SW1983;
    
    %save('P1983.out','P1983','-ascii');
    %save('SW1983.out','SW1983','-ascii');
    
    FOE=A1(:,3);
     
	 WBHP1=A1(:,4);
     WBHP2=A1(:,5);
     WBHP3=A1(:,6);
     WBHP4=A1(:,7);
	 WBHP5=A1(:,8);
	 WBHP6=A1(:,9);
	 
     Time=A1(:,1);
	 
	 GORP1=A1(:,10);
     GORP2=A2(:,2);
     GORP3=A2(:,3);
     GORP4=A2(:,4);
	 GORP5=A2(:,5);
	 GORP6=A2(:,6);
	 
	 
     
     WWCT1=A2(:,7);
     WWCT2=A2(:,8);
     WWCT3=A2(:,9);
     WWCT4=A2(:,10);
	 WWCT5=A3(:,2);
	 WWCT6=A3(:,3);
     
  
    %Saturation
    
    WBHPA(:,i)=WBHP1;
    WBHPB(:,i)=WBHP2;
    WBHPC(:,i)=WBHP3;
    WBHPD(:,i)=WBHP4;
	WBHPE(:,i)=WBHP5;
	WBHPF(:,i)=WBHP6;
    
	GORA(:,i)=GORP1;
    GORB(:,i)=GORP2;
    GORC(:,i)=GORP3;
    GORD(:,i)=GORP4;
	GORE(:,i)=GORP5;
	GORF(:,i)=GORP6;
	
    WCTA(:,i)=WWCT1;
    WCTB(:,i)=WWCT2;
    WCTC(:,i)=WWCT3;
    WCTD(:,i)=WWCT4;
    WCTE(:,i)=WWCT5;
	WCTF(:,i)=WWCT6;
    
	
	
	
	FOEA(:,i)=FOE;
	
    
    cd(oldfolder);
    end
   cd(oldfolder) % returning to original directory
 %Import true data
 True= importdata('Real.RSM',' ',7);
 True2= importdata('Real.RSM',' ',95);
 True3= importdata('Real.RSM',' ',183);
 
 
 True=True.data;
 True2=True2.data;
 True3=True3.data;
 
 
  TP1=True(:,4);
 TP2=True(:,5);
 TP3=True(:,6);
 TP4=True(:,7);
  TP5=True(:,8);
   TP6=True(:,9);
 
 
 TG1=True(:,10);
 TG2=True2(:,2);
 TG3=True2(:,3);
 TG4=True2(:,4);
 TG5=True2(:,5);
  TG6=True2(:,6);
 
 
 
 
  TW1=True2(:,7);
 TW2=True2(:,8);
 TW3=True2(:,9);
 TW4=True2(:,10);
  TW5=True3(:,2);
   TW6=True3(:,3);
 
 
 
 
 
 TFOE=True(:,3);
 
 
 grey = [0.4,0.4,0.4]; 
 linecolor1 = colordg(4);
 
 
%% Plot for Well Bottom Hole Pressure
 figure()
 plot(Time,WBHPA(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('WBHP(BARSA)','FontName','Helvetica', 'Fontsize', 13);
 ylim([100 300])
title('PRO-1-WBHP','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TP1,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [100 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,sprintf('PRO-1-WBHP_iter%d.fig',inelly))
close(figure)

 figure()
 plot(Time,WBHPB(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('WBHP(BARSA)','FontName','Helvetica', 'Fontsize', 13);
 ylim([100 300])
title('PRO-4-WBHP','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TP2,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [100 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,sprintf('PRO-4-WBHP_iter%d.fig',inelly))
close(figure)

 figure()
 plot(Time,WBHPC(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('WBHP(BARSA)','FontName','Helvetica', 'Fontsize', 13);
ylim([100 300])
title('PRO-5-WBHP','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TP3,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [100 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,sprintf('PRO-5-WBHP_iter%d.fig',inelly))
close(figure)


 figure()
 plot(Time,WBHPD(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('WBHP(BARSA)','FontName','Helvetica', 'Fontsize', 13);
ylim([100 300])
title('PRO-11-WBHP','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TP4,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [100 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,sprintf('PRO-11-WBHP_iter%d.fig',inelly))
close(figure)

figure()
 plot(Time,WBHPE(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('WBHP(BARSA)','FontName','Helvetica', 'Fontsize', 13);
ylim([100 300])
title('PRO-12-WBHP','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TP5,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [100 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,sprintf('PRO-12-WBHP_iter%d.fig',inelly))
close(figure)

 figure()
 plot(Time,WBHPF(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('WBHP(BARSA)','FontName','Helvetica', 'Fontsize', 13);
ylim([100 300])
title('PRO-15-WBHP','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TP6,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [100 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,sprintf('PRO-15-WBHP_iter%d.fig',inelly))
close(figure)

%% Plot for GOR
figure()
 plot(Time,GORA(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Gas oil ratio(Sm^{3}/Sm^{3})','FontName','Helvetica', 'Fontsize', 13);
title('PRO-1-GOR','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TG1,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [50  300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,sprintf('PRO-1-GOR_iter%d.fig',inelly))
close(figure)

figure()
   plot(Time,GORB(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Gas oil ratio(Sm^{3}/Sm^{3})','FontName','Helvetica', 'Fontsize', 13);
title('PRO-4-GOR','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TG2,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [50 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,sprintf('PRO-4-GOR_iter%d.fig',inelly))
close(figure)

figure()
   plot(Time,GORC(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Gas oil ratio(Sm^{3}/Sm^{3})','FontName','Helvetica', 'Fontsize', 13);
title('PRO-5-GOR','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TG3,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [50 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,sprintf('PRO-5-GOR_iter%d.fig',inelly))
close(figure)


 figure()
   plot(Time,GORD(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Gas oil ratio(Sm^{3}/Sm^{3})','FontName','Helvetica', 'Fontsize', 13);
title('PRO-11-GOR','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TG4,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [50 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,sprintf('PRO-11-GOR_iter%d.fig',inelly))
close(figure)

figure()
   plot(Time,GORE(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Gas oil ratio(Sm^{3}/Sm^{3})','FontName','Helvetica', 'Fontsize', 13);
title('PRO-12','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TG5,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [50 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,sprintf('PRO-12-GOR_iter%d.fig',inelly))
close(figure)

figure()
   plot(Time,GORF(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Gas oil ratio(Sm^{3}/Sm^{3})','FontName','Helvetica', 'Fontsize', 13);
title('PRO-15-GOR','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TG6,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [50 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,sprintf('PRO-15-GOR_iter%d.fig',inelly))
close(figure)

%% Plot for water cut
figure()

 plot(Time,WCTA(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Water cut','FontName','Helvetica', 'Fontsize', 13);
title('PRO-1-WCT','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TW1,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,sprintf('PRO-1-WCT_iter%d.fig',inelly))
close(figure)

figure()
  plot(Time,WCTB(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Water cut','FontName','Helvetica', 'Fontsize', 13);
title('PRO-4-WCT','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TW2,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,sprintf('PRO-4-WCT_iter%d.fig',inelly))
close(figure)

figure()
  plot(Time,WCTC(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Water cut','FontName','Helvetica', 'Fontsize', 13);
title('PRO-5-WCT','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TW3,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,sprintf('PRO-5-WCT_iter%d.fig',inelly))
close(figure)

figure()
  plot(Time,WCTD(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Water cut','FontName','Helvetica', 'Fontsize', 13);
title('PRO-11-WCT','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TW4,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,sprintf('PRO-11-WCT_iter%d.fig',inelly))
close(figure)

figure()
plot(Time,WCTE(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Water cut','FontName','Helvetica', 'Fontsize', 13);
title('PRO-12-WCT','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TW5,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,sprintf('PRO-12-WCT_iter%d.fig',inelly))
close(figure)

figure()
  plot(Time,WCTF(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Water cut','FontName','Helvetica', 'Fontsize', 13);
title('PRO-15-WCT','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TW6,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,sprintf('PRO-15-WCT_iter%d.fig',inelly))
close(figure)




%% Plot for field oil recovery ratio
 figure()
 plot(Time,FOEA(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Oil recovery ratio','FontName','Helvetica', 'Fontsize', 13);
title('Field oil recovery ratio','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TFOE,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,sprintf('FOE_iter%d.fig',inelly))
close(figure)


for i=1:N

    EBHP1(i,:)=immse(WBHPA(:,i),TP1);
    EBHP2(i,:)=immse(WBHPB(:,i),TP2);
    EBHP3(i,:)=immse(WBHPC(:,i),TP3);
    EBHP4(i,:)=immse(WBHPD(:,i),TP4);
	EBHP5(i,:)=immse(WBHPE(:,i),TP5);
    EBHP6(i,:)=immse(WBHPF(:,i),TP6);
	
	
    EWCT1(i,:)=immse(WCTA(:,i),TW1);
    EWCT2(i,:)=immse(WCTB(:,i),TW2);
    EWCT3(i,:)=immse(WCTC(:,i),TW3);
    EWCT4(i,:)=immse(WCTD(:,i),TW4);
    EWCT5(i,:)=immse(WCTE(:,i),TW5);
    EWCT6(i,:)=immse(WCTF(:,i),TW6);
	
	
	
	EGORP1(i,:)=immse(GORA(:,i),TG1);
    EGORP2(i,:)=immse(GORB(:,i),TG2);
    EGORP3(i,:)=immse(GORC(:,i),TG3);
    EGORP4(i,:)=immse(GORD(:,i),TG4);
	EGORP5(i,:)=immse(GORE(:,i),TG5);
    EGORP6(i,:)=immse(GORF(:,i),TG6);
end
TOTALERROR=ones(200,1);
TOTALERROR=(EWCT1./std(TW1))+(EWCT2./std(TW2))...
    +(EWCT3./std(TW3))+(EWCT4./std(TW4))+(EWCT5./std(TW5))...
	+(EWCT6./std(TW6))+(EBHP1./std(TP1))...
    +(EBHP2./std(TP2))+(EBHP3./std(TP3))+(EBHP4./std(TP4))...
	+(EBHP5./std(TP5))+(EBHP6./std(TP6))+(EGORP1./std(TG1))+(EGORP2./std(TG2))...
	+(EGORP3./std(TG3))+(EGORP4./std(TG4))+(EGORP5./std(TG5))+(EGORP6./std(TG6));
TOTALERROR=TOTALERROR./81;
jj=min(TOTALERROR);
index = TOTALERROR; 
bestnorm = find(index == min(index));
	%Pssim = Pnew(:,bestssim); %best due to ssim
fprintf('The best Norm Realization for production data match is number %i with value %4.6f \n',bestnorm,jj);
% JOYLINE=[1:100]';
% figure()
%bar(JOYLINE,TOTALERROR);

reali=[1:200]';

 figure()
 bar(reali,index,'cyan');
 xlabel('Realizations', 'FontName','Helvetica', 'Fontsize', 13);
 ylabel('RMSE value', 'FontName','Helvetica', 'Fontsize', 13);
 title('Production data Cost function for Realizations','FontName','Helvetica', 'Fontsize', 13)
 set(gcf,'color', 'white');
 hold on
 scatter(reali,index,'black','filled');
  xlim([1,200]);
 xlabel('Realizations', 'FontName','Helvetica', 'Fontsize', 13)
 ylabel('RMSE value', 'FontName','Helvetica', 'Fontsize', 13)
  saveas(gcf,sprintf('RMS_iter%d.fig',inelly))
close(figure)

 disp('  program almost executed  ');


decreasingnorm(:,inelly)=index;
 
 
 disp( 'Get the simulated files for all the time step')
 N=200;


oldfolder=cd;
cd(oldfolder) % setting original directory


overallsim=zeros(19,history,N);
    for ii=1:N %list of folders 
    
      f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',ii));
    cd(folder)   
    
   A1 = importdata('MASTER0.RSM',' ',7);
   A2 = importdata('MASTER0.RSM',' ',95);
   A3 = importdata('MASTER0.RSM',' ',183);
 
 
 
 A1=A1.data;
 A2=A2.data;
 A3=A3.data;
 
 
 FOE=A1(:,3);
     
	 WBHP1=A1(:,4);
     WBHP2=A1(:,5);
     WBHP3=A1(:,6);
     WBHP4=A1(:,7);
	 WBHP5=A1(:,8);
	 WBHP6=A1(:,9);
	 
     Time=A1(:,1);
	 
	 GORP1=A1(:,10);
     GORP2=A2(:,2);
     GORP3=A2(:,3);
     GORP4=A2(:,4);
	 GORP5=A2(:,5);
	 GORP6=A2(:,6);
	 
	 
     
     WWCT1=A2(:,7);
     WWCT2=A2(:,8);
     WWCT3=A2(:,9);
     WWCT4=A2(:,10);
	 WWCT5=A3(:,2);
	 WWCT6=A3(:,3);

 for i=1:history
 obs=zeros(19,1);
 obs(1,:)=FOE(i,:);
 obs(2,:)=WBHP1(i,:);
 obs(3,:)=WBHP2(i,:);
 obs(4,:)=WBHP3(i,:);
 obs(5,:)=WBHP4(i,:);
 obs(6,:)=WBHP5(i,:);
 obs(7,:)=WBHP6(i,:);
 obs(8,:)=GORP1(i,:);
 obs(9,:)=GORP2(i,:);
 obs(10,:)=GORP3(i,:);
 obs(11,:)=GORP4(i,:);
 obs(12,:)=GORP5(i,:);
 obs(13,:)=GORP6(i,:);
 obs(14,:)=WWCT1(i,:);
 obs(15,:)=WWCT2(i,:);
 obs(16,:)=WWCT3(i,:);
 obs(17,:)=WWCT4(i,:);
 obs(18,:)=WWCT5(i,:);
 obs(19,:)=WWCT6(i,:);
 observationsim(:,i)=obs;
 end
        
   overallsim(:,:,ii)=observationsim; 
    cd(oldfolder) % returning to original directory

    end

cd(oldfolder) % returning to original directory
%% Enter the assimilation loop
%% Get the dynamic states
disp('Get the dynamic states at the data assimilation time')
[SWn83,PEn83,SGn83,RSEn83]=getstatesallenkf(N,inelly);
disp('Recovered the dynamic states at the data assimilation time')
disp('now entering the assimilation loop')
  
switch method
    case 1
 disp( 'method 1 specified-standard EnKF')
[mumyperm,mumyporo,mumypermz]=main_EnKF(nx,ny,nz,N,tol,observation,overallsim,rossmary,rossmaryporo,rossmaryz2,perm,history,inelly,effective,SWn83,PEn83,SGn83,RSEn83);
   case 2
   disp( 'method 2 specified-Localization with EnKF')       
[mumyperm,mumyporo,mumypermz]=main_EnKF_Localization(nx,ny,nz,N,tol,observation,overallsim,rossmary,rossmaryporo,rossmaryz2,perm,history,inelly,effective,SWn83,PEn83,SGn83,RSEn83); 
    case 3
 disp( 'method 3 specified-DCT')   
[mumyperm,mumyporo,mumypermz]=main_DCT(nx,ny,nz,N,tol,observation,overallsim,rossmary,rossmaryporo,rossmaryz2,perm,history,inelly,effective,SWn83,PEn83,SGn83,RSEn83);
 
    case 4
     disp( 'method 4 specified-Sparsity')    
[mumyperm,mumyporo,mumypermz]=main_sparsity(nx,ny,nz,N,tol,observation,overallsim,rossmary,rossmaryporo,rossmaryz2,perm,history,inelly,effective,Yes2PUNQ,SWn83,PEn83,SGn83,RSEn83);
      
    case 5
     disp( 'method 5 specified-PCA-EnKF')    
  [mumyperm,mumyporo,mumypermz,Rens]=main_PCA_EnKF(Rens,nx,ny,nz,N,tol,observation,overallsim,rossmary,rossmaryporo,rossmaryz2,perm,history,inelly,effective,SWn83,PEn83,SGn83,RSEn83);  
    case 6
    disp( 'method 6 specified-OPCA-ESMDA')       
 [mumyperm,mumyporo,mumypermz,Rens]=main_OPCA_EnKF(Rens,nx,ny,nz,N,tol,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,inelly,effective,SWn83,PEn83,SGn83,RSEn83);
    case 7 
disp( 'method 7 specified-Localization with ESMDA and bootstrap')       
[mumyperm,mumyporo,mumypermz]=main_EnKF_Localization_Boot(nx,ny,nz,N,tol,observation,overallsim,rossmary,rossmaryporo,rossmaryz2,perm,history,inelly,effective);  
    otherwise
        disp('method not specified correctly')
end

perm=reshape(mumyperm,2660,N);
 poro=reshape(mumyporo,2660,N);
 permz=reshape(mumypermz,2660,N);
fprintf('Finished Iteration %d .\n', inelly);
end
 %% Exit the loop
 %% Now run the code to see the final history matcing step
 disp( 'now run the code after the last Iteration to see how good')
 fprintf('Get the RMS after iteration %d .\n', inelly);   
%% Loading Porosity and Permeability ensemble files
disp(' use the permeability and porosity fields after Last iteration')

%  perm=reshape(mumyperm,72000,N);
%  poro=reshape(mumyporo,72000,N);   

cd(oldfolder) % setting original directory

%% Saving POROVANCOUVER and KVANCOUVER

for i=1:N %list of folders 
    
    f = 'MASTER';
   folder = strcat(f, sprintf('%.5d',i));
   
    cd(folder) % changing directory 
    
    PORO2=poro(:,i);
    PERMX2=perm(:,i);
    PERMX2Z=permz(:,i);
    
    save('PERMX2.GRDECL','PERMX2','-ascii');
    save('PERMZ2.GRDECL','PERMX2Z','-ascii');
    save('PORO2.GRDECL','PORO2','-ascii');
    
    cd(oldfolder) % returning to original cd
    
end

%% Inserting KEYWORDS PORO and PERMY 

parfor i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',i));
    cd(folder)

CStr = regexp(fileread('PERMX2.GRDECL'), char(10), 'split');
CStr2 = strrep(CStr, 'toReplace', 'Replacement');
CStr2 = cat(2, {'PERMX'}, CStr2(1:end));
CStr2 = cat(2, CStr2(1:end), {'/'});
FID = fopen('PERMX2.GRDECL', 'w');
if FID < 0, error('Cannot open file'); end
fprintf(FID, '%s\n', CStr2{:});
fclose(FID);

CStr = regexp(fileread('PERMZ2.GRDECL'), char(10), 'split');
CStr2 = strrep(CStr, 'toReplace', 'Replacement');
CStr2 = cat(2, {'PERMZ'}, CStr2(1:end));
CStr2 = cat(2, CStr2(1:end), {'/'});
FID = fopen('PERMZ2.GRDECL', 'w');
if FID < 0, error('Cannot open file'); end
fprintf(FID, '%s\n', CStr2{:});
fclose(FID);


CStr = regexp(fileread('PORO2.GRDECL'), char(10), 'split');
CStr2 = strrep(CStr, 'toReplace', 'Replacement');
CStr2 = cat(2, {'PORO'}, CStr2(1:end));
CStr2 = cat(2, CStr2(1:end), {'/'});
FID = fopen('PORO2.GRDECL', 'w');
if FID < 0, error('Cannot open file'); end
fprintf(FID, '%s\n', CStr2{:});
fclose(FID);

cd(oldfolder) % setting original directory

end


%% Running Simulations
disp( 'Solve the Non-Linear fluid flow Forward Problem for the History matched ensemble' )
cd(oldfolder) % setting original directory

parfor i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',i));
    cd(folder)   

    fid = fopen('MASTER0.bat', 'w');
    fprintf(fid,'@ECHO OFF\n');
    % fprintf(fid,'SET SLBSLS_LICENSE_FILE=27008@eclipse.cc.ic.ac.uk\n');
    fprintf(fid,'SET SLBSLS_LICENSE_FILE=27000@10.99.15.78\n');
    fprintf(fid,'@ECHO OFF\n');
    fprintf(fid,['c:\\ecl\\macros\\$eclipse ', 'MASTER0'],'\n');
    fclose(fid);
    %while ~exist('HM.F0016','file')
        system('MASTER0.bat')
    %end

    cd(oldfolder) % setting original directory
    
end


disp(' plot production profile for the run')
N=200;



oldfolder=cd;
cd(oldfolder) % setting original directory
 %% Plot the Production profile of ensemble
disp('  start the plotting  ');

    for i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',i));
    %folder=oldfolder;
    %cd 'C:\Work\GSLIB\sgsim\EnKFMATLABRun'   
    cd(folder);
   
        
  
    
    %Saturation data lines [2939-5206]
    A1 = importdata('MASTER0.RSM',' ',7);
    A2 = importdata('MASTER0.RSM',' ',95);
    A3 = importdata('MASTER0.RSM',' ',183);
	
    
    A1=A1.data;
    A2=A2.data;
    A3=A3.data;
	
    %SO1983=ones(2268,4)-SW1983;
    
    %save('P1983.out','P1983','-ascii');
    %save('SW1983.out','SW1983','-ascii');
    
    FOE=A1(:,3);
     
	 WBHP1=A1(:,4);
     WBHP2=A1(:,5);
     WBHP3=A1(:,6);
     WBHP4=A1(:,7);
	 WBHP5=A1(:,8);
	 WBHP6=A1(:,9);
	 
     Time=A1(:,1);
	 
	 GORP1=A1(:,10);
     GORP2=A2(:,2);
     GORP3=A2(:,3);
     GORP4=A2(:,4);
	 GORP5=A2(:,5);
	 GORP6=A2(:,6);
	 
	 
     
     WWCT1=A2(:,7);
     WWCT2=A2(:,8);
     WWCT3=A2(:,9);
     WWCT4=A2(:,10);
	 WWCT5=A3(:,2);
	 WWCT6=A3(:,3);
     
  
    %Saturation
    
    WBHPA(:,i)=WBHP1;
    WBHPB(:,i)=WBHP2;
    WBHPC(:,i)=WBHP3;
    WBHPD(:,i)=WBHP4;
	WBHPE(:,i)=WBHP5;
	WBHPF(:,i)=WBHP6;
    
	GORA(:,i)=GORP1;
    GORB(:,i)=GORP2;
    GORC(:,i)=GORP3;
    GORD(:,i)=GORP4;
	GORE(:,i)=GORP5;
	GORF(:,i)=GORP6;
	
    WCTA(:,i)=WWCT1;
    WCTB(:,i)=WWCT2;
    WCTC(:,i)=WWCT3;
    WCTD(:,i)=WWCT4;
    WCTE(:,i)=WWCT5;
	WCTF(:,i)=WWCT6;
    
	
	
	
	FOEA(:,i)=FOE;
	
    
    cd(oldfolder);
    end
   cd(oldfolder) % returning to original directory
 %Import true data
 True= importdata('Real.RSM',' ',7);
 True2= importdata('Real.RSM',' ',95);
 True3= importdata('Real.RSM',' ',183);
 
 
 True=True.data;
 True2=True2.data;
 True3=True3.data;
 
 
  TP1=True(:,4);
 TP2=True(:,5);
 TP3=True(:,6);
 TP4=True(:,7);
  TP5=True(:,8);
   TP6=True(:,9);
 
 
 TG1=True(:,10);
 TG2=True2(:,2);
 TG3=True2(:,3);
 TG4=True2(:,4);
 TG5=True2(:,5);
  TG6=True2(:,6);
 
 
 
 
  TW1=True2(:,7);
 TW2=True2(:,8);
 TW3=True2(:,9);
 TW4=True2(:,10);
  TW5=True3(:,2);
   TW6=True3(:,3);
 
 
 
 
 
 TFOE=True(:,3);
 
 
 grey = [0.4,0.4,0.4]; 
 linecolor1 = colordg(4);
 
 
%% Plot for Well Bottom Hole Pressure
 figure()
 plot(Time,WBHPA(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('WBHP(BARSA)','FontName','Helvetica', 'Fontsize', 13);
 ylim([100 300])
title('PRO-1-WBHP','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TP1,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [100 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,'PRO-1-WBHP_final','fig')
close(figure)

 figure()
 plot(Time,WBHPB(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('WBHP(BARSA)','FontName','Helvetica', 'Fontsize', 13);
 ylim([100 300])
title('PRO-4-WBHP','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TP2,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [100 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,'PRO-4-WBHP_final','fig')
close(figure)

 figure()
 plot(Time,WBHPC(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('WBHP(BARSA)','FontName','Helvetica', 'Fontsize', 13);
ylim([100 300])
title('PRO-5-WBHP','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TP3,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [100 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
saveas(gcf,'PRO-5-WBHP_final','fig')
close(figure)


 figure()
 plot(Time,WBHPD(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('WBHP(BARSA)','FontName','Helvetica', 'Fontsize', 13);
ylim([100 300])
title('PRO-11-WBHP','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TP4,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [100 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,'PRO-11-WBHP_final','fig')
close(figure)

figure()
 plot(Time,WBHPE(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('WBHP(BARSA)','FontName','Helvetica', 'Fontsize', 13);
ylim([100 300])
title('PRO-12-WBHP','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TP5,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [100 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,'PRO-12-WBHP_final','fig')
close(figure)

 figure()
 plot(Time,WBHPF(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('WBHP(BARSA)','FontName','Helvetica', 'Fontsize', 13);
ylim([100 300])
title('PRO-15-WBHP','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TP6,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [100 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,'PRO-15-WBHP_final','fig')
close(figure)

%% Plot for GOR
figure()
 plot(Time,GORA(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Gas oil ratio(Sm^{3}/Sm^{3})','FontName','Helvetica', 'Fontsize', 13);
title('PRO-1-GOR','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TG1,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [50  300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,'PRO-1-GOR_final','fig')
close(figure)

figure()
   plot(Time,GORB(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Gas oil ratio(Sm^{3}/Sm^{3})','FontName','Helvetica', 'Fontsize', 13);
title('PRO-4-GOR','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TG2,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [50 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,'PRO-4-GOR_final','fig')
close(figure)

figure()
   plot(Time,GORC(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Gas oil ratio(Sm^{3}/Sm^{3})','FontName','Helvetica', 'Fontsize', 13);
title('PRO-5-GOR','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TG3,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [50 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,'PRO-5-GOR_final','fig')
close(figure)


 figure()
   plot(Time,GORD(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Gas oil ratio(Sm^{3}/Sm^{3})','FontName','Helvetica', 'Fontsize', 13);
title('PRO-11-GOR','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TG4,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [50 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,'PRO-11-GOR_final','fig')
close(figure)

figure()
   plot(Time,GORE(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Gas oil ratio(Sm^{3}/Sm^{3})','FontName','Helvetica', 'Fontsize', 13);
title('PRO-12-GOR','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TG5,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [50 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,'PRO-12-GOR_final','fig')
close(figure)

figure()
   plot(Time,GORF(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Gas oil ratio(Sm^{3}/Sm^{3})','FontName','Helvetica', 'Fontsize', 13);
title('PRO-15-GOR','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TG6,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [50 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,'PRO-15-GOR_final','fig')
close(figure)

%% Plot for water cut
figure()

 plot(Time,WCTA(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Water cut','FontName','Helvetica', 'Fontsize', 13);
title('PRO-1-WCT','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TW1,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,'PRO-1-WCT_final','fig')
close(figure)

figure()
  plot(Time,WCTB(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Water cut','FontName','Helvetica', 'Fontsize', 13);
title('PRO-4-WCT','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TW2,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,'PRO-4-WCT_final','fig')
close(figure)

figure()
  plot(Time,WCTC(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Water cut','FontName','Helvetica', 'Fontsize', 13);
title('PRO-5-WCT','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TW3,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,'PRO-5-WCT_final','fig')
close(figure)

figure()
  plot(Time,WCTD(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Water cut','FontName','Helvetica', 'Fontsize', 13);
title('PRO-11-WCT','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TW4,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,'PRO-11-WCT_final','fig')
close(figure)

figure()
plot(Time,WCTE(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Water cut','FontName','Helvetica', 'Fontsize', 13);
title('PRO-12-WCT','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TW5,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,'PRO-12-WCT_final','fig')
close(figure)

figure()
  plot(Time,WCTF(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Water cut','FontName','Helvetica', 'Fontsize', 13);
title('PRO-15-WCT','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TW6,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,'PRO-15-WCT_final','fig')
close(figure)




%% Plot for field oil recovery ratio
 figure()
 plot(Time,FOEA(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Oil recovery ratio','FontName','Helvetica', 'Fontsize', 13);
title('Field oil recovery ratio','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TFOE,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,'FOE_final','fig')
close(figure)


for i=1:N

    EBHP1(i,:)=immse(WBHPA(:,i),TP1);
    EBHP2(i,:)=immse(WBHPB(:,i),TP2);
    EBHP3(i,:)=immse(WBHPC(:,i),TP3);
    EBHP4(i,:)=immse(WBHPD(:,i),TP4);
	EBHP5(i,:)=immse(WBHPE(:,i),TP5);
    EBHP6(i,:)=immse(WBHPF(:,i),TP6);
	
	
    EWCT1(i,:)=immse(WCTA(:,i),TW1);
    EWCT2(i,:)=immse(WCTB(:,i),TW2);
    EWCT3(i,:)=immse(WCTC(:,i),TW3);
    EWCT4(i,:)=immse(WCTD(:,i),TW4);
    EWCT5(i,:)=immse(WCTE(:,i),TW5);
    EWCT6(i,:)=immse(WCTF(:,i),TW6);
	
	
	
	EGORP1(i,:)=immse(GORA(:,i),TG1);
    EGORP2(i,:)=immse(GORB(:,i),TG2);
    EGORP3(i,:)=immse(GORC(:,i),TG3);
    EGORP4(i,:)=immse(GORD(:,i),TG4);
	EGORP5(i,:)=immse(GORE(:,i),TG5);
    EGORP6(i,:)=immse(GORF(:,i),TG6);
end
TOTALERROR=ones(200,1);
TOTALERROR=(EWCT1./std(TW1))+(EWCT2./std(TW2))...
    +(EWCT3./std(TW3))+(EWCT4./std(TW4))+(EWCT5./std(TW5))...
	+(EWCT6./std(TW6))+(EBHP1./std(TP1))...
    +(EBHP2./std(TP2))+(EBHP3./std(TP3))+(EBHP4./std(TP4))...
	+(EBHP5./std(TP5))+(EBHP6./std(TP6))+(EGORP1./std(TG1))+(EGORP2./std(TG2))...
	+(EGORP3./std(TG3))+(EGORP4./std(TG4))+(EGORP5./std(TG5))+(EGORP6./std(TG6));
TOTALERROR=TOTALERROR./81;
jj=min(TOTALERROR);
indexfinal = TOTALERROR; 
bestnorm = find(indexfinal == min(indexfinal));
	%Pssim = Pnew(:,bestssim); %best due to ssim
fprintf('The best Norm Realization for production data match is number %i with value %4.6f \n',bestnorm,jj);
decreasingseries=zeros(200,inelly+1);
decreasingseries(:,1:inelly)=decreasingnorm;
decreasingseries(:,inelly+1)=indexfinal;

reali=[1:200]';

 figure()
 bar(reali,indexfinal,'cyan');
 xlabel('Realizations', 'FontName','Helvetica', 'Fontsize', 13);
 ylabel('RMSE value', 'FontName','Helvetica', 'Fontsize', 13);
 title('Production data Cost function for Realizations','FontName','Helvetica', 'Fontsize', 13)
 set(gcf,'color', 'white');
 hold on
 scatter(reali,indexfinal,'black','filled');
  xlim([1,200]);
 xlabel('Realizations', 'FontName','Helvetica', 'Fontsize', 13)
 ylabel('RMSE value', 'FontName','Helvetica', 'Fontsize', 13)
  saveas(gcf,'RMS_final','fig')
close(figure)

 disp('  Final RMS computation executed  ');
disp( 'output the permeability and porosity history matched model for the last iteration')
file = fopen('sgsimfinal.out','w+'); %output the dictionary
for k=1:numel(mumyperm)                                                                       
fprintf(file,' %4.6f \n',mumyperm(k) );             
end

file2 = fopen('sgsimporofinal.out','w+'); %output the dictionary
for k=1:numel(mumyporo)                                                                       
fprintf(file2,' %4.6f \n',mumyporo(k) );             
end
file6 = fopen('sgzfinal.out','w+'); %output the dictionary
for k=1:numel(mumypermz)                                                                       
fprintf(file6,' %4.6f \n',mumypermz(k) );             
end

file3 = fopen('genesisNorm.out','w+');
 for k=1:numel(decreasingnorm)                                                                       
 fprintf(file3,' %4.4f \n',decreasingnorm(k) );             
 end
 
 file4 = fopen('evolvingNorm.out','w+');
 for k=1:numel(decreasingseries)                                                                       
 fprintf(file4,' %4.4f \n',decreasingseries(k) );             
 end
 
 bestnorm=double(bestnorm);


disp( 'Well locaions consisting of producer well')

iProd = [10, 9, 17, 11, 15, 17]; % 6 wells configuration, production wells
jProd = [22, 17, 11, 24, 12 22]; % 6 wells configuration, production wells
%CMRmap=[0 0 0;.3 .15 .75;.6 .2 .50;1 .25 .15;.9 .5 0;.9 .9 .5;1 1 1];
effective=reshape(effective,2660,1);
if response==1
    disp( 'Pixel map needed')
    [bestnorm3,PlogK]=clementPlot(19,28,5,iProd, jProd,mumyperm,rossmary,200,bestnorm,effective);
%     xr=reshape(PlogK,nx*ny,Nz);
%     
% plottinglocations(xr, nx, ny,nz, 'Layer', iInj, jInj, iProd, jProd, min(xr), max(xr));
disp('  black are producers')
     %run('clementPlot.m')
else
    disp (' pixel map not needed')
end

fprintf('Finished Iterations with the History matching method %d .\n', method);
if method==1
disp('The method used was standard EnKF impelemented with main_ESMDA')
elseif method==2
disp('The method used was EnKF with Localization')
elseif method==3
disp('The method used was EnKF impelemented with main_DCT( discrete cosine transform method coupled with ESMDA)')
elseif method==4
disp('The method used was compressed sensing EnKF impelemented with main_sparsity(compressed sensing)')
elseif method==5
disp('The method used was PCA_EnKF (EnKF with PCA')
elseif method==6
disp('The method used was OPCA_EnKF (EnKF with OPCA')
else
 disp('The method used was EnKF  with Localization and Bootstrap')   
end
disp('  The overall program has been executed and the history matched files saved in the folder  ');
toc