function [DupdateK] = EnKF_PCA (sgactual,f, N, Sim1,Saturation,Pressure,SaturationG,RSG);
%%History matching data assimilation technique 
%%PhD Student: Clement Etienam
%%Supervisor: Dr Rossmary Villegas
%%Co-supervisor: Dr Masoud Babei

%-----------------------------------------------------------------------------
%disp( 'History matching data assimilation technique using standard ESMDA for PUNQ Reservoir'  ) 
disp( 'PhD Student: Clement Etienam' )
disp( 'Supervisor: Dr Rossmary Villegas' )
disp( 'Co-supervisor: Dr Masoud Babei' )
disp( 'Advisor: Dr Oliver Dorn' )
disp('  load the files  ');

sgsim1=(sgactual);
% sgz1=log(sgz);

 sgsim11 = reshape(sgsim1,200,N);

disp('  generate Gaussian noise for the observed measurments  ');


    stddFOE =    0.1*f(1,:);
	
	stddBHP1 = 0.15*f(2,:);
    stddBHP2 = 0.15*f(3,:);
    stddBHP3 = 0.15*f(4,:);
    stddBHP4 = 0.15*f(5,:);
	stddBHP5 = 0.15*f(6,:);
	stddBHP6 = 0.15*f(7,:);
	
	stddGORP1 = 0.15*f(8,:);
    stddGORP2 = 0.15*f(9,:);
    stddGORP3 = 0.15*f(10,:);
    stddGORP4 = 0.15*f(11,:);
	stddGORP5 = 0.15*f(12,:);
    stddGORP6 = 0.15*f(13,:);
  

    stddWWCT1 = 0.2*f(14,:);
    stddWWCT2 = 0.2*f(15,:);
    stddWWCT3 =0.2*f(16,:);
    stddWWCT4 = 0.2*f(17,:);
	stddWWCT5 = 0.2*f(18,:);
	stddWWCT6 = 0.2*f(19,:);

  
Error1=ones(19,N);
Error1(1,:)=normrnd(0,stddFOE,1,N);
Error1(2,:)=normrnd(0,stddBHP1,1,N);
Error1(3,:)=normrnd(0,stddBHP2,1,N);
Error1(4,:)=normrnd(0,stddBHP3,1,N);
Error1(5,:)=normrnd(0,stddBHP4,1,N);
Error1(6,:)=normrnd(0,stddBHP5,1,N);
Error1(7,:)=normrnd(0,stddBHP6,1,N);
Error1(8,:)= normrnd(0,stddGORP1,1,N);
Error1(9,:)= normrnd(0,stddGORP2,1,N);
Error1(10,:)= normrnd(0,stddGORP3,1,N);
Error1(11,:)= normrnd(0,stddGORP4,1,N);
Error1(12,:)= normrnd(0,stddGORP5,1,N);
Error1(13,:)= normrnd(0,stddGORP6,1,N);
Error1(14,:)=normrnd(0,stddWWCT1,1,N);
Error1(15,:)=normrnd(0,stddWWCT2,1,N);
Error1(16,:)=normrnd(0,stddWWCT3,1,N);
Error1(17,:)=normrnd(0,stddWWCT4,1,N);
Error1(18,:)=normrnd(0,stddWWCT5,1,N);
Error1(19,:)=normrnd(0,stddWWCT6,1,N);


Cd2 = (Error1*Error1')./(N-1);


for i=1:N
     Dj(:,i)=f+(Error1(:,i));
	
 end

disp('  generate the ensemble state matrix containing parameters and states  ');

overall=zeros(7275,N); 

overall(1:200,1:N)=sgsim11;
overall(201:1964,1:N)=Saturation;
overall(1965:3728,1:N)=Pressure;
overall(3729:5492,1:N)=SaturationG;
overall(5493:7256,1:N)=RSG;
overall(7257:7275,1:N)=Sim1;
Y=overall; %State variable,it is important we include simulated measurements in the ensemble state variable

M = mean(Sim1,2);
% Mean of the ensemble state
M2=mean(overall,2);
%M=M'
% Get the ensemble states pertubations
for j=1:N
    S(:,j)=Sim1(:,j)-M;
end
for j=1:N
    yprime(:,j)=overall(:,j)-M2;
end


H=zeros(19,7275);
H(1:19,7257:7275)=eye(19);
unie=H*yprime;
Sim=H*Y;
unie2=unie+Error1;
[U0,Z0,V0] = svd(unie2,'econ');
joy2=Z0*Z0';

[Usig,Sig,Vsig] = svd(joy2);
xsmall = diag(Sig);
Bsig = cumsum(xsmall);
valuesig=Bsig(end);
valuesig=valuesig*0.9999;
indices = find(cumsum(xsmall) >= valuesig );
toluse=xsmall(indices,:);
tol=toluse(1,:);


X1=pinv(joy2,tol)*U0';
% Residual vector
X2=X1*(Dj-Sim);

X3=U0*X2;

X4=unie'*X3;
%Update the ensemble state
disp('  update the new ensemble  ');
Ynew=Y+(yprime*X4);



disp( 'extract the active permeability field ')
value1=Ynew(1:200,1:N);


DupdateK=(value1);

end