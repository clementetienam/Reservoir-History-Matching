function[output,outputporo,outputz] = honour2(rossmary, rossmaryporo,rossmaryz2, N,sgz1,sgsim2,DupdateK);
% honour the well permeability and porosity values



% read true permeability well value
unie=reshape(rossmary,19,28,5);
unieporo=reshape(rossmaryporo,19,28,5);
uniez=reshape(rossmaryz2,19,28,5);
% read true porosity well values

for j=1:5;
    aa(j)=unie(10,22,j);
    bb(j)=unie(9,17,j);
   cc(j)=unie(17,11,j);
    dd(j)=unie(11,24,j);
    ee(j)=unie(15,12,j);
    ff(j)=unie(17,22,j);
  
end

for j=1:5;
    aa1(j)=unieporo(10,22,j);
    bb1(j)=unieporo(9,17,j);
   cc1(j)=unieporo(17,11,j);
    dd1(j)=unieporo(11,24,j);
    ee1(j)=unieporo(15,12,j);
    ff1(j)=unieporo(17,22,j);
    
end

for j=1:5;
    aa2(j)=uniez(10,22,j);
    bb2(j)=uniez(9,17,j);
   cc2(j)=uniez(17,11,j);
    dd2(j)=uniez(11,24,j);
    ee2(j)=uniez(15,12,j);
    ff2(j)=uniez(17,22,j);
    
end


% read permeability ensemble after EnKF update
A=reshape(DupdateK,2660,N);
C=reshape(sgsim2,2660,N);
C2=reshape(sgz1,2660,N);


% start the conditioning for permeabilityX
for i=1:N;
    %B=reshape(A(:,i),120,60,10);
    B = reshape(A(:,i),19,28,5); 
    %clement=B(i);
    for j=1:5;
    B(10,22,j)=aa(j);
    B(9,17,j)=bb(j);
   B(17,11,j)=cc(j);
    B(11,23,j)=dd(j);
    B(15,12,j)=ee(j);
    B(17,22,j)=ff(j);

    
    end
    output(:,i)=reshape(B,2660,1); 
    %Aa=reshape(B(i),72000,1);
end

for i=1:N;
    %B=reshape(A(:,i),120,60,10);
    D = reshape(C(:,i),19,28,5); 
    %clement=B(i);
    for j=1:5;
    D(10,22,j)=aa1(j);
    D(9,17,j)=bb1(j);
   D(17,11,j)=cc1(j);
    D(11,23,j)=dd1(j);
    D(15,12,j)=ee1(j);
    D(17,22,j)=ff1(j);
    
    
    end
    outputporo(:,i)=reshape(D,2660,1); 
    %Aa=reshape(B(i),72000,1);
end% 

for i=1:N;
    %B=reshape(A(:,i),120,60,10);
    D2 = reshape(C2(:,i),19,28,5); 
    %clement=B(i);
    for j=1:5;
    D2(10,22,j)=aa2(j);
    D2(9,17,j)=bb2(j);
   D2(17,11,j)=cc2(j);
    D2(11,23,j)=dd2(j);
    D2(15,12,j)=ee2(j);
    D2(17,22,j)=ff2(j);
    
    
    end
    outputz(:,i)=reshape(D2,2660,1); 
    %Aa=reshape(B(i),72000,1);
end% 

% output=reshape(B,120*60*10,100);
%output permeability conditioned ensemble

end