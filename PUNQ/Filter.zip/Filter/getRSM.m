%%This code is to plot all the ensemble production data at once
clc;
clear;
close all;
disp('  Load the relevant files  ');
% N - size of ensemble

N=200;



oldfolder=cd;
cd(oldfolder) % setting original directory

%for m=1:2
%Get for oil production rate

disp('  start the plotting  ');

    for i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',i));
    %folder=oldfolder;
    %cd 'C:\Work\GSLIB\sgsim\EnKFMATLABRun'   
    cd(folder);
   
        
  
    
    %Saturation data lines [2939-5206]
    A1 = importdata('MASTER0.RSM',' ',7);
    A2 = importdata('MASTER0.RSM',' ',95);
    A3 = importdata('MASTER0.RSM',' ',183);
	
    
    A1=A1.data;
    A2=A2.data;
    A3=A3.data;
	
    %SO1983=ones(2268,4)-SW1983;
    
    %save('P1983.out','P1983','-ascii');
    %save('SW1983.out','SW1983','-ascii');
    
    FOE=A1(:,3);
     
	 WBHP1=A1(:,4);
     WBHP2=A1(:,5);
     WBHP3=A1(:,6);
     WBHP4=A1(:,7);
	 WBHP5=A1(:,8);
	 WBHP6=A1(:,9);
	 
     Time=A1(:,1);
	 
	 GORP1=A1(:,10);
     GORP2=A2(:,2);
     GORP3=A2(:,3);
     GORP4=A2(:,4);
	 GORP5=A2(:,5);
	 GORP6=A2(:,6);
	 
	 
     
     WWCT1=A2(:,7);
     WWCT2=A2(:,8);
     WWCT3=A2(:,9);
     WWCT4=A2(:,10);
	 WWCT5=A3(:,2);
	 WWCT6=A3(:,3);
     
   
	 

	 
	 
	
	 
     
    %Saturation
    
    WBHPA(:,i)=WBHP1;
    WBHPB(:,i)=WBHP2;
    WBHPC(:,i)=WBHP3;
    WBHPD(:,i)=WBHP4;
	WBHPE(:,i)=WBHP5;
	WBHPF(:,i)=WBHP6;
    
	GORA(:,i)=GORP1;
    GORB(:,i)=GORP2;
    GORC(:,i)=GORP3;
    GORD(:,i)=GORP4;
	GORE(:,i)=GORP5;
	GORF(:,i)=GORP6;
	
    WCTA(:,i)=WWCT1;
    WCTB(:,i)=WWCT2;
    WCTC(:,i)=WWCT3;
    WCTD(:,i)=WWCT4;
    WCTE(:,i)=WWCT5;
	WCTF(:,i)=WWCT6;
    
	
	
	
	FOEA(:,i)=FOE;
	
    
    cd(oldfolder);
    end
   cd(oldfolder) % returning to original directory
 %Import true data
 True= importdata('Real.RSM',' ',7);
 True2= importdata('Real.RSM',' ',95);
 True3= importdata('Real.RSM',' ',183);
 
 
 True=True.data;
 True2=True2.data;
 True3=True3.data;
 
 
  TP1=True(:,4);
 TP2=True(:,5);
 TP3=True(:,6);
 TP4=True(:,7);
  TP5=True(:,8);
   TP6=True(:,9);
 
 
 TG1=True(:,10);
 TG2=True2(:,2);
 TG3=True2(:,3);
 TG4=True2(:,4);
 TG5=True2(:,5);
  TG6=True2(:,6);
 
 
 
 
  TW1=True2(:,7);
 TW2=True2(:,8);
 TW3=True2(:,9);
 TW4=True2(:,10);
  TW5=True3(:,2);
   TW6=True3(:,3);
 
 
 
 
 
 TFOE=True(:,3);
 
 
 grey = [0.4,0.4,0.4]; 
 linecolor1 = colordg(4);
 
 
%% Plot for Well Bottom Hole Pressure
 figure()
 subplot(2,3,1)
 plot(Time,WBHPA(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('WBHP(BARSA)','FontName','Helvetica', 'Fontsize', 13);
 ylim([100 300])
title('PRO-1','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TP1,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [100 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off

 subplot(2,3,2)
 plot(Time,WBHPB(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('WBHP(BARSA)','FontName','Helvetica', 'Fontsize', 13);
 ylim([100 300])
title('PRO-4','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TP2,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [100 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off

 subplot(2,3,3)
 plot(Time,WBHPC(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('WBHP(BARSA)','FontName','Helvetica', 'Fontsize', 13);
ylim([100 300])
title('PRO-5','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TP3,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [100 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
 subplot(2,3,4)
 plot(Time,WBHPD(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('WBHP(BARSA)','FontName','Helvetica', 'Fontsize', 13);
ylim([100 300])
title('PRO-11','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TP4,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [100 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off

 subplot(2,3,5)
 plot(Time,WBHPE(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('WBHP(BARSA)','FontName','Helvetica', 'Fontsize', 13);
ylim([100 300])
title('PRO-12','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TP5,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [100 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off

 subplot(2,3,6)
 plot(Time,WBHPF(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('WBHP(BARSA)','FontName','Helvetica', 'Fontsize', 13);
ylim([100 300])
title('PRO-15','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TP6,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [100 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off

%% Plot for GOR
figure()
 subplot(2,3,1)
 plot(Time,GORA(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Gas oil ratio(Sm^{3}/Sm^{3})','FontName','Helvetica', 'Fontsize', 13);
title('PRO-1','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TG1,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [50  300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off

 subplot(2,3,2)
   plot(Time,GORB(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Gas oil ratio(Sm^{3}/Sm^{3})','FontName','Helvetica', 'Fontsize', 13);
title('PRO-4','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TG2,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [50 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off

 subplot(2,3,3)
   plot(Time,GORC(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Gas oil ratio(Sm^{3}/Sm^{3})','FontName','Helvetica', 'Fontsize', 13);
title('PRO-5','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TG3,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [50 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off
 subplot(2,3,4)
   plot(Time,GORD(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Gas oil ratio(Sm^{3}/Sm^{3})','FontName','Helvetica', 'Fontsize', 13);
title('PRO-11','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TG4,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [50 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off

 subplot(2,3,5)
   plot(Time,GORE(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Gas oil ratio(Sm^{3}/Sm^{3})','FontName','Helvetica', 'Fontsize', 13);
title('PRO-12','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TG5,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [50 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off

 subplot(2,3,6)
   plot(Time,GORF(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Gas oil ratio(Sm^{3}/Sm^{3})','FontName','Helvetica', 'Fontsize', 13);
title('PRO-15','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TG6,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [50 300],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off

%% Plot for water cut
figure()
 subplot(2,3,1)
 plot(Time,WCTA(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Water cut','FontName','Helvetica', 'Fontsize', 13);
title('PRO-1','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TW1,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off

 subplot(2,3,2)
  plot(Time,WCTB(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Water cut','FontName','Helvetica', 'Fontsize', 13);
title('PRO-4','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TW2,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off

 subplot(2,3,3)
  plot(Time,WCTC(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Water cut','FontName','Helvetica', 'Fontsize', 13);
title('PRO-5','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TW3,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off

 subplot(2,3,4)
  plot(Time,WCTD(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Water cut','FontName','Helvetica', 'Fontsize', 13);
title('PRO-11','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TW4,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off

 subplot(2,3,5)
plot(Time,WCTE(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Water cut','FontName','Helvetica', 'Fontsize', 13);
title('PRO-12','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TW5,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off

 subplot(2,3,6)
  plot(Time,WCTF(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Water cut','FontName','Helvetica', 'Fontsize', 13);
title('PRO-15','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TW6,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off




%% Plot for field oil recovery ratio
 figure()
 plot(Time,FOEA(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Oil recovery ratio','FontName','Helvetica', 'Fontsize', 13);
title('Field oil recovery ratio','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TFOE,'r','LineWidth',2)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([2500 2500], [0 1],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');

hold off







for i=1:N

    EBHP1(i,:)=immse(WBHPA(:,i),TP1);
    EBHP2(i,:)=immse(WBHPB(:,i),TP2);
    EBHP3(i,:)=immse(WBHPC(:,i),TP3);
    EBHP4(i,:)=immse(WBHPD(:,i),TP4);
	EBHP5(i,:)=immse(WBHPE(:,i),TP5);
    EBHP6(i,:)=immse(WBHPF(:,i),TP6);
	
	
    EWCT1(i,:)=immse(WCTA(:,i),TW1);
    EWCT2(i,:)=immse(WCTB(:,i),TW2);
    EWCT3(i,:)=immse(WCTC(:,i),TW3);
    EWCT4(i,:)=immse(WCTD(:,i),TW4);
    EWCT5(i,:)=immse(WCTE(:,i),TW5);
    EWCT6(i,:)=immse(WCTF(:,i),TW6);
	
	
	
	EGORP1(i,:)=immse(GORA(:,i),TG1);
    EGORP2(i,:)=immse(GORB(:,i),TG2);
    EGORP3(i,:)=immse(GORC(:,i),TG3);
    EGORP4(i,:)=immse(GORD(:,i),TG4);
	EGORP5(i,:)=immse(GORE(:,i),TG5);
    EGORP6(i,:)=immse(GORF(:,i),TG6);
end
TOTALERROR=ones(200,1);
TOTALERROR=(EWCT1./std(TW1))+(EWCT2./std(TW2))...
    +(EWCT3./std(TW3))+(EWCT4./std(TW4))+(EWCT5./std(TW5))...
	+(EWCT6./std(TW6))+(EBHP1./std(TP1))...
    +(EBHP2./std(TP2))+(EBHP3./std(TP3))+(EBHP4./std(TP4))...
	+(EBHP5./std(TP5))+(EBHP6./std(TP6))+(EGORP1./std(TG1))+(EGORP2./std(TG2))...
	+(EGORP3./std(TG3))+(EGORP4./std(TG4))+(EGORP5./std(TG5))+(EGORP6./std(TG6));
TOTALERROR=TOTALERROR./18;
jj=min(TOTALERROR);
index = TOTALERROR; 
bestnorm = find(index == min(index));
	%Pssim = Pnew(:,bestssim); %best due to ssim
fprintf('The best Norm Realization for production data match is number %i with value %4.4f \n',bestnorm,jj);
% JOYLINE=[1:100]';
% figure()
%bar(JOYLINE,TOTALERROR);

reali=[1:200]';

 figure()
 subplot(2,3,1)
 bar(reali,index,'cyan');
 xlabel('Realizations', 'FontName','Helvetica', 'Fontsize', 13);
 ylabel('RMSE value', 'FontName','Helvetica', 'Fontsize', 13);
 title('Production data Cost function for Realizations','FontName','Helvetica', 'Fontsize', 13)
 set(gcf,'color', 'white');
 hold on
 scatter(reali,index,'black','filled');
 xlabel('Realizations', 'FontName','Helvetica', 'Fontsize', 13)
 ylabel('RMSE value', 'FontName','Helvetica', 'Fontsize', 13)
 hold off
 xlim([1,200]);
 
 disp('  program almost executed  ');
 file = fopen('normenkf.out','w+'); 
 for k=1:numel(index)                                                                       
 fprintf(file,' %4.4f \n',index(k) );             
 end

 disp(' get the dissimilarity for permeability reconstruction')
 
load sgsim.out;
load rossmary.GRDECL;


A=reshape(sgsim,2660,200);
load effective.out;
True=rossmary.*effective;
True=log10(True);
True(True==-Inf)=0;

Joyeffective= repmat(effective,1,200);
Ause=A.*Joyeffective;
A1=log10(Ause);
A1(A1==-Inf)=0;
Cm=A1*A1';
for i=1:200
    J(:,i)=A1(:,i)-True;
end
for i=1:200
test(i,:)=sum(abs((J(:,i))));
end

reali=[1:200]';

 
 subplot(2,3,2)
 bar(reali,test,'cyan');
 xlabel('Realizations', 'FontName','Helvetica', 'Fontsize', 13);
 ylabel('RMSE value of model', 'FontName','Helvetica', 'Fontsize', 13);
 title('Absolute diffrence for permeability reconstruction','FontName','Helvetica', 'Fontsize', 13)
 set(gcf,'color', 'white');
 hold on
 scatter(reali,test,'black','filled');
 xlabel('Realizations', 'FontName','Helvetica', 'Fontsize', 13)
 ylabel('RMSE value of models', 'FontName','Helvetica', 'Fontsize', 13)
 hold off
 xlim([1,200]);

overallcostjoy=((0.02.*test)+index)./2;

jj2=min(overallcostjoy);
index2 = overallcostjoy; 
bestnorm2 = find(index2 == min(index2));

jj3=min(test);
index3 = test; 
bestnorm3 = find(index3 == min(index3));
	%Pssim = Pnew(:,bestssim); %best due to ssim
fprintf('The best Norm Realization for Log(K) reconstruction and production data is number %i with value %4.4f \n',bestnorm2,jj2);


fprintf('The best Norm Realization for Log(K) reconstruction  is number %i with value %4.4f \n',bestnorm3,jj3);

outvar = [reali, test,index];
save('Normoverall.out','outvar','-ascii')
subplot(2,3,3);
scatter(index,test, 'Red')
xlabel('Production data Norm', 'FontName','Helvetica', 'Fontsize', 13);
ylabel('Permeability reconstruction Norm', 'FontName','Helvetica', 'Fontsize', 13);
title('Overall cost fucntion correlation between Log(K) and production data','FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color', 'white');

 subplot(2,3,4)
 bar(reali,overallcostjoy,'cyan');
 xlabel('Realizations', 'FontName','Helvetica', 'Fontsize', 13);
 ylabel('Combined cost functions', 'FontName','Helvetica', 'Fontsize', 13);
 title('Combined cost function of Log(K) and production data','FontName','Helvetica', 'Fontsize', 13)
 set(gcf,'color', 'white');
 hold on
 scatter(reali,overallcostjoy,'black','filled');
 xlabel('Realizations', 'FontName','Helvetica', 'Fontsize', 13)
 ylabel('Combined cost functions', 'FontName','Helvetica', 'Fontsize', 13)
 hold off
 xlim([1,200]);

 
 
  subplot(2,3,5)
 scatter(reali,test,'black');
 xlabel('Realizations', 'FontName','Helvetica', 'Fontsize', 13);
 ylabel('Cost function', 'FontName','Helvetica', 'Fontsize', 13);
 title('Combined cost function of Log(K) and production data','FontName','Helvetica', 'Fontsize', 13)
 set(gcf,'color', 'white');
 hold on
 plot(reali,index,'red');
 xlabel('Realizations', 'FontName','Helvetica', 'Fontsize', 13);
 ylabel('Cost functions', 'FontName','Helvetica', 'Fontsize', 13);
 title('Combined cost function of Log(K) and production data','FontName','Helvetica', 'Fontsize', 13)
 set(gcf,'color', 'white');


 hold off
 xlim([1,200]);
 
   subplot(2,3,6)
 plot(reali,test,'black');
 xlabel('Realizations', 'FontName','Helvetica', 'Fontsize', 13);
 ylabel('Cost function', 'FontName','Helvetica', 'Fontsize', 13);
 title('Combined cost function of Log(K) and production data','FontName','Helvetica', 'Fontsize', 13)
 set(gcf,'color', 'white');
 hold on
 plot(reali,index,'red');
 xlabel('Realizations', 'FontName','Helvetica', 'Fontsize', 13);
 ylabel('Cost functions', 'FontName','Helvetica', 'Fontsize', 13);
 title('Combined cost function of Log(K) and production data','FontName','Helvetica', 'Fontsize', 13)
 set(gcf,'color', 'white');


 hold off
 xlim([1,200]);
 Pssim = reshape(A1(:,bestnorm2),19,28,5);
 Pprodnorm = reshape(A1(:,bestnorm),19,28,5);
 PlogK = reshape(A1(:,bestnorm3),19,28,5);
 
 Pssim(Pssim==0)=NaN;
  Pprodnorm(Pprodnorm==0)=NaN;
  PlogK(PlogK==0)=NaN;
 [X,Y] = meshgrid(1:19,1:28);
iProd = [10, 9, 17, 11, 15, 17]; % 6 wells configuration, production wells
jProd = [ 22, 17, 11, 24,  12, 22]; % 6 wells configuration, production wells


Trueperm=reshape(True,19,28,5);
Trueperm(Trueperm==0)=NaN;
figure()
subplot(4,5,1);
surf(X',Y',Trueperm(:,:,1))

shading flat
axis([1 19 1 28 ])
grid off
title('True Layer 1','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
hold on


subplot(4,5,2);
surf(X',Y',Trueperm(:,:,2))

shading flat
axis([1 19 1 28 ])
grid off
title('True Layer 2','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
%hold on
% plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0.99 0.99 0.99], 'MarkerSize',8);
% % %  Write production well names
%  for index=1:length(iProd)
%      text(iProd(index)-2, jProd(index)-2, ['PRO' num2str(index)], 'FontName', 'Times New Roman', 'color', 'k', 'FontSize', 12, 'FontWeight', 'b'); 
%  end

subplot(4,5,3);
surf(X',Y',Trueperm(:,:,3))

shading flat
axis([1 19 1 28 ])
grid off
title('True Layer 3','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
% hold on
% plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0.99 0.99 0.99], 'MarkerSize',8);
% % %  Write production well names
%  for index=1:length(iProd)
%      text(iProd(index)-2, jProd(index)-2, ['PRO' num2str(index)], 'FontName', 'Times New Roman', 'color', 'k', 'FontSize', 12, 'FontWeight', 'b'); 
%  end

subplot(4,5,4);
surf(X',Y',Trueperm(:,:,4))

shading flat
axis([1 19 1 28 ])
grid off
title('True Layer 4','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
% hold on
% plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0.99 0.99 0.99], 'MarkerSize',8);
% % %  Write production well names
%  for index=1:length(iProd)
%      text(iProd(index)-2, jProd(index)-2, ['PRO' num2str(index)], 'FontName', 'Times New Roman', 'color', 'k', 'FontSize', 12, 'FontWeight', 'b'); 
%  end

subplot(4,5,5);

surf(X',Y',Trueperm(:,:,5))

shading flat
axis([1 19 1 28 ])
grid off
title('True Layer 5','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
% hold on
% plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0.99 0.99 0.99], 'MarkerSize',8);
% % %  Write production well names
%  for index=1:length(iProd)
%      text(iProd(index)-2, jProd(index)-2, ['PRO' num2str(index)], 'FontName', 'Times New Roman', 'color', 'k', 'FontSize', 12, 'FontWeight', 'b'); 
%  end	
	

subplot(4,5,6);
surf(X',Y',Pssim(:,:,1))

shading flat
axis([1 19 1 28 ])
grid off
title('Layer 1 combined','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])	
% hold on
% plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0.99 0.99 0.99], 'MarkerSize',8);
% % %  Write production well names
%  for index=1:length(iProd)
%      text(iProd(index)-2, jProd(index)-2, ['PRO' num2str(index)], 'FontName', 'Times New Roman', 'color', 'k', 'FontSize', 12, 'FontWeight', 'b'); 
%  end

subplot(4,5,7);
surf(X',Y',Pssim(:,:,2))

shading flat
axis([1 19 1 28 ])
grid off
title('Layer 2 combined','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])	
% hold on
% plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0.99 0.99 0.99], 'MarkerSize',8);
% % %  Write production well names
%  for index=1:length(iProd)
%      text(iProd(index)-2, jProd(index)-2, ['PRO' num2str(index)], 'FontName', 'Times New Roman', 'color', 'k', 'FontSize', 12, 'FontWeight', 'b'); 
%  end

subplot(4,5,8);
surf(X',Y',Pssim(:,:,3))

shading flat
axis([1 19 1 28 ])
grid off
title('Layer 3 combined','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
% hold on
% plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0.99 0.99 0.99], 'MarkerSize',8);
% % %  Write production well names
%  for index=1:length(iProd)
%      text(iProd(index)-2, jProd(index)-2, ['PRO' num2str(index)], 'FontName', 'Times New Roman', 'color', 'k', 'FontSize', 12, 'FontWeight', 'b'); 
%  end
 
subplot(4,5,9);
surf(X',Y',Pssim(:,:,4))

shading flat
axis([1 19 1 28 ])
grid off
title('Layer 4 combined','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
% hold on
% plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0.99 0.99 0.99], 'MarkerSize',8);
% % %  Write production well names
%  for index=1:length(iProd)
%      text(iProd(index)-2, jProd(index)-2, ['PRO' num2str(index)], 'FontName', 'Times New Roman', 'color', 'k', 'FontSize', 12, 'FontWeight', 'b'); 
%  end
subplot(4,5,10);
surf(X',Y',Pssim(:,:,5))

shading flat
axis([1 19 1 28 ])
grid off
title('Layer 5 combined','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
% hold on
% plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0.99 0.99 0.99], 'MarkerSize',8);
% % %  Write production well names
%  for index=1:length(iProd)
%      text(iProd(index)-2, jProd(index)-2, ['PRO' num2str(index)], 'FontName', 'Times New Roman', 'color', 'k', 'FontSize', 12, 'FontWeight', 'b'); 
%  end
subplot(4,5,11);
surf(X',Y',Pprodnorm(:,:,1))

shading flat
axis([1 19 1 28 ])
grid off
title('Layer 1(best Prod-Match)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
% hold on
% plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0.99 0.99 0.99], 'MarkerSize',8);
% % %  Write production well names
%  for index=1:length(iProd)
%      text(iProd(index)-2, jProd(index)-2, ['PRO' num2str(index)], 'FontName', 'Times New Roman', 'color', 'k', 'FontSize', 12, 'FontWeight', 'b'); 
%  end
subplot(4,5,12);
surf(X',Y',Pprodnorm(:,:,2))

shading flat
axis([1 19 1 28 ])
grid off
title('Layer 2(best Prod-Match)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
% hold on
% plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0.99 0.99 0.99], 'MarkerSize',8);
% % %  Write production well names
%  for index=1:length(iProd)
%      text(iProd(index)-2, jProd(index)-2, ['PRO' num2str(index)], 'FontName', 'Times New Roman', 'color', 'k', 'FontSize', 12, 'FontWeight', 'b'); 
%  end
subplot(4,5,13);
surf(X',Y',Pprodnorm(:,:,3))

shading flat
axis([1 19 1 28 ])
grid off
title('Layer 3(best Prod-Match)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
% hold on
% plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0.99 0.99 0.99], 'MarkerSize',8);
% % %  Write production well names
%  for index=1:length(iProd)
%      text(iProd(index)-2, jProd(index)-2, ['PRO' num2str(index)], 'FontName', 'Times New Roman', 'color', 'k', 'FontSize', 12, 'FontWeight', 'b'); 
%  end
subplot(4,5,14);
surf(X',Y',Pprodnorm(:,:,4))

shading flat
axis([1 19 1 28 ])
grid off
title('Layer 4(best Prod-Match)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
% hold on
% plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0.99 0.99 0.99], 'MarkerSize',8);
% % %  Write production well names
%  for index=1:length(iProd)
%      text(iProd(index)-2, jProd(index)-2, ['PRO' num2str(index)], 'FontName', 'Times New Roman', 'color', 'k', 'FontSize', 12, 'FontWeight', 'b'); 
%  end
subplot(4,5,15);
surf(X',Y',Pprodnorm(:,:,5))

shading flat
axis([1 19 1 28 ])
grid off
title('Layer 5(best Prod-Match)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
% hold on
% plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0.99 0.99 0.99], 'MarkerSize',8);
% % %  Write production well names
%  for index=1:length(iProd)
%      text(iProd(index)-2, jProd(index)-2, ['PRO' num2str(index)], 'FontName', 'Times New Roman', 'color', 'k', 'FontSize', 12, 'FontWeight', 'b'); 
%  end
subplot(4,5,16);
surf(X',Y',PlogK(:,:,1))

shading flat
axis([1 19 1 28 ])
grid off
title('Layer 1(best Log(K)-Match)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
% hold on
% plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0.99 0.99 0.99], 'MarkerSize',8);
% % %  Write production well names
%  for index=1:length(iProd)
%      text(iProd(index)-2, jProd(index)-2, ['PRO' num2str(index)], 'FontName', 'Times New Roman', 'color', 'k', 'FontSize', 12, 'FontWeight', 'b'); 
%  end
subplot(4,5,17);
surf(X',Y',PlogK(:,:,2))

shading flat
axis([1 19 1 28 ])
grid off
title('Layer 2(best Log(K)-Match)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
% hold on
% plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0.99 0.99 0.99], 'MarkerSize',8);
% % %  Write production well names
%  for index=1:length(iProd)
%      text(iProd(index)-2, jProd(index)-2, ['PRO' num2str(index)], 'FontName', 'Times New Roman', 'color', 'k', 'FontSize', 12, 'FontWeight', 'b'); 
%  end
subplot(4,5,18);
surf(X',Y',PlogK(:,:,3))

shading flat
axis([1 19 1 28 ])
grid off
title('Layer 3(best Log(K)-Match)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
% hold on
% plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0.99 0.99 0.99], 'MarkerSize',8);
% % %  Write production well names
%  for index=1:length(iProd)
%      text(iProd(index)-2, jProd(index)-2, ['PRO' num2str(index)], 'FontName', 'Times New Roman', 'color', 'k', 'FontSize', 12, 'FontWeight', 'b'); 
%  end

subplot(4,5,19);
surf(X',Y',PlogK(:,:,4))

shading flat
axis([1 19 1 28 ])
grid off
title('Layer 4(best Log(K)-Match)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
% hold on
% plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0.99 0.99 0.99], 'MarkerSize',8);
% % %  Write production well names
%  for index=1:length(iProd)
%      text(iProd(index)-2, jProd(index)-2, ['PRO' num2str(index)], 'FontName', 'Times New Roman', 'color', 'k', 'FontSize', 12, 'FontWeight', 'b'); 
%  end
subplot(4,5,20);
surf(X',Y',PlogK(:,:,5))

shading flat
axis([1 19 1 28 ])
grid off
title('Layer 5(best Log(K)-Match)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
caxis([1 3])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [1 3])
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
% hold on
% plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0.99 0.99 0.99], 'MarkerSize',8);
% % %  Write production well names
%  for index=1:length(iProd)
%      text(iProd(index)-2, jProd(index)-2, ['PRO' num2str(index)], 'FontName', 'Times New Roman', 'color', 'k', 'FontSize', 12, 'FontWeight', 'b'); 
%  end
disp(' programme completed')