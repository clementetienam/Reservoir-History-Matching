function [sg,sgporo,velocity,velocityporo,clement,clementporo] = ESMDA_Velocity(sg,sgporo,f, N,Sim1,velocity,velocityporo,tol,alpha,nbandall,nbandallporo,clement,clementporo,c)

%
% PARAMETERS:
%   f           -   True data
%   sgsim           -  ensemble of simulate states
%   N           -   ensemble size
%   Sim1      -   Simulated measurments

%-----------------------------------------------------------------------------
disp( 'History matching data assimilation technique using ESMDA with Levelset and velocity functions for SPE 10 Reservoir'  ) 
disp( 'PhD Student: Clement Etienam' )
disp( 'Supervisor: Dr Rossmary Villegas' )
disp( 'Co-supervisor: Dr Masoud Babei' )
disp( 'Advisor: Dr Oliver Dorn' )
disp('  load the files  ');

A=zeros(120,60,5);
for j=1:5
    A(14,25,j)=1;
    A(38,39,j)=1;
    A(96,23,j)=1;
    A(67,41,j)=1;
    A(30,55,j)=1;
    A(58,18,j)=1;
    A(90,6,j)=1;
    A(14,25,j)=1;
    A(101,39,j)=1;
    
    
    
end
disp( 'calculate the euclidean distance function to the 6 producer wells')
    lf=reshape(A,120,60,5);
   for j=1:5;
     sdf=lf(:,:,j);
  [usdf,IDX] = bwdist(sdf);
  usdf=reshape(usdf,7200,1);
  young(:,j)=usdf;
   
   end
   sdfbig=reshape(young,36000,1);
   sdfbig1=abs(sdfbig);
   z=sdfbig1;
   % the value of the range should be computed accurately.
   %c=range(z);
  
  
   c0OIL1=zeros(36000,1);
   disp( 'compute the gaspari-cohn coefficent')
  for i=1:36000;
 if (0<=z(i,:) || z(i,:)<=c)
  c0OIL1(i,:)=-0.25*(z(i,:)/c)^5+0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3-(5.0/3.0)*(z(i,:)/c)^2+1;
elseif z < 2*c
  c0OIL1(i,:)=(1.0/12.0)*(z(i,:)/c)^5-0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3+(5.0/3.0)*(z(i,:)/c)^2-5*(z(i,:)/c)+4-(2.0/3.0)*(c/z(i,:));
 elseif (c<=z(i,:) || z(i,:)<=2*c)
     c0OIL1(i,:)=-5*(z(i,:)/c)+4-0.667*(c/z(i,:));
 else
     c0OIL1(i,:)=0;
 end
  
  end
  
c0OIL1(c0OIL1<0)=0;
  

  
 disp(' get the gaspari cohn for Cyd') 
 
    schur=c0OIL1;
  Bsch = repmat(schur,1,N);
  
  yoboschur=ones(72000,N);
 
  yoboschur(1:36000,:)=Bsch;
  yoboschur(36001:72000,:)=Bsch;

sgsim1=log(sg);
 sgsim11 = reshape(sgsim1,36000,N);
 sgsim11poro = reshape(sgporo,36000,N);
 velocity=reshape(velocity,36000,N);
 velocityporo=reshape(velocityporo,36000,N);
 clement=reshape(clement,36000,N);
 clementporo=reshape(clementporo,36000,N);
 nbandall=reshape(nbandall,36000,N);
 nbandallporo=reshape(nbandallporo,36000,N);

disp('  generate Gaussian noise for the observed measurments  ');


Error1=ones(17,N);
Error1(1,:)=normrnd(0,481.15,1,N);
Error1(2,:)=normrnd(0,861.3795,1,N);
Error1(3,:)=normrnd(0,784.1,1,N);
Error1(4,:)=normrnd(0,1358.9735,1,N);
Error1(5,:)=normrnd(0,0.085,1,N);
Error1(6,:)=normrnd(0,0.186,1,N);
Error1(7,:)=normrnd(0,0.185,1,N);
Error1(8,:)=normrnd(0,0.164,1,N);
Error1(9,:)= normrnd(0,17.79,1,N);
Error1(10,:)= normrnd(0,16.3,1,N);
Error1(11,:)= normrnd(0,16.7,1,N);
Error1(12,:)= normrnd(0,17.4,1,N);
Error1(13,:)= normrnd(0,51.9,1,N);
Error1(14,:)= normrnd(0,36.9,1,N);
Error1(15,:)= normrnd(0,64.87,1,N);
Error1(16,:)= normrnd(0,76.43,1,N);
Error1(17,:)= normrnd(0,0.062265,1,N);

 Cd2 = (Error1*Error1')./(N-1);

for i=1:N
     Dj(:,i)=f+Error1(:,i);
	
 end
   
disp('  generate the ensemble state matrix containing parameters and states  ');

nbandI=ones(216017,N); %narrow band and covariance correlation matrix
nbandI(1:72000,1:N)=yoboschur;
nbandI(72001:144000,1:N)=yoboschur;
nbandI(144001:216000,1:N)=yoboschur;

overall=zeros(216017,N); %ensemble state

overall(1:36000,1:N)=sgsim11;
overall(36001:72000,1:N)=sgsim11poro;
overall(72001:108000,1:N)=velocity;
overall(108001:144000,1:N)=velocityporo;
overall(144001:180000,1:N)=clement;
overall(180001:216000,1:N)=clementporo;
overall(216001:216017,1:N)=Sim1;

Y=overall; %State variable,it is important we include simulated measurements in the ensemble state variable


M = mean(Sim1,2);
% Mean of the ensemble state
M2=mean(overall,2);
%M=M'
% Get the ensemble states pertubations
for j=1:N
    S(:,j)=Sim1(:,j)-M;
end
for j=1:N
    yprime(:,j)=overall(:,j)-M2;
end


disp('  update the stochastic gradient  ');
Cyd=(yprime*S')./((N-1));
Cdd=(S*S')./((N-1));
% nbandI=ones(216017,N);
% nbandI(144001:180000,1:N)=nbandall;
% nbandI(180001:216000,1:N)=nbandallporo;
% nbandI(216001:252000,1:N)=nbandall;
% nbandI(252001:288000,1:N)=nbandallporo;

[Usig,Sig,Vsig] = svd(Cdd+(alpha.*Cd2));
xsmall = diag(Sig);
Bsig = cumsum(xsmall);
valuesig=Bsig(end);
valuesig=valuesig*0.9999;
indices = find(cumsum(xsmall) >= valuesig );
toluse=xsmall(indices,:);
tol=toluse(1,:);


disp('  update the new ensemble  ');
Ynew=Y+((Cyd*pinv((Cdd+(alpha.*Cd2)),tol))*(Dj-Sim1)).*nbandI;
disp( 'extract the updated states ')
value1=Ynew(1:36000,1:N);


sg=exp(value1);
sgporo=Ynew(36001:72000,1:N);

velocity=Ynew(72001:108000,1:N);
velocityporo=Ynew(108001:144000,1:N);
clement=Ynew(144001:180000,1:N);
clementporo=Ynew(180001:216000,1:N);
 
 
end