clc;
clear;
[SWn83,PEn83]=getstatesallenkf(200,3);