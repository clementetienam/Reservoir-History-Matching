function [PE,SW,SG,RS,sgz1,sgsim2,DupdateK] = ESMDA (sgsim, f, N, PE,SW,SG,RS, Sim1,alpha)
%%History matching data assimilation technique 
%%PhD Student: Clement Etienam
%%Supervisor: Dr Rossmary Villegas
%%Co-supervisor: Dr Masoud Babei

%-----------------------------------------------------------------------------
disp( 'History matching data assimilation technique using standard ESMDA for PUNQ Reservoir'  ) 
disp( 'PhD Student: Clement Etienam' )
disp( 'Supervisor: Dr Rossmary Villegas' )
disp( 'Co-supervisor: Dr Masoud Babei' )
disp( 'Advisor: Dr Oliver Dorn' )
disp('  load the files  ');

sgsim1=log(sgsim);
% sgz1=log(sgz);

 sgsim11 = reshape(sgsim1,2660,N);
 
%  load f.dat;
%  N=200;

disp('  generate Gaussian noise for the observed measurments  ');

for i=1:N
    noisewater1(:,i)=normrnd(0,0.000051);
end
for i=1:N
    noisewater2(:,i)=normrnd(0,0.29);
end
for i=1:N
    noisewater3(:,i)=normrnd(0,0.039);
end
for i=1:N
    noisewater4(:,i)=normrnd(0,0.233);
end
for i=1:N
    noisewater5(:,i)=normrnd(0,0.19);
end
for i=1:N
    noisewater6(:,i)=normrnd(0,0.00013);
end


for i=1:N
    noisepressure1(:,i)=normrnd(0,25);
end
for i=1:N
    noisepressure2(:,i)=normrnd(0,40);
end
for i=1:N
    noisepressure3(:,i)=normrnd(0,18.45);
end
for i=1:N
    noisepressure4(:,i)=normrnd(0,41.65);
end
for i=1:N
    noisepressure5(:,i)=normrnd(0,35.2);
end
for i=1:N
    noisepressure6(:,i)=normrnd(0,37.8);
end

for i=1:N
    noisegor1(:,i)=normrnd(0,31.93);

end

for i=1:N
    noisegor2(:,i)=normrnd(0,6.22);
end
for i=1:N
    noisegor3(:,i)=normrnd(0,4.5);
end
for i=1:N
    noisegor4(:,i)=normrnd(0,4.9);
end
for i=1:N
    noisegor5(:,i)=normrnd(0,4.06);
end
for i=1:N
    noisegor6(:,i)=normrnd(0,48.28);
end

for i=1:N
    noiserecovery(:,i)=normrnd(0,0.079);
end
Error1=ones(19,N);
Error1(1,:)=normrnd(0,0.079,1,N);;
Error1(2,:)=normrnd(0,5,1,N);;
Error1(3,:)=normrnd(0,5,1,N);
Error1(4,:)=normrnd(0,5,1,N);
Error1(5,:)=normrnd(0,5,1,N);
Error1(6,:)=normrnd(0,5,1,N);
Error1(7,:)=normrnd(0,5,1,N);
Error1(8,:)= normrnd(0,5,1,N);
Error1(9,:)= normrnd(0,5,1,N);
Error1(10,:)= normrnd(0,4,1,N);
Error1(11,:)= normrnd(0,4,1,N);
Error1(12,:)= normrnd(0,4,1,N);
Error1(13,:)= normrnd(0,4,1,N);
Error1(14,:)=normrnd(0,0.000051,1,N);
Error1(15,:)=normrnd(0,0.2,1,N);
Error1(16,:)=normrnd(0,0.039,1,N);
Error1(17,:)=normrnd(0,0.2,1,N);
Error1(18,:)=normrnd(0,0.19,1,N);
Error1(19,:)=normrnd(0,0.00013,1,N);



Cd2 = (Error1*Error1')./(N-1);


 
MU=zeros(1,19);
R = mvnrnd2(MU,Cd2,N,1);
 R=R';

 
 %for i=1:N
   %  Dj(:,i)=f+((sqrt(alpha).*sqrt(abs(Cd2)))*R(:,i));
	
 %end
 
 for i=1:N
     Dj(:,i)=f+Error1(:,i);
	
 end

 %simulated measurements
%load Sim.uF; %simulated measurements


%Sim1=reshape(Sim,19,200);
disp('  generate the ensemble state matrix containing parameters and states  ');
%overall=zeros(9716,N); %ensemble state for EnKF
overall=zeros(9735,N); %ensemble state for EnKF




overall(1:2660,1:N)=sgsim11;
overall(2661:4424,1:N)=PE;
overall(4425:6188,1:N)=SW;
overall(6189:7952,1:N)=SG;
overall(7953:9716,1:N)=RS;
overall(9717:9735,1:N)=Sim1;





Y=overall; %State variable,it is important we include simulated measurements in the ensemble state variable

M = mean(Sim1,2);
% Mean of the ensemble state
M2=mean(overall,2);
%M=M'
% Get the ensemble states pertubations
for j=1:N
    S(:,j)=Sim1(:,j)-M;
end
for j=1:N
    yprime(:,j)=overall(:,j)-M2;
end


disp('  update the new ensemble  ');
Cyd=(yprime*S')./((N-1));
Cdd=(S*S')./((N-1));


% Get the tolerance range for the pseduo inversion
[Usig,Sig,Vsig] = svd(Cdd+(alpha.*Cd2));
xsmall = diag(Sig);
Bsig = cumsum(xsmall);
valuesig=Bsig(end);
valuesig=valuesig*0.99;
indices = find(cumsum(xsmall) >= valuesig );
toluse=xsmall(indices,:);
tol=toluse(1,:);
%tol=0.01;

%Duc=Dj+((sqrt(alpha).*sqrt(abs(Cd)))*R);

%Update the ensemble state
disp('  update the new ensemble  ');
Ynew=Y+(Cyd*pinv((Cdd+(alpha.*Cd2)),tol))*(Dj-Sim1);
%Ynew=Y+(Cyd/(Cdd+(alpha.*Cd)))*(Dj-Sim1);



disp( 'extract the active permeability field ')
value1=Ynew(1:2660,1:N);


sgsim11=value1;
% sgsim2=value2;
% sgz1=value3;

sgsim11=exp(sgsim11);
sgsim11(sgsim11<=0.4967)=0.4967;
sgsim11(sgsim11>=9500)=9500;

PE=Ynew(2661:4424,1:200);
SW=Ynew(4425:6188,1:200);
SG=Ynew(6189:7952,1:200);
RS=Ynew(7953:9716,1:200);


SW(SW>=1)=1;

SG(SG>=1)=1;


 
DupdateK= sgsim11;
%DupdateK= sgsim1;

disp('  recover the porosity and permz field from Logs  ');
for ii=1:N;
    Knew=reshape(DupdateK(:,ii),19,28,5);
   for j=1:5;
 pore(:,:,1)=0.040228*log(Knew(:,:,1))-0.03101;
pore(:,:,2)=0.022608*log(Knew(:,:,2))+0.0066038;
pore(:,:,3)=0.046974*log(Knew(:,:,3))-0.072764;
pore(:,:,4)=0.025312*log(Knew(:,:,4))+0.01088;
pore(:,:,5)=0.039746*log(Knew(:,:,5))-0.038238;


permz(:,:,1)=0.88227*log(Knew(:,:,1))-0.29112;
permz(:,:,2)=0.89976*log(Knew(:,:,2))-1.1289;
permz(:,:,3)=0.69049*log(Knew(:,:,3))+1.0074;
permz(:,:,4)=0.82778*log(Knew(:,:,4))-0.56077;
permz(:,:,5)=0.97173*log(Knew(:,:,5))-0.74865;

   end
   bigporo=reshape(pore,2660,1);
   bigpermz=reshape(permz,2660,1);
  clementporo(:,ii)=bigporo;
   clementpermz(:,ii)=bigpermz;
end
disp('  exit the loop  ');
disp('  output porosity field  ');
sgsim2=clementporo;
sgsim2(sgsim2<0.01024)=0.01024;
sgsim2(sgsim2>=0.2992)=0.2992;

disp('  output the perm z field from Logs  ');
sgz1=exp(clementpermz);
sgz1(sgz1<=0.1478)=0.1478;
sgz1(sgz1>=498.4011)=498.4011;


end