clc;
clear;
N=200;
history=81;
oldfolder=cd;
cd(oldfolder) % setting original directory


overallsim=zeros(19,history,N);
    for ii=1:N %list of folders 
    
      f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',ii));
    cd(folder)   
    
   A1 = importdata('MASTER0.RSM',' ',7);
   A2 = importdata('MASTER0.RSM',' ',95);
   A3 = importdata('MASTER0.RSM',' ',183);
 
 
 
 A1=A1.data;
 A2=A2.data;
 A3=A3.data;
 
 
 FOE=A1(:,3);
     
	 WBHP1=A1(:,4);
     WBHP2=A1(:,5);
     WBHP3=A1(:,6);
     WBHP4=A1(:,7);
	 WBHP5=A1(:,8);
	 WBHP6=A1(:,9);
	 
     Time=A1(:,1);
	 
	 GORP1=A1(:,10);
     GORP2=A2(:,2);
     GORP3=A2(:,3);
     GORP4=A2(:,4);
	 GORP5=A2(:,5);
	 GORP6=A2(:,6);
	 
	 
     
     WWCT1=A2(:,7);
     WWCT2=A2(:,8);
     WWCT3=A2(:,9);
     WWCT4=A2(:,10);
	 WWCT5=A3(:,2);
	 WWCT6=A3(:,3);

 for i=1:history
 obs=zeros(19,1);
 obs(1,:)=FOE(i,:);
 obs(2,:)=WBHP1(i,:);
 obs(3,:)=WBHP2(i,:);
 obs(4,:)=WBHP3(i,:);
 obs(5,:)=WBHP4(i,:);
 obs(6,:)=WBHP5(i,:);
 obs(7,:)=WBHP6(i,:);
 obs(8,:)=GORP1(i,:);
 obs(9,:)=GORP2(i,:);
 obs(10,:)=GORP3(i,:);
 obs(11,:)=GORP4(i,:);
 obs(12,:)=GORP5(i,:);
 obs(13,:)=GORP6(i,:);
 obs(14,:)=WWCT1(i,:);
 obs(15,:)=WWCT2(i,:);
 obs(16,:)=WWCT3(i,:);
 obs(17,:)=WWCT4(i,:);
 obs(18,:)=WWCT5(i,:);
 obs(19,:)=WWCT6(i,:);
 observationsim(:,i)=obs;
 end
        
   overallsim(:,:,ii)=observationsim; 
    cd(oldfolder) % returning to original directory

    end

    disp('  import the true observation data  ');
 
  True= importdata('Real.RSM',' ',7);
 True2= importdata('Real.RSM',' ',95);
 True3= importdata('Real.RSM',' ',183);
 
 
 True=True.data;
 True2=True2.data;
 True3=True3.data;
 
 
  TP1=True(:,4);
 TP2=True(:,5);
 TP3=True(:,6);
 TP4=True(:,7);
  TP5=True(:,8);
   TP6=True(:,9);
 
 
 TG1=True(:,10);
 TG2=True2(:,2);
 TG3=True2(:,3);
 TG4=True2(:,4);
 TG5=True2(:,5);
  TG6=True2(:,6);
 
 
 
 
  TW1=True2(:,7);
 TW2=True2(:,8);
 TW3=True2(:,9);
 TW4=True2(:,10);
  TW5=True3(:,2);
   TW6=True3(:,3);
 
 
 

 TFOE=True(:,3);
 disp(' make the true observation')
 for ihistory=1:history
 obs=zeros(19,1);
 obs(1,:)=TFOE(ihistory,:);
 obs(2,:)=TP1(ihistory,:);
 obs(3,:)=TP2(ihistory,:);
 obs(4,:)=TP3(ihistory,:);
 obs(5,:)=TP4(ihistory,:);
 obs(6,:)=TP5(ihistory,:);
 obs(7,:)=TP6(ihistory,:);
 obs(8,:)=TG1(ihistory,:);
 obs(9,:)=TG2(ihistory,:);
 obs(10,:)=TG3(ihistory,:);
 obs(11,:)=TG4(ihistory,:);
 obs(12,:)=TG5(ihistory,:);
 obs(13,:)=TG6(ihistory,:);
 obs(14,:)=TW1(ihistory,:);
 obs(15,:)=TW2(ihistory,:);
 obs(16,:)=TW3(ihistory,:);
 obs(17,:)=TW4(ihistory,:);
 obs(18,:)=TW5(ihistory,:);
 obs(19,:)=TW6(ihistory,:);
 observation(:,ihistory)=obs;
 end
    
    
    
    
    
load sgsim.out;
load effective.out;
load rossmary.GRDECL;
load rossmaryporo.GRDECL;
load rossmaryz2.GRDECL;
nx=19;
ny=28;
nz=5;
perm=sgsim;
sgsim=reshape(perm,nx*ny*nz,N);
sgsim=sgsim.*repmat(effective,1,N);
indices=find(sgsim(:,1));
for i=1:N
    a=sgsim(:,i);
 sgactual(:,i)=a(indices);
end

Sim11=reshape(overallsim,19,history,N);

%History matching using ESMDA
for i=1:history
 fprintf('Now assimilating timestep %d .\n', i);

Sim1=Sim11(:,i,:);
Sim1=reshape(Sim1,19,N);

f=observation(:,i);
DupdateK = ESMDA (sgactual,f, 200, Sim1,6,0.99,indices);

sgactual=DupdateK;

 fprintf('Finished assimilating timestep %d \n', i);
end
disp('recover the full permeability field')

DupdateK2=zeros(2660,N);
bb=zeros(2660,1);
for ii=1:N
    
    aperm=DupdateK(:,ii);
   bb(indices)=aperm;
 DupdateK2(:,ii)=bb;

end

disp('  recover the porosity and permz field from Logs  ');
for ii=1:N;
    Knew=reshape(DupdateK2(:,ii),nx,ny,nz);
   for j=1:5;
 pore(:,:,1)=0.040228*log(Knew(:,:,1))-0.03101;
pore(:,:,2)=0.022608*log(Knew(:,:,2))+0.0066038;
pore(:,:,3)=0.046974*log(Knew(:,:,3))-0.072764;
pore(:,:,4)=0.025312*log(Knew(:,:,4))+0.01088;
pore(:,:,5)=0.039746*log(Knew(:,:,5))-0.038238;


permz(:,:,1)=0.88227*log(Knew(:,:,1))-0.29112;
permz(:,:,2)=0.89976*log(Knew(:,:,2))-1.1289;
permz(:,:,3)=0.69049*log(Knew(:,:,3))+1.0074;
permz(:,:,4)=0.82778*log(Knew(:,:,4))-0.56077;
permz(:,:,5)=0.97173*log(Knew(:,:,5))-0.74865;

   end
   bigporo=reshape(pore,nx*ny*nz,1);
   bigpermz=reshape(permz,nx*ny*nz,1);
  clementporo(:,ii)=bigporo;
   clementpermz(:,ii)=bigpermz;
end
clementporo(clementporo<0.01024)=0.01024;
clementporo(clementporo>=0.2992)=0.2992;
sgsim2=clementporo;

disp('  output the perm z field from Logs  ');
sgz1=exp(clementpermz);
sgz1(sgz1<=0.1478)=0.1478;
sgz1(sgz1>=498.4011)=498.4011;

sgsim2=sgsim2.*repmat(effective,1,N);
sgz1=sgz1.*repmat(effective,1,N);

[output,outputporo,outputz] = honour2(rossmary, rossmaryporo,rossmaryz2, N,sgz1,sgsim2,DupdateK2);



mumyperm=output;
mumyporo=outputporo;
mumypermz=outputz;

 disp('  program executed  ');
