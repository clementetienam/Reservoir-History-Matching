function Smean=compteglobalobjective(overallsim,N,observation,history)

%% This code is to calculate the overall objectove function based on Descripancy principle
Sim11=reshape(overallsim,3,history,N);

for i=1:history
    i=6;
 fprintf('Now computing the data match for timestep %d .\n', i);
 f=observation(:,i);
 Sim1=Sim11(:,i,:);
Sim1=reshape(Sim1,3,N);

stddoil=0.0001*f(1,:);
stddwater=0.0001*f(2,:);
stddpressure=0.0001*f(3,:);

disp('  generate Gaussian noise for the observed measurments  ');
Error1=ones(3,1);
Error1(1,:)=stddoil;
Error1(2,:)=stddwater;
Error1(3,:)=stddpressure;
nobs = length(f);
noise = randn(max(10000,nobs),1);
sig=Error1;
R = sig.^2;
Cd2 =diag(R);

for ii = 1 : length(f)
           f(ii) = f(ii) + sig(ii)*noise(end-nobs+ii);
end

  Dj = repmat(f, 1, N);
           for iii = 1:size(Dj,1)
             rndm(iii,:) = randn(1,N); 
             rndm(iii,:) = rndm(iii,:) - mean(rndm(iii,:)); 
             rndm(iii,:) = rndm(iii,:) / std(rndm(iii,:));
             Dj(iii,:) = Dj(iii,:) + sqrt(R(iii)) * rndm(iii,:);
           end

Sobj=(Sim1-Dj)'*Cd2*(Sim1-Dj);
Snoella(:,:,i)=Sobj;
end
Soverall=(sum(Snoella,3))./history;
Svalues=sum(Soverall);
index=Svalues;
jj=min(abs(Svalues));
Smean=mean(sum(Soverall),2);

bestnorm = find(index == min(index));

fprintf('The best Norm Realization for production data match is number %i with value %4.6f \n',bestnorm,jj);
fprintf('The avergae data mismatch values for all the ensemble is %4.6f \n',Smean);
end