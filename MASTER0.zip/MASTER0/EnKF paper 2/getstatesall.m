function [Sall,Pall]=getstatesall(N);


oldfolder=cd;
cd(oldfolder) % setting original directory

%for m=1:2

    for i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',i));
    %folder=oldfolder;
    %cd 'C:\Work\GSLIB\sgsim\EnKFMATLABRun'   
    cd(folder);
    %if m==1  % 1983
        
  
    parfor j=1:16
	 ff = 'MASTER0.F';
   
    %Saturation data lines [2939-5206]
    SW1983 = importdata(strcat(ff, sprintf('%.4d',j)),' ',2938); %change here for 1st and 10th timestep
    SW1983=SW1983.data;
    %SO1983=ones(2268,4)-SW1983;
     A=SW1983;
    B2=Eclipse2Matlab(A);
     B2 = resize(B2,[9072,1]);
	B(:,j)=B2;
    end
    
	 parfor jj=1:16
	 fff = 'MASTER0.F';
    %save('P1983.out','P1983','-ascii');
    %save('SW1983.out','SW1983','-ascii');
    P1983 = importdata(strcat(fff, sprintf('%.4d',jj)),' ',669);
    P1983=P1983.data;
     C=P1983;
	 D2=Eclipse2Matlab(C);
     D2 = resize(D2,[9072,1]);
	 D(:,jj)=D2;
      end
    %Saturation
   
    Sall(:,:,i)=B;
     
	
    Pall(:,:,i)=D;
	
    cd(oldfolder);
    end
   cd(oldfolder) % returning to original directory



end
    %run Assimilate.m % data assimilation