function[output,outputporo] = honour2(rossmary, rossmaryporo, N,sgsim2,DupdateK)
% honour the well permeability and porosity values


% read true permeability well value
unie=reshape(rossmary,84,27,4);
% read true porosity well values
unieporo=reshape(rossmaryporo,84,27,4);
for j=1:4;
    aa(j)=unie(10,10,j);
    bb(j)=unie(70,10,j);
   
end

for j=1:4;
    aa1(j)=unieporo(10,10,j);
    bb1(j)=unieporo(70,10,j);
  
end


% read permeability ensemble after EnKF update
A=reshape(DupdateK,9072,N);
% read porosity ensemble after EnKF update
A1=reshape(sgsim2,9072,N);

% start the conditioning for permeability
for i=1:N;
    %B=reshape(A(:,i),120,60,10);
    B = reshape(A(:,i),84,27,4); 
    %clement=B(i);
    for j=1:4;
    B(10,10,j)=aa(j);
    B(70,10,j)=bb(j);
  
    
    end
    output(:,i)=reshape(B,9072,1); 
    %Aa=reshape(B(i),72000,1);
end

% start the conditioning for porosity
for i=1:N;
    %B=reshape(A(:,i),120,60,10);
    B1 = reshape(A1(:,i),84,27,4); 
    %clement=B(i);
    for j=1:4;
    B1(10,10,j)=aa1(j);
    B1(70,10,j)=bb1(j);
  
    end
    outputporo(:,i)=reshape(B1,9072,1); 
    %Aa=reshape(B(i),72000,1);
end
 output(output>=1500)=1500;
 output(output<=100)=100;
 
 
 outputporo(outputporo>=0.5)=0.5;
 outputporo(outputporo<=0.01)=0.01;
          
 end
%save('SEn83.out','SEn83','-ascii');