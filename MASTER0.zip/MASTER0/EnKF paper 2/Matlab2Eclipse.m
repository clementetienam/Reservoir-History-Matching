%Reshape from matlab to eclipse
function B=Matlab2Eclipse(A)
%Reshape from eclipse to matlab
for i=1:length(A); % array of matlab data
    y=mod(int32(i)-1,4)+1; % value of i
    x=idivide(int32(i)-1,4) + 1; % value of j
    B(x,y)=A(i); % new matrix in eclipse shape

end
end