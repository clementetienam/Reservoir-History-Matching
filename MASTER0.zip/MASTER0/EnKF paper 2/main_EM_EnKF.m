function [mumyperm,mumyporo]=main_EM_EnKF(upsensitivity,nx,ny,nz,N,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,iclement,EMwater,SclementEn89);
% N - size of ensemble
    EMwater=reshape(EMwater,nx*ny*nz,1);
pertubedtruewater=repmat(EMwater,1,N);
for i=1:N
    noiseI(:,i)=normrnd(0,0.04,[9072,1]); % white noise (mean zero & variance one) 
end
pertubedtruewater=abs(pertubedtruewater+ noiseI);
Sim11=reshape(overallsim,3,history,N);

%History matching using ESMDA
iss=iclement;


if iss~=16 % if its not the time step we need to assimilate water saturation data do this
fprintf('Now assimilating timestep %d .\n', iss);


Sim1=Sim11(:,iss,:);
Sim1=reshape(Sim1,3,N);

f=observation(:,iss);

sgsim=reshape(perm,nx*ny*nz,N);
sgsimporo=reshape(poro,nx*ny*nz,N);


nobs = length(f);
noise = randn(max(10000,nobs),1);   
c=15;
A=zeros(84,27,4);
for j=1:4
    A(10,10,j)=1;
    A(70,10,j)=1;
       
end
disp( 'calculate the euclidean distance function to the wells')
    lf=reshape(A,84,27,4);
   for j=1:4;
     sdf=lf(:,:,j);
  [usdf,IDX] = bwdist(sdf);
  usdf=reshape(usdf,2268,1);
  young(:,j)=usdf;
   
   end
   sdfbig=reshape(young,9072,1);
   sdfbig1=abs(sdfbig);
   z=sdfbig1;
   % the value of the range should be computed accurately.
   %c=range(z);
  
  
   c0OIL1=zeros(9072,1);
   disp( 'compute the gaspari-cohn coefficent')
  for i=1:9072;
 if (0<=z(i,:) || z(i,:)<=c)
  c0OIL1(i,:)=-0.25*(z(i,:)/c)^5+0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3-(5.0/3.0)*(z(i,:)/c)^2+1;
elseif z < 2*c
  c0OIL1(i,:)=(1.0/12.0)*(z(i,:)/c)^5-0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3+(5.0/3.0)*(z(i,:)/c)^2-5*(z(i,:)/c)+4-(2.0/3.0)*(c/z(i,:));
 elseif (c<=z(i,:) || z(i,:)<=2*c)
     c0OIL1(i,:)=-5*(z(i,:)/c)+4-0.667*(c/z(i,:));
 else
     c0OIL1(i,:)=0;
 end
  
  end
  
c0OIL1(c0OIL1<0)=0;
  

 disp(' get the gaspari cohn') 
 
    schurr=c0OIL1;

% schur becomes our tunning matrix to the updates from the kalman gain

Bsch = repmat(schurr,1,N);
  
  yoboschur=ones(18144,N);
 
  yoboschur(1:9072,:)=Bsch;
  yoboschur(9073:18144,:)=Bsch; % this is the gaspari cohn covariance matrix


sgsim=log(sgsim);
 sgsim = reshape(sgsim,9072,N);
sgsimporo = reshape(sgsimporo,9072,N);

disp(' determine the standard deviation for measurement pertubation')
stddoil=0.001*f(1,:);
stddwater=0.001*f(2,:);
stddpressure=0.001*f(3,:);


disp('  generate Gaussian noise for the observed measurments  ');

Error1=ones(3,N);
Error1(1,:)=normrnd(0,stddoil,1,N);
Error1(2,:)=normrnd(0,stddwater,1,N);
Error1(3,:)=normrnd(0,stddpressure,1,N);

Error11=ones(3,1);
Error11(1,:)=stddoil;
Error11(2,:)=stddwater;
Error11(3,:)=stddpressure;

sig=Error11;
for i = 1 : length(f)
           f(i) = f(i) + sig(i)*noise(end-nobs+i);
end
R = sig.^2;


  Dj = repmat(f, 1, N);
           for i = 1:size(Dj,1)
             rndm(i,:) = randn(1,N); 
             rndm(i,:) = rndm(i,:) - mean(rndm(i,:)); 
             rndm(i,:) = rndm(i,:) / std(rndm(i,:));
             Dj(i,:) = Dj(i,:) + sqrt(R(i)) * rndm(i,:);
           end


Cd2 =diag(R);

disp('  generate the ensemble state matrix containing parameters and states  ');

overall=zeros(18144,N); 

overall(1:9072,1:N)=sgsim;
overall(9073:18144,1:N)=sgsimporo;
%overall(18145:18147,1:N)=Sim1;
Y=overall; %State variable,it is important we include simulated measurements in the ensemble state variable

% Get the ensemble states pertubations
S = Sim1-repmat(mean(Sim1,2),1,N);
yprime=Y - repmat(mean(Y,2),1,N);

disp('  update the new ensemble  ');
unie=S;
%Sim=H*Y;
unie2=S;
[U0,Z0,V0] = svd(unie2,'econ');
joy2=Z0*Z0';
X1=pinv2(joy2)*U0';
% Residual vector
X2=X1*(Dj-Sim1);

X3=U0*X2;

X4=unie'*X3;
update=(yprime*X4);
Ynew=Y+(update);
disp( 'extract the active permeability field ')
value1=Ynew(1:9072,1:N);

DupdateK=exp(value1);
Dupdateporo=Ynew(9073:18144,1:N);

else %do the next command where we assimilate water saturation using covaraiance localization and sensitivity function
SclementEn89=reshape(SclementEn89,nx*ny*nz,N);
Sim1=Sim11(:,iss,:);
Sim1=reshape(Sim1,3,N);

f=observation(:,iss);

sgsim=reshape(perm,nx*ny*nz,N);
sgsimporo=reshape(poro,nx*ny*nz,N);
c=10; % radius round the well
A=zeros(84,27,4);
for j=1:4
    A(10,10,j)=1;
    A(70,10,j)=1;
       
end
disp( 'calculate the euclidean distance function to the wells')
    lf=reshape(A,84,27,4);
   for j=1:4;
     sdf=lf(:,:,j);
  [usdf,IDX] = bwdist(sdf);
  usdf=reshape(usdf,2268,1);
  young(:,j)=usdf;
   
   end
   sdfbig=reshape(young,9072,1);
   sdfbig1=abs(sdfbig);
   z=sdfbig1;
   % the value of the range should be computed accurately.
   %c=range(z);
  
  
   c0OIL1=zeros(9072,1);
   disp( 'compute the gaspari-cohn coefficent')
  for i=1:9072;
 if (0<=z(i,:) || z(i,:)<=c)
  c0OIL1(i,:)=-0.25*(z(i,:)/c)^5+0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3-(5.0/3.0)*(z(i,:)/c)^2+1;
elseif z < 2*c
  c0OIL1(i,:)=(1.0/12.0)*(z(i,:)/c)^5-0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3+(5.0/3.0)*(z(i,:)/c)^2-5*(z(i,:)/c)+4-(2.0/3.0)*(c/z(i,:));
 elseif (c<=z(i,:) || z(i,:)<=2*c)
     c0OIL1(i,:)=-5*(z(i,:)/c)+4-0.667*(c/z(i,:));
 else
     c0OIL1(i,:)=0;
 end
  
  end
  
c0OIL1(c0OIL1<0)=0;
  
disp( 'add the gaspari cohn matrix with the sensitivity functions')    
 thetwoclementt=c0OIL1+upsensitivity;
% rescale it
thetwoclementt=reshape(thetwoclementt,9072,1);
disp('rescale it to be between 1 and 0')
for i=1:9072
schur(i)=(thetwoclementt(i)-min(thetwoclementt))/(max(thetwoclementt)-min(thetwoclementt));
end
schur=schur';

    %schur=c0OIL1;

Bsch = repmat(schur,1,N);
  
  yoboschur=ones(18144,N);
 
  yoboschur(1:9072,:)=Bsch;
  yoboschur(9073:18144,:)=Bsch;
  
sgsim=log(sgsim);
 sgsim = reshape(sgsim,9072,N);
sgsimporo = reshape(sgsimporo,9072,N);

disp(' determine the standard deviation for measurement pertubation')
stddoil=0.001*f(1,:);
stddwater=0.001*f(2,:);
stddpressure=0.001*f(3,:);


for i=1:N
    noiseI(:,i)=normrnd(0,0.04,[9072,1]); % white noise (mean zero & variance one) 
end

nobs = length(f);
noise = randn(max(10000,nobs),1);   


disp('  generate Gaussian noise for the observed measurments  ');

Error1=ones(3,N);
Error1(1,:)=normrnd(0,stddoil,1,N);
Error1(2,:)=normrnd(0,stddwater,1,N);
Error1(3,:)=normrnd(0,stddpressure,1,N);


Erroroverall=zeros(9075,N);
Erroroverall(1:3,:)=Error1;
Erroroverall(4:9075,:)=noiseI;


Error11=ones(3,1);
Error11(1,:)=stddoil;
Error11(2,:)=stddwater;
Error11(3,:)=stddpressure;

sig=Error11;
for i = 1 : length(f)
           f(i) = f(i) + sig(i)*noise(end-nobs+i);
end
R = sig.^2;


  Dj = repmat(f, 1, N);
           for i = 1:size(Dj,1)
             rndm(i,:) = randn(1,N); 
             rndm(i,:) = rndm(i,:) - mean(rndm(i,:)); 
             rndm(i,:) = rndm(i,:) / std(rndm(i,:));
             Dj(i,:) = Dj(i,:) + sqrt(R(i)) * rndm(i,:);
           end


 
Djoverall=zeros(9075,N);
Djoverall(1:3,:)=Dj;
Djoverall(4:9075,:)=pertubedtruewater;
Simoverall=zeros(9075,N);
Simoverall(1:3,:)=Sim1;
Simoverall(4:9075,:)=SclementEn89;
disp('  generate the ensemble state matrix containing parameters and states  ');

overall=zeros(18144,N); 

overall(1:9072,1:N)=sgsim;
overall(9073:18144,1:N)=sgsimporo;

%overall(18145:27216,1:N)=Simoverall;

Y=overall; %State variable,it is important we include simulated measurements in the ensemble state variable

S = Simoverall-repmat(mean(Simoverall,2),1,N);
yprime=Y - repmat(mean(Y,2),1,N);

disp('  update the new ensemble  ');
unie=S;
%Sim=H*Y;
unie2=S+Erroroverall;
[U0,Z0,V0] = svd(unie2,'econ');
joy2=Z0*Z0';
X1=pinv2(joy2)*U0';
% Residual vector
X2=X1*(Djoverall-Simoverall);

X3=U0*X2;

X4=unie'*X3;
update=yprime*X4;
%Update the ensemble state
Ynew=Y+(yoboschur.*update);

disp( 'extract the active permeability field ')
value1=Ynew(1:9072,1:N);

DupdateK=exp(value1);
Dupdateporo=Ynew(9073:18144,1:N);
end % exit the if then statement


sgsimout=DupdateK;
sgsimporoout=Dupdateporo;
 
[output,outputporo] = honour2(rossmary, rossmaryporo, N,sgsimporoout,sgsimout);

mumyperm=output;
mumyporo=outputporo;

end
 