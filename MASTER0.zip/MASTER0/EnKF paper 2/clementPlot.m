%%This code is to plot all the ensemble permeability field data at once

function [bestnorm3,PlogK]=clementPlot(nx,ny,nz, iProd, jProd,mumyperm,rossmary,N,bestnorm3,iclement);
disp( 'PhD Student: Clement Etienam' )
disp( 'Supervisor: Dr Rossmary Villegas' )
disp( 'Co-supervisor: Dr Masoud Babei' )
disp( 'Co-supervisor: Dr Oliver Dorn' )
disp('  Load the relevant files  ');


disp(' extract the active grid cells' )
sgsim=reshape(mumyperm,9072,N);
perm=sgsim;

   disp(' get the dissimilarity for permeability reconstruction')
 
True=(rossmary);

%True(True==0)=NaN;


Ause=perm;
A1=(Ause);


for i=1:N
    J(:,i)=sqrt(((A1(:,i)-True).^2)./9072);
end
for i=1:N
test(i,:)=sum(abs((J(:,i))));
end
reali=[1:N]';

jj3=min(test);
index3 = test; 
bestnorm3 = find(index3 == min(index3));
	%Pssim = Pnew(:,bestssim); %best due to ssim

fprintf('The best Norm Realization for Log(K) reconstruction  is number %i with value %4.4f \n',bestnorm3,jj3);




 PlogK = reshape(A1(:,bestnorm3),84,27,4);
 

  



Trueperm=reshape(True,84,27,4);


yobo1=figure()

h1=subplot(4,4,1);

%surf(X',Y',Trueperm(:,:,1))
imagesc(reshape(Trueperm(:,:,1), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([100 1100])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [100 1100])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('True Layer 1','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h1,direction,180)
 
 
h2=subplot(4,4,2);
imagesc(reshape(Trueperm(:,:,2), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([100 1100])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [100 1100])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('True Layer 2','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h2,direction,180)

h3=subplot(4,4,3);
imagesc(reshape(Trueperm(:,:,3), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([100 1100])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [100 1100])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('True Layer 4','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h3,direction,180)
 
h4=subplot(4,4,4);
imagesc(reshape(Trueperm(:,:,4), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([100 1100])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [100 1100])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('True Layer 4','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h4,direction,180)


	
	
h6=subplot(4,4,5);
imagesc(reshape(PlogK(:,:,1), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([100 1100])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [100 1100])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('BestLog(K)-1','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h6,direction,180)

h7=subplot(4,4,6);
imagesc(reshape(PlogK(:,:,2), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([100 1100])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [100 1100])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('BestLog(K)-2','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h7,direction,180)

h8=subplot(4,4,7);
imagesc(reshape(PlogK(:,:,3), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([100 1100])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [100 1100])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('BestLog(K)-3','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h8,direction,180)


h9=subplot(4,4,8);
imagesc(reshape(PlogK(:,:,4), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([100 1100])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [100 1100])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('BestLog(K)-4','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h9,direction,180)



disp(' plot the mean of the ensemble')
A1=reshape(A1,9072,N);
A12mean=mean(A1,2);
A12mean=reshape(A12mean,84,27,4);
A1mean=reshape(A1(:,bestnorm3),84,27,4);


h11=subplot(4,4,9);
imagesc(reshape(A1mean(:,:,1), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([100 1100])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [100 1100])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('Layer 1-prod','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h11,direction,180)

h12=subplot(4,4,10);
imagesc(reshape(A1mean(:,:,2), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([100 1100])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [100 1100])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('Layer 2-prod','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h12,direction,180)

h13=subplot(4,4,11);
imagesc(reshape(A1mean(:,:,3), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([100 1100])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [100 1100])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('Layer 3-prod','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h13,direction,180)

h14=subplot(4,4,12);
imagesc(reshape(A1mean(:,:,4), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([100 1100])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [100 1100])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('Layer 4-prod','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h14,direction,180)



h16=subplot(4,4,13);

imagesc(reshape(A12mean(:,:,1), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([100 1100])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [100 1100])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('Layer 1-mean','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h11,direction,180)

h17=subplot(4,4,14);
imagesc(reshape(A12mean(:,:,2), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([100 1100])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [100 1100])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('Layer 2-mean','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h17,direction,180)

h18=subplot(4,4,15);
imagesc(reshape(A12mean(:,:,3), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([100 1100])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [100 1100])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('Layer 1-mean','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h18,direction,180)

 h19=subplot(4,4,16);
 imagesc(reshape(A12mean(:,:,4), nx, ny)')
hold on
plot(iProd, jProd, 'ok', 'MarkerFaceColor',[0 0 0], 'MarkerSize',8);
shading flat
grid off
colormap('jet')
caxis([100 1100])
h = colorbar;
ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
set(h, 'ylim', [100 1100])
set(gca, 'ydir', 'normal'); % put origin in the bottom left corner (normal location) 
axis equal tight
title('Layer 1-mean','FontName','Helvetica', 'Fontsize', 13);
ylabel('Y', 'FontName','Helvetica', 'Fontsize', 13);
xlabel('X', 'FontName','Helvetica', 'Fontsize', 13);
set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
 direction = [1 0];
 rotate(h19,direction,180)
 
 
 saveas(gcf,sprintf('analyse2D_iter%d.fig',iclement))
  saveas(gcf,sprintf('analyse2D_iter%d.eps',iclement))
%hfig = tightfig(yobo1);
close(figure)



G2=cartGrid([84 27 4]);

yobo1=figure();
subplot(2,2,1);
plotCellData(G2,reshape(Trueperm,9072,1));
view(3)
axis equal on
title('True','FontName','Helvetica', 'Fontsize', 13);
grid off
shading flat
caxis([100 1100])
colormap('jet')
% h = colorbar;
% ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
% set(h, 'ylim', [1 5])
hold on
plot3([10 10],[10 10],[1 -8],'k','Linewidth',2);
text(  10,10,-10,'I','HorizontalAlignment','left','FontSize',11)
hold on
plot3([70 70],[10 10],[1 -8],'r','Linewidth',2);
text(  70,10, -9,'P','Fontsize', 11)

set(gcf,'color','white')
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca,'zticklabel',[])



subplot(2,2,2);
%redd=slice(PlogK,[1 60],[1 120],[1 5]);
plotCellData(G2,reshape(PlogK,9072,1));
view(3)
axis equal on
title('Best Log','FontName','Helvetica', 'Fontsize', 13);
grid off
shading flat
caxis([100 1100])
colormap('jet')
hold on
plot3([10 10],[10 10],[1 -8],'r','Linewidth',2);
text(  10,10,-10,'I','HorizontalAlignment','left','FontSize',11)
hold on
plot3([70 70],[10 10],[1 -8],'k','Linewidth',2);
text(  70,10, -9,'P','Fontsize', 11)

set(gcf,'color','white')
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca,'zticklabel',[])

subplot(2,2,3);
%redd=slice(PlogK,[1 60],[1 120],[1 5]);
plotCellData(G2,reshape(A1mean,9072,1));
view(3)
axis equal on
title('Best Production','FontName','Helvetica', 'Fontsize', 13);
grid off
shading flat
caxis([100 1100])
colormap('jet')
% h = colorbar;
% ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
% set(h, 'ylim', [1 5])
hold on
plot3([10 10],[10 10],[1 -8],'k','Linewidth',2);
text(  10,10,-10,'I','HorizontalAlignment','left','FontSize',11)
hold on
plot3([70 70],[10 10],[1 -8],'r','Linewidth',2);
text(  70,10, -9,'P','Fontsize', 11)

set(gcf,'color','white')
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca,'zticklabel',[])

subplot(2,2,4);
%redd=slice(PlogK,[1 60],[1 120],[1 5]);
plotCellData(G2,reshape(A12mean,9072,1));
view(3)
axis equal on
title('Mean','FontName','Helvetica', 'Fontsize', 13);
grid off
shading flat
caxis([100 1100])
colormap('jet')
% h = colorbar;
% ylabel(h, 'Log K(mD)','FontName','Helvetica', 'Fontsize', 13);
% set(h, 'ylim', [1 5])
hold on
plot3([10 10],[10 10],[1 -8],'k','Linewidth',2);
text(  10,10,-10,'I','HorizontalAlignment','left','FontSize',11)
hold on
plot3([70 70],[10 10],[1 -8],'r','Linewidth',2);
text(  70,10, -9,'P','Fontsize', 11)

set(gcf,'color','white')
set(gcf,'color','white')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca,'zticklabel',[])

hfig = tightfig(yobo1);

saveas(gcf,sprintf('analyse3D_iter%d.fig',iclement))
close(figure)

file2 = fopen('bestlog.out','w+'); %output the dictionary
for k=1:numel(PlogK)                                                                       
fprintf(file2,' %4.6f \n',PlogK(k) );             
end

% file = fopen('meanK.out','w+');
%  for k=1:numel(A1mean)                                                                       
%  fprintf(file,' %4.6f \n',A1mean(k) );             
%  end
 
 file3 = fopen('bestRMS.out','w+');
 for k=1:numel(A1mean)                                                                       
 fprintf(file3,' %4.6f \n',A1mean(k) );             
 end
end
%run('testvar.m')