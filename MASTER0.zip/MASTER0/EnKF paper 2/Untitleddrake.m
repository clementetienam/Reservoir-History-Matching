clc;
clear;
close all;
syms x
a=[ 3 2 1];
b=diag(a);
eqn = (x*x') == (99.*b);
solx = solve(eqn,x);
