function [mumyperm,mumyporo]=main_EnKF_Localization(nx,ny,nz,N,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,iyobo,Sall,Pall); 
sgsim=reshape(perm,nx*ny*nz,N);
sgsimporo=reshape(poro,nx*ny*nz,N);

Sall=reshape(Sall,nx*ny*nz,history,N);
Pall=reshape(Pall,nx*ny*nz,history,N);
Sim11=reshape(overallsim,3,history,N);

%History matching using ESMDA
 iss=1:iyobo;
 fprintf('Now assimilating timestep %d .\n', iss);

Sim1=Sim11(:,iss,:);
Sim1=reshape(Sim1,3,N);


Saturation=Sall(:,iss,:);
Saturation=reshape(Saturation,nx*ny*nz,N);


Pressure=Pall(:,iss,:);
Pressure=reshape(Pressure,nx*ny*nz,N);


f=observation(:,iss);
[DupdateK,Dupdateporo] = ESMDA_Localization (sgsim,sgsimporo,f, N, Sim1,alpha,10,Saturation,Pressure);


disp('recover the full permeability and porosity field')


[output,outputporo] = honour2(rossmary, rossmaryporo, N,Dupdateporo,DupdateK);

mumyperm=output;
mumyporo=outputporo;


 disp('  program executed  ');
end
 