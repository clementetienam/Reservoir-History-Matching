function [mumyperm,mumyporo]=main_sparsity(nx,ny,nz,N,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha,Yes2PUNQ,Yes2PUNQporo);


sgsim=reshape(perm,nx*ny*nz,N);
sgsimporo=reshape(poro,nx*ny*nz,N);


sgsparse=Sparse(sgsim,Yes2PUNQ);
sgsparseporo=Sparse(sgsimporo,Yes2PUNQporo);

Sim11=reshape(overallsim,3,history,N);

%History matching using ESMDA
for i=1:history
 fprintf('Now assimilating timestep %d .\n', i);

Sim1=Sim11(:,i,:);
Sim1=reshape(Sim1,3,N);

f=observation(:,i);
[DupdateK,Dupdateporo] = ESMDA_sparsity (sgsparse,sgsparseporo,f, N, Sim1,alpha);

sgsparse=DupdateK;
sgsparseporo=Dupdateporo;
 fprintf('Finished assimilating timestep %d \n', i);
end
disp('recover the full permeability and porosity field')

joyyperm=reshape(Yes2PUNQ,9072,1500)*sgsparse;
joyyporo=reshape(Yes2PUNQporo,9072,1500)*sgsparseporo;


[output,outputporo] = honour2(rossmary, rossmaryporo, N,joyyporo,joyyperm);

mumyperm=output;
mumyporo=outputporo;


 disp('  program executed  ');
end
 