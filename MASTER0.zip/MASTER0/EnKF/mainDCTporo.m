function clement2 = mainDCTporo(sg, N)
%% DCT domain reduction for permeability field
disp('  DCT domain reduction for permeability  ');
%%PhD student: Clement Oku Etienam
%%Supervisor: Dr Rossmary Villegas
%%Co-supervisor: Dr Masoud Babei
%%Collaborator : Dr Oliver Dorn
disp('  Load the relevant files  ');

sgsim=(sg);
LF=reshape(sgsim,9072,N);
disp('  carry out DCT domain reduction  ');
for ii=1:N
    lf=reshape(LF(:,ii),84,27,4);
     for jj=1:4
         value=lf(:,:,jj);
         usdf=mirt_dctn(value);
         usdf=reshape(usdf,2268,1);
         young(:,jj)=usdf;
     end
      sdfbig=reshape(young,9072,1);
  clement(:,ii)=sdfbig;
end
disp('  extract the significant DCT coefficients  ');
clement=reshape(clement,9072,N);
for iii=1:N
    lf2=reshape(clement(:,iii),84,27,4);
for jjj=1:4
    val1=lf2(1:40,1:15,jjj);
    val1=reshape(val1,600,1);
   val2(:,jjj)=val1;
end
  sdfbig2=reshape(val2,2400,1);
  clement2(:,iii)=sdfbig2;
end


end