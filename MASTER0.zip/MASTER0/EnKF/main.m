%----------------------------------------------------------------------------------
% History matching using serveral methods with EnKF
% Running Ensembles
% the code couples ECLIPSE reservoir simulator with MATLAB used to implement my ideas on history matching of
% The MASTER0 Reservoir.
% Extra source of data is 4D seismic data and Electromagnetic data inveretd
% to water saturation using our Kazsmarz equation
% Author: Clement Etienam ,PhD Petroleum Engineering 2015-2018
% Supervisor:Dr Rossmary Villegas
% Co-Supervisor: Dr Masoud Babei
% Co-Supervisor: Dr Oliver Dorn
%-----------------------------------------------------------------------------------
%% 

clc
clear
disp('choose from the methods listed below for history matching with ESMDA')
disp('1-main_EnKF')
disp('2-main_EnKF_direct')


method=input(' Enter the  required data assimilation scheme method  ');

% N - size of ensemble

N=input( ' enter the number of realizations(ensemble size)  '); %100
nx=input( ' enter the number of grid blocks in x direction  '); %84
ny=input( ' enter the number of grid blocks in y direction  '); %27
nz=input( ' enter the number of grid blocks in z direction  '); % 4

% alpha is the number of iteration and damping coefficient
history=input(' enter the number of timestep for the history period '); %16

disp( 'Load the true permeability and porosity')
load rossmary.GRDECL; %true permeability field
load rossmaryporo.GRDECL; %True porosity field
oldfolder=cd;
cd(oldfolder) % setting original directory
disp('  import the true observation data  ');
 
  True= importdata('Real.RSM',' ',7);
 
 True=True.data;

 
  TO1=True(:,6);
 TW1=True(:,8);
 TP1=True(:,9);

 
 
 disp(' make the true observation')
 for ihistory=1:history
 obs=zeros(3,1);
 obs(1,:)=TO1(ihistory,:);
 obs(2,:)=TW1(ihistory,:);
 obs(3,:)=TP1(ihistory,:);
 observation(:,ihistory)=obs;
 end
 
%% extract the true water for base survey
 true31 = importdata('true.F0001',' ',2938); %true water sat for year 83
 true31=true31.data;
 truewater83=true31;
 SO=ones(2268,4)-true31;

truepressure = importdata('true.F0001',' ',669);
truepressure=truepressure.data;
truepressure83=truepressure;
Pr=truepressure83;
PORO = importdata('porojoy.DAT',' ',1); % true porosity field
 PORO=PORO.data;
ImpP=Gassmann(PORO,Pr,SO);
ImpP83=reshape(ImpP,2268,1); % True impedance at year 83;

trueimpedance83=repmat(ImpP83,1,N);
%% extract true water and impedance for monitor survey
true32 = importdata('true.F0016',' ',2938); %true water sat for the time 89 timestep
true32=true32.data;
truewater89=true32;
SO=ones(2268,4)-true32;
truepressure89 = importdata('true.F0016',' ',669);
truepressure89=truepressure89.data;
 Pr=truepressure89;
 PORO = importdata('porojoy.DAT',' ',1);
 PORO=PORO.data;
ImpP=Gassmann(PORO,Pr,SO);
ImpP89=reshape(ImpP,2268,1);
trueimpedance89=repmat(ImpP89,1,N);
EMwater=truewater89; % for history matching electromagnetic data
%   for i=1:N
%   noiseimp(:,i)=normrnd(0,20); % white noise (mean zero & variance one) 
%   end

oldfolder=cd;

%% Creating Folders
disp( 'create the folders')
for j=1:N
f = 'MASTER';
folder = strcat(f, sprintf('%.5d',j));
mkdir(folder);
end

%% Coppying simulation files
disp( 'copy simulation files for the forward problem')
for j=1:N
f = 'MASTER';
folder = strcat(f, sprintf('%.5d',j));
copyfile('FAULT.DAT',folder)
copyfile('MASTER0.DATA',folder)
copyfile('Gassmann.m',folder)
copyfile('field2Metric.m',folder)
copyfile('Eclipse2Matlab.m',folder)
copyfile('Matlab2Eclipse.m',folder)
copyfile('resize.m',folder)
end
%% Machine Learning part
% disp( 'Loading the overcomplete dictionary of permeability')
% load Yes2.out; %Permeability dictionary
% load Yes2poro.out; %porosity dictionary


%% The big history matching iterative loop will start here
tic;
for inelly=1:history
fprintf('Now running the code for iteration %d .\n', inelly);   
%% Loading Porosity and Permeability ensemble files
disp(' load the permeability and porosity fields')
if inelly==1
    disp( 'permeability loaded from initial ensemble')
load sgsimporo.out; %initial porosity
load sgsim.out; %initial permeabiity

perm=reshape(sgsim,nx*ny*nz,N);
poro=reshape(sgsimporo,nx*ny*nz,N);


else
 disp( 'permeability loaded from UPDATED ensemble')
 perm=reshape(mumyperm,nx*ny*nz,N);
 poro=reshape(mumyporo,nx*ny*nz,N);

end
cd(oldfolder) % setting original directory

%% Saving POROVANCOUVER and KVANCOUVER

for i=1:N %list of folders 
    
    f = 'MASTER';
   folder = strcat(f, sprintf('%.5d',i));
   
    cd(folder) % changing directory 
    
    PORO2=poro(:,i);
    PERMX2=perm(:,i);
   
    
    save('KVANCOUVER.DAT','PERMX2','-ascii');
    save('POROVANCOUVER.DAT','PORO2','-ascii');
    
    cd(oldfolder) % returning to original cd
    
end

%% Inserting KEYWORDS PORO and PERMY 

parfor i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',i));
    cd(folder)

CStr = regexp(fileread('KVANCOUVER.DAT'), char(10), 'split');
CStr2 = strrep(CStr, 'toReplace', 'Replacement');
CStr2 = cat(2, {'PERMY'}, CStr2(1:end));
CStr2 = cat(2, CStr2(1:end), {'/'});
FID = fopen('KVANCOUVER.DAT', 'w');
if FID < 0, error('Cannot open file'); end
fprintf(FID, '%s\n', CStr2{:});
fclose(FID);

CStr = regexp(fileread('POROVANCOUVER.DAT'), char(10), 'split');
CStr2 = strrep(CStr, 'toReplace', 'Replacement');
CStr2 = cat(2, {'PORO'}, CStr2(1:end));
CStr2 = cat(2, CStr2(1:end), {'/'});
FID = fopen('POROVANCOUVER.DAT', 'w');
if FID < 0, error('Cannot open file'); end
fprintf(FID, '%s\n', CStr2{:});
fclose(FID);

cd(oldfolder) % setting original directory

end


%% Running Simulations
disp( 'Solve the Non-Linear fluid flow Forward Problem' )
cd(oldfolder) % setting original directory

parfor i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',i));
    cd(folder)   

    fid = fopen('MASTER0.bat', 'w');
    fprintf(fid,'@ECHO OFF\n');
    % fprintf(fid,'SET SLBSLS_LICENSE_FILE=27008@eclipse.cc.ic.ac.uk\n');
    fprintf(fid,'SET SLBSLS_LICENSE_FILE=27000@10.99.15.78\n');
    fprintf(fid,'@ECHO OFF\n');
    fprintf(fid,['c:\\ecl\\macros\\$eclipse ', 'MASTER0'],'\n');
    fclose(fid);
    %while ~exist('MASTER0.F0016','file')
        system('MASTER0.bat')
    %end

    cd(oldfolder) % setting original directory
    
end
disp(' plot production profile for the run')
index=plotproduction(N,inelly);
decreasingnorm(:,inelly)=index;
 
 
 %% disp( 'Get the simulated files for all the time step')
disp( 'Get the simulated files for all the time step')



oldfolder=cd;
cd(oldfolder) % setting original directory


overallsim=zeros(3,history,N);
    for ii=1:N %list of folders 
    
      f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',ii));
    cd(folder)   
    
  True= importdata('MASTER0.RSM',' ',7);
 
 True=True.data;
 
 TO1=True(:,3);
 TW1=True(:,5);
 TP1=True(:,6);

 for i=1:history
 obs=zeros(3,1);
 obs(1,:)=TO1(i,:);
 obs(2,:)=TW1(i,:);
 obs(3,:)=TP1(i,:);
 observationsim(:,i)=obs;
 end
        
   overallsim(:,:,ii)=observationsim; 
    cd(oldfolder) % returning to original directory

    end
disp(' done saving simulated production data')
cd(oldfolder) % returning to original directory
%% Saving Pressure & Saturation Ensemble 

%cd(oldfolder) % setting original directory

%for m=1:2

[PclementEn83,SclementEn83,PclementEn89,SclementEn89]=getitnow(100);
    
 %cd(oldfolder)

PclementEn83=reshape(PclementEn83,nx*ny*nz*N,1); %pressure ensemble initial
SclementEn83=reshape(SclementEn83,nx*ny*nz*N,1); %water saturation ensemble initial

PclementEn89=reshape(PclementEn89,nx*ny*nz*N,1); %pressure ensemble final
SclementEn89=reshape(SclementEn89,nx*ny*nz*N,1); %water saturation ensemble final

cd(oldfolder) % returning to original directory

disp( 'save the ensemble to see how good')
pressureensemble83(:,inelly)=PclementEn83;
pressureensemble89(:,inelly)=PclementEn89;
saturationensemble83(:,inelly)=SclementEn83;
saturationensemble89(:,inelly)=SclementEn89;

% save('PEn83.out','PEn83','-ascii');
% save('SEn83.out','SEn83','-ascii');
% save('PEn89.out','PEn89','-ascii');
% save('SEn89.out','SEn89','-ascii');

%% Construction of Synthetic Seismic using Gassmann's equation
disp('Construction of Synthetic Seismic using Gassmanns equation')
[IEn83,IEn89]=getitimp(N,nx,ny,nz);


[Sall,Pall]=getstatesall(N);
%% Enter the assimilation loop
disp('now entering the assimilation loop')
  
switch method
    case 1
 disp( 'method 1 specified-standard EnKF')
[mumyperm,mumyporo]=main_EnKF(nx,ny,nz,N,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,inelly,EMwater,SEn89,Sall,Pall);
   case 2
   disp( 'method 2 specified-Localization with EnKF')       
[mumyperm,mumyporo]=main_EnKF_Localization(nx,ny,nz,N,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,inelly,Sall,Pall); 
    case 3
 disp( 'method 3 specified-DCT')   
[mumyperm,mumyporo]=main_DCT(nx,ny,nz,N,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,inelly,Sall,Pall);
 
    case 4
     disp( 'method 4 specified-Sparsity')    
[mumyperm,mumyporo]=main_sparsity(nx,ny,nz,N,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,inelly,Yes2PUNQ,YesPUNQporo,Sall,Pall);
      
    otherwise
        disp('method not specified correctly')
end

perm=reshape(mumyperm,nx*ny*nz,N);
 poro=reshape(mumyporo,nx*ny*nz,N);

fprintf('Finished Iteration %d .\n', inelly);
end
 %% Exit the loop
 %% Now run the code to see the final history matcing step
 disp( 'now run the code after the last Iteration to see how good')
 fprintf('Get the RMS after exiting the loop');   
%% Loading Porosity and Permeability ensemble files
disp(' use the permeability and porosity fields after Last iteration')

%  perm=reshape(mumyperm,72000,N);
%  poro=reshape(mumyporo,72000,N);   

cd(oldfolder) % setting original directory
for i=1:N %list of folders 
    
    f = 'MASTER';
   folder = strcat(f, sprintf('%.5d',i));
   
    cd(folder) % changing directory 
    
    PORO2=poro(:,i);
    PERMX2=perm(:,i);
   
    
    save('KVANCOUVER.DAT','PERMX2','-ascii');
    save('POROVANCOUVER.DAT','PORO2','-ascii');
    
    cd(oldfolder) % returning to original cd
    
end

%% Inserting KEYWORDS PORO and PERMY 

parfor i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',i));
    cd(folder)

CStr = regexp(fileread('KVANCOUVER.DAT'), char(10), 'split');
CStr2 = strrep(CStr, 'toReplace', 'Replacement');
CStr2 = cat(2, {'PERMY'}, CStr2(1:end));
CStr2 = cat(2, CStr2(1:end), {'/'});
FID = fopen('KVANCOUVER.DAT', 'w');
if FID < 0, error('Cannot open file'); end
fprintf(FID, '%s\n', CStr2{:});
fclose(FID);

CStr = regexp(fileread('POROVANCOUVER.DAT'), char(10), 'split');
CStr2 = strrep(CStr, 'toReplace', 'Replacement');
CStr2 = cat(2, {'PORO'}, CStr2(1:end));
CStr2 = cat(2, CStr2(1:end), {'/'});
FID = fopen('POROVANCOUVER.DAT', 'w');
if FID < 0, error('Cannot open file'); end
fprintf(FID, '%s\n', CStr2{:});
fclose(FID);

cd(oldfolder) % setting original directory

end


%% Running Simulations
disp( 'Solve the Non-Linear fluid flow Forward Problem' )
cd(oldfolder) % setting original directory

parfor i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',i));
    cd(folder)   

    fid = fopen('MASTER0.bat', 'w');
    fprintf(fid,'@ECHO OFF\n');
    % fprintf(fid,'SET SLBSLS_LICENSE_FILE=27008@eclipse.cc.ic.ac.uk\n');
    fprintf(fid,'SET SLBSLS_LICENSE_FILE=27000@10.99.15.78\n');
    fprintf(fid,'@ECHO OFF\n');
    fprintf(fid,['c:\\ecl\\macros\\$eclipse ', 'MASTER0'],'\n');
    fclose(fid);
    %while ~exist('MASTER0.F0016','file')
        system('MASTER0.bat')
   % end

    cd(oldfolder) % setting original directory
    
end


disp(' plot production profile for the final run')
N=100;

oldfolder=cd;
cd(oldfolder) % setting original directory
 %% Plot the Production profile of ensemble
disp('  start the plotting  ');

    for i=1:N %list of folders 
    
    f = 'MASTER';
    folder = strcat(f, sprintf('%.5d',i));
    
    cd(folder);
    A1 = importdata('MASTER0.RSM',' ',7);
  
    
    A1=A1.data;
    
    
     WOPR1=A1(:,3);
    
     WWPR1=A1(:,5);
     WBHP1=A1(:,6);
     
     Time=A1(:,1);

    WOPRA(:,i)=WOPR1;
    WWPRB(:,i)=WWPR1;
    WBHPC(:,i)=WBHP1;
    
   
    
    cd(oldfolder);
    end
   cd(oldfolder) % returning to original directory
 %Import true data
 True= importdata('Real.RSM',' ',7);
 
 
 True=True.data;

 
 TO1=True(:,6);
 TO2=True(:,8);
 TO3=True(:,9);
 
 
 %grey = [0.4,0.4,0.4]; 
 linecolor1 = colordg(4);
 
 
%% Plot for Well Bottom Hole Pressure
figure()
 plot(Time,WOPRA(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Q_o(STB/DAY)','FontName','Helvetica', 'Fontsize', 13);
  ylim([5000 25000])
title('Producer Oil production Rate','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');

hold on
plot(Time,TO1,'r','LineWidth',1)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([1500 1500], [5000 25000],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,sprintf('PRO-Oilrate_iter%d.fig',inelly))
close(figure)

figure()
 plot(Time,WWPRB(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('Q_w(STB/DAY)','FontName','Helvetica', 'Fontsize', 13);
ylim([1 200])
title('Producer Water production Rate','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TO2,'r','LineWidth',1)
b = get(gca,'Children');
set(gca,'yscale','log', 'FontName','Helvetica', 'Fontsize', 13)
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([1500 1500], [1 200],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,sprintf('PRO-WATER_iter%d.fig',inelly))
close(figure)

figure()
 plot(Time,WBHPC(:,1:N),'Color',linecolor1,'LineWidth',2)
xlabel('Time (days)','FontName','Helvetica', 'Fontsize', 13);
ylabel('BHP(Psia)','FontName','Helvetica', 'Fontsize', 13);
 ylim([1500 4000])
title('Injector BHP','FontName','Helvetica', 'Fontsize', 13)
a = get(gca,'Children');
hold on
plot(Time,TO3,'r','LineWidth',1)
b = get(gca,'Children');
 set(gca, 'FontName','Helvetica', 'Fontsize', 13)
set(gcf,'color','white')
line([1500 1500], [1500 4000],'Color','black','LineStyle','--')
h = [b;a];
legend(h,'True model','Realisations','location','northeast');
hold off
saveas(gcf,sprintf('Injector-WBHP_iter%d.fig',inelly))
close(figure)


for i=1:N
    EWOP1(i,:)=immse(WOPRA(:,i),TO1);
    EWOP2(i,:)=immse(WWPRB(:,i),TO2);
    EWOP3(i,:)=immse(WBHPC(:,i),TO3);
   
end
TOTALERROR=ones(N,1);
TOTALERROR=(EWOP1./std(TO1))+(EWOP2./std(TO2))+(EWOP3./std(TO3));
   
   
TOTALERROR=TOTALERROR./16;
jj=min(TOTALERROR);
index = TOTALERROR; 
bestnorm = find(index == min(index));

fprintf('The best Norm Realization for production data match is number %i with value %4.6f \n',bestnorm,jj);
decreasingseries=zeros(N,inelly+1);
decreasingseries(:,1:inelly)=decreasingnorm;
decreasingseries(:,inelly+1)=index;

reali=[1:N]';

 figure()
 bar(reali,index,'cyan');
 xlabel('Realizations', 'FontName','Helvetica', 'Fontsize', 13);
 ylabel('RMSE value', 'FontName','Helvetica', 'Fontsize', 13);
 title('Production data Cost function for Realizations','FontName','Helvetica', 'Fontsize', 13)
 set(gcf,'color', 'white');
 hold on
 scatter(reali,index,'black','filled');
  xlim([1,N]);
 xlabel('Realizations', 'FontName','Helvetica', 'Fontsize', 13)
 ylabel('RMSE value', 'FontName','Helvetica', 'Fontsize', 13)
  saveas(gcf,'RMS_final','fig')
close(figure)

 disp('  Final RMS computation executed  ');
disp( 'output the permeability and porosity history matched model for the last iteration')
file = fopen('sgsimfinal.out','w+'); %output the dictionary
for k=1:numel(mumyperm)                                                                       
fprintf(file,' %4.6f \n',mumyperm(k) );             
end

file2 = fopen('sgsimporofinal.out','w+'); %output the dictionary
for k=1:numel(mumyporo)                                                                       
fprintf(file2,' %4.6f \n',mumyporo(k) );             
end
 
 file4 = fopen('evolvingNorm.out','w+');
 for k=1:numel(decreasingseries)                                                                       
 fprintf(file4,' %4.4f \n',decreasingseries(k) );             
 end

%  disp('save the ensemble of pressure and saturation for all iterations')
%  save('PEn83.out','pressureensemble83','-ascii');
% save('SEn83.out','saturationensemble83','-ascii');
% save('PEn89.out','pressureensemble89','-ascii');
% save('SEn89.out','saturationensemble83','-ascii');
 
 bestnorm=double(bestnorm);
disp('1=yes')
disp('2=no' )
response=input('Do you want to plot the permeability map ');

disp( 'Well locaions consisting of producer well')

iProd = [10, 70]; %1 injector well
jProd = [10, 10]; % 1 producer well
%CMRmap=[0 0 0;.3 .15 .75;.6 .2 .50;1 .25 .15;.9 .5 0;.9 .9 .5;1 1 1];

if response==1
    disp( 'Pixel map needed')
    [bestnorm3,PlogK]=clementPlot(nx,ny,nz,iProd, jProd,mumyperm,rossmary,N,bestnorm);
    clementPlotporo(nx,ny,nz,iProd, jProd,mumyporo,rossmaryporo,N,bestnorm3);
%     xr=reshape(PlogK,nx*ny,Nz);
%     
% plottinglocations(xr, nx, ny,nz, 'Layer', iInj, jInj, iProd, jProd, min(xr), max(xr));
disp('  red is producer and black is injector')
     %run('clementPlot.m')
else
    disp (' pixel map not needed')
end

fprintf('Finished Iterations with the History matching method %d .\n', method);
if method==1
disp('The method used was standard EnKF impelemented with main_EnKF')
elseif method==2
disp('The method used was ESMDA with Localization')
elseif method==3
disp('The method used was ESMDA impelemented with main_DCT( discrete cosine transform method coupled with ESMDA)')
elseif method==4
disp('The method used was compressed sensing ESMDA impelemented with main_sparsity(compressed sensing)')
else
  disp('The method used was main_ESMDA+ DCT parametrisation on Electromagnetic data uncertain')  
end
disp('  The overall program has been executed and the history matched files saved in the folder  ');
toc