function [mumyperm,mumyporo]=main_EnKF(nx,ny,nz,N,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,iyobo,EMwater,SEn89,Sall,Pall);
% N - size of ensemble

sgsim=reshape(perm,nx*ny*nz,N);
sgsimporo=reshape(poro,nx*ny*nz,N);
Sall=reshape(Sall,nx*ny*nz,history,N);
Pall=reshape(Pall,nx*ny*nz,history,N);


Sim11=reshape(overallsim,3,history,N);

%History matching using ESMDA
 iss=iyobo;
 fprintf('Now assimilating timestep %d .\n', iss);

Sim1=Sim11(:,iss,:);
Sim1=reshape(Sim1,3,N);

Saturation=Sall(:,iss,:);
Saturation=reshape(Saturation,nx*ny*nz,N);


Pressure=Pall(:,iss,:);
Pressure=reshape(Pressure,nx*ny*nz,N);
f=observation(:,iss);
if iss~=16 
[DupdateK,Dupdateporo] = EnKF (sgsim,sgsimporo,f, N, Sim1,Saturation,Pressure);
else
  [DupdateK,Dupdateporo] = EnKF_Sensitivity (sgsim,sgsimporo,f, N, Sim1,Saturation,Pressure); 
end


 fprintf('Finished assimilating timestep %d \n', iss);

disp('recover the full permeability and porosity field')


[output,outputporo] = honour2(rossmary, rossmaryporo, N,Dupdateporo,DupdateK);

mumyperm=output;
mumyporo=outputporo;


 disp('  program executed  ');
end
 