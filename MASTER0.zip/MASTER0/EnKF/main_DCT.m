function [mumyperm,mumyporo]=main_DCT(nx,ny,nz,N,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha,Sall,Pall);

% N - size of ensemble

sgsim=reshape(perm,nx*ny*nz,N);
sgsimporo=reshape(poro,nx*ny*nz,N);
Sall=reshape(Sall,nx*ny*nz,history,N);
Pall=reshape(Pall,nx*ny*nz,history,N);

disp( 'reduce the permeability and porosity field')
clement2perm = mainDCTpetro(sgsim, N);
clement2poro = mainDCTporo(sgsimporo, N);
Sim11=reshape(overallsim,3,history,N);

%History matching using ESMDA
for i=1:history
 fprintf('Now assimilating timestep %d .\n', i);

Sim1=Sim11(:,i,:);
Sim1=reshape(Sim1,3,N);

Saturation=Sall(:,i,:);
Saturation=reshape(Saturation,nx*ny*nz,N);
clement2sat = mainDCTporo(Saturation, N);

Pressure=Pall(:,i,:);
Pressure=reshape(Pressure,nx*ny*nz,N);
clement2pres = mainDCTporo(Pressure, N);
f=observation(:,i);
[DupdateK,Dupdateporo] = ESMDA_DCT (clement2perm,clement2poro,f, N, Sim1,alpha,clement2sat,clement2pres);

clement2perm=DupdateK;
clement2poro=Dupdateporo;
 fprintf('Finished assimilating timestep %d \n', i);
end
disp('recover the full permeability and porosity field')

valuepermjoy=clement2perm;
for ii=1:N
    lf=reshape(valuepermjoy(:,ii),40,15,nz);
     for jj=1:4
         valueperm=lf(:,:,jj);
         big=zeros(nx,ny,nz);

        big(1:40,1:15,jj)=valueperm;
        kkperm=big(:,:,jj);
        rec = mirt_idctn(kkperm);
        rec=(abs(rec));
         usdf=reshape(rec,2268,1);
         young(:,jj)=usdf;
     end
      sdfbig=reshape(young,9072,1);
  clementperm(:,ii)=sdfbig;
end

DupdateK=exp(clementperm);

valuepermjoy=clement2poro;
for ii=1:N
    lf=reshape(valuepermjoy(:,ii),40,15,nz);
     for jj=1:4
         valueperm=lf(:,:,jj);
         big=zeros(nx,ny,nz);

        big(1:40,1:15,jj)=valueperm;
        kkperm=big(:,:,jj);
        rec = mirt_idctn(kkperm);
        rec=(abs(rec));
         usdf=reshape(rec,2268,1);
         young(:,jj)=usdf;
     end
      sdfbig=reshape(young,9072,1);
  clementporo(:,ii)=sdfbig;
end

Dupdateporo=(clementporo);



[output,outputporo] = honour2(rossmary, rossmaryporo, N,Dupdateporo,DupdateK);

mumyperm=output;
mumyporo=outputporo;


 disp('  program executed  ');
end
 