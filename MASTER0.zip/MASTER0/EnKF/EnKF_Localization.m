function [DupdateK,Dupdateporo] = EnKF_Localization (sgsim,sgsimporo,f, N, Sim1,alpha,c,Saturation,Pressure);
A=zeros(84,27,4);
for j=1:4
    A(10,10,j)=1;
    A(70,10,j)=1;
       
end
disp( 'calculate the euclidean distance function to the wells')
    lf=reshape(A,84,27,4);
   for j=1:4;
     sdf=lf(:,:,j);
  [usdf,IDX] = bwdist(sdf);
  usdf=reshape(usdf,2268,1);
  young(:,j)=usdf;
   
   end
   sdfbig=reshape(young,9072,1);
   sdfbig1=abs(sdfbig);
   z=sdfbig1;
   % the value of the range should be computed accurately.
   %c=range(z);
  
  
   c0OIL1=zeros(9072,1);
   disp( 'compute the gaspari-cohn coefficent')
  for i=1:9072;
 if (0<=z(i,:) || z(i,:)<=c)
  c0OIL1(i,:)=-0.25*(z(i,:)/c)^5+0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3-(5.0/3.0)*(z(i,:)/c)^2+1;
elseif z < 2*c
  c0OIL1(i,:)=(1.0/12.0)*(z(i,:)/c)^5-0.5*(z(i,:)/c)^4+0.625*(z(i,:)/c)^3+(5.0/3.0)*(z(i,:)/c)^2-5*(z(i,:)/c)+4-(2.0/3.0)*(c/z(i,:));
 elseif (c<=z(i,:) || z(i,:)<=2*c)
     c0OIL1(i,:)=-5*(z(i,:)/c)+4-0.667*(c/z(i,:));
 else
     c0OIL1(i,:)=0;
 end
  
  end
  
c0OIL1(c0OIL1<0)=0;
 [c0OIL1] = calc_loccoeffs(c, 'Gaspari_Cohn', z);  

 disp(' get the gaspari cohn for Cyd') 
 
    schur=c0OIL1;

Bsch = repmat(schur,1,N);
  
  yoboschur=ones(36291,N);
 
  yoboschur(1:9072,:)=Bsch;
  yoboschur(9073:18144,:)=Bsch;


sgsim=log(sgsim);
 sgsim = reshape(sgsim,9072,N);
sgsimporo = reshape(sgsimporo,9072,N);

disp(' determine the standard deviation for measurement pertubation')
stddoil=0.1*f(1,:);
stddwater=0.1*f(2,:);
stddpressure=0.1*f(3,:);


disp('  generate Gaussian noise for the observed measurments  ');

Error1=ones(3,N);
Error1(1,:)=normrnd(0,stddoil,1,N);
Error1(2,:)=normrnd(0,stddwater,1,N);
Error1(3,:)=normrnd(0,stddpressure,1,N);

Cd2 = (Error1*Error1')./(N-1);


for i=1:N
    Dj(:,i)=f+(Error1(:,i));
	
 end

disp('  generate the ensemble state matrix containing parameters and states  ');

overall=zeros(36291,N); 

overall(1:9072,1:N)=sgsim;
overall(9073:18144,1:N)=sgsimporo;
overall(18145:27216,1:N)=Saturation;
overall(27217:36288,1:N)=Pressure;
overall(36289:36291,1:N)=Sim1;
Y=overall; %State variable,it is important we include simulated measurements in the ensemble state variable

M = mean(Sim1,2);
% Mean of the ensemble state
M2=mean(overall,2);
%M=M'
% Get the ensemble states pertubations
for j=1:N
    S(:,j)=Sim1(:,j)-M;
end
for j=1:N
    yprime(:,j)=overall(:,j)-M2;
end


disp('  update the new ensemble  ');
Cyd=(yprime*S')./((N-1));
Cdd=(S*S')./((N-1));


% [Usig,Sig,Vsig] = svd(Cdd+(alpha.*Cd2));
% xsmall = diag(Sig);
% Bsig = cumsum(xsmall);
% valuesig=Bsig(end);
% valuesig=valuesig*0.9999;
% indices = find(cumsum(xsmall) >= valuesig );
% toluse=xsmall(indices,:);
% tol=toluse(1,:);

disp('  update the new ensemble  ');
Ynew=Y+yoboschur.*((Cyd*pinv((Cdd+(alpha.*Cd2))))*(Dj-Sim1));
%Ynew=Y+(Cyd/(Cdd+(alpha.*Cd)))*(Dj-Sim1);



disp( 'extract the active permeability field ')
value1=Ynew(1:9072,1:N);

DupdateK=exp(value1);
Dupdateporo=Ynew(9073:18144,1:N);
end