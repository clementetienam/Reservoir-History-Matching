function [mumyperm,mumyporo]=main_ESMDA(nx,ny,nz,N,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha,Sall,Pall);
% N - size of ensemble

sgsim=reshape(perm,nx*ny*nz,N);
sgsimporo=reshape(poro,nx*ny*nz,N);
Sall=reshape(Sall,nx*ny*nz,history,N);
Pall=reshape(Pall,nx*ny*nz,history,N);


Sim11=reshape(overallsim,3,history,N);

%History matching using ESMDA
for i=1:history
 fprintf('Now assimilating timestep %d .\n', i);

Sim1=Sim11(:,i,:);
Sim1=reshape(Sim1,3,N);

Saturation=Sall(:,i,:);
Saturation=reshape(Saturation,nx*ny*nz,N);


Pressure=Pall(:,i,:);
Pressure=reshape(Pressure,nx*ny*nz,N);
f=observation(:,i);
[DupdateK,Dupdateporo] = ESMDA (sgsim,sgsimporo,f, N, Sim1,alpha,Saturation,Pressure);

sgsim=DupdateK;
sgsimporo=Dupdateporo;
 fprintf('Finished assimilating timestep %d \n', i);
end
disp('recover the full permeability and porosity field')


[output,outputporo] = honour2(rossmary, rossmaryporo, N,Dupdateporo,DupdateK);

mumyperm=output;
mumyporo=outputporo;


 disp('  program executed  ');
end
 