function [DupdateK,Dupdateporo] = ESMDA_GA2 (sgsim,sgsimporo,f, N, Sim1);
sgsim=log(sgsim);
 sgsim = reshape(sgsim,9072,N);
sgsimporo = reshape(sgsimporo,9072,N);

Y=sgsim; 
Yporo=sgsimporo;

disp(' determine the standard deviation for measurement pertubation')
stddoil=0.1*f(1,:);
stddwater=0.1*f(2,:);
stddpressure=0.1*f(3,:);

disp('  generate Gaussian noise for the observed measurments  ');

Error1=ones(3,N);
Error1(1,:)=normrnd(0,stddoil,1,N);
Error1(2,:)=normrnd(0,stddwater,1,N);
Error1(3,:)=normrnd(0,stddpressure,1,N);

for i=1:N
    Dj(:,i)=f+(Error1(:,i));
	
 end

disp('get the fitness function')
for i=1:N
    truef=Dj(:,i);
    simulated=Sim1(:,i);
    Eoil(i,:)=immse(simulated(1,:),truef(1,:));
    Ewater(i,:)=immse(simulated(2,:),truef(2,:));
    Epressure(i,:)=immse(simulated(3,:),truef(3,:));
   
end
TOTALERROR=ones(N,1);
TOTALERROR=((Eoil)./stddoil)+((Ewater)./stddwater)+((Epressure)./stddpressure);
FitnV=TOTALERROR;
%FitnV=FitnV./16;
disp('  update the new ensemble  ');

Yperm=Y';

    oldchrom=Yperm;
    
    [ popNewSub, elite, fvalOfElite ] = selectchromo( oldchrom, FitnV );
    [ popNewSub ] = crossover(popNewSub,1);
    [ popNewSub ] = mutate( popNewSub, 0.001);
   chromosomeRandom = datasample(elite,9072,'replace',false);
    %chromosomeRandom = randi([0,1], [1,9072]);
    pop = [popNewSub;chromosomeRandom;elite];   
%newchromm=mutrandbin(newchromc,vlub,mutationrate); %new population after mutation
oldchrom=pop;
Yperm=(oldchrom);


Yporo=Yporo';
disp('Finished for permeability')

    oldchromp=Yporo;
  [ popNewSub, elite, fvalOfElite ] = selectchromo( oldchromp, FitnV );
    [ popNewSub ] = crossover(popNewSub,1);
    [ popNewSub ] = mutate( popNewSub, 0.001);
   chromosomeRandom = datasample(elite,9072,'replace',false);
    %chromosomeRandom = randi([0,1], [1,9072]);
    pop = [popNewSub;chromosomeRandom;elite];   

%newchromm=mutrandbin(newchromc,vlub,mutationrate); %new population after mutation
oldchromp=pop;
Yporo=abs(oldchromp);
disp('Finished for porosity')
value1=Yperm;
value1=value1';
DupdateK=exp(value1);

Yporo=Yporo';
Dupdateporo=Yporo;
end