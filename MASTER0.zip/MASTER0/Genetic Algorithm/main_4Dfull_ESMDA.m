function [mumyperm,mumyporo]=main_4Dfull_ESMDA(nx,ny,nz,N,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha,trueimpedance83,trueimpedance89,IEn83,IEn89,Sall,Pall);
% N - size of ensemble
%Clement Etienam PhD Petroleum Engineering 2015:2018
% pertubedtruewater=repmat(EMwater,1,N);

sgsim=reshape(perm,nx*ny*nz,N);
sgsimporo=reshape(poro,nx*ny*nz,N);
Sall=reshape(Sall,nx*ny*nz,history,N);
Pall=reshape(Pall,nx*ny*nz,history,N);
for i=1:N
    noiseI(:,i)=normrnd(0,1,[2268,1]); % white noise (mean zero & variance one) 
end

for i=1:N
    noiserI(:,i)=normrnd(0,0.04,[9072,1]); % white noise (mean zero & variance one) 
end
trueimpedance83=reshape(trueimpedance83,nx*ny,N);
trueimpedance89=reshape(trueimpedance89,nx*ny,N);

trueimpedance83=(trueimpedance83+ noiseI).*0.3048;
trueimpedance89=(trueimpedance89+ noiseI).*0.3048;



Imp83true = trueimpedance83;
Imp89true = trueimpedance89;
deltaimptrue=(Imp89true-Imp83true)./1000;

IEn83=reshape(IEn83,nx*ny,N).*0.3048;
IEn89=reshape(IEn89,nx*ny,N).*0.3048;

Imp83sim = IEn83;
Imp89sim = IEn89;

deltaimpsim=(Imp89sim-Imp83sim)./1000;
Sim11=reshape(overallsim,3,history,N);
disp( 'assimilate 3d seismic at first time step')
% Sim1=Sim11(:,1,:);
% Sim1=reshape(Sim1,3,N);
% 
% f=observation(:,1);
% [DupdateK,Dupdateporo] = ESMDA_Impedance (sgsim,sgsimporo,f, N, Sim1,alpha,Imp83true,Imp83sim);
% 
% sgsim=DupdateK;
% sgsimporo=Dupdateporo;


%History matching using ESMDA
for i=1:15
 fprintf('Now assimilating timestep %d .\n', i);

Sim1=Sim11(:,i,:);
Sim1=reshape(Sim1,3,N);


Saturation=Sall(:,i,:);
Saturation=reshape(Saturation,nx*ny*nz,N);


Pressure=Pall(:,i,:);
Pressure=reshape(Pressure,nx*ny*nz,N);
f=observation(:,i);
[DupdateK,Dupdateporo] = ESMDA (sgsim,sgsimporo,f, N, Sim1,alpha,Saturation,Pressure);

sgsim=DupdateK;
sgsimporo=Dupdateporo;
 fprintf('Finished assimilating timestep %d \n', i);
end

disp( 'assimilate 3d seismic and water saturation dsitribution at last time step')
Sim1=Sim11(:,16,:);
Sim1=reshape(Sim1,3,N);
Saturation=Sall(:,16,:);
Saturation=reshape(Saturation,nx*ny*nz,N);


Pressure=Pall(:,16,:);
Pressure=reshape(Pressure,nx*ny*nz,N);
f=observation(:,16);
[DupdateK,Dupdateporo] = ESMDA_full (sgsim,sgsimporo,f, N, Sim1,alpha,deltaimpsim,deltaimptrue,Saturation,Pressure);


disp('recover the full permeability and porosity field')


[output,outputporo] = honour2(rossmary, rossmaryporo, N,Dupdateporo,DupdateK);

mumyperm=output;
mumyporo=outputporo;


 disp('  program executed  ');
end
 