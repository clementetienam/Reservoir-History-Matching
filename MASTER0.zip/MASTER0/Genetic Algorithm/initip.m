function Chrom = initip(Nind, VLUB);

% Create initial population

   % First, extend the bound array
   ValExtend = 0.4999;
   VLUBIntern = VLUB + repmat([-ValExtend; ValExtend], [1, size(VLUB,2)]);
   
   % Create real population and round the values
   Chrom = round(initrp(Nind, VLUBIntern));


% End of function