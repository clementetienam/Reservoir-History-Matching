%  Author:    Hartmut Pohlheim
%  History:   28.03.95     file created

function NewChrom = recsp(OldChrom, RecRate);

if nargin < 2, RecRate = NaN; end

% call low level function with appropriate parameters
   NewChrom = recmp(OldChrom, RecRate, 1, 0);


% End of function