function [DupdateK,Dupdateporo,pc,pm] = ESMDA_GA (sgsim,sgsimporo,f, N, Sim1,pc,pm);
sgsim=log(sgsim);
 sgsim = reshape(sgsim,9072,N);
sgsimporo = reshape(sgsimporo,9072,N);

Y=sgsim; 
Yporo=sgsimporo;

disp(' determine the standard deviation for measurement pertubation')
stddoil=0.1*f(1,:);
stddwater=0.1*f(2,:);
stddpressure=0.1*f(3,:);

disp('  generate Gaussian noise for the observed measurments  ');

Error1=ones(3,N);
Error1(1,:)=normrnd(0,stddoil,1,N);
Error1(2,:)=normrnd(0,stddwater,1,N);
Error1(3,:)=normrnd(0,stddpressure,1,N);

for i=1:N
    Dj(:,i)=f+(Error1(:,i));
	
 end

disp('get the fitness function')
for i=1:N
    truef=Dj(:,i);
    simulated=Sim1(:,i);
    Eoil(i,:)=immse(simulated(1,:),truef(1,:));
    Ewater(i,:)=immse(simulated(2,:),truef(2,:));
    Epressure(i,:)=immse(simulated(3,:),truef(3,:));
   
end
TOTALERROR=ones(N,1);
TOTALERROR=((Eoil)./stddoil)+((Ewater)./stddwater)+((Epressure)./stddpressure);
FitnV=TOTALERROR;
FitnV=FitnV./16;
disp('  update the new ensemble  ');

Yperm=Y';

    oldchrom=Yperm;
%apply roulette wheel selection
Nsel=100;
newchrix=selrws(FitnV, Nsel);
newchrom=oldchrom(newchrix,:);
%Perform Crossover
crossoverrate=pc;
newchromc=recsp(newchrom,crossoverrate); %new population after crossover
%Perform mutation
vlub=2:4;
mutationrate=pm;
newchromm = mutate( newchromc, mutationrate);
%newchromm=mutrandbin(newchromc,vlub,mutationrate); %new population after mutation
oldchrom=newchromm;
Yperm=oldchrom;


Yporo=Yporo';
disp('Finished for permeability')

    oldchromp=Yporo;
%apply roulette wheel selection
Nsel=100;
newchrixp=selrws(FitnV, Nsel);
newchromp=oldchromp(newchrixp,:);
%Perform Crossover
crossoverrate=pc;
newchromcp=recsp(newchromp,crossoverrate); %new population after crossover
%Perform mutation
vlub=2:4;
mutationrate=pm;
newchrommp = mutate( newchromcp, mutationrate);
%newchromm=mutrandbin(newchromc,vlub,mutationrate); %new population after mutation
oldchromp=newchrommp;
Yporo=oldchromp;
index=FitnV;
fmean=mean(index);
fmax=max(index);
fmin=min(index);
n2=0.05;
landd=((fmax-fmin)/fmean)^n2;
landpc=(fmean^n2)/(((fmax-fmin)^n2)+(fmean.^n2));
disp('Calculate new pc and pm')
pc=pc*(1+0.02*(landpc));
az=(((fmax-fmin)^n2)-(fmean^n2))/(landd*(((fmax-fmin)^n2))+fmean^n2);
pm=pm*(1+0.02*(az));


disp( 'extract the active permeability field ')
value1=abs(Yperm);
value1=value1';
DupdateK=exp(value1);

Yporo=abs(Yporo');
Dupdateporo=Yporo;
end