function Chrom = initrp(Nind, VLUB);

% Check parameter consistency
   if nargin < 2, error('parameter VLUB missing'); end

   [NindRow, NindCol] = size(Nind);
   if any([NindRow, NindCol] ~= 1), Nind = Nind(1); warning('Number of individuals to create must be a scalar!'); end

   [VLUBRow, Nvar] = size(VLUB);
   if VLUBRow < 2, error('VLUB must be a matrix with 2 rows!'); end
   if VLUBRow > 2, VLUB = VLUB([1,2],:); end

   if any(VLUB(1,:) > VLUB(2,:)),
      error('At least one lower bound is greater than the corresponding upper bound!');
   end

% Create initial population
   % Compute Matrix with Range of variables and Matrix with Lower value
   Range = repmat((VLUB(2,:) - VLUB(1,:)), [Nind 1]);
   Lower = repmat(VLUB(1,:), [Nind 1]);

   % Each row contains one individual, the values of each variable uniformly
   % distributed between lower and upper bound (given by VLUB)
   Chrom = rand(Nind, Nvar) .* Range + Lower;


% End of function