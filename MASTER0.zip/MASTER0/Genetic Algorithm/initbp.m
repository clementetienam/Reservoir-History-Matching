function [Chrom] = initbp(Nind, VarLength)

% Check input parameter consistency
   if length(Nind) > 1, Nind = Nind(1); warning('Number of individuals to create (Nind) must be a scalar!'); end
   if min(size(VarLength)) > 1,
      if size(VarLength,1) > size(VarLength,2), VarLength = VarLength(:,1); else VarLength = VarLength(1,:); end
      warning('Length of individuals (VarLength) must be a scalar or vector (and not a matrix!)');
   end


% Create a structure of random chromosomes in row wise order, dimensions
% Nind by sum of VarLength.
   Chrom = rand(Nind, sum(VarLength)) < 0.5;


% End of function