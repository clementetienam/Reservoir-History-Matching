function [mumyperm,mumyporo]=main_ESMDA_GA2(nx,ny,nz,N,rossmary,rossmaryporo,perm,poro,index);
% N - size of ensemble
disp(' History matching using genetic algorithm type 2')
sgsim=reshape(perm,nx*ny*nz,N);
sgsimporo=reshape(poro,nx*ny*nz,N);

%i=2;
%History matching using Genetic algorithm
sgsim=log(sgsim);
 sgsim = reshape(sgsim,9072,N);
sgsimporo = reshape(sgsimporo,9072,N);

Y=sgsim; 
Yporo=sgsimporo;

FitnV=index;

disp('  update the new ensemble  ');

Yperm=Y';

    oldchrom=Yperm;
%apply roulette wheel selection
Nsel=100;
newchrix=selrws(FitnV, Nsel);
newchrom=oldchrom(newchrix,:);
%Perform Crossover
crossoverrate=0.5;
newchromc=recsp(newchrom,crossoverrate); %new population after crossover
%Perform mutation
mutationrate=0.001;
newchromm = mutate( newchromc, mutationrate);
%newchromm=mutrandbin(newchromc,vlub,mutationrate); %new population after mutation
oldchrom=newchromm;
Yperm=oldchrom;


Yporo=Yporo';
disp('Finished for permeability')

    oldchromp=Yporo;
%apply roulette wheel selection
Nsel=100;
newchrixp=selrws(FitnV, Nsel);
newchromp=oldchromp(newchrixp,:);
%Perform Crossover
crossoverrate=0.5;
newchromcp=recsp(newchromp,crossoverrate); %new population after crossover
%Perform mutation

mutationrate=0.001;
newchrommp = mutate( newchromcp, mutationrate);
%newchromm=mutrandbin(newchromc,vlub,mutationrate); %new population after mutation
oldchromp=newchrommp;
Yporo=oldchromp;

disp( 'extract the active permeability field ')
value1=abs(Yperm);
value1=value1';
DupdateK=exp(value1);

Yporo=abs(Yporo');
Dupdateporo=Yporo;

[output,outputporo] = honour2(rossmary, rossmaryporo, N,Dupdateporo,DupdateK);

mumyperm=output;
mumyporo=outputporo;


 disp('  program executed  ');
end
 