function [mumyperm,mumyporo]=GAmatch(nx,ny,nz,N,rossmary,rossmaryporo,perm,poro,index);
% N - size of ensemble
disp(' History matching using genetic algorithm')
sgsim=reshape(perm,nx*ny*nz,N);
sgsimporo=reshape(poro,nx*ny*nz,N);

 sgsim=log(sgsim);
 sgsim = reshape(sgsim,9072,N);
sgsimporo = reshape(sgsimporo,9072,N);

Y=sgsim; 
Yporo=sgsimporo;

FitnV=index;

disp('  update the new ensemble  ');

Yperm=Y';
for mhh=1:2
    if mhh==1
npar=nx*ny*nz; % # of optimization variables
Nt=npar; % # of columns in population matrix
popsize=N; % set population size
mutrate=.05; % set mutation rate
selection=0.5; % fraction of population kept
keep=floor(selection*popsize); % #population members that survive
M=ceil((popsize-keep)/2); % number of matings
odds=1;
for ii=2:keep
odds=[odds ii*ones(1,ii)];
end
Nodds=length(odds);
odds=keep-odds+1; % odds determines probabilities for being parents
% Create the initial population

pop=Yperm;
cost=index; 
[cost,ind]=sort(cost); % min cost in element 1
pop=pop(ind,:); % sort population with lowest cost first
minc(1)=min(cost); % minc contains min of population
meanc(1)=mean(cost); % meanc contains mean of population
% Pair and mate
pick1=ceil(Nodds*rand(1,M)); % mate #1
pick2=ceil(Nodds*rand(1,M)); % mate #2
% ma and pa contain the indices of the parents
ma=odds(pick1);
pa=odds(pick2);
% Performs mating
for ic=1:M
mate1=pop(ma(ic),:);
mate2=pop(pa(ic),:);
indx=2*(ic-1)+1; % odd numbers starting at 1
xp=ceil(rand*npar); % random value between 1 and N
temp=mate1;
x0=xp;
while mate1(xp)~=temp(x0)
mate1(xp)=mate2(xp);
mate2(xp)=temp(xp);
xs=find(temp==mate1(xp));
xp=xs;
end
pop(keep+indx,:)=mate1;
pop(keep+indx+1,:)=mate2;
end
% Mutate the population
nmut=ceil(popsize*npar*mutrate);
for ic = 1:nmut
row1=ceil(rand*(popsize-1))+1;
col1=ceil(rand*npar);
col2=ceil(rand*npar);
temp=pop(row1,col1);
pop(row1,col1)=pop(row1,col2);
pop(row1,col2)=temp;
im(ic)=row1;
end
Yperm=pop;
disp('Finished for permeability')
    end
 if mhh==2
Yporo=Yporo';
npar=nx*ny*nz; % # of optimization variables
Nt=npar; % # of columns in population matrix
popsize=N; % set population size
mutrate=.05; % set mutation rate
selection=0.5; % fraction of population kept
keep=floor(selection*popsize); % #population members that survive
M=ceil((popsize-keep)/2); % number of matings
odds=1;
for ii=2:keep
odds=[odds ii*ones(1,ii)];
end
Nodds=length(odds);
odds=keep-odds+1; % odds determines probabilities for being parents
% Create the initial population
pop=Yporo;
cost=index; 
[cost,ind]=sort(cost); % min cost in element 1
pop=pop(ind,:); % sort population with lowest cost first
minc(1)=min(cost); % minc contains min of population
meanc(1)=mean(cost); % meanc contains mean of population
% Pair and mate
pick1=ceil(Nodds*rand(1,M)); % mate #1
pick2=ceil(Nodds*rand(1,M)); % mate #2
% ma and pa contain the indices of the parents
ma=odds(pick1);
pa=odds(pick2);
% Performs mating
for ic=1:M
mate1=pop(ma(ic),:);
mate2=pop(pa(ic),:);
indx=2*(ic-1)+1; % odd numbers starting at 1
xp=ceil(rand*npar); % random value between 1 and N
temp=mate1;
x0=xp;
while mate1(xp)~=temp(x0)
mate1(xp)=mate2(xp);
mate2(xp)=temp(xp);
xs=find(temp==mate1(xp));
xp=xs;
end
pop(keep+indx,:)=mate1;
pop(keep+indx+1,:)=mate2;
end
% Mutate the population
nmut=ceil(popsize*npar*mutrate);
for ic = 1:nmut
row1=ceil(rand*(popsize-1))+1;
col1=ceil(rand*npar);
col2=ceil(rand*npar);
temp=pop(row1,col1);
pop(row1,col1)=pop(row1,col2);
pop(row1,col2)=temp;
im(ic)=row1;
end
Yporo=pop;
    end
end
disp( 'extract the active permeability field ')
value1=abs(Yperm);
value1=value1';
DupdateK=exp(value1);

Yporo=abs(Yporo');
Dupdateporo=Yporo;

[output,outputporo] = honour2(rossmary, rossmaryporo, N,Dupdateporo,DupdateK);
mumyperm=output;
mumyporo=outputporo;
 disp('  program executed  ');

end
 