function [ popNewSub, elite, fvalOfElite ] = selectchromo( popPrev, fvals )
%SELECTCHROMO Select, choose sub new population and elite
% output:
% popNewSub: the new sub population (size = size-2)
% elite: the elite chromosome of previous population
% input:
% popPrev: the previous population
% fvals: the function values of previous population
fitness = fvals;
popSize = size(popPrev,1);
[fitnessMin, indexMin] = min(fitness);
[fitnessMax, indexMax] = max(fitness);
elite = popPrev(indexMax,:); % the min-fval aka the best individial
fvalOfElite = fvals(indexMax); % the function value on elite
listTemp = [1:popSize];
listTemp(indexMin) = 0;
listTemp(indexMax) = 0;
listTemp = nonzeros(listTemp);
popTemp = popPrev(listTemp,:);
fitnessTemp = fitness(listTemp,:);
popSizeToBeRenew = popSize - 2;
probAdded = cumsum(fitnessTemp / sum(fitnessTemp));
chromosomeSelected = sum(probAdded*ones(1,popSizeToBeRenew)<ones(popSizeToBeRenew,1)*rand(1,popSizeToBeRenew))+1;
popNewSub = popTemp(chromosomeSelected,:);
end