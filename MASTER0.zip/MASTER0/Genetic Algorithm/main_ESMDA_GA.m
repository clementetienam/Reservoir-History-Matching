function [mumyperm,mumyporo]=main_ESMDA_GA(nx,ny,nz,N,observation,overallsim,rossmary,rossmaryporo,perm,poro,history,alpha,geneticindex);
% N - size of ensemble
disp(' History matching using genetic algorithm')
sgsim=reshape(perm,nx*ny*nz,N);
sgsimporo=reshape(poro,nx*ny*nz,N);

Sim11=reshape(overallsim,3,history,N);
%i=2;
%History matching using Genetic algorithm
pc=0.9;
pm=0.001;
for i=1:history
 fprintf('Now assimilating timestep %d .\n', i);

Sim1=Sim11(:,i,:);
Sim1=reshape(Sim1,3,N);

f=observation(:,i);
[DupdateK,Dupdateporo,pc,pm] = ESMDA_GA (sgsim,sgsimporo,f, N, Sim1,pc,pm);
%[DupdateK,Dupdateporo] = ESMDA_GA2 (sgsim,sgsimporo,f, N, Sim1);
sgsim=DupdateK;
sgsimporo=Dupdateporo;
 fprintf('Finished assimilating timestep %d \n', i);
end

[output,outputporo] = honour2(rossmary, rossmaryporo, N,Dupdateporo,DupdateK);

mumyperm=output;
mumyporo=outputporo;


 disp('  program executed  ');
end
 