function NewChromIx = selrws(FitnV, Nsel, Dummy);

% Identify the population size (Nind)
   [Nind,ans] = size(FitnV);

% Perform selection (roulette wheel selection)
% (often called Stochastic Sampling with Replacement)
   if Nind == 1,
      NewChromIx = repmat(FitnV, [Nsel, 1]);
   else
      CumFitn  = cumsum(FitnV);
      Trials = CumFitn(Nind) .* rand(1, Nsel);
      MatFitn   = repmat(CumFitn, [1, Nsel]);
      MatTrials = repmat(Trials, [Nind, 1]);
      NewChromIx = sum(MatTrials >= MatFitn)+1;
      NewChromIx = NewChromIx(:);
   end

% Shuffle selected values
   [ans, shuf] = sort(rand(Nsel, 1));
   NewChromIx = NewChromIx(shuf);


% End of function