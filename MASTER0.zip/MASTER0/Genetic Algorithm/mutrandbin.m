% Author:   Hartmut Pohlheim
% History:  14.06.99    file created


function NewChrom = mutrandbin(Chrom, VLUB, MutRate)

% Check input parameters
if nargin < 3, MutRate = NaN; end

% call low level function with appropriate parameters
   VarFormat = 1;
   NewChrom = mutrand(Chrom, VLUB, MutRate, VarFormat);


% End of function