function Chrom = initpp(Nind, VarLength)

% Check input parameter consistency
   if length(Nind) > 1, Nind = Nind(1); warning('Number of individuals to create (Nind) must be a scalar!'); end
   if length(VarLength) > 1,
      % If VLUB is provided in VarLength
      if size(VarLength, 1) >= 2, VarLength = size(VarLength, 2);
      % If a vector was provided, use just the first element
      else VarLength = VarLength(1);
           warning('Length of individuals to create (VarLength) must be a scalar (or use VLUB)!');
      end
   end

% Create the random permutations
   [dummy, Chrom] = sort(rand(VarLength, Nind));
   Chrom = Chrom';


% End of function