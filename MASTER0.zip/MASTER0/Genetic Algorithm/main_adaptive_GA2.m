function [mumyperm,mumyporo,pc,pm]=main_adaptive_GA2(pc,pm,nx,ny,nz,N,rossmary,rossmaryporo,perm,poro,index);
% N - size of ensemble
disp(' History matching using genetic algorithm type 2')
sgsim=reshape(perm,nx*ny*nz,N);
sgsimporo=reshape(poro,nx*ny*nz,N);

%i=2;
%History matching using Genetic algorithm
sgsim=log(sgsim);
 sgsim = reshape(sgsim,9072,N);
sgsimporo = reshape(sgsimporo,9072,N);

Y=sgsim; 
Yporo=sgsimporo;

FitnV=index;

disp('  update the new ensemble  ');

Yperm=Y';

    oldchrom=Yperm;
%apply roulette wheel selection
Nsel=100;
newchrix=selrws(FitnV, Nsel);
newchrom=oldchrom(newchrix,:);
%Perform Crossover
crossoverrate=pc;
newchromc=recsp(newchrom,crossoverrate); %new population after crossover
%Perform mutation
mutationrate=pm;
newchromm = mutate( newchromc, mutationrate);
%newchromm=mutrandbin(newchromc,vlub,mutationrate); %new population after mutation
oldchrom=newchromm;
Yperm=oldchrom;


Yporo=Yporo';
disp('Finished for permeability')

    oldchromp=Yporo;
%apply roulette wheel selection
Nsel=100;
newchrixp=selrws(FitnV, Nsel);
newchromp=oldchromp(newchrixp,:);
%Perform Crossover
crossoverrate=pc;
newchromcp=recsp(newchromp,crossoverrate); %new population after crossover
%Perform mutation

mutationrate=pm;
newchrommp = mutate( newchromcp, mutationrate);
%newchromm=mutrandbin(newchromc,vlub,mutationrate); %new population after mutation
oldchromp=newchrommp;
Yporo=oldchromp;


%%
fmean=mean(index);
fmax=max(index);
fmin=min(index);
n2=0.05;
landd=((fmax-fmin)/fmean)^n2;
landpc=(fmean^n2)/(((fmax-fmin)^n2)+(fmean.^n2));
disp('Calculate new pc and pm')
pc=pc*(1+0.02*(landpc));
az=(((fmax-fmin)^n2)-(fmean^n2))/(landd*(((fmax-fmin)^n2))+fmean^n2);
pm=pm*(1+0.02*(az));
%%
disp( 'extract the active permeability field ')
value1=abs(Yperm);
value1=value1';
DupdateK=exp(value1);

Yporo=abs(Yporo');
Dupdateporo=Yporo;

[output,outputporo] = honour2(rossmary, rossmaryporo, N,Dupdateporo,DupdateK);

mumyperm=output;
mumyporo=outputporo;


 disp('  program executed  ');
end
 