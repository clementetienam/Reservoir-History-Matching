function [DupdateK,Dupdateporo] = ESMDA (sgsim,sgsimporo,f, N, Sim1,alpha,Saturation,Pressure);;

sgsim=log(sgsim);
 sgsim = reshape(sgsim,9072,N);
sgsimporo = reshape(sgsimporo,9072,N);

disp(' determine the standard deviation for measurement pertubation')
stddoil=0.1*f(1,:);
stddwater=0.1*f(2,:);
stddpressure=0.1*f(3,:);


disp('  generate Gaussian noise for the observed measurments  ');

Error1=ones(3,N);
Error1(1,:)=normrnd(0,stddoil,1,N);
Error1(2,:)=normrnd(0,stddwater,1,N);
Error1(3,:)=normrnd(0,stddpressure,1,N);

Cd2 = (Error1*Error1')./(N-1);


for i=1:N
    Dj(:,i)=f+(Error1(:,i));
	
 end

disp('  generate the ensemble state matrix containing parameters and states  ');

overall=zeros(36291,N); 

overall(1:9072,1:N)=sgsim;
overall(9073:18144,1:N)=sgsimporo;
overall(18145:27216,1:N)=Saturation;
overall(27217:36288,1:N)=Pressure;
overall(36289:36291,1:N)=Sim1;
Y=overall; %State variable,it is important we include simulated measurements in the ensemble state variable

M = mean(Sim1,2);
% Mean of the ensemble state
M2=mean(overall,2);
%M=M'
% Get the ensemble states pertubations
for j=1:N
    S(:,j)=Sim1(:,j)-M;
end
for j=1:N
    yprime(:,j)=overall(:,j)-M2;
end


disp('  update the new ensemble  ');
Cyd=(yprime*S')./((N-1));
Cdd=(S*S')./((N-1));


% [Usig,Sig,Vsig] = svd(Cdd+(alpha.*Cd2));
% xsmall = diag(Sig);
% Bsig = cumsum(xsmall);
% valuesig=Bsig(end);
% valuesig=valuesig*0.9999;
% indices = find(cumsum(xsmall) >= valuesig );
% toluse=xsmall(indices,:);
% tol=toluse(1,:);

disp('  update the new ensemble  ');
Ynew=Y+(Cyd*pinv((Cdd+(alpha.*Cd2))))*(Dj-Sim1);
%Ynew=Y+(Cyd/(Cdd+(alpha.*Cd)))*(Dj-Sim1);



disp( 'extract the active permeability field ')
value1=Ynew(1:9072,1:N);

DupdateK=exp(value1);
Dupdateporo=Ynew(9073:18144,1:N);
end